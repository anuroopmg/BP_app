package com.h6ah4i.android.widget.verticalseekbar;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import happy.hacking.iv;

public class VerticalSeekBarWrapper extends FrameLayout {
    public VerticalSeekBarWrapper(Context context) {
        this(context, null, 0);
    }

    public VerticalSeekBarWrapper(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VerticalSeekBarWrapper(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        if (m639a()) {
            VerticalSeekBar childSeekBar = getChildSeekBar();
            if (childSeekBar != null) {
                childSeekBar.measure(MeasureSpec.makeMeasureSpec(i2, 1073741824), MeasureSpec.makeMeasureSpec(i, Integer.MIN_VALUE));
            }
            m640a(i, i2);
        } else {
            VerticalSeekBar childSeekBar2 = getChildSeekBar();
            if (childSeekBar2 != null) {
                LayoutParams layoutParams = (LayoutParams) childSeekBar2.getLayoutParams();
                layoutParams.width = -2;
                layoutParams.height = i2;
                childSeekBar2.setLayoutParams(layoutParams);
                childSeekBar2.measure(0, 0);
                int measuredWidth = childSeekBar2.getMeasuredWidth();
                childSeekBar2.measure(MeasureSpec.makeMeasureSpec(i, Integer.MIN_VALUE), MeasureSpec.makeMeasureSpec(i2, 1073741824));
                layoutParams.gravity = 51;
                layoutParams.leftMargin = (i - measuredWidth) / 2;
                childSeekBar2.setLayoutParams(layoutParams);
            }
        }
        super.onSizeChanged(i, i2, i3, i4);
    }

    protected void onMeasure(int i, int i2) {
        VerticalSeekBar childSeekBar = getChildSeekBar();
        int mode = MeasureSpec.getMode(i);
        if (childSeekBar == null || mode == 1073741824) {
            super.onMeasure(i, i2);
            return;
        }
        int measuredWidth;
        if (m639a()) {
            childSeekBar.measure(i2, i);
            mode = childSeekBar.getMeasuredHeight();
            measuredWidth = childSeekBar.getMeasuredWidth();
        } else {
            childSeekBar.measure(i, i2);
            mode = childSeekBar.getMeasuredWidth();
            measuredWidth = childSeekBar.getMeasuredHeight();
        }
        setMeasuredDimension(iv.m5900a(mode, i, 0), iv.m5900a(measuredWidth, i2, 0));
    }

    final void m640a(int i, int i2) {
        View childSeekBar = getChildSeekBar();
        if (childSeekBar != null) {
            int rotationAngle = childSeekBar.getRotationAngle();
            ViewGroup.LayoutParams layoutParams = childSeekBar.getLayoutParams();
            layoutParams.width = i2;
            layoutParams.height = -2;
            childSeekBar.setLayoutParams(layoutParams);
            if (rotationAngle == 90) {
                rotationAngle = iv.m5939p(childSeekBar);
                iv.m5923d(childSeekBar, 90.0f);
                iv.m5903a(childSeekBar, (float) ((-(i2 - i)) / 2));
                iv.m5915b(childSeekBar, (float) ((i2 / 2) - rotationAngle));
            } else if (rotationAngle == 270) {
                rotationAngle = iv.m5938o(childSeekBar);
                iv.m5923d(childSeekBar, -90.0f);
                iv.m5903a(childSeekBar, (float) ((-(i2 - i)) / 2));
                iv.m5915b(childSeekBar, (float) ((i2 / 2) - rotationAngle));
            }
        }
    }

    private VerticalSeekBar getChildSeekBar() {
        View childAt;
        if (getChildCount() > 0) {
            childAt = getChildAt(0);
        } else {
            childAt = null;
        }
        if (childAt instanceof VerticalSeekBar) {
            return (VerticalSeekBar) childAt;
        }
        return null;
    }

    private boolean m639a() {
        VerticalSeekBar childSeekBar = getChildSeekBar();
        if (childSeekBar != null) {
            return childSeekBar.m638a();
        }
        return false;
    }
}
