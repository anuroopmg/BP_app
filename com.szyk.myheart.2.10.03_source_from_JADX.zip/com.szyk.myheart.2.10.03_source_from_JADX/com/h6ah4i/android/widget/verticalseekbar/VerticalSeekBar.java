package com.h6ah4i.android.widget.verticalseekbar;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.widget.SeekBar;
import happy.hacking.cfx;
import happy.hacking.iv;
import happy.hacking.py;
import happy.hacking.ug;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class VerticalSeekBar extends SeekBar {
    private boolean f904a;
    private Drawable f905b;
    private Method f906c;
    private int f907d;

    public VerticalSeekBar(Context context) {
        super(context);
        this.f907d = 90;
        m633a(context, null, 0);
    }

    public VerticalSeekBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f907d = 90;
        m633a(context, attributeSet, 0);
    }

    public VerticalSeekBar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f907d = 90;
        m633a(context, attributeSet, i);
    }

    private void m633a(Context context, AttributeSet attributeSet, int i) {
        iv.m5932i(this);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, cfx.VerticalSeekBar, i, 0);
            int integer = obtainStyledAttributes.getInteger(cfx.VerticalSeekBar_seekBarRotation, 0);
            if (m636a(integer)) {
                this.f907d = integer;
            }
            obtainStyledAttributes.recycle();
        }
    }

    public void setThumb(Drawable drawable) {
        this.f905b = drawable;
        super.setThumb(drawable);
    }

    private Drawable getThumbCompat() {
        return this.f905b;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (m638a()) {
            switch (motionEvent.getAction()) {
                case ug.RecyclerView_android_orientation /*0*/:
                    m635a(true);
                    break;
                case ug.RecyclerView_layoutManager /*1*/:
                    m635a(false);
                    break;
            }
            return super.onTouchEvent(motionEvent);
        } else if (!isEnabled()) {
            return false;
        } else {
            Drawable thumbCompat = getThumbCompat();
            switch (motionEvent.getAction()) {
                case ug.RecyclerView_android_orientation /*0*/:
                    setPressed(true);
                    if (thumbCompat != null) {
                        invalidate(thumbCompat.getBounds());
                    }
                    this.f904a = true;
                    m634a(motionEvent);
                    m635a(true);
                    break;
                case ug.RecyclerView_layoutManager /*1*/:
                    if (this.f904a) {
                        m634a(motionEvent);
                        this.f904a = false;
                        setPressed(false);
                    } else {
                        this.f904a = true;
                        m634a(motionEvent);
                        this.f904a = false;
                        m635a(false);
                    }
                    invalidate();
                    break;
                case ug.RecyclerView_spanCount /*2*/:
                    if (this.f904a) {
                        m634a(motionEvent);
                        break;
                    }
                    break;
                case ug.RecyclerView_reverseLayout /*3*/:
                    if (this.f904a) {
                        this.f904a = false;
                        setPressed(false);
                    }
                    invalidate();
                    break;
            }
            return true;
        }
    }

    private void m634a(MotionEvent motionEvent) {
        float f;
        float f2 = 0.0f;
        int paddingTop = super.getPaddingTop();
        int paddingBottom = super.getPaddingBottom();
        int height = getHeight();
        paddingBottom = (height - paddingTop) - paddingBottom;
        int y = (int) motionEvent.getY();
        switch (this.f907d) {
            case py.Theme_controlBackground /*90*/:
                f = (float) (y - paddingTop);
                break;
            case 270:
                f = (float) ((height - paddingTop) - y);
                break;
            default:
                f = 0.0f;
                break;
        }
        if (f >= 0.0f && paddingBottom != 0) {
            f2 = f > ((float) paddingBottom) ? 1.0f : f / ((float) paddingBottom);
        }
        setProgress$2563266((int) (f2 * ((float) getMax())));
    }

    private void m635a(boolean z) {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        boolean z = false;
        int i2 = -1;
        if (isEnabled()) {
            switch (i) {
                case py.Toolbar_collapseContentDescription /*19*/:
                    if (this.f907d == 270) {
                        i2 = 1;
                    }
                    z = true;
                    break;
                case py.Toolbar_navigationIcon /*20*/:
                    if (this.f907d == 90) {
                        i2 = 1;
                    }
                    z = true;
                    break;
                case py.Toolbar_navigationContentDescription /*21*/:
                case py.Toolbar_logoDescription /*22*/:
                    i2 = 0;
                    z = true;
                    break;
                default:
                    i2 = 0;
                    break;
            }
            if (z) {
                int keyProgressIncrement = getKeyProgressIncrement();
                i2 = (i2 * keyProgressIncrement) + getProgress();
                if (i2 < 0 || i2 > getMax()) {
                    return true;
                }
                setProgress$2563266(i2 - keyProgressIncrement);
                return true;
            }
        }
        return super.onKeyDown(i, keyEvent);
    }

    public synchronized void setProgress(int i) {
        super.setProgress(i);
        if (!m638a()) {
            m637b();
        }
    }

    private synchronized void setProgress$2563266(int i) {
        if (this.f906c == null) {
            try {
                Method method = getClass().getMethod("setProgress", new Class[]{Integer.TYPE, Boolean.TYPE});
                method.setAccessible(true);
                this.f906c = method;
            } catch (NoSuchMethodException e) {
            }
        }
        if (this.f906c != null) {
            try {
                this.f906c.invoke(this, new Object[]{Integer.valueOf(i), Boolean.valueOf(true)});
            } catch (IllegalArgumentException e2) {
            } catch (IllegalAccessException e3) {
            } catch (InvocationTargetException e4) {
            }
        } else {
            super.setProgress(i);
        }
        m637b();
    }

    protected synchronized void onMeasure(int i, int i2) {
        if (m638a()) {
            super.onMeasure(i, i2);
        } else {
            super.onMeasure(i2, i);
            LayoutParams layoutParams = getLayoutParams();
            if (!isInEditMode() || layoutParams == null || layoutParams.height < 0) {
                setMeasuredDimension(super.getMeasuredHeight(), super.getMeasuredWidth());
            } else {
                setMeasuredDimension(super.getMeasuredHeight(), getLayoutParams().height);
            }
        }
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        if (m638a()) {
            super.onSizeChanged(i, i2, i3, i4);
        } else {
            super.onSizeChanged(i2, i, i4, i3);
        }
    }

    protected synchronized void onDraw(Canvas canvas) {
        if (!m638a()) {
            switch (this.f907d) {
                case py.Theme_controlBackground /*90*/:
                    canvas.rotate(90.0f);
                    canvas.translate(0.0f, (float) (-super.getWidth()));
                    break;
                case 270:
                    canvas.rotate(-90.0f);
                    canvas.translate((float) (-super.getHeight()), 0.0f);
                    break;
            }
        }
        super.onDraw(canvas);
    }

    public int getRotationAngle() {
        return this.f907d;
    }

    public void setRotationAngle(int i) {
        if (!m636a(i)) {
            throw new IllegalArgumentException("Invalid angle specified :" + i);
        } else if (this.f907d != i) {
            this.f907d = i;
            if (m638a()) {
                VerticalSeekBarWrapper wrapper = getWrapper();
                if (wrapper != null) {
                    wrapper.m640a(wrapper.getWidth(), wrapper.getHeight());
                    return;
                }
                return;
            }
            requestLayout();
        }
    }

    private void m637b() {
        onSizeChanged(super.getWidth(), super.getHeight(), 0, 0);
    }

    final boolean m638a() {
        boolean z;
        if (VERSION.SDK_INT >= 11) {
            z = true;
        } else {
            z = false;
        }
        return z && !isInEditMode();
    }

    private VerticalSeekBarWrapper getWrapper() {
        ViewParent parent = getParent();
        if (parent instanceof VerticalSeekBarWrapper) {
            return (VerticalSeekBarWrapper) parent;
        }
        return null;
    }

    private static boolean m636a(int i) {
        return i == 90 || i == 270;
    }
}
