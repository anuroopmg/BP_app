package com.szyk.myheart;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import happy.hacking.cfz;
import happy.hacking.cgb;
import happy.hacking.cgc;
import happy.hacking.cge;
import happy.hacking.cin;
import happy.hacking.cip;
import happy.hacking.cjn;
import happy.hacking.cjq;
import happy.hacking.cjx;
import happy.hacking.clv;
import happy.hacking.clw;
import happy.hacking.clx;
import happy.hacking.con;
import happy.hacking.cqr;
import happy.hacking.ctz;
import happy.hacking.cul;
import happy.hacking.cum;
import happy.hacking.cun;
import happy.hacking.cwl;
import happy.hacking.cwm;
import happy.hacking.cwo;
import happy.hacking.cwp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ItemEditActivity extends cge implements cwl {
    private static long f1012a;
    private cul f1013b;

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(cgb.menu_mode_confirm, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case cfz.menu_mode_save /*2131624401*/:
                con i = con.m4822i();
                ctz happy_hacking_ctz = this.f1013b;
                happy_hacking_ctz.f5028p.m4987a(happy_hacking_ctz.f4990d.getValue());
                happy_hacking_ctz.f5028p.m4989b(happy_hacking_ctz.f4991e.getValue());
                happy_hacking_ctz.f5028p.m4992c(happy_hacking_ctz.f4992f.getValue());
                happy_hacking_ctz.f5028p.f4808d = happy_hacking_ctz.f4997k.getTimeInMillis();
                happy_hacking_ctz.f5028p.f4810f = happy_hacking_ctz.m5128g();
                List arrayList = new ArrayList();
                for (cjn happy_hacking_cjn : happy_hacking_ctz.f4993g.getTags()) {
                    if (happy_hacking_cjn.isChecked()) {
                        arrayList.add(happy_hacking_cjn);
                    }
                }
                happy_hacking_ctz.f5028p.f4815k = arrayList;
                happy_hacking_ctz.f5028p.f4809e = happy_hacking_ctz.f4998l;
                con.m4822i().m4838a(happy_hacking_ctz.f5028p);
                i.m4861j();
                finish();
                break;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public final cwm m700a(int i) {
        return this.f1013b.f5001o.m5226a(i);
    }

    public final cwo m701b(int i) {
        return this.f1013b.f5001o.m5228b(i);
    }

    public final cwp m702c(int i) {
        return this.f1013b.f5001o.m5229c(i);
    }

    protected void onResume() {
        super.onResume();
        setTitle(cgc.measurement_edit);
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        switch (i) {
            case 8765:
                if (i2 == -1) {
                    this.f1013b.m5115a(cjx.m774a(intent.getBundleExtra("tags_bundle"), con.m4822i()));
                    break;
                }
                break;
        }
        super.onActivityResult(i, i2, intent);
    }

    protected void onCreate(Bundle bundle) {
        cin.f4281a.m4457a((Activity) this);
        cip.m4463a((Activity) this);
        super.onCreate(bundle);
        setContentView(2130903089);
        setSupportActionBar((Toolbar) findViewById(cfz.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        long longExtra = getIntent().getLongExtra("ITEM_ID", -1);
        f1012a = longExtra;
        if (longExtra == -1) {
            finish();
        }
        cqr c = con.m4822i().m4850c(f1012a);
        Calendar instance = Calendar.getInstance();
        instance.setTimeInMillis(c.f4808d);
        this.f1013b = new cul(this, instance, c);
        View findViewById = findViewById(2131624086);
        View findViewById2 = findViewById(2131624088);
        View findViewById3 = findViewById(2131624089);
        View findViewById4 = findViewById(2131624079);
        View findViewById5 = findViewById(2131624080);
        View findViewById6 = findViewById(2131624081);
        View findViewById7 = findViewById(2131624082);
        View findViewById8 = findViewById(2131624137);
        View findViewById9 = findViewById(2131624090);
        this.f1013b.m5114a(findViewById4);
        this.f1013b.m5125e(findViewById2);
        this.f1013b.m5127f(findViewById3);
        this.f1013b.m5123d(findViewById);
        this.f1013b.m5119b(findViewById6);
        this.f1013b.m5121c(findViewById7);
        this.f1013b.m5129g(findViewById5);
        this.f1013b.f5029q = (TextView) findViewById8;
        this.f1013b.m5131h(findViewById9);
        ctz happy_hacking_ctz = this.f1013b;
        long j = c.f4808d;
        int i = c.f4805a;
        int i2 = c.f4806b;
        int i3 = c.f4807c;
        happy_hacking_ctz.m5118b(j);
        happy_hacking_ctz.m5112a(j);
        happy_hacking_ctz.d.setValue(i);
        happy_hacking_ctz.e.setValue(i2);
        happy_hacking_ctz.f.setValue(i3);
        List arrayList = new ArrayList();
        if (c.f4815k != null) {
            for (cjq happy_hacking_cjn : c.f4815k) {
                arrayList.add(new cjn(happy_hacking_cjn, true));
            }
        }
        for (cjq happy_hacking_cjn2 : happy_hacking_ctz.b.m4843b()) {
            if (!arrayList.contains(happy_hacking_cjn2)) {
                arrayList.add(new cjn(happy_hacking_cjn2));
            }
        }
        happy_hacking_ctz.g.setTags(arrayList);
        happy_hacking_ctz.c.setText(c.f4810f);
        happy_hacking_ctz.f4998l = c.f4809e;
        happy_hacking_ctz.f5029q.setText(Float.valueOf(c.f4809e).toString());
        happy_hacking_ctz.d.setNumberChangedListener(new cum(happy_hacking_ctz));
        happy_hacking_ctz.e.setNumberChangedListener(new cun(happy_hacking_ctz));
        happy_hacking_ctz.m5116a(true);
        happy_hacking_ctz.f5001o.m5227a();
        findViewById6.setOnClickListener(new clv(this));
        findViewById7.setOnClickListener(new clw(this));
        findViewById8.setOnClickListener(new clx(this));
    }
}
