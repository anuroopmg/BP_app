package com.szyk.myheart;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import happy.hacking.cfz;
import happy.hacking.cgc;
import happy.hacking.cge;
import happy.hacking.cin;
import happy.hacking.cip;
import happy.hacking.cjq;
import happy.hacking.cnp;
import happy.hacking.cnq;
import happy.hacking.con;
import happy.hacking.cqr;
import happy.hacking.cso;
import happy.hacking.cvd;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Calendar;

public class ItemInfoActivity extends cge {
    private static final String f1014a;
    private long f1015b;
    private cvd f1016c;

    static {
        f1014a = ItemInfoActivity.class.getName();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(2131689480, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        cqr c = con.m4822i().m4850c(this.f1015b);
        switch (menuItem.getItemId()) {
            case 2131624402:
                new cnq(c, this).m4326a();
                return true;
            case 2131624403:
                new cnp(c).m4326a();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(menuItem);
        }
    }

    protected void onSaveInstanceState(Bundle bundle) {
        bundle.putLong("ITEM_ID", this.f1015b);
        super.onSaveInstanceState(bundle);
    }

    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        if (bundle.containsKey("ITEM_ID")) {
            this.f1015b = bundle.getLong("ITEM_ID");
        }
    }

    protected void onResume() {
        super.onResume();
        setTitle(cgc.measurement_details);
        cqr c = con.m4822i().m4850c(this.f1015b);
        if (c == null) {
            finish();
        }
        cvd happy_hacking_cvd = this.f1016c;
        new StringBuilder("Setup item view: ").append(c);
        CharSequence charSequence = c.f4810f;
        if (TextUtils.isEmpty(charSequence)) {
            happy_hacking_cvd.f5099l.setVisibility(8);
        } else {
            happy_hacking_cvd.f5099l.setVisibility(0);
            happy_hacking_cvd.f5094g.setText(charSequence);
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (c.f4815k != null) {
            for (cjq happy_hacking_cjq : c.f4815k) {
                if (happy_hacking_cjq != null) {
                    stringBuilder.append(happy_hacking_cjq.m4508a()).append("; ");
                }
            }
        }
        charSequence = stringBuilder.toString();
        if (TextUtils.isEmpty(charSequence)) {
            happy_hacking_cvd.f5100m.setVisibility(8);
        } else {
            happy_hacking_cvd.f5100m.setVisibility(0);
            happy_hacking_cvd.f5088a.setText(charSequence);
        }
        DateFormat dateInstance = DateFormat.getDateInstance(2);
        Calendar instance = Calendar.getInstance();
        instance.setTimeInMillis(c.f4808d);
        happy_hacking_cvd.f5093f.setText(dateInstance.format(instance.getTime()));
        happy_hacking_cvd.f5092e.setText(DateFormat.getTimeInstance(3).format(instance.getTime()) + ", ");
        happy_hacking_cvd.f5091d.setText(Integer.valueOf(c.f4805a).toString());
        happy_hacking_cvd.f5090c.setText(Integer.valueOf(c.f4806b).toString());
        happy_hacking_cvd.f5089b.setText(Integer.valueOf(c.f4807c).toString());
        if (c.f4809e != 0.0f) {
            happy_hacking_cvd.f5095h.setText(Float.valueOf(c.f4809e).toString());
        } else {
            happy_hacking_cvd.f5095h.setText("-");
        }
        happy_hacking_cvd.f5097j.setText(Integer.valueOf(cso.m5066a(c)).toString());
        float b = cso.m5067b(c);
        NumberFormat instance2 = NumberFormat.getInstance();
        instance2.setMaximumFractionDigits(2);
        happy_hacking_cvd.f5098k.setText(instance2.format((double) b));
        happy_hacking_cvd.f5096i.setText(c.m4991c().m4942a().f5288a);
        if (c.m4991c().m4945d()) {
            happy_hacking_cvd.f5101n.setVisibility(0);
        } else {
            happy_hacking_cvd.f5101n.setVisibility(8);
        }
        if (c.m4991c().m4944c()) {
            happy_hacking_cvd.f5103p.setVisibility(0);
        } else {
            happy_hacking_cvd.f5103p.setVisibility(8);
        }
        if (c.m4991c().m4943b()) {
            happy_hacking_cvd.f5102o.setVisibility(0);
        } else {
            happy_hacking_cvd.f5102o.setVisibility(8);
        }
    }

    protected void onCreate(Bundle bundle) {
        View findViewById;
        View findViewById2;
        View findViewById3;
        View findViewById4;
        View findViewById5;
        View findViewById6;
        View findViewById7;
        View findViewById8;
        View findViewById9;
        View findViewById10;
        View findViewById11;
        View findViewById12;
        View findViewById13;
        View findViewById14;
        View findViewById15;
        View findViewById16;
        cin.f4281a.m4457a((Activity) this);
        cip.m4463a((Activity) this);
        super.onCreate(bundle);
        setContentView(2130903090);
        if (bundle != null) {
            if (bundle.containsKey("ITEM_ID")) {
                this.f1015b = bundle.getLong("ITEM_ID");
                Log.i(f1014a, "Creating activity " + this.f1015b);
                if (this.f1015b == -1) {
                    Log.e(f1014a, "Info activity didn't find Item id!");
                    finish();
                }
                setSupportActionBar((Toolbar) findViewById(cfz.toolbar));
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                this.f1016c = new cvd();
                new StringBuilder("initLayout view on mediator ").append(this.f1016c).append(" with item ").append(this.f1015b);
                findViewById = findViewById(2131624162);
                findViewById2 = findViewById(2131624139);
                findViewById3 = findViewById(2131624140);
                findViewById4 = findViewById(2131624145);
                findViewById5 = findViewById(2131624147);
                findViewById6 = findViewById(2131624149);
                findViewById7 = findViewById(2131624153);
                findViewById8 = findViewById(2131624155);
                findViewById9 = findViewById(2131624164);
                findViewById10 = findViewById(2131624151);
                findViewById11 = findViewById(2131624142);
                findViewById12 = findViewById(2131624160);
                findViewById13 = findViewById(2131624163);
                findViewById14 = findViewById(2131624156);
                findViewById15 = findViewById(2131624158);
                findViewById16 = findViewById(2131624159);
                this.f1016c.f5093f = (TextView) findViewById2;
                this.f1016c.f5094g = (TextView) findViewById;
                this.f1016c.f5092e = (TextView) findViewById3;
                this.f1016c.f5091d = (TextView) findViewById4;
                this.f1016c.f5090c = (TextView) findViewById5;
                this.f1016c.f5089b = (TextView) findViewById6;
                this.f1016c.f5088a = (TextView) findViewById9;
                this.f1016c.f5095h = (TextView) findViewById10;
                this.f1016c.f5096i = (TextView) findViewById11;
                this.f1016c.f5097j = (TextView) findViewById7;
                this.f1016c.f5098k = (TextView) findViewById8;
                this.f1016c.f5099l = (ViewGroup) findViewById12;
                this.f1016c.f5100m = (ViewGroup) findViewById13;
                this.f1016c.f5101n = findViewById15;
                this.f1016c.f5102o = findViewById14;
                this.f1016c.f5103p = findViewById16;
            }
        }
        this.f1015b = getIntent().getLongExtra("ITEM_ID", -1);
        Log.i(f1014a, "Creating activity " + this.f1015b);
        if (this.f1015b == -1) {
            Log.e(f1014a, "Info activity didn't find Item id!");
            finish();
        }
        setSupportActionBar((Toolbar) findViewById(cfz.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.f1016c = new cvd();
        new StringBuilder("initLayout view on mediator ").append(this.f1016c).append(" with item ").append(this.f1015b);
        findViewById = findViewById(2131624162);
        findViewById2 = findViewById(2131624139);
        findViewById3 = findViewById(2131624140);
        findViewById4 = findViewById(2131624145);
        findViewById5 = findViewById(2131624147);
        findViewById6 = findViewById(2131624149);
        findViewById7 = findViewById(2131624153);
        findViewById8 = findViewById(2131624155);
        findViewById9 = findViewById(2131624164);
        findViewById10 = findViewById(2131624151);
        findViewById11 = findViewById(2131624142);
        findViewById12 = findViewById(2131624160);
        findViewById13 = findViewById(2131624163);
        findViewById14 = findViewById(2131624156);
        findViewById15 = findViewById(2131624158);
        findViewById16 = findViewById(2131624159);
        this.f1016c.f5093f = (TextView) findViewById2;
        this.f1016c.f5094g = (TextView) findViewById;
        this.f1016c.f5092e = (TextView) findViewById3;
        this.f1016c.f5091d = (TextView) findViewById4;
        this.f1016c.f5090c = (TextView) findViewById5;
        this.f1016c.f5089b = (TextView) findViewById6;
        this.f1016c.f5088a = (TextView) findViewById9;
        this.f1016c.f5095h = (TextView) findViewById10;
        this.f1016c.f5096i = (TextView) findViewById11;
        this.f1016c.f5097j = (TextView) findViewById7;
        this.f1016c.f5098k = (TextView) findViewById8;
        this.f1016c.f5099l = (ViewGroup) findViewById12;
        this.f1016c.f5100m = (ViewGroup) findViewById13;
        this.f1016c.f5101n = findViewById15;
        this.f1016c.f5102o = findViewById14;
        this.f1016c.f5103p = findViewById16;
    }
}
