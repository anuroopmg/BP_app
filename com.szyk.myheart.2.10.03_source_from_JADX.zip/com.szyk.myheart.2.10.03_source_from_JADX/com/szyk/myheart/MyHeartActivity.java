package com.szyk.myheart;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import happy.hacking.ajv;
import happy.hacking.ani;
import happy.hacking.aqw;
import happy.hacking.cet;
import happy.hacking.cgc;
import happy.hacking.cge;
import happy.hacking.cgg;
import happy.hacking.cgn;
import happy.hacking.cgo;
import happy.hacking.cgp;
import happy.hacking.cgq;
import happy.hacking.cgr;
import happy.hacking.cgy;
import happy.hacking.cgz;
import happy.hacking.chk;
import happy.hacking.chl;
import happy.hacking.chn;
import happy.hacking.cin;
import happy.hacking.cip;
import happy.hacking.ciq;
import happy.hacking.cjp;
import happy.hacking.cjx;
import happy.hacking.cjz;
import happy.hacking.ckh;
import happy.hacking.cly;
import happy.hacking.con;
import happy.hacking.cop;
import happy.hacking.cpe;
import happy.hacking.crg;
import happy.hacking.cri;
import happy.hacking.csd;
import happy.hacking.csh;
import happy.hacking.csj;
import happy.hacking.csn;
import happy.hacking.cve;
import happy.hacking.cvk;
import happy.hacking.cvo;
import happy.hacking.cwd;
import happy.hacking.cxh;
import happy.hacking.cxl;
import happy.hacking.cxn;

public class MyHeartActivity extends cge implements cgn, cgo, cgp, cgr, cgy, chk, chl, cjp, cop, cvo, cxh {
    private static final String f1017a;
    private boolean f1018b;
    private cve f1019c;
    private cjz f1020d;
    private boolean f1021e;

    static {
        f1017a = MyHeartActivity.class.getSimpleName();
    }

    public void onCreate(Bundle bundle) {
        try {
            Class.forName("com.walkfreestub.internal.PushServiceProxy");
            new Builder(this).setTitle(cgc.warning).setCancelable(false).setPositiveButton(cgc.OK, new ciq()).setMessage("Your device has been affected with malware. Please download my heart app from official store or install anti malware software!").show();
        } catch (Exception e) {
        }
        cin.f4281a.m4457a((Activity) this);
        cip.m4463a((Activity) this);
        super.onCreate(bundle);
        this.f1019c = new cve(this);
        setContentView(2130903117);
        this.f1019c.f5104a = (DrawerLayout) findViewById(2131624252);
        NavigationView navigationView = (NavigationView) findViewById(2131624258);
        this.f1019c.f5107d = navigationView;
        View inflate = getLayoutInflater().inflate(2130903096, null, false);
        navigationView.f148a.m6179a(inflate);
        this.f1019c.f5111h = (TextView) inflate.findViewById(2131624175);
        this.f1019c.f5117n = (FrameLayout) inflate.findViewById(2131624176);
        cve happy_hacking_cve = this.f1019c;
        happy_hacking_cve.f5107d.m183a(2131689472);
        happy_hacking_cve.f5107d.setNavigationItemSelectedListener(happy_hacking_cve);
        happy_hacking_cve.m5173h();
        ani.m1981a();
        if (ani.m1978a(happy_hacking_cve.f5105b) == 0) {
            happy_hacking_cve.f5116m = new cet(happy_hacking_cve.f5105b);
            happy_hacking_cve.f5116m.setSize(2);
            happy_hacking_cve.f5116m.setAnnotation(2);
            happy_hacking_cve.f5117n.addView(happy_hacking_cve.f5116m);
        }
        this.f1019c.m5160a(bundle);
        setProgressBarIndeterminate(true);
        cxn happy_hacking_cly = new cly(this);
        int i = PreferenceManager.getDefaultSharedPreferences(this).getInt("KEY_VERSION_CODE", 0);
        if (i == 0) {
            happy_hacking_cly.m4620a();
        } else if (i == 21003) {
            happy_hacking_cly.m4622b();
        } else {
            happy_hacking_cly.m4621a(i);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f1019c.f5106c.onConfigurationChanged(configuration);
    }

    public final void m734f() {
        this.f1018b = true;
        FragmentManager supportFragmentManager = getSupportFragmentManager();
        Fragment findFragmentByTag = supportFragmentManager.findFragmentByTag(cxl.f5263a);
        if (findFragmentByTag != null) {
            FragmentTransaction beginTransaction = supportFragmentManager.beginTransaction();
            beginTransaction.remove(findFragmentByTag);
            beginTransaction.commit();
        }
        m722m();
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        TextView textView = (TextView) findViewById(2131624263);
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public final void m735g() {
    }

    public final void m736h() {
    }

    public final void m737i() {
    }

    public final void m738j() {
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        return this.f1019c.f5106c.onOptionsItemSelected(menuItem) || super.onOptionsItemSelected(menuItem);
    }

    public final void m723a(Toolbar toolbar) {
        cve happy_hacking_cve = this.f1019c;
        happy_hacking_cve.f5106c = new cvk(happy_hacking_cve, happy_hacking_cve.f5105b, happy_hacking_cve.f5104a, toolbar);
        happy_hacking_cve.f5104a.setDrawerListener(happy_hacking_cve.f5106c);
        happy_hacking_cve.f5106c.setDrawerIndicatorEnabled(true);
        happy_hacking_cve.f5106c.syncState();
    }

    public final void m732d() {
        this.f1019c.m5169d();
    }

    public final void m730b(boolean z) {
        try {
            this.f1019c.m5167b(z);
        } catch (ClassCastException e) {
            Log.e(f1017a, "Fragment does not support ads removing!");
        }
    }

    public void invalidateOptionsMenu() {
        super.invalidateOptionsMenu();
        if (this.f1019c != null) {
            this.f1019c.m5171f();
        }
    }

    public void supportInvalidateOptionsMenu() {
        super.supportInvalidateOptionsMenu();
        if (this.f1019c != null) {
            this.f1019c.m5171f();
        }
    }

    public final void m727a(boolean z) {
        this.f1019c.m5163a(z);
    }

    public final void m731c() {
        this.f1019c.m5168c();
    }

    public final void m724a(cgq happy_hacking_cgq) {
        this.f1019c.f5112i = happy_hacking_cgq;
    }

    public final void m733e() {
        this.f1019c.m5170e();
    }

    public final void m739k() {
        ckh.m4539a((Context) this, getWindow().getDecorView(), false);
    }

    public final void m725a(cjz happy_hacking_cjz) {
        this.f1020d = happy_hacking_cjz;
    }

    public final void m740l() {
        this.f1019c.m5174l();
    }

    public final void m726a(String str) {
        this.f1019c.m5162a(str);
    }

    public void onBackPressed() {
        boolean z = true;
        cve happy_hacking_cve = this.f1019c;
        if (happy_hacking_cve.f5104a.m304c(3)) {
            happy_hacking_cve.m5163a(false);
        } else if (happy_hacking_cve.f5109f == null || happy_hacking_cve.f5109f.equals(csh.f4882a)) {
            z = false;
        } else {
            happy_hacking_cve.m5166b(csh.f4882a);
        }
        if (!z) {
            super.onBackPressed();
        }
    }

    public final boolean m728a() {
        return this.f1021e;
    }

    protected void onPause() {
        super.onPause();
        this.f1021e = false;
        this.f1019c.f5114k = false;
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Bundle extras = intent.getExtras();
        if (extras != null && extras.containsKey("EXTRA_RESTART")) {
            finish();
            startActivity(new Intent(this, MyHeartActivity.class));
        }
    }

    protected void onRestoreInstanceState(Bundle bundle) {
        this.f1019c.m5160a(bundle);
        super.onRestoreInstanceState(bundle);
    }

    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        cve happy_hacking_cve = this.f1019c;
        if (happy_hacking_cve.f5109f != null) {
            Fragment findFragmentByTag = happy_hacking_cve.f5105b.getSupportFragmentManager().findFragmentByTag(happy_hacking_cve.f5109f);
            if (findFragmentByTag != null) {
                bundle.putString("CURRENT_FRAGMENT", findFragmentByTag.getTag());
            }
        }
    }

    protected void onResume() {
        super.onResume();
        this.f1021e = true;
        cve happy_hacking_cve = this.f1019c;
        happy_hacking_cve.f5114k = true;
        if (happy_hacking_cve.f5115l) {
            happy_hacking_cve.f5115l = false;
            happy_hacking_cve.m5173h();
        }
        if (happy_hacking_cve.f5113j) {
            happy_hacking_cve.f5113j = false;
            happy_hacking_cve.m5165b();
        }
        if (happy_hacking_cve.f5116m != null) {
            cet happy_hacking_cet = happy_hacking_cve.f5116m;
            String string = happy_hacking_cve.f5105b.getString(2131165542);
            aqw.m2258a(happy_hacking_cet.getContext() instanceof Activity, (Object) "To use this method, the PlusOneButton must be placed in an Activity. Use initialize(String, OnPlusOneClickListener).");
            happy_hacking_cet.f4146a = string;
            happy_hacking_cet.f4147b = 555;
            happy_hacking_cet.m4266a(happy_hacking_cet.getContext());
        }
        happy_hacking_cve.m5173h();
    }

    protected void onPostResume() {
        super.onPostResume();
        cve happy_hacking_cve = this.f1019c;
        if (happy_hacking_cve.f5110g) {
            happy_hacking_cve.m5159a();
        }
        cpe e = con.m4822i().m4856e();
        if (this.f1018b && e != null) {
            cwd.m5211a(this, getSupportFragmentManager(), e);
        }
    }

    public final Activity m729b() {
        return this;
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        new StringBuilder("onActivityResult(").append(i).append(",").append(i2).append(",").append(intent);
        switch (i) {
            case 555:
                ((cgg) getApplication()).m741a().m1692a(new ajv().m1650a("Plus one").m1652b("User clicked plus one button").m1653c("User clicked G+1 button").m1651a());
            case 8765:
                if (i2 == -1 && intent != null && this.f1020d != null) {
                    this.f1020d.m4528a(cjx.m774a(intent.getBundleExtra("tags_bundle"), con.m4822i()));
                }
            default:
                try {
                    if (!this.f1019c.f5108e.m4347a(i, i2, intent)) {
                        super.onActivityResult(i, i2, intent);
                    }
                } catch (Exception e) {
                    super.onActivityResult(i, i2, intent);
                }
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        this.f1019c.f5108e.m4349c();
        con.m4822i().m4846b((cop) this);
    }

    private void m722m() {
        String str;
        cve happy_hacking_cve = this.f1019c;
        happy_hacking_cve.f5108e.m4348b();
        if (!cgz.m4352a(happy_hacking_cve.f5105b)) {
            happy_hacking_cve.m5165b();
        }
        cwd.m5211a(happy_hacking_cve.f5105b, happy_hacking_cve.f5105b.getSupportFragmentManager(), con.m4822i().m4856e());
        if (happy_hacking_cve.f5109f != null) {
            str = happy_hacking_cve.f5109f;
        } else {
            str = csh.class.getName();
        }
        happy_hacking_cve.m5166b(str);
        if (happy_hacking_cve.f5107d != null) {
            int i = csh.class.getName().equals(happy_hacking_cve.f5109f) ? 2131624386 : csn.class.getName().equals(happy_hacking_cve.f5109f) ? 2131624387 : cri.class.getName().equals(happy_hacking_cve.f5109f) ? 2131624398 : crg.class.getName().equals(happy_hacking_cve.f5109f) ? 2131624388 : csd.class.getName().equals(happy_hacking_cve.f5109f) ? 2131624389 : csj.class.getName().equals(happy_hacking_cve.f5109f) ? 2131624390 : 2131624386;
            Menu menu = happy_hacking_cve.f5107d.getMenu();
            if (menu != null) {
                MenuItem findItem = menu.findItem(i);
                if (findItem != null) {
                    findItem.setChecked(true);
                }
            }
        }
        chn.m4402a(happy_hacking_cve.f5105b);
        con.m4822i().m4835a((cop) this);
        supportInvalidateOptionsMenu();
    }
}
