package com.szyk.myheart.tags;

import android.app.Activity;
import android.os.Bundle;
import happy.hacking.cgc;
import happy.hacking.cin;
import happy.hacking.cip;
import happy.hacking.cjo;
import happy.hacking.cjv;
import happy.hacking.con;

public class MyHeartTagsPickerActivity extends cjv {
    public final cjo m773c() {
        return con.m4822i();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        cin.f4281a.m4457a((Activity) this);
        cip.m4463a((Activity) this);
    }

    protected void onResume() {
        super.onResume();
        setTitle(cgc.tags);
    }
}
