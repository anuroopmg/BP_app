package com.szyk.myheart.tags;

import android.content.Context;
import android.util.AttributeSet;
import happy.hacking.cjo;
import happy.hacking.cjx;
import happy.hacking.con;

public class MyHeartTagsView extends cjx {
    public MyHeartTagsView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public cjo getTagAccess() {
        return con.m4822i();
    }

    public Class getTagsPickerActivity() {
        return MyHeartTagsPickerActivity.class;
    }
}
