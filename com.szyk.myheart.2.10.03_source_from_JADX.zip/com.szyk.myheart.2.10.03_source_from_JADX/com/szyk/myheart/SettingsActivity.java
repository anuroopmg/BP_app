package com.szyk.myheart;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceCategory;
import android.preference.PreferenceManager;
import happy.hacking.cin;
import happy.hacking.cip;
import happy.hacking.clz;
import happy.hacking.cma;
import happy.hacking.cmb;
import happy.hacking.cmc;
import happy.hacking.cmd;
import happy.hacking.cme;
import happy.hacking.cmf;
import happy.hacking.cmg;
import happy.hacking.cmh;
import happy.hacking.cmj;
import happy.hacking.cmk;
import happy.hacking.cml;
import happy.hacking.cmm;
import happy.hacking.cmn;
import happy.hacking.con;
import happy.hacking.coz;

public class SettingsActivity extends PreferenceActivity {
    private static Activity f1024a;

    public static /* synthetic */ Activity m747a(SettingsActivity settingsActivity) {
        return settingsActivity;
    }

    public static /* synthetic */ void m748b(SettingsActivity settingsActivity) {
        settingsActivity.overridePendingTransition(0, 0);
        settingsActivity.finish();
        Intent intent = new Intent(settingsActivity, MyHeartActivity.class);
        settingsActivity.overridePendingTransition(0, 0);
        intent.addFlags(65536);
        intent.addFlags(335544320);
        intent.putExtra("EXTRA_RESTART", true);
        con.m4822i();
        con.m4823k();
        settingsActivity.startActivity(intent);
    }

    public void onCreate(Bundle bundle) {
        boolean z = true;
        cin.f4281a.m4457a((Activity) this);
        cip.m4463a((Activity) this);
        super.onCreate(bundle);
        f1024a = this;
        addPreferencesFromResource(2131034113);
        getPreferenceManager().findPreference("erase_data").setOnPreferenceClickListener(new cme(this));
        getPreferenceManager().findPreference("facebook").setOnPreferenceClickListener(new cmd(this));
        getPreferenceManager().findPreference("googleplus").setOnPreferenceClickListener(new cmc(this));
        getPreferenceManager().findPreference("contact").setOnPreferenceClickListener(new cmb(this));
        getPreferenceManager().findPreference("about").setOnPreferenceClickListener(new cma(this));
        ((ListPreference) getPreferenceManager().findPreference("language_list")).setOnPreferenceChangeListener(new cmn(this));
        ((ListPreference) getPreferenceManager().findPreference("csv_format")).setOnPreferenceChangeListener(new cmj(this));
        getPreferenceManager().findPreference("pick_weight_unit").setOnPreferenceClickListener(new cmh(this));
        ((ListPreference) getPreferenceManager().findPreference("theme")).setOnPreferenceChangeListener(new cmm(this));
        getPreferenceManager().findPreference("categories").setOnPreferenceClickListener(new cml(this));
        CheckBoxPreference checkBoxPreference = (CheckBoxPreference) getPreferenceManager().findPreference("google_analytics");
        if (PreferenceManager.getDefaultSharedPreferences(this).getInt("key_analytics_license", 0) != 1) {
            z = false;
        }
        checkBoxPreference.setChecked(z);
        checkBoxPreference.setOnPreferenceClickListener(new cmg(this, checkBoxPreference));
        Preference findPreference = getPreferenceManager().findPreference("restore_old_data");
        if (coz.m4884a(this)) {
            findPreference.setOnPreferenceClickListener(new cmf(this));
        } else {
            ((PreferenceCategory) findPreference("preference_category_data_settings")).removePreference(findPreference);
        }
        getPreferenceManager().findPreference("more_apps").setOnPreferenceClickListener(new clz(this));
        ((ListPreference) getPreferenceManager().findPreference("pick_trend_algorithm")).setOnPreferenceChangeListener(new cmk(this));
    }
}
