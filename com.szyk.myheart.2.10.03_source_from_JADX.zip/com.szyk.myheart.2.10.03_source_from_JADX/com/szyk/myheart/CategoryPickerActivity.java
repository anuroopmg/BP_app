package com.szyk.myheart;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import happy.hacking.cge;
import happy.hacking.cin;
import happy.hacking.cip;
import happy.hacking.cqt;

public class CategoryPickerActivity extends cge {
    public void onCreate(Bundle bundle) {
        cin.f4281a.m4457a((Activity) this);
        cip.m4463a((Activity) this);
        super.onCreate(bundle);
        setContentView(2130903139);
        FragmentManager supportFragmentManager = getSupportFragmentManager();
        Fragment findFragmentByTag = supportFragmentManager.findFragmentByTag(cqt.f4816a);
        FragmentTransaction beginTransaction = supportFragmentManager.beginTransaction();
        if (findFragmentByTag == null) {
            beginTransaction.add(2131624283, new cqt(), cqt.f4816a);
        } else {
            beginTransaction.attach(findFragmentByTag);
        }
        beginTransaction.commit();
    }
}
