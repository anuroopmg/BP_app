package com.szyk.myheart.data.db;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import happy.hacking.ug;
import java.io.File;
import java.io.FileNotFoundException;

public class CachedFileProvider extends ContentProvider {
    private UriMatcher f1027a;

    public boolean onCreate() {
        this.f1027a = new UriMatcher(-1);
        this.f1027a.addURI("com.szyk.myheart.cachedfileprovider", "*", 1);
        return true;
    }

    public ParcelFileDescriptor openFile(Uri uri, String str) {
        new StringBuilder("Called with uri: '").append(uri).append("'.").append(uri.getLastPathSegment());
        switch (this.f1027a.match(uri)) {
            case ug.RecyclerView_layoutManager /*1*/:
                return ParcelFileDescriptor.open(new File(getContext().getCacheDir() + File.separator + uri.getLastPathSegment()), 268435456);
            default:
                new StringBuilder("Unsupported uri: '").append(uri).append("'.");
                throw new FileNotFoundException("Unsupported uri: " + uri.toString());
        }
    }

    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        return 0;
    }

    public int delete(Uri uri, String str, String[] strArr) {
        return 0;
    }

    public Uri insert(Uri uri, ContentValues contentValues) {
        return null;
    }

    public String getType(Uri uri) {
        return null;
    }

    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        return null;
    }
}
