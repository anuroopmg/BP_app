package com.szyk.myheart.data.db;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;
import happy.hacking.cpn;
import happy.hacking.cpp;
import happy.hacking.cpq;
import happy.hacking.cpr;
import happy.hacking.cps;
import happy.hacking.cpt;
import happy.hacking.cpu;
import happy.hacking.cpv;
import happy.hacking.cpw;
import happy.hacking.cpx;
import happy.hacking.py;
import happy.hacking.ug;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;

public class DBProvider extends ContentProvider {
    private static final UriMatcher f1028a;
    private SQLiteOpenHelper f1029b;

    static {
        UriMatcher uriMatcher = new UriMatcher(-1);
        f1028a = uriMatcher;
        uriMatcher.addURI("com.szyk.myheart.contentprovider", "filters", 3);
        f1028a.addURI("com.szyk.myheart.contentprovider", "filters/#", 4);
        f1028a.addURI("com.szyk.myheart.contentprovider", "filters_categories", 19);
        f1028a.addURI("com.szyk.myheart.contentprovider", "filters_tags", 21);
        f1028a.addURI("com.szyk.myheart.contentprovider", "measurements", 7);
        f1028a.addURI("com.szyk.myheart.contentprovider", "measurements/#", 8);
        f1028a.addURI("com.szyk.myheart.contentprovider", "reminders", 9);
        f1028a.addURI("com.szyk.myheart.contentprovider", "reminders/#", 10);
        f1028a.addURI("com.szyk.myheart.contentprovider", "tags_measurement", 11);
        f1028a.addURI("com.szyk.myheart.contentprovider", "tags_measurement/#", 12);
        f1028a.addURI("com.szyk.myheart.contentprovider", "tags_users", 17);
        f1028a.addURI("com.szyk.myheart.contentprovider", "tags", 13);
        f1028a.addURI("com.szyk.myheart.contentprovider", "tags/#", 14);
        f1028a.addURI("com.szyk.myheart.contentprovider", "users", 15);
        f1028a.addURI("com.szyk.myheart.contentprovider", "users/#", 16);
    }

    public boolean onCreate() {
        this.f1029b = new cpn(getContext(), new cpq(), new cpr(), new cpp(), new cps(), new cpt(), new cpv(), new cpw(), new cpu(), new cpx());
        return true;
    }

    public int delete(Uri uri, String str, String[] strArr) {
        int match = f1028a.match(uri);
        String lastPathSegment = uri.getLastPathSegment();
        SQLiteDatabase writableDatabase = this.f1029b.getWritableDatabase();
        switch (match) {
            case ug.RecyclerView_reverseLayout /*3*/:
                match = writableDatabase.delete("filters", str, strArr);
                break;
            case ug.RecyclerView_stackFromEnd /*4*/:
                match = m754a("filters", "_id", str, strArr, writableDatabase, lastPathSegment);
                break;
            case py.Toolbar_contentInsetLeft /*7*/:
                match = writableDatabase.delete("measurements", str, strArr);
                break;
            case py.Toolbar_contentInsetRight /*8*/:
                match = m754a("measurements", "_id", str, strArr, writableDatabase, lastPathSegment);
                break;
            case py.Toolbar_popupTheme /*9*/:
                match = writableDatabase.delete("reminders", str, strArr);
                break;
            case py.Toolbar_titleTextAppearance /*10*/:
                match = m754a("reminders", "_id", str, strArr, writableDatabase, lastPathSegment);
                break;
            case py.Toolbar_subtitleTextAppearance /*11*/:
                match = writableDatabase.delete("tags_measurement", str, strArr);
                break;
            case py.Toolbar_titleMarginStart /*13*/:
                match = writableDatabase.delete("tags", str, strArr);
                break;
            case py.Toolbar_titleMarginEnd /*14*/:
                match = m754a("tags", "_id", str, strArr, writableDatabase, lastPathSegment);
                break;
            case py.Toolbar_titleMarginTop /*15*/:
                match = writableDatabase.delete("users", str, strArr);
                break;
            case py.Toolbar_titleMarginBottom /*16*/:
                match = m754a("users", "_id", str, strArr, writableDatabase, lastPathSegment);
                break;
            case py.Toolbar_maxButtonHeight /*17*/:
                match = writableDatabase.delete("tags_users", str, strArr);
                break;
            case py.Toolbar_collapseContentDescription /*19*/:
                match = writableDatabase.delete("filters_categories", str, strArr);
                break;
            case py.Toolbar_navigationContentDescription /*21*/:
                match = writableDatabase.delete("filters_tags", str, strArr);
                break;
            default:
                throw new IllegalArgumentException("Unknown Uri: " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return match;
    }

    public String getType(Uri uri) {
        return null;
    }

    public Uri insert(Uri uri, ContentValues contentValues) {
        String str;
        Object obj;
        int match = f1028a.match(uri);
        SQLiteDatabase writableDatabase = this.f1029b.getWritableDatabase();
        switch (match) {
            case ug.RecyclerView_reverseLayout /*3*/:
                str = "filters";
                obj = cpp.f4731a;
                break;
            case py.Toolbar_contentInsetLeft /*7*/:
                str = "measurements";
                obj = cps.f4737a;
                break;
            case py.Toolbar_popupTheme /*9*/:
                str = "reminders";
                obj = cpt.f4739a;
                break;
            case py.Toolbar_subtitleTextAppearance /*11*/:
                str = "tags_measurement";
                obj = cpv.f4743a;
                break;
            case py.Toolbar_titleMarginStart /*13*/:
                str = "tags";
                obj = cpu.f4741a;
                break;
            case py.Toolbar_titleMarginTop /*15*/:
                str = "users";
                obj = cpx.f4747a;
                break;
            case py.Toolbar_maxButtonHeight /*17*/:
                str = "tags_users";
                obj = cpw.f4745a;
                break;
            case py.Toolbar_collapseContentDescription /*19*/:
                str = "filters_categories";
                obj = cpq.f4733a;
                break;
            case py.Toolbar_navigationContentDescription /*21*/:
                str = "filters_tags";
                obj = cpr.f4735a;
                break;
            default:
                throw new IllegalArgumentException("Unknown Uri: " + uri);
        }
        writableDatabase.beginTransaction();
        long j = null;
        try {
            j = writableDatabase.insertOrThrow(str, null, contentValues);
            writableDatabase.setTransactionSuccessful();
        } catch (SQLException e) {
            j = -1;
            getContext().getContentResolver().notifyChange(uri, null);
            if (j != -1) {
                return Uri.parse(obj + "/" + j);
            }
            return null;
        } finally {
            writableDatabase.endTransaction();
        }
        getContext().getContentResolver().notifyChange(uri, null);
        if (j != -1) {
            return null;
        }
        return Uri.parse(obj + "/" + j);
    }

    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        SQLiteQueryBuilder sQLiteQueryBuilder = new SQLiteQueryBuilder();
        if (strArr != null) {
            Collection hashSet = new HashSet(Arrays.asList(strArr));
            Object hashSet2 = new HashSet();
            Collections.addAll(hashSet2, cpp.f4732b);
            Collections.addAll(hashSet2, cps.f4738b);
            Collections.addAll(hashSet2, cpt.f4740b);
            Collections.addAll(hashSet2, cpv.f4744b);
            Collections.addAll(hashSet2, cpu.f4742b);
            Collections.addAll(hashSet2, cpx.f4748b);
            Collections.addAll(hashSet2, cpq.f4734b);
            Collections.addAll(hashSet2, cpr.f4736b);
            if (!hashSet2.containsAll(hashSet)) {
                throw new IllegalArgumentException("Unknown columns in projection");
            }
        }
        switch (f1028a.match(uri)) {
            case ug.RecyclerView_reverseLayout /*3*/:
                sQLiteQueryBuilder.setTables("filters");
                break;
            case ug.RecyclerView_stackFromEnd /*4*/:
                sQLiteQueryBuilder.setTables("filters");
                sQLiteQueryBuilder.appendWhere("_id = " + uri.getLastPathSegment());
                break;
            case py.Toolbar_contentInsetLeft /*7*/:
                sQLiteQueryBuilder.setTables("measurements");
                break;
            case py.Toolbar_contentInsetRight /*8*/:
                sQLiteQueryBuilder.setTables("measurements");
                sQLiteQueryBuilder.appendWhere("_id = " + uri.getLastPathSegment());
                break;
            case py.Toolbar_popupTheme /*9*/:
                sQLiteQueryBuilder.setTables("reminders");
                break;
            case py.Toolbar_titleTextAppearance /*10*/:
                sQLiteQueryBuilder.setTables("reminders");
                sQLiteQueryBuilder.appendWhere("_id = " + uri.getLastPathSegment());
                break;
            case py.Toolbar_subtitleTextAppearance /*11*/:
                sQLiteQueryBuilder.setTables("tags_measurement");
                break;
            case py.Toolbar_titleMarginStart /*13*/:
                sQLiteQueryBuilder.setTables("tags");
                break;
            case py.Toolbar_titleMarginEnd /*14*/:
                sQLiteQueryBuilder.setTables("tags");
                sQLiteQueryBuilder.appendWhere("_id = " + uri.getLastPathSegment());
                break;
            case py.Toolbar_titleMarginTop /*15*/:
                sQLiteQueryBuilder.setTables("users");
                break;
            case py.Toolbar_titleMarginBottom /*16*/:
                sQLiteQueryBuilder.setTables("users");
                sQLiteQueryBuilder.appendWhere("_id = " + uri.getLastPathSegment());
                break;
            case py.Toolbar_maxButtonHeight /*17*/:
                sQLiteQueryBuilder.setTables("tags_users");
                break;
            case py.Toolbar_collapseContentDescription /*19*/:
                sQLiteQueryBuilder.setTables("filters_categories");
                break;
            case py.Toolbar_navigationContentDescription /*21*/:
                sQLiteQueryBuilder.setTables("filters_tags");
                break;
            default:
                throw new IllegalArgumentException("Unknown Uri: " + uri);
        }
        Cursor query = sQLiteQueryBuilder.query(this.f1029b.getWritableDatabase(), strArr, str, strArr2, null, null, str2);
        query.setNotificationUri(getContext().getContentResolver(), uri);
        return query;
    }

    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        int update;
        SQLiteDatabase writableDatabase = this.f1029b.getWritableDatabase();
        String lastPathSegment = uri.getLastPathSegment();
        switch (f1028a.match(uri)) {
            case ug.RecyclerView_reverseLayout /*3*/:
                update = writableDatabase.update("filters", contentValues, str, strArr);
                break;
            case ug.RecyclerView_stackFromEnd /*4*/:
                update = m753a("filters", "_id", contentValues, str, strArr, writableDatabase, lastPathSegment);
                break;
            case py.Toolbar_contentInsetLeft /*7*/:
                update = writableDatabase.update("measurements", contentValues, str, strArr);
                break;
            case py.Toolbar_contentInsetRight /*8*/:
                update = m753a("measurements", "_id", contentValues, str, strArr, writableDatabase, lastPathSegment);
                break;
            case py.Toolbar_popupTheme /*9*/:
                update = writableDatabase.update("reminders", contentValues, str, strArr);
                break;
            case py.Toolbar_titleTextAppearance /*10*/:
                update = m753a("reminders", "_id", contentValues, str, strArr, writableDatabase, lastPathSegment);
                break;
            case py.Toolbar_titleMarginStart /*13*/:
                update = writableDatabase.update("tags", contentValues, str, strArr);
                break;
            case py.Toolbar_titleMarginEnd /*14*/:
                update = m753a("tags", "_id", contentValues, str, strArr, writableDatabase, lastPathSegment);
                break;
            case py.Toolbar_titleMarginTop /*15*/:
                update = writableDatabase.update("users", contentValues, str, strArr);
                break;
            case py.Toolbar_titleMarginBottom /*16*/:
                update = m753a("users", "_id", contentValues, str, strArr, writableDatabase, lastPathSegment);
                break;
            case py.Toolbar_collapseContentDescription /*19*/:
                update = writableDatabase.update("filters_categories", contentValues, str, strArr);
                break;
            case py.Toolbar_navigationContentDescription /*21*/:
                update = writableDatabase.update("filters_tags", contentValues, str, strArr);
                break;
            default:
                throw new IllegalArgumentException("Unknown Uri: " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return update;
    }

    private static int m753a(String str, String str2, ContentValues contentValues, String str3, String[] strArr, SQLiteDatabase sQLiteDatabase, String str4) {
        if (TextUtils.isEmpty(str3)) {
            return sQLiteDatabase.update(str, contentValues, str2 + "=" + str4, null);
        }
        return sQLiteDatabase.update(str, contentValues, str2 + "=" + str4 + " AND " + str3, strArr);
    }

    private static int m754a(String str, String str2, String str3, String[] strArr, SQLiteDatabase sQLiteDatabase, String str4) {
        if (TextUtils.isEmpty(str3)) {
            return sQLiteDatabase.delete(str, str2 + "=" + str4, null);
        }
        return sQLiteDatabase.delete(str, str2 + "=" + str4 + " AND " + str3, strArr);
    }
}
