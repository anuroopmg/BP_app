package com.szyk.myheart;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;
import happy.hacking.cfz;
import happy.hacking.cgb;
import happy.hacking.cgc;
import happy.hacking.cge;
import happy.hacking.cin;
import happy.hacking.cip;
import happy.hacking.clr;
import happy.hacking.cls;
import happy.hacking.clt;
import happy.hacking.clu;
import happy.hacking.con;
import happy.hacking.ctl;
import happy.hacking.cty;

public class DataFilterCreatorActivity extends cge {
    private ctl f1011a;

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(cgb.menu_mode_confirm, menu);
        this.f1011a.f4963u = findViewById(cfz.menu_mode_save);
        this.f1011a.m5099b();
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case cfz.menu_mode_save /*2131624401*/:
                this.f1011a.m5095a();
                finish();
                break;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    protected void onCreate(Bundle bundle) {
        cip.m4463a((Activity) this);
        cin.f4281a.m4457a((Activity) this);
        super.onCreate(bundle);
        setContentView(2130903071);
        setSupportActionBar((Toolbar) findViewById(cfz.toolbar));
        cip.m4464a((AppCompatActivity) this, "");
        long longExtra = getIntent().getLongExtra("filter_id", -1);
        if (longExtra != -1) {
            this.f1011a = new cty(this, con.m4822i().m4853d(longExtra));
        } else {
            this.f1011a = new ctl(this);
        }
        View findViewById = findViewById(2131624102);
        View findViewById2 = findViewById(2131624097);
        View findViewById3 = findViewById(2131624100);
        View findViewById4 = findViewById(2131624095);
        View findViewById5 = findViewById(2131624115);
        View findViewById6 = findViewById(2131624106);
        View findViewById7 = findViewById(2131624101);
        View findViewById8 = findViewById(2131624099);
        View findViewById9 = findViewById(2131624094);
        View findViewById10 = findViewById(2131624096);
        View findViewById11 = findViewById(2131624092);
        View findViewById12 = findViewById(2131624104);
        View findViewById13 = findViewById(2131624103);
        View findViewById14 = findViewById(2131624113);
        View findViewById15 = findViewById(2131624105);
        View findViewById16 = findViewById(2131624117);
        View findViewById17 = findViewById(2131624116);
        View findViewById18 = findViewById(2131624107);
        View findViewById19 = findViewById(2131624109);
        View findViewById20 = findViewById(2131624111);
        this.f1011a.f4967y = (ToggleButton) findViewById17;
        this.f1011a.f4945c = (TextView) findViewById;
        this.f1011a.f4946d = (TextView) findViewById2;
        this.f1011a.f4947e = (TextView) findViewById3;
        this.f1011a.f4948f = (TextView) findViewById4;
        this.f1011a.f4943a = (LinearLayout) findViewById5;
        this.f1011a.f4944b = (LinearLayout) findViewById6;
        this.f1011a.f4955m = (CheckBox) findViewById7;
        this.f1011a.f4954l = (CheckBox) findViewById8;
        this.f1011a.f4961s = (CheckBox) findViewById9;
        this.f1011a.f4962t = (CheckBox) findViewById10;
        this.f1011a.f4958p = (EditText) findViewById11;
        this.f1011a.f4959q = (EditText) findViewById12;
        this.f1011a.f4960r = (CheckBox) findViewById13;
        this.f1011a.f4966x = (CheckBox) findViewById14;
        this.f1011a.f4965w = (CheckBox) findViewById15;
        this.f1011a.f4964v = (CheckBox) findViewById16;
        this.f1011a.f4940A = (CheckBox) findViewById18;
        this.f1011a.f4941B = (CheckBox) findViewById20;
        this.f1011a.f4942C = (CheckBox) findViewById19;
        findViewById.setOnClickListener(new clr(this));
        findViewById2.setOnClickListener(new cls(this));
        findViewById3.setOnClickListener(new clt(this));
        findViewById4.setOnClickListener(new clu(this));
    }

    protected void onResume() {
        super.onResume();
        setTitle(cgc.filter_setup);
    }
}
