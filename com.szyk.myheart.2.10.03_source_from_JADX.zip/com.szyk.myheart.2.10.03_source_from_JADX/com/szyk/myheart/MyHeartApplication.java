package com.szyk.myheart;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import android.util.Log;
import happy.hacking.cgg;
import happy.hacking.cim;
import happy.hacking.cin;
import happy.hacking.com;
import happy.hacking.con;
import happy.hacking.cor;
import happy.hacking.coz;
import happy.hacking.cpe;
import happy.hacking.cpy;
import happy.hacking.cxj;
import happy.hacking.cxm;
import java.io.File;

public class MyHeartApplication extends cgg implements cxj {
    private cxm f1023a;

    public void onCreate() {
        int i = 1;
        int i2 = 0;
        super.onCreate();
        if (cpy.f4749a == null) {
            cpy.f4749a = new cpy(this);
        }
        cim a = cin.f4281a;
        a.f4279b = 2131427588;
        a.f4278a = 2131427590;
        this.f1023a = new cxm(this);
        con i3 = con.m4822i();
        if (i3.f4660a == null) {
            i3.f4660a = new com(this);
        }
        con.m4824l();
        i3.m4841a((Context) this);
        coz happy_hacking_coz = new coz(this);
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(happy_hacking_coz.f4673c);
        boolean z = defaultSharedPreferences.getBoolean("is_migrated_v2", false);
        boolean z2 = defaultSharedPreferences.getBoolean("is_memory_migrated_v2", false);
        if (z && z2) {
            i = 0;
        }
        if (i != 0) {
            File d;
            Editor edit;
            SharedPreferences defaultSharedPreferences2 = PreferenceManager.getDefaultSharedPreferences(this);
            z2 = defaultSharedPreferences2.getBoolean("is_migrated_v2", false);
            z = defaultSharedPreferences2.getBoolean("is_memory_migrated_v2", false);
            if (!z2) {
                try {
                    d = coz.m4887d(this);
                    cpe e = con.m4822i().m4856e();
                    if (d.exists()) {
                        coz.m4882a(happy_hacking_coz.f4672b, e, d);
                    }
                    String[] c = coz.m4886c(this);
                    if (c != null) {
                        int length = c.length;
                        while (i2 < length) {
                            cpe a2 = con.m4822i().m4829a(c[i2], null, false);
                            File a3 = coz.m4880a(a2.f4698b, (Context) this);
                            if (a3.exists()) {
                                coz.m4882a(happy_hacking_coz.f4672b, a2, a3);
                            }
                            i2++;
                        }
                    }
                    edit = defaultSharedPreferences2.edit();
                    edit.putBoolean("is_migrated_v2", true);
                    edit.commit();
                } catch (Exception e2) {
                    Log.e(coz.f4671a, "Data migration has failed!");
                }
            }
            if (!z) {
                d = new File(getFilesDir().getAbsolutePath() + "/users/");
                coz.m4887d(this);
                happy_hacking_coz.m4889b();
                d.delete();
                edit = defaultSharedPreferences2.edit();
                edit.putBoolean("is_memory_migrated_v2", true);
                edit.commit();
            }
            coz.m4881a();
        }
        cor.m4871a();
    }

    public final cxm m745c() {
        return this.f1023a;
    }

    protected final String m744b() {
        return "UA-41614984-2";
    }
}
