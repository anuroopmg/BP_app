package com.szyk.myheart.reminder;

import com.szyk.myheart.MyHeartActivity;
import happy.hacking.chq;

public class MyHeartAlarmReceiver extends chq {
    public final Class m757a() {
        return RemindersIntentService.class;
    }

    public final Class m758b() {
        return MyHeartActivity.class;
    }
}
