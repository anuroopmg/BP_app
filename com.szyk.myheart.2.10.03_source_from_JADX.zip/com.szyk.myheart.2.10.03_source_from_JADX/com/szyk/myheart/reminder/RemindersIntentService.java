package com.szyk.myheart.reminder;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import happy.hacking.cqh;
import happy.hacking.cxf;

public class RemindersIntentService extends IntentService {
    public RemindersIntentService() {
        super("Reminders");
    }

    protected void onHandleIntent(Intent intent) {
        RemindersIntentService.class.getSimpleName();
        Context applicationContext = getApplicationContext();
        new cqh(new cxf()).execute(new Context[]{applicationContext});
    }
}
