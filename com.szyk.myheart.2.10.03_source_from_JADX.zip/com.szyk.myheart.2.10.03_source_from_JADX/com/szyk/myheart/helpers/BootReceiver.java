package com.szyk.myheart.helpers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.szyk.myheart.reminder.RemindersIntentService;

public class BootReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        getClass().getSimpleName();
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
            getClass().getSimpleName();
            context.startService(new Intent(context, RemindersIntentService.class));
        }
    }
}
