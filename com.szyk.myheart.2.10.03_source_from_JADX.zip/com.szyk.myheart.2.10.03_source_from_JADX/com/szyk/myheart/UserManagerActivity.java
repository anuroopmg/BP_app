package com.szyk.myheart;

import android.app.Activity;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import happy.hacking.cfz;
import happy.hacking.cgb;
import happy.hacking.cge;
import happy.hacking.cin;
import happy.hacking.cip;
import happy.hacking.cpe;
import happy.hacking.cqn;
import happy.hacking.cvw;
import happy.hacking.cvx;
import happy.hacking.cvy;
import happy.hacking.cwc;

public class UserManagerActivity extends cge implements cwc {
    private cvy f1025a;
    private boolean f1026b;

    public void onSaveInstanceState(Bundle bundle, PersistableBundle persistableBundle) {
        super.onSaveInstanceState(bundle, persistableBundle);
        this.f1025a.m5196a(bundle);
    }

    public void onRestoreInstanceState(Bundle bundle, PersistableBundle persistableBundle) {
        super.onRestoreInstanceState(bundle, persistableBundle);
        this.f1025a.m5199b(bundle);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        if (this.f1026b) {
            getMenuInflater().inflate(cgb.menu_mode_confirm, menu);
        }
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case cfz.menu_mode_save /*2131624401*/:
                this.f1025a.m5195a();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(menuItem);
        }
    }

    public final void m751a() {
        this.f1026b = true;
        supportInvalidateOptionsMenu();
    }

    public final void m752b() {
        this.f1026b = false;
        supportInvalidateOptionsMenu();
    }

    protected void onResume() {
        super.onResume();
        setTitle(2131165513);
    }

    protected void onCreate(Bundle bundle) {
        cin.f4281a.m4457a((Activity) this);
        cip.m4463a((Activity) this);
        super.onCreate(bundle);
        setContentView(2130903153);
        setSupportActionBar((Toolbar) findViewById(cfz.toolbar));
        cip.m4464a((AppCompatActivity) this, "");
        long longExtra = getIntent().getLongExtra("user_id", -1);
        if (longExtra != -1) {
            for (cpe happy_hacking_cpe : cqn.m4981a().f4776a) {
                if (happy_hacking_cpe.f4697a == longExtra) {
                    break;
                }
            }
            cpe happy_hacking_cpe2 = null;
            this.f1025a = new cvx(this, happy_hacking_cpe2, bundle);
        } else {
            this.f1025a = new cvw(this, bundle);
        }
        this.f1025a.f5200e = this;
        View findViewById = findViewById(2131624365);
        View findViewById2 = findViewById(2131624366);
        View findViewById3 = findViewById(2131624367);
        this.f1025a.m5202c(findViewById);
        this.f1025a.m5200b(findViewById2);
        this.f1025a.m5197a(findViewById3);
        this.f1025a.m5198b();
        this.f1025a.m5201c();
    }
}
