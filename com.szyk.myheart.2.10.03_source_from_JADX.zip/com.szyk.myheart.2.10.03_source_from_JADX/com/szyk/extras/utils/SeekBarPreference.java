package com.szyk.extras.utils;

import android.content.Context;
import android.content.res.TypedArray;
import android.preference.Preference;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import happy.hacking.cfz;
import happy.hacking.cga;

public class SeekBarPreference extends Preference implements OnSeekBarChangeListener {
    private final String f1001a;
    private int f1002b;
    private int f1003c;
    private int f1004d;
    private int f1005e;
    private String f1006f;
    private String f1007g;
    private SeekBar f1008h;
    private TextView f1009i;

    public SeekBarPreference(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1001a = getClass().getName();
        this.f1002b = 100;
        this.f1003c = 0;
        this.f1004d = 1;
        this.f1006f = "";
        this.f1007g = "";
        m694a(context, attributeSet);
    }

    public SeekBarPreference(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1001a = getClass().getName();
        this.f1002b = 100;
        this.f1003c = 0;
        this.f1004d = 1;
        this.f1006f = "";
        this.f1007g = "";
        m694a(context, attributeSet);
    }

    public void onBindView(View view) {
        super.onBindView(view);
        try {
            ViewParent parent = this.f1008h.getParent();
            ViewParent viewParent = (ViewGroup) view.findViewById(cfz.seekBarPrefBarContainer);
            if (parent != viewParent) {
                if (parent != null) {
                    ((ViewGroup) parent).removeView(this.f1008h);
                }
                viewParent.removeAllViews();
                viewParent.addView(this.f1008h, -1, -2);
            }
        } catch (Exception e) {
            Log.e(this.f1001a, "Error binding view: " + e.toString());
        }
        try {
            RelativeLayout relativeLayout = (RelativeLayout) view;
            this.f1009i = (TextView) relativeLayout.findViewById(cfz.seekBarPrefValue);
            this.f1009i.setText(String.valueOf(this.f1005e));
            this.f1009i.setMinimumWidth(30);
            this.f1008h.setProgress(this.f1005e - this.f1003c);
            ((TextView) relativeLayout.findViewById(cfz.seekBarPrefUnitsRight)).setText(this.f1007g);
            ((TextView) relativeLayout.findViewById(cfz.seekBarPrefUnitsLeft)).setText(this.f1006f);
        } catch (Throwable e2) {
            Log.e(this.f1001a, "Error updating seek bar preference", e2);
        }
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        int i2 = this.f1003c + i;
        if (i2 > this.f1002b) {
            i2 = this.f1002b;
        } else if (i2 < this.f1003c) {
            i2 = this.f1003c;
        } else if (!(this.f1004d == 1 || i2 % this.f1004d == 0)) {
            i2 = Math.round(((float) i2) / ((float) this.f1004d)) * this.f1004d;
        }
        if (callChangeListener(Integer.valueOf(i2))) {
            this.f1005e = i2;
            this.f1009i.setText(String.valueOf(i2));
            persistInt(i2);
            return;
        }
        seekBar.setProgress(this.f1005e - this.f1003c);
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
        notifyChanged();
    }

    protected View onCreateView(ViewGroup viewGroup) {
        try {
            return (RelativeLayout) ((LayoutInflater) getContext().getSystemService("layout_inflater")).inflate(cga.seek_bar_preference, viewGroup, false);
        } catch (Throwable e) {
            Log.e(this.f1001a, "Error creating seek bar preference", e);
            return null;
        }
    }

    protected Object onGetDefaultValue(TypedArray typedArray, int i) {
        return Integer.valueOf(typedArray.getInt(i, 50));
    }

    protected void onSetInitialValue(boolean z, Object obj) {
        if (z) {
            this.f1005e = getPersistedInt(this.f1005e);
            return;
        }
        int intValue;
        try {
            intValue = ((Integer) obj).intValue();
        } catch (Exception e) {
            Log.e(this.f1001a, "Invalid default value: " + obj.toString());
            intValue = 0;
        }
        persistInt(intValue);
        this.f1005e = intValue;
    }

    private static String m693a(AttributeSet attributeSet, String str, String str2, String str3) {
        String attributeValue = attributeSet.getAttributeValue(str, str2);
        return attributeValue == null ? str3 : attributeValue;
    }

    private void m694a(Context context, AttributeSet attributeSet) {
        this.f1002b = attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "max", 100);
        this.f1003c = attributeSet.getAttributeIntValue("http://robobunny.com", "min", 0);
        this.f1006f = m693a(attributeSet, "http://robobunny.com", "unitsLeft", "");
        this.f1007g = m693a(attributeSet, "http://robobunny.com", "unitsRight", m693a(attributeSet, "http://robobunny.com", "units", ""));
        try {
            String attributeValue = attributeSet.getAttributeValue("http://robobunny.com", "interval");
            if (attributeValue != null) {
                this.f1004d = Integer.parseInt(attributeValue);
            }
        } catch (Throwable e) {
            Log.e(this.f1001a, "Invalid interval value", e);
        }
        this.f1008h = new SeekBar(context, attributeSet);
        this.f1008h.setMax(this.f1002b - this.f1003c);
        this.f1008h.setOnSeekBarChangeListener(this);
    }
}
