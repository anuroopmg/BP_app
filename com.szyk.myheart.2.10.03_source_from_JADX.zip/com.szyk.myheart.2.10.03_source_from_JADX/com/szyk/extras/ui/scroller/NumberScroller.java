package com.szyk.extras.ui.scroller;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Shader.TileMode;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.widget.Scroller;
import happy.hacking.cgd;
import happy.hacking.cjh;
import java.text.DecimalFormat;
import java.text.NumberFormat;

public class NumberScroller extends View implements OnTouchListener {
    private static float f964a;
    private final Paint f965A;
    private int f966B;
    private int f967C;
    private cjh f968D;
    private Integer f969E;
    private int f970F;
    private int f971G;
    private int f972H;
    private int f973I;
    private final int f974J;
    private final int f975K;
    private final int f976b;
    private final String f977c;
    private final int f978d;
    private int f979e;
    private boolean f980f;
    private float f981g;
    private boolean f982h;
    private boolean f983i;
    private final Scroller f984j;
    private VelocityTracker f985k;
    private float f986l;
    private int f987m;
    private float f988n;
    private float f989o;
    private Integer f990p;
    private Integer f991q;
    private Paint f992r;
    private Paint f993s;
    private Paint f994t;
    private float f995u;
    private NumberFormat f996v;
    private Integer f997w;
    private float f998x;
    private final Rect f999y;
    private final Paint f1000z;

    public NumberScroller(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f976b = 10;
        this.f977c = NumberScroller.class.getName();
        this.f978d = 1000;
        this.f979e = 20;
        this.f980f = true;
        this.f981g = 0.0f;
        this.f982h = false;
        this.f983i = false;
        this.f999y = new Rect();
        this.f1000z = new Paint();
        this.f965A = new Paint();
        this.f974J = getContext().getResources().getDisplayMetrics().heightPixels;
        this.f975K = getContext().getResources().getDisplayMetrics().widthPixels;
        this.f984j = new Scroller(getContext());
        f964a = getResources().getDisplayMetrics().density * 10.0f;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, cgd.NumberScroller);
        setMaxScrollerNumber(Integer.valueOf(obtainStyledAttributes.getInteger(cgd.NumberScroller_maximum, 99)));
        setMinScrollerNumber(Integer.valueOf(obtainStyledAttributes.getInteger(cgd.NumberScroller_minimum, 0)));
        setSensitivity(obtainStyledAttributes.getInteger(cgd.NumberScroller_sesnitivity, 25));
        setActiveNumberColor(obtainStyledAttributes.getColor(cgd.NumberScroller_activeNumberColor, -16711681));
        this.f971G = obtainStyledAttributes.getColor(cgd.NumberScroller_colorBackground, -16777216);
        this.f972H = obtainStyledAttributes.getColor(cgd.NumberScroller_colorBorder, -16711681);
        this.f970F = obtainStyledAttributes.getColor(cgd.NumberScroller_nonActiveNumberColor, -1);
        if (getMaxScrollerNumber().intValue() < getMinScrollerNumber().intValue()) {
            int intValue = getMinScrollerNumber().intValue();
            setMinScrollerNumber(getMaxScrollerNumber());
            setMaxScrollerNumber(Integer.valueOf(intValue));
        }
        this.f998x = obtainStyledAttributes.getFloat(cgd.NumberScroller_visibleNumbers, 5.0f);
        this.f973I = obtainStyledAttributes.getInt(cgd.NumberScroller_defaultValue, 0);
        obtainStyledAttributes.recycle();
        setOnTouchListener(this);
        m686a();
        setValue(this.f973I);
    }

    public int getCurrentNumber() {
        return (int) Math.round((((double) (this.f987m + (getHeight() / 2))) - ((double) (this.f989o / 2.0f))) / ((double) (-this.f989o)));
    }

    private void setCurrentNumber(int i) {
        m687a(i, 0.0d);
    }

    public int getValue() {
        this.f984j.forceFinished(true);
        return this.f969E.intValue();
    }

    public void setValue(int i) {
        if (i < getMinScrollerNumber().intValue()) {
            i = getMinScrollerNumber().intValue();
        }
        if (i > getMaxScrollerNumber().intValue()) {
            i = getMaxScrollerNumber().intValue();
        }
        this.f997w = Integer.valueOf(i);
        this.f984j.forceFinished(true);
        setCurrentNumber(i);
        m690b(this.f969E.intValue());
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouch(android.view.View r12, android.view.MotionEvent r13) {
        /*
        r11 = this;
        r10 = 1;
        r1 = 0;
        r11.f980f = r1;
        r9 = r13.getY();
        r0 = r11.f986l;
        r0 = r0 - r9;
        r2 = r13.getAction();
        switch(r2) {
            case 0: goto L_0x0018;
            case 1: goto L_0x0045;
            case 2: goto L_0x0020;
            default: goto L_0x0012;
        };
    L_0x0012:
        r11.f986l = r9;
        r11.invalidate();
    L_0x0017:
        return r10;
    L_0x0018:
        r11.f981g = r9;
        r0 = r11.f984j;
        r0.forceFinished(r10);
        goto L_0x0012;
    L_0x0020:
        r2 = 0;
        r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
        if (r2 == 0) goto L_0x0017;
    L_0x0025:
        r11.f982h = r10;
        r2 = r11.f987m;
        r2 = (float) r2;
        r0 = r0 + r2;
        r0 = (int) r0;
        r11.f987m = r0;
        r0 = r11.f987m;
        r11.scrollTo(r1, r0);
        r0 = r11.f983i;
        if (r0 != 0) goto L_0x003f;
    L_0x0037:
        r0 = android.view.VelocityTracker.obtain();
        r11.f985k = r0;
        r11.f983i = r10;
    L_0x003f:
        r0 = r11.f985k;
        r0.addMovement(r13);
        goto L_0x0012;
    L_0x0045:
        r0 = r11.f981g;
        r0 = r0 - r9;
        r0 = java.lang.Math.abs(r0);
        r11.f981g = r0;
        r0 = new java.lang.StringBuilder;
        r2 = "Up ";
        r0.<init>(r2);
        r2 = r11.f981g;
        r0.append(r2);
        r0 = r11.f982h;
        if (r0 == 0) goto L_0x00b2;
    L_0x005e:
        r11.f982h = r1;
        r0 = r11.f985k;
        r0.addMovement(r13);
        r0 = r11.f985k;
        r2 = r11.getSensitivity();
        r3 = r11.f979e;
        r2 = r2 * r3;
        r0.computeCurrentVelocity(r2);
        r0 = r11.f985k;
        r0 = r0.getYVelocity();
        r11.f988n = r0;
        r0 = r11.f984j;
        r2 = r11.f987m;
        r3 = r11.f988n;
        r3 = (int) r3;
        r4 = -r3;
        r7 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r8 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        r3 = r1;
        r5 = r1;
        r6 = r1;
        r0.fling(r1, r2, r3, r4, r5, r6, r7, r8);
        r0 = new java.lang.StringBuilder;
        r2 = "Vel Y:";
        r0.<init>(r2);
        r2 = r11.f988n;
        r0.append(r2);
        r0 = r11.f988n;
        r0 = java.lang.Math.abs(r0);
        r2 = 1092616192; // 0x41200000 float:10.0 double:5.398241246E-315;
        r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
        if (r0 >= 0) goto L_0x00a7;
    L_0x00a4:
        r11.m689b();
    L_0x00a7:
        r0 = r11.f983i;
        if (r0 == 0) goto L_0x00b2;
    L_0x00ab:
        r0 = r11.f985k;
        r0.recycle();
        r11.f983i = r1;
    L_0x00b2:
        r0 = r11.f981g;
        r1 = 1101004800; // 0x41a00000 float:20.0 double:5.439686476E-315;
        r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1));
        if (r0 > 0) goto L_0x0012;
    L_0x00ba:
        r0 = new happy.hacking.cjg;
        r0.<init>(r11);
        r11.post(r0);
        goto L_0x0012;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.szyk.extras.ui.scroller.NumberScroller.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }

    private int getSensitivity() {
        return this.f967C;
    }

    public void setNumberChangedListener(cjh happy_hacking_cjh) {
        this.f968D = happy_hacking_cjh;
    }

    private Integer getMaxScrollerNumber() {
        return this.f990p;
    }

    public void setMaxScrollerNumber(Integer num) {
        this.f990p = num;
        m686a();
    }

    private Integer getMinScrollerNumber() {
        return this.f991q;
    }

    public void setMinScrollerNumber(Integer num) {
        this.f991q = num;
    }

    private int getActiveNumberColor() {
        return this.f966B;
    }

    public void setActiveNumberColor(int i) {
        this.f966B = i;
        invalidate();
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        new StringBuilder("size: ").append(i).append(" ").append(i2);
        m692d();
        this.f984j.forceFinished(true);
        if (this.f969E != null) {
            setValue(this.f969E.intValue());
        } else if (this.f997w != null) {
            setValue(this.f997w.intValue());
        } else {
            setValue(getMinScrollerNumber().intValue());
        }
    }

    public void computeScroll() {
        if (this.f982h || this.f980f || Math.abs(this.f984j.getFinalY() - this.f987m) >= 10) {
            if (!(this.f982h || this.f984j.isFinished())) {
                this.f984j.computeScrollOffset();
                this.f987m = this.f984j.getCurrY();
                scrollTo(0, this.f987m);
            }
            if (!this.f980f) {
                return;
            }
            if (this.f984j.isFinished()) {
                this.f980f = false;
                return;
            } else {
                invalidate();
                return;
            }
        }
        m689b();
    }

    @SuppressLint({"DrawAllocation"})
    protected void onDraw(Canvas canvas) {
        Integer num;
        if (this.f969E != null) {
            num = this.f969E;
        } else {
            num = getMinScrollerNumber();
        }
        int intValue = num.intValue();
        this.f969E = Integer.valueOf(getCurrentNumber());
        int ceil = (int) Math.ceil((double) this.f998x);
        int intValue2 = this.f969E.intValue() - ceil;
        ceil += this.f969E.intValue();
        if (this.f991q.intValue() > intValue2) {
            intValue2 = this.f991q.intValue();
        }
        if (this.f990p.intValue() < ceil) {
            ceil = this.f990p.intValue();
        }
        while (intValue2 <= ceil) {
            if (intValue2 != this.f969E.intValue()) {
                m688a(canvas, intValue2, this.f992r);
            } else {
                m688a(canvas, intValue2, this.f993s);
            }
            intValue2++;
        }
        Integer num2 = this.f969E;
        if (num2.intValue() < getMinScrollerNumber().intValue()) {
            intValue2 = 1;
        } else {
            intValue2 = 0;
        }
        if (intValue2 != 0) {
            m687a(getMaxScrollerNumber().intValue(), (double) (((-this.f989o) / 2.0f) - (f964a / 2.0f)));
            if (!this.f982h) {
                m691c();
            }
        } else {
            if (num2.intValue() > getMaxScrollerNumber().intValue()) {
                intValue2 = 1;
            } else {
                intValue2 = 0;
            }
            if (intValue2 != 0) {
                m687a(getMinScrollerNumber().intValue(), (double) ((this.f989o / 2.0f) - (f964a / 2.0f)));
                if (!this.f982h) {
                    m691c();
                }
            }
        }
        if (!(this.f969E == null || intValue == this.f969E.intValue())) {
            m690b(this.f969E.intValue());
        }
        int visibleNumbersCount = getVisibleNumbersCount();
        float a = m684a(getMinScrollerNumber().intValue());
        for (intValue2 = 0; intValue2 < visibleNumbersCount; intValue2++) {
            a += this.f989o;
            canvas.drawText(this.f996v.format((long) (getMaxScrollerNumber().intValue() - intValue2)), this.f995u, a, this.f992r);
        }
        a = m684a(getMaxScrollerNumber().intValue());
        for (intValue2 = 0; intValue2 < visibleNumbersCount; intValue2++) {
            a -= this.f989o;
            canvas.drawText(this.f996v.format((long) (getMinScrollerNumber().intValue() + intValue2)), this.f995u, a, this.f992r);
        }
        canvas.getClipBounds(this.f999y);
        Shader linearGradient = new LinearGradient(0.0f, (float) (this.f999y.top + (getHeight() / 2)), 0.0f, (float) this.f999y.bottom, 0, this.f971G, TileMode.CLAMP);
        Shader linearGradient2 = new LinearGradient(0.0f, (float) this.f999y.top, 0.0f, (float) (this.f999y.top + (getHeight() / 2)), this.f971G, 0, TileMode.CLAMP);
        Paint paint = this.f994t;
        Rect clipBounds = canvas.getClipBounds();
        getDrawingRect(new Rect());
        canvas.drawLine(0.0f, (float) clipBounds.top, 0.0f, (float) clipBounds.bottom, paint);
        canvas.drawLine((float) (getWidth() - 1), (float) clipBounds.top, (float) (getWidth() - 1), (float) clipBounds.bottom, paint);
        canvas.drawLine(0.0f, (float) clipBounds.top, (float) (getWidth() - 1), (float) clipBounds.top, paint);
        canvas.drawLine(0.0f, (float) (clipBounds.bottom - 1), (float) (getWidth() - 1), (float) (clipBounds.bottom - 1), paint);
        this.f1000z.setShader(linearGradient2);
        canvas.drawRect(this.f999y, this.f1000z);
        this.f965A.setShader(linearGradient);
        canvas.drawRect(this.f999y, this.f965A);
    }

    public Parcelable onSaveInstanceState() {
        Parcelable bundle = new Bundle();
        bundle.putParcelable("state", super.onSaveInstanceState());
        if (isShown()) {
            Integer num;
            if (this.f969E != null) {
                num = this.f969E;
            } else {
                num = Integer.valueOf(getValue());
            }
            this.f997w = num;
        }
        bundle.putInt("savedNumber", this.f997w.intValue());
        return bundle;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof Bundle) {
            Bundle bundle = (Bundle) parcelable;
            int i = bundle.getInt("savedNumber");
            if (i >= getMinScrollerNumber().intValue() && i <= getMaxScrollerNumber().intValue()) {
                setValue(i);
                super.onRestoreInstanceState(bundle.getParcelable("state"));
                return;
            }
        }
        super.onRestoreInstanceState(parcelable);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
    }

    protected void onMeasure(int i, int i2) {
        setMeasuredDimension(Math.min(MeasureSpec.getSize(i), this.f975K), Math.min(MeasureSpec.getSize(i2), this.f974J));
        m692d();
    }

    private void m686a() {
        this.f996v = new DecimalFormat();
        this.f996v.setMinimumIntegerDigits(getMaxScrollerNumber().toString().length());
        this.f996v.setMinimumFractionDigits(0);
    }

    private float m684a(int i) {
        return (-this.f989o) * ((float) i);
    }

    private void m687a(int i, double d) {
        this.f969E = Integer.valueOf(i);
        this.f987m = (int) (((((double) (((-this.f989o) * ((float) i)) - ((float) (getHeight() / 2)))) - ((double) ((this.f989o / 2.0f) - (f964a / 2.0f)))) + ((double) this.f989o)) + d);
        scrollTo(0, this.f987m);
    }

    private void m688a(Canvas canvas, int i, Paint paint) {
        Float valueOf = Float.valueOf(m684a(i));
        if (valueOf.floatValue() > ((float) this.f987m) && valueOf.floatValue() < ((float) (this.f987m + getHeight())) - this.f989o) {
            canvas.drawText(this.f996v.format((long) i), this.f995u, valueOf.floatValue(), paint);
        }
    }

    private void m690b(int i) {
        if (this.f968D != null && i >= getMinScrollerNumber().intValue() && i <= getMaxScrollerNumber().intValue()) {
            this.f968D.m4500a((float) i);
        }
    }

    private void m689b() {
        this.f980f = true;
        float height = (float) (this.f987m + (getHeight() / 2));
        float a = (m684a(getCurrentNumber()) + (this.f989o / 2.0f)) + (f964a / 2.0f);
        this.f984j.forceFinished(true);
        this.f984j.startScroll(0, this.f987m, 0, (int) (a - height), 1000);
        invalidate();
    }

    private void m691c() {
        this.f984j.fling(0, this.f987m, 0, -((int) (this.f988n - (((((386.0878f * getContext().getResources().getDisplayMetrics().density) * 160.0f) * ViewConfiguration.getScrollFriction()) * ((float) this.f984j.timePassed())) / 2000.0f))), 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    private void m692d() {
        this.f992r = new Paint();
        Paint paint = this.f992r;
        paint.setTextSize(100.0f);
        float ascent = ((paint.ascent() != 0.0f ? ((float) (-getHeight())) / paint.ascent() : 1.0f) * 100.0f) / this.f998x;
        float width = ((((float) getWidth()) * 0.9f) * 100.0f) / ((float) m685a(100.0f));
        if (ascent > width) {
            ascent = width;
        }
        paint.setTextSize(ascent);
        this.f995u = (float) ((getWidth() - m685a(ascent)) / 2);
        this.f992r.setColor(this.f970F);
        this.f992r.setAntiAlias(true);
        Rect rect = new Rect();
        this.f992r.getTextBounds("0", 0, 1, rect);
        this.f989o = ((float) (rect.top - rect.bottom)) - f964a;
        this.f993s = new Paint(this.f992r);
        this.f993s.setColor(getActiveNumberColor());
        this.f993s.setAntiAlias(true);
        this.f994t = new Paint();
        this.f994t.setColor(this.f972H);
        this.f994t.setAntiAlias(false);
    }

    private int getVisibleNumbersCount() {
        return this.f989o != 0.0f ? Math.round(((float) getHeight()) / (-this.f989o)) : 0;
    }

    private int m685a(float f) {
        Paint paint = new Paint();
        paint.setTextSize(f);
        Rect rect = new Rect();
        Rect rect2 = new Rect();
        String format = this.f996v.format(getMaxScrollerNumber());
        String format2 = this.f996v.format(getMinScrollerNumber());
        paint.getTextBounds(format, 0, format.length(), rect);
        paint.getTextBounds(format2, 0, format2.length(), rect2);
        return Math.max(rect.right - rect.left, rect2.right - rect2.left);
    }

    public void setSensitivity(int i) {
        if (i > 0 || i <= 10) {
            this.f967C = i;
            this.f979e = (int) (((float) (i * 10)) * 0.1f);
            return;
        }
        throw new Exception("sensitivity value exceeds 1-10");
    }
}
