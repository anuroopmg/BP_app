package com.szyk.extras.ui;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

public class SwipeControlledViewPager extends ViewPager {
    private boolean f908c;

    public SwipeControlledViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f908c = true;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f908c && super.onInterceptTouchEvent(motionEvent);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        return this.f908c && super.onTouchEvent(motionEvent);
    }

    public void setSwipeEnabled(boolean z) {
        this.f908c = z;
    }
}
