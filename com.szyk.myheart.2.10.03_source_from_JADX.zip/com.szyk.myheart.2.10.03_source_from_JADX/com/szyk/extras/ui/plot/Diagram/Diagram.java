package com.szyk.extras.ui.plot.Diagram;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import happy.hacking.cfz;
import happy.hacking.cga;
import happy.hacking.cgd;
import happy.hacking.cir;
import happy.hacking.cis;

public class Diagram extends FrameLayout {
    private DiagramDrawer f909a;
    private boolean f910b;
    private boolean f911c;
    private int f912d;
    private int f913e;

    public Diagram(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f911c = true;
        m642a(context);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, cgd.Diagram);
        setLegendOnLeft(obtainStyledAttributes.getBoolean(cgd.Diagram_isLegendOnLeft, false));
        obtainStyledAttributes.recycle();
    }

    public Diagram(Context context) {
        super(context);
        this.f911c = true;
        m642a(context);
    }

    public void setSizeInDpEnabled(boolean z) {
        this.f911c = z;
    }

    public void setLegendOnLeft(boolean z) {
        this.f910b = z;
    }

    private int getLegendTextSize() {
        return this.f912d;
    }

    public void setLegendTextSize(int i) {
        this.f912d = i;
    }

    public int getLegendColor() {
        return this.f913e;
    }

    public void setLegendColor(int i) {
        this.f913e = i;
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    private void m642a(Context context) {
        inflate(context, cga.diagram_layout, this);
        this.f909a = getDiagramDrawer();
    }

    private View getLabelLayout() {
        int i;
        if (this.f911c) {
            i = cga.diagram_label;
        } else {
            i = cga.diagram_label_pdf;
        }
        return inflate(getContext(), i, null);
    }

    private DiagramDrawer getDiagramDrawer() {
        return (DiagramDrawer) findViewById(cfz.diagramDrawer);
    }

    public final void m643a(cir happy_hacking_cir) {
        LinearLayout linearLayout;
        float f = happy_hacking_cir.f4285a;
        CharSequence charSequence = happy_hacking_cir.f4286b;
        int i = happy_hacking_cir.f4287c;
        DiagramDrawer diagramDrawer = this.f909a;
        diagramDrawer.f914a.add(new cis(diagramDrawer, f, charSequence, i));
        diagramDrawer.invalidate();
        View labelLayout = getLabelLayout();
        TextView textView = (TextView) labelLayout.findViewById(cfz.label_text);
        ImageView imageView = (ImageView) labelLayout.findViewById(cfz.label_image);
        textView.setText(charSequence);
        if (getLegendTextSize() > 0) {
            textView.setTextSize((float) getLegendTextSize());
        }
        if (this.f913e != 0) {
            textView.setTextColor(this.f913e);
        }
        imageView.setBackgroundColor(i);
        if (this.f910b) {
            linearLayout = (LinearLayout) findViewById(cfz.diagram_label_layout_left);
        } else {
            linearLayout = (LinearLayout) findViewById(cfz.diagram_label_layout_bottom);
        }
        linearLayout.addView(labelLayout);
    }
}
