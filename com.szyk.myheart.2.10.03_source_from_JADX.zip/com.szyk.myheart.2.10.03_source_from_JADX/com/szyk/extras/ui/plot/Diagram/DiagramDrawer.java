package com.szyk.extras.ui.plot.Diagram;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import happy.hacking.cis;
import java.util.ArrayList;
import java.util.List;

public class DiagramDrawer extends View {
    final List f914a;
    private final String f915b;

    public DiagramDrawer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f915b = "com.szyk.extras.ui.Diagram";
        this.f914a = new ArrayList();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float f = 0.0f;
        for (cis happy_hacking_cis : this.f914a) {
            f = happy_hacking_cis.f4288a.floatValue() + f;
        }
        float f2 = 0.0f;
        for (cis happy_hacking_cis2 : this.f914a) {
            float floatValue = (360.0f * happy_hacking_cis2.f4288a.floatValue()) / f;
            RectF rectF = new RectF();
            float min = (float) Math.min(getHeight(), getWidth());
            float width = ((float) (getWidth() / 2)) + (min / 2.0f);
            float height = ((float) (getHeight() / 2)) - (min / 2.0f);
            rectF.set(((float) (getWidth() / 2)) - (min / 2.0f), height, width, ((float) (getHeight() / 2)) + (min / 2.0f));
            canvas.drawArc(rectF, f2, floatValue, true, happy_hacking_cis2.f4289b);
            f2 += floatValue;
        }
    }
}
