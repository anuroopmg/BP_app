package com.szyk.extras.ui.plot.Graph;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader.TileMode;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnTouchListener;
import android.widget.SeekBar;
import happy.hacking.cja;
import happy.hacking.cjb;
import happy.hacking.cjc;
import happy.hacking.cjd;
import happy.hacking.cje;
import happy.hacking.cjf;
import happy.hacking.py;
import happy.hacking.ug;
import java.util.ArrayList;
import java.util.List;

public class Plotter extends View implements OnTouchListener {
    public SeekBar f952a;
    public final List f953b;
    int f954c;
    int f955d;
    private final cja f956e;
    private final cjd f957f;
    private float f958g;
    private float f959h;
    private boolean f960i;
    private boolean f961j;
    private float f962k;
    private float f963l;

    public Plotter(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f953b = new ArrayList();
        this.f957f = new cjd();
        this.f956e = new cja(this, this.f957f);
        getDrawer().f4311c = (float) getResources().getDisplayMetrics().heightPixels;
        getDrawer().f4312d = (float) getResources().getDisplayMetrics().widthPixels;
        setOnTouchListener(this);
    }

    public void setFixedDensity(float f) {
        cja drawer = getDrawer();
        drawer.f4319k = f;
        drawer.m4480a();
    }

    public final void m681a(cjc happy_hacking_cjc, boolean z) {
        this.f953b.add(happy_hacking_cjc);
        if (z) {
            setDrawingRange(happy_hacking_cjc.m4493b());
        }
        invalidate();
    }

    public List getItems() {
        return this.f953b;
    }

    public void setHeightCorrection(float f) {
        this.f959h = f;
    }

    final void m682a(cjf happy_hacking_cjf) {
        this.f957f.m4497a((float) happy_hacking_cjf.m4499a());
        float f = Float.MAX_VALUE;
        float f2 = 0.0f;
        for (cjc happy_hacking_cjc : this.f953b) {
            if (happy_hacking_cjc.f4343b && happy_hacking_cjc.m4493b() != null) {
                for (cje happy_hacking_cje : happy_hacking_cjc.m4493b()) {
                    f2 = Math.max(f2, happy_hacking_cje.f4355b);
                    f = Math.min(f, happy_hacking_cje.f4355b);
                }
            }
            f2 = f2;
            f = f;
        }
        cjd happy_hacking_cjd = this.f957f;
        if (happy_hacking_cjd.f4353f != 0.0f) {
            f -= f % happy_hacking_cjd.f4353f;
        }
        happy_hacking_cjd.f4352e = f;
        happy_hacking_cjd = this.f957f;
        if (happy_hacking_cjd.f4353f != 0.0f) {
            f2 = happy_hacking_cjd.f4353f + (f2 - (f2 % happy_hacking_cjd.f4353f));
        }
        happy_hacking_cjd.f4351d = f2;
        cja drawer = getDrawer();
        drawer.m4485a((Paint) drawer.f4315g.get(cjb.LABEL));
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (!this.f960i) {
            return false;
        }
        float x = motionEvent.getX();
        float f = this.f958g - x;
        switch (motionEvent.getAction()) {
            case ug.RecyclerView_spanCount /*2*/:
                cja drawer = getDrawer();
                cjf happy_hacking_cjf = drawer.f4317i;
                double d = (double) (1.0f / drawer.f4318j.f4348a);
                happy_hacking_cjf.f4357a = (long) (((double) happy_hacking_cjf.f4357a) + (((double) f) * d));
                happy_hacking_cjf.f4358b = (long) ((d * ((double) f)) + ((double) happy_hacking_cjf.f4358b));
                break;
        }
        this.f958g = x;
        invalidate();
        return true;
    }

    public final void m680a(int i) {
        int i2 = (-i) + py.Theme_checkboxStyle;
        cjf happy_hacking_cjf = getDrawer().f4317i;
        long j = happy_hacking_cjf.f4358b - (((long) (i2 * 21)) * 3600000);
        long j2 = happy_hacking_cjf.f4358b;
        happy_hacking_cjf.f4357a = j;
        happy_hacking_cjf.f4358b = j2;
        m682a(happy_hacking_cjf);
        invalidate();
    }

    public void setTouchable(boolean z) {
        this.f960i = z;
    }

    public cja getDrawer() {
        return this.f956e;
    }

    public void setDrawMarkers(boolean z) {
        this.f961j = z;
    }

    private float getLineWidthNormal() {
        return this.f962k;
    }

    public void setLineWidthNormal(float f) {
        this.f962k = f;
    }

    public float getLineWidthTrend() {
        return this.f963l;
    }

    public void setLineWidthTrend(float f) {
        this.f963l = f;
    }

    public void setRoundBy(float f) {
        this.f957f.m4498b(f);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
    }

    protected void onMeasure(int i, int i2) {
        float f = this.f959h;
        cja drawer = getDrawer();
        f = ((float) MeasureSpec.getSize(i2)) - f;
        drawer.f4313e = f;
        drawer.f4318j.f4349b = f - (drawer.f4310b * 2.0f);
        cja drawer2 = getDrawer();
        float size = (float) MeasureSpec.getSize(i);
        drawer2.f4314f = size;
        drawer2.f4318j.f4350c = (size - drawer2.f4309a) - drawer2.f4316h;
        if (this.f952a != null) {
            m680a(this.f952a.getProgress());
        } else {
            m683a(this.f953b);
        }
        m682a(getDrawer().f4317i);
        setMeasuredDimension(MeasureSpec.getSize(i), (int) (((float) MeasureSpec.getSize(i2)) - this.f959h));
    }

    protected void onDraw(Canvas canvas) {
        Paint b;
        float f = (float) getRootView().getResources().getDisplayMetrics().widthPixels;
        float f2 = (float) getRootView().getResources().getDisplayMetrics().heightPixels;
        cja drawer = getDrawer();
        int i = this.f954c;
        int i2 = this.f955d;
        Paint paint = (Paint) drawer.f4315g.get(cjb.PLOT_BACKGROUND);
        if (paint == null) {
            b = drawer.m4487b();
        } else {
            b = paint;
        }
        b.setShader(new LinearGradient(0.0f, drawer.f4313e, 0.0f, 0.0f, i2, i, TileMode.CLAMP));
        canvas.drawRect(0.0f, 0.0f, f, f2, (Paint) drawer.f4315g.get(cjb.BACKGROUND));
        cja drawer2 = getDrawer();
        paint = (Paint) drawer2.f4315g.get(cjb.PLOT_BACKGROUND);
        Rect rect = new Rect();
        rect.left = (int) drawer2.f4309a;
        rect.right = (int) (drawer2.f4314f - drawer2.f4316h);
        rect.top = (int) drawer2.f4310b;
        rect.bottom = (int) (drawer2.f4313e - drawer2.f4310b);
        canvas.drawRect(rect, paint);
        getDrawer().m4484a(canvas, this.f957f.f4353f);
        cja drawer3 = getDrawer();
        Paint paint2 = (Paint) drawer3.f4315g.get(cjb.THIN);
        canvas.drawLine(drawer3.f4309a, drawer3.f4310b, drawer3.f4314f - drawer3.f4316h, drawer3.f4310b, paint2);
        canvas.drawLine(drawer3.f4314f - drawer3.f4316h, drawer3.f4310b, drawer3.f4314f - drawer3.f4316h, drawer3.f4313e - drawer3.f4310b, paint2);
        drawer3 = getDrawer();
        canvas.drawLine(drawer3.f4309a, drawer3.f4313e - drawer3.f4310b, drawer3.f4314f - drawer3.f4316h, drawer3.f4313e - drawer3.f4310b, (Paint) drawer3.f4315g.get(cjb.AXIS));
        drawer3.m4482a(0, canvas);
        canvas.drawLine(drawer3.f4309a, drawer3.f4310b, drawer3.f4309a, drawer3.f4313e - drawer3.f4310b, (Paint) drawer3.f4315g.get(cjb.AXIS));
        drawer3.m4482a(1, canvas);
        if (this.f953b != null) {
            for (cjc happy_hacking_cjc : this.f953b) {
                if (happy_hacking_cjc.f4343b && happy_hacking_cjc.m4493b() != null) {
                    if (getLineWidthNormal() != -1.0f) {
                        happy_hacking_cjc.m4492a().setStrokeWidth(getLineWidthNormal());
                    }
                    getDrawer().m4486a(happy_hacking_cjc.m4493b(), happy_hacking_cjc.m4492a(), canvas, this.f961j);
                }
            }
        }
        super.onDraw(canvas);
    }

    protected Parcelable onSaveInstanceState() {
        Parcelable bundle = new Bundle();
        bundle.putParcelable("state", super.onSaveInstanceState());
        if (this.f953b != null && this.f953b.size() > 0) {
            String[] strArr = new String[this.f953b.size()];
            boolean[] zArr = new boolean[this.f953b.size()];
            int i = 0;
            for (cjc happy_hacking_cjc : this.f953b) {
                strArr[i] = happy_hacking_cjc.f4342a;
                zArr[i] = happy_hacking_cjc.f4343b;
                i++;
            }
            bundle.putStringArray("ITEMS_NAME", strArr);
            bundle.putBooleanArray("ITEMS_ACTIVE", zArr);
        }
        long j = getDrawer().f4317i.f4357a;
        long j2 = getDrawer().f4317i.f4358b;
        bundle.putLong("START_TIME", j);
        bundle.putLong("END_TIME", j2);
        if (this.f952a != null) {
            bundle.putInt("SCALE", this.f952a.getProgress());
        }
        return bundle;
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof Bundle) {
            Bundle bundle = (Bundle) parcelable;
            long j = bundle.getLong("START_TIME");
            long j2 = bundle.getLong("END_TIME");
            String[] stringArray = bundle.getStringArray("ITEMS_NAME");
            boolean[] booleanArray = bundle.getBooleanArray("ITEMS_ACTIVE");
            int i = bundle.getInt("SCALE");
            getDrawer().f4317i.f4357a = j;
            getDrawer().f4317i.f4358b = j2;
            if (!(stringArray == null || this.f953b == null || stringArray.length != this.f953b.size())) {
                int i2 = 0;
                for (cjc happy_hacking_cjc : this.f953b) {
                    if (happy_hacking_cjc.f4342a.equals(stringArray[i2])) {
                        happy_hacking_cjc.f4343b = booleanArray[i2];
                    }
                    i2++;
                }
            }
            if (i != 0) {
                m680a(i);
                if (this.f952a != null) {
                    this.f952a.setProgress(i);
                }
            }
            super.onRestoreInstanceState(bundle.getParcelable("state"));
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    final void m683a(List list) {
        long j = 0;
        long j2 = Long.MAX_VALUE;
        int i = 0;
        for (cjc b : list) {
            int i2;
            List b2 = b.m4493b();
            if (b2 == null || b2.size() <= 1) {
                i2 = i;
            } else {
                j2 = Math.min(j2, ((cje) b2.get(0)).f4354a);
                j = Math.max(j, ((cje) b2.get(b2.size() - 1)).f4354a);
                i2 = 1;
            }
            i = i2;
        }
        if (i != 0) {
            getDrawer().m4483a(j2, j);
        }
    }

    private void setDrawingRange(List list) {
        if (list != null && list.size() > 1) {
            getDrawer().m4483a(((cje) list.get(0)).f4354a, ((cje) list.get(list.size() - 1)).f4354a);
        }
    }
}
