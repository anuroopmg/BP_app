package com.szyk.extras.ui.plot.Graph;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import happy.hacking.cgd;
import happy.hacking.cit;
import happy.hacking.ciu;
import happy.hacking.civ;
import happy.hacking.ciw;
import happy.hacking.cix;
import happy.hacking.ciy;
import happy.hacking.ciz;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CategoryGraph extends View {
    private int f916A;
    private float f917B;
    private Paint f918C;
    private Paint f919D;
    private float f920E;
    private String f921F;
    private String f922G;
    private final float f923a;
    private ciz f924b;
    private cit f925c;
    private ciw f926d;
    private ciu f927e;
    private cix f928f;
    private float f929g;
    private float f930h;
    private float f931i;
    private Paint f932j;
    private Paint f933k;
    private float f934l;
    private int f935m;
    private int f936n;
    private int f937o;
    private int f938p;
    private int f939q;
    private int f940r;
    private List f941s;
    private float f942t;
    private float f943u;
    private List f944v;
    private List f945w;
    private int f946x;
    private int f947y;
    private int f948z;

    public CategoryGraph(Context context) {
        super(context);
        this.f937o = 100;
        this.f938p = 100;
        this.f946x = -16777216;
        this.f947y = Color.argb(123, 0, 0, 0);
        this.f948z = -7829368;
        this.f916A = -7829368;
        this.f923a = 1.0f;
        m647a();
    }

    public CategoryGraph(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f937o = 100;
        this.f938p = 100;
        this.f946x = -16777216;
        this.f947y = Color.argb(123, 0, 0, 0);
        this.f948z = -7829368;
        this.f916A = -7829368;
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, cgd.CategoryGraph);
        this.f946x = obtainStyledAttributes.getColor(cgd.CategoryGraph_axisColor, 4095);
        this.f948z = obtainStyledAttributes.getColor(cgd.CategoryGraph_gridColor, 4095);
        this.f916A = obtainStyledAttributes.getColor(cgd.CategoryGraph_labelColor, 4095);
        this.f947y = obtainStyledAttributes.getColor(cgd.CategoryGraph_dotColor, 4095);
        this.f921F = obtainStyledAttributes.getString(cgd.CategoryGraph_axisXlabel);
        this.f922G = obtainStyledAttributes.getString(cgd.CategoryGraph_axisYlabel);
        obtainStyledAttributes.recycle();
        this.f923a = context.getResources().getDisplayMetrics().density;
        m647a();
    }

    private void m647a() {
        this.f924b = new ciz(this);
        this.f925c = new cit(this, this.f921F, this.f922G);
        this.f926d = new ciw(this);
        this.f927e = new ciu();
        this.f928f = new cix();
        this.f941s = new ArrayList();
        this.f933k = new Paint();
        this.f933k.setAntiAlias(true);
        this.f933k.setTextSize(this.f923a * 8.0f);
        this.f933k.setStrokeWidth(this.f923a * 3.0f);
        this.f933k.setColor(this.f946x);
        this.f933k.setStyle(Style.STROKE);
        this.f918C = new Paint();
        this.f918C.setAntiAlias(true);
        this.f918C.setTextSize(this.f923a * 10.0f);
        this.f918C.setStrokeWidth(this.f923a * 0.5f);
        this.f918C.setColor(this.f916A);
        this.f918C.setStyle(Style.FILL_AND_STROKE);
        this.f919D = new Paint();
        this.f919D.setAntiAlias(true);
        this.f919D.setStrokeWidth(this.f923a * 0.5f);
        this.f919D.setColor(this.f948z);
        this.f919D.setStyle(Style.STROKE);
        this.f917B = this.f923a * 2.0f;
        this.f935m = (int) Math.ceil((double) (15.0f * this.f923a));
        this.f936n = (int) Math.ceil((double) (4.0f * this.f923a));
        this.f942t = 12.0f * this.f923a;
        this.f943u = 5.0f * this.f923a;
        this.f920E = this.f923a * 2.0f;
        this.f929g = (((this.f923a + ((float) m652c(Integer.valueOf(888).toString(), this.f932j))) + this.f942t) + this.f943u) + this.f920E;
        this.f934l = (float) this.f935m;
        this.f930h = ((this.f942t + this.f943u) + this.f920E) + this.f923a;
        this.f931i = (float) this.f935m;
    }

    public final void m674a(ciy happy_hacking_ciy) {
        this.f941s.add(happy_hacking_ciy);
        invalidate();
    }

    public void setDataRange(List list) {
        Collections.sort(list);
        this.f944v = list;
    }

    public void setData(List list) {
        this.f945w = list;
        int i = Integer.MAX_VALUE;
        int i2 = 0;
        int i3 = 0;
        int i4 = Integer.MAX_VALUE;
        for (Point point : this.f945w) {
            i3 = Math.max(i3, point.x);
            i2 = Math.max(i2, point.y);
            i4 = Math.min(i4, point.x);
            i = Math.min(i, point.y);
        }
        setMaxX(i3 + 5);
        setMaxY(i2 + 5);
        setMinX(i4 - 5);
        setMinY(i - 5);
    }

    private void setMaxX(int i) {
        this.f937o = i;
    }

    private void setMaxY(int i) {
        this.f938p = i;
    }

    private void setMinY(int i) {
        this.f939q = i;
    }

    private void setMinX(int i) {
        this.f940r = i;
    }

    protected void onDraw(Canvas canvas) {
        ciw happy_hacking_ciw = this.f926d;
        if (happy_hacking_ciw.f4302b.f944v != null) {
            for (civ happy_hacking_civ : happy_hacking_ciw.f4302b.f944v) {
                Rect rect = new Rect();
                rect.left = (int) happy_hacking_ciw.f4302b.f929g;
                rect.right = (int) Math.min((float) ((int) (happy_hacking_ciw.f4302b.f929g + (((float) (happy_hacking_civ.f4299d - happy_hacking_ciw.f4302b.f940r)) * happy_hacking_ciw.f4302b.getUnitX()))), ((float) happy_hacking_ciw.f4302b.getWidth()) - happy_hacking_ciw.f4302b.f934l);
                rect.top = (int) Math.max((float) ((int) ((((float) happy_hacking_ciw.f4302b.getHeight()) - happy_hacking_ciw.f4302b.f930h) - (((float) (happy_hacking_civ.f4297b - happy_hacking_ciw.f4302b.f939q)) * happy_hacking_ciw.f4302b.getUnitY()))), happy_hacking_ciw.f4302b.f931i);
                rect.bottom = (int) (((float) happy_hacking_ciw.f4302b.getHeight()) - happy_hacking_ciw.f4302b.f930h);
                happy_hacking_ciw.f4301a.setColor(happy_hacking_civ.f4300e);
                canvas.drawRect(rect, happy_hacking_ciw.f4301a);
            }
        }
        cit happy_hacking_cit = this.f925c;
        canvas.drawLine(happy_hacking_cit.f4294c.f929g, ((float) happy_hacking_cit.f4294c.getHeight()) - happy_hacking_cit.f4294c.f930h, ((float) happy_hacking_cit.f4294c.getWidth()) - happy_hacking_cit.f4294c.f934l, ((float) happy_hacking_cit.f4294c.getHeight()) - happy_hacking_cit.f4294c.f930h, happy_hacking_cit.f4294c.f932j);
        happy_hacking_cit.m4465a(0, canvas);
        canvas.drawLine(happy_hacking_cit.f4294c.f929g, happy_hacking_cit.f4294c.f931i, happy_hacking_cit.f4294c.f929g, ((float) happy_hacking_cit.f4294c.getHeight()) - happy_hacking_cit.f4294c.f930h, happy_hacking_cit.f4294c.f932j);
        happy_hacking_cit.m4465a(1, canvas);
        if (happy_hacking_cit.f4293b != null) {
            canvas.drawText(happy_hacking_cit.f4293b, happy_hacking_cit.f4294c.f929g + happy_hacking_cit.f4294c.f920E, happy_hacking_cit.f4294c.f931i + ((float) happy_hacking_cit.f4294c.f935m), happy_hacking_cit.f4294c.f932j);
        }
        if (happy_hacking_cit.f4292a != null) {
            canvas.drawText(happy_hacking_cit.f4292a, ((((float) happy_hacking_cit.f4294c.getWidth()) - happy_hacking_cit.f4294c.f934l) - ((float) happy_hacking_cit.f4294c.f935m)) - ((float) m652c(happy_hacking_cit.f4292a, happy_hacking_cit.f4294c.f932j)), (((float) happy_hacking_cit.f4294c.getHeight()) - happy_hacking_cit.f4294c.f930h) - happy_hacking_cit.f4294c.f920E, happy_hacking_cit.f4294c.f932j);
        }
        cix happy_hacking_cix = this.f928f;
        happy_hacking_cix.m4467a(canvas);
        happy_hacking_cix.m4468b(canvas);
        m648a(canvas);
        this.f927e.m4466a(canvas);
    }

    private static int m652c(String str, Paint paint) {
        Rect rect = new Rect();
        paint.getTextBounds(str, 0, str.length(), rect);
        return rect.right - rect.left;
    }

    private void m648a(Canvas canvas) {
        for (ciy happy_hacking_ciy : this.f941s) {
            ciz happy_hacking_ciz = this.f924b;
            if (happy_hacking_ciz.f4308b.f940r < happy_hacking_ciy.f4305b && happy_hacking_ciz.f4308b.f939q < happy_hacking_ciy.f4304a) {
                float unitX = happy_hacking_ciz.f4308b.getUnitX();
                float unitY = happy_hacking_ciz.f4308b.getUnitY();
                unitX = (unitX * ((float) (happy_hacking_ciy.f4305b - happy_hacking_ciz.f4308b.f940r))) + happy_hacking_ciz.f4308b.f929g;
                float height = ((float) happy_hacking_ciz.f4308b.getHeight()) - happy_hacking_ciz.f4308b.f930h;
                float f = happy_hacking_ciz.f4308b.f929g;
                unitY = (((float) happy_hacking_ciz.f4308b.getHeight()) - happy_hacking_ciz.f4308b.f930h) - (unitY * ((float) (happy_hacking_ciy.f4304a - happy_hacking_ciz.f4308b.f939q)));
                Path path = new Path();
                path.moveTo(unitX, height);
                path.lineTo(unitX, unitY);
                path.lineTo(f, unitY);
                canvas.drawPath(path, happy_hacking_ciz.f4307a);
                path = new Path();
                path.moveTo(unitX, happy_hacking_ciz.f4308b.f943u + height);
                path.lineTo(unitX, height - happy_hacking_ciz.f4308b.f943u);
                canvas.drawPath(path, happy_hacking_ciz.f4308b.f933k);
                if (happy_hacking_ciy.f4306c != null) {
                    happy_hacking_ciy.f4306c.setBounds((int) (unitX - (happy_hacking_ciz.f4308b.f942t / 2.0f)), (int) ((happy_hacking_ciz.f4308b.f943u + height) + happy_hacking_ciz.f4308b.f920E), (int) (unitX + (happy_hacking_ciz.f4308b.f942t / 2.0f)), (int) (((height + happy_hacking_ciz.f4308b.f942t) + happy_hacking_ciz.f4308b.f943u) + happy_hacking_ciz.f4308b.f920E));
                    happy_hacking_ciy.f4306c.setColorFilter(happy_hacking_ciz.f4308b.f916A, Mode.SRC_ATOP);
                    happy_hacking_ciy.f4306c.draw(canvas);
                }
                Path path2 = new Path();
                path2.moveTo(happy_hacking_ciz.f4308b.f943u + f, unitY);
                path2.lineTo(f - happy_hacking_ciz.f4308b.f943u, unitY);
                canvas.drawPath(path2, happy_hacking_ciz.f4308b.f933k);
                if (happy_hacking_ciy.f4306c != null) {
                    happy_hacking_ciy.f4306c.setBounds((int) (((f - happy_hacking_ciz.f4308b.f943u) - happy_hacking_ciz.f4308b.f942t) - happy_hacking_ciz.f4308b.f920E), (int) (unitY - (happy_hacking_ciz.f4308b.f942t / 2.0f)), (int) ((f - happy_hacking_ciz.f4308b.f943u) - happy_hacking_ciz.f4308b.f920E), (int) (unitY + (happy_hacking_ciz.f4308b.f942t / 2.0f)));
                    happy_hacking_ciy.f4306c.setColorFilter(happy_hacking_ciz.f4308b.f916A, Mode.SRC_ATOP);
                    happy_hacking_ciy.f4306c.draw(canvas);
                }
            }
        }
    }

    private float getUnitY() {
        return getDrawingHeight() / ((float) (this.f938p - this.f939q));
    }

    private float getDrawingHeight() {
        return ((((float) getHeight()) - this.f930h) - this.f931i) - ((float) this.f935m);
    }

    private float getUnitX() {
        return getDrawingWidth() / ((float) (this.f937o - this.f940r));
    }

    private float getDrawingWidth() {
        return ((((float) getWidth()) - this.f929g) - this.f934l) - ((float) this.f935m);
    }

    public static /* synthetic */ int m650b(String str, Paint paint) {
        Rect rect = new Rect();
        paint.getTextBounds(str, 0, str.length(), rect);
        return rect.bottom - rect.top;
    }
}
