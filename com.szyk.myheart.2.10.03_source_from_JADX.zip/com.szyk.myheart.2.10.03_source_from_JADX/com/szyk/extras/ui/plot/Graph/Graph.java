package com.szyk.extras.ui.plot.Graph;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import happy.hacking.cfz;
import happy.hacking.cga;
import happy.hacking.cgd;
import happy.hacking.cja;
import happy.hacking.cjb;
import happy.hacking.cjc;
import java.util.List;

public class Graph extends FrameLayout {
    private Plotter f949a;
    private boolean f950b;
    private float f951c;

    public Graph(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m675a();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, cgd.Plotter);
        setDrawLegend(obtainStyledAttributes.getBoolean(cgd.Plotter_drawLegend, true));
        float f = obtainStyledAttributes.getFloat(cgd.Plotter_roundYAxis, 1.0f);
        obtainStyledAttributes.recycle();
        this.f949a.setRoundBy(f);
        Plotter plotter = this.f949a;
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, cgd.Plotter);
        plotter.getDrawer().m4481a(obtainStyledAttributes2.getColor(cgd.Plotter_axisColor, -16777216));
        plotter.getDrawer().m4489c(obtainStyledAttributes2.getColor(cgd.Plotter_gridColor, -16777216));
        plotter.getDrawer().m4488b(obtainStyledAttributes2.getColor(cgd.Plotter_backgroundColor, -16759740));
        plotter.f954c = obtainStyledAttributes2.getColor(cgd.Plotter_plotBackgroundColor, 4095);
        plotter.f955d = obtainStyledAttributes2.getColor(cgd.Plotter_plotBackgroundColor_start, 4095);
        plotter.getDrawer().m4490d(obtainStyledAttributes2.getColor(cgd.Plotter_labelColor, -16777216));
        plotter.getDrawer().m4491e(obtainStyledAttributes2.getInt(cgd.Plotter_labelSize, 12));
        plotter.setLineWidthNormal(obtainStyledAttributes2.getDimension(cgd.Plotter_lineWidthNormal, -1.0f));
        plotter.setLineWidthTrend(obtainStyledAttributes2.getDimension(cgd.Plotter_lineWidthTrend, -1.0f));
        plotter.setDrawMarkers(obtainStyledAttributes2.getBoolean(cgd.Plotter_drawMarkers, true));
        plotter.setHeightCorrection(obtainStyledAttributes2.getDimension(cgd.Plotter_heightCorrection, 0.0f));
        plotter.setTouchable(obtainStyledAttributes2.getBoolean(cgd.Plotter_touchable, true));
        obtainStyledAttributes2.recycle();
        cja drawer = plotter.getDrawer();
        drawer.m4485a((Paint) drawer.f4315g.get(cjb.LABEL));
    }

    public Graph(Context context) {
        super(context);
        m675a();
    }

    public void setFixedDensity(float f) {
        getPlotter().setFixedDensity(f);
    }

    public final void m678a(String str, boolean z) {
        Plotter plotter = getPlotter();
        for (cjc happy_hacking_cjc : plotter.f953b) {
            if (happy_hacking_cjc.f4342a.equals(str)) {
                happy_hacking_cjc.f4343b = z;
                break;
            }
        }
        plotter.m682a(plotter.getDrawer().f4317i);
        plotter.invalidate();
    }

    public final void m679a(cjc... happy_hacking_cjcArr) {
        int i = 0;
        Plotter plotter = getPlotter();
        for (cjc a : happy_hacking_cjcArr) {
            plotter.m681a(a, false);
        }
        plotter.m683a(plotter.f953b);
        getLegend().removeAllViews();
        int length = happy_hacking_cjcArr.length;
        while (i < length) {
            m676a(happy_hacking_cjcArr[i]);
            i++;
        }
    }

    public final void m677a(cjc happy_hacking_cjc, boolean z) {
        getPlotter().m681a(happy_hacking_cjc, z);
        m676a(happy_hacking_cjc);
    }

    public List getItems() {
        return getPlotter().getItems();
    }

    public Plotter getPlotter() {
        return this.f949a;
    }

    public void setDrawLegend(boolean z) {
        this.f950b = z;
    }

    private float getLegendTextSize() {
        return this.f951c;
    }

    public void setLegendTextSize(float f) {
        this.f951c = f;
    }

    private void m675a() {
        inflate(getContext(), cga.graph_layout, this);
        this.f949a = (Plotter) findViewById(cfz.graph_plotter);
    }

    public LinearLayout getLegend() {
        return (LinearLayout) findViewById(cfz.graph_legend_layout);
    }

    private void m676a(cjc happy_hacking_cjc) {
        if (this.f950b) {
            CharSequence charSequence = happy_hacking_cjc.f4342a;
            int color = happy_hacking_cjc.m4492a().getColor();
            happy_hacking_cjc.m4492a().getColor();
            View inflate = inflate(getContext(), cga.graph_legend_item, null);
            TextView textView = (TextView) inflate.findViewById(cfz.legend_item_text);
            textView.setText(charSequence);
            textView.setTextColor(color);
            if (getLegendTextSize() > 0.0f) {
                textView.setTextSize(getLegendTextSize());
            }
            getLegend().addView(inflate);
        }
    }
}
