package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.amx;
import happy.hacking.amz;
import happy.hacking.aqw;
import happy.hacking.cbt;
import happy.hacking.cbu;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class GoogleSignInAccount implements SafeParcelable {
    public static final Creator CREATOR;
    public static cbt f796a;
    private static Comparator f797l;
    public final int f798b;
    public String f799c;
    public String f800d;
    public String f801e;
    public String f802f;
    public Uri f803g;
    public String f804h;
    public long f805i;
    public String f806j;
    public List f807k;

    static {
        CREATOR = new amz();
        f796a = cbu.m4074d();
        f797l = new amx();
    }

    public GoogleSignInAccount(int i, String str, String str2, String str3, String str4, Uri uri, String str5, long j, String str6, List list) {
        this.f798b = i;
        this.f799c = str;
        this.f800d = str2;
        this.f801e = str3;
        this.f802f = str4;
        this.f803g = uri;
        this.f804h = str5;
        this.f805i = j;
        this.f806j = str6;
        this.f807k = list;
    }

    public static GoogleSignInAccount m613a(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(str);
        Object optString = jSONObject.optString("photoUrl", null);
        Uri parse = !TextUtils.isEmpty(optString) ? Uri.parse(optString) : null;
        long parseLong = Long.parseLong(jSONObject.getString("expirationTime"));
        Object hashSet = new HashSet();
        JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
        int length = jSONArray.length();
        for (int i = 0; i < length; i++) {
            hashSet.add(new Scope(jSONArray.getString(i)));
        }
        String optString2 = jSONObject.optString("id");
        String optString3 = jSONObject.optString("tokenId", null);
        String optString4 = jSONObject.optString(NotificationCompatApi21.CATEGORY_EMAIL, null);
        String optString5 = jSONObject.optString("displayName", null);
        Long valueOf = Long.valueOf(parseLong);
        GoogleSignInAccount googleSignInAccount = new GoogleSignInAccount(2, optString2, optString3, optString4, optString5, parse, null, (valueOf == null ? Long.valueOf(f796a.m4071a() / 1000) : valueOf).longValue(), aqw.m2255a(jSONObject.getString("obfuscatedIdentifier")), new ArrayList((Collection) aqw.m2253a(hashSet)));
        googleSignInAccount.f804h = jSONObject.optString("serverAuthCode", null);
        return googleSignInAccount;
    }

    private JSONObject m614a() {
        JSONObject jSONObject = new JSONObject();
        try {
            if (this.f799c != null) {
                jSONObject.put("id", this.f799c);
            }
            if (this.f800d != null) {
                jSONObject.put("tokenId", this.f800d);
            }
            if (this.f801e != null) {
                jSONObject.put(NotificationCompatApi21.CATEGORY_EMAIL, this.f801e);
            }
            if (this.f802f != null) {
                jSONObject.put("displayName", this.f802f);
            }
            if (this.f803g != null) {
                jSONObject.put("photoUrl", this.f803g.toString());
            }
            if (this.f804h != null) {
                jSONObject.put("serverAuthCode", this.f804h);
            }
            jSONObject.put("expirationTime", this.f805i);
            jSONObject.put("obfuscatedIdentifier", this.f806j);
            JSONArray jSONArray = new JSONArray();
            Collections.sort(this.f807k, f797l);
            for (Scope scope : this.f807k) {
                jSONArray.put(scope.f821b);
            }
            jSONObject.put("grantedScopes", jSONArray);
            return jSONObject;
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        return !(obj instanceof GoogleSignInAccount) ? false : ((GoogleSignInAccount) obj).m614a().toString().equals(m614a().toString());
    }

    public void writeToParcel(Parcel parcel, int i) {
        amz.m1956a(this, parcel, i);
    }
}
