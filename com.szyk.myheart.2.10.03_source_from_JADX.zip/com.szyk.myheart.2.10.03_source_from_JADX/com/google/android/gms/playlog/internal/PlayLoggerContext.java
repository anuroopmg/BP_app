package com.google.android.gms.playlog.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aqu;
import happy.hacking.aqw;
import happy.hacking.ces;
import java.util.Arrays;

public class PlayLoggerContext implements SafeParcelable {
    public static final ces CREATOR;
    public final int f884a;
    public final String f885b;
    public final int f886c;
    public final int f887d;
    public final String f888e;
    public final String f889f;
    public final boolean f890g;
    public final String f891h;
    public final boolean f892i;
    public final int f893j;

    static {
        CREATOR = new ces();
    }

    public PlayLoggerContext(int i, String str, int i2, int i3, String str2, String str3, boolean z, String str4, boolean z2, int i4) {
        this.f884a = i;
        this.f885b = str;
        this.f886c = i2;
        this.f887d = i3;
        this.f888e = str2;
        this.f889f = str3;
        this.f890g = z;
        this.f891h = str4;
        this.f892i = z2;
        this.f893j = i4;
    }

    public PlayLoggerContext(String str, int i, int i2, String str2, String str3, String str4, boolean z, int i3) {
        this.f884a = 1;
        this.f885b = (String) aqw.m2253a((Object) str);
        this.f886c = i;
        this.f887d = i2;
        this.f891h = str2;
        this.f888e = str3;
        this.f889f = str4;
        this.f890g = !z;
        this.f892i = z;
        this.f893j = i3;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof PlayLoggerContext)) {
            return false;
        }
        PlayLoggerContext playLoggerContext = (PlayLoggerContext) obj;
        return this.f884a == playLoggerContext.f884a && this.f885b.equals(playLoggerContext.f885b) && this.f886c == playLoggerContext.f886c && this.f887d == playLoggerContext.f887d && aqu.m2251a(this.f891h, playLoggerContext.f891h) && aqu.m2251a(this.f888e, playLoggerContext.f888e) && aqu.m2251a(this.f889f, playLoggerContext.f889f) && this.f890g == playLoggerContext.f890g && this.f892i == playLoggerContext.f892i && this.f893j == playLoggerContext.f893j;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f884a), this.f885b, Integer.valueOf(this.f886c), Integer.valueOf(this.f887d), this.f891h, this.f888e, this.f889f, Boolean.valueOf(this.f890g), Boolean.valueOf(this.f892i), Integer.valueOf(this.f893j)});
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("PlayLoggerContext[");
        stringBuilder.append("versionCode=").append(this.f884a).append(',');
        stringBuilder.append("package=").append(this.f885b).append(',');
        stringBuilder.append("packageVersionCode=").append(this.f886c).append(',');
        stringBuilder.append("logSource=").append(this.f887d).append(',');
        stringBuilder.append("logSourceName=").append(this.f891h).append(',');
        stringBuilder.append("uploadAccount=").append(this.f888e).append(',');
        stringBuilder.append("loggingId=").append(this.f889f).append(',');
        stringBuilder.append("logAndroidId=").append(this.f890g).append(',');
        stringBuilder.append("isAnonymous=").append(this.f892i).append(',');
        stringBuilder.append("qosTier=").append(this.f893j);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        ces.m4263a(this, parcel);
    }
}
