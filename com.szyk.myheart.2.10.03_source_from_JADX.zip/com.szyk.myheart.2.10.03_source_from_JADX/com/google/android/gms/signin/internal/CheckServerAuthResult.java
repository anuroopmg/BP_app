package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.cfh;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public class CheckServerAuthResult implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f897a;
    public final boolean f898b;
    public final List f899c;

    static {
        CREATOR = new cfh();
    }

    public CheckServerAuthResult(int i, boolean z, List list) {
        this.f897a = i;
        this.f898b = z;
        this.f899c = list;
    }

    public CheckServerAuthResult(boolean z, Set set) {
        this(1, z, set == null ? Collections.emptyList() : Collections.unmodifiableList(new ArrayList(set)));
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        cfh.m4285a(this, parcel);
    }
}
