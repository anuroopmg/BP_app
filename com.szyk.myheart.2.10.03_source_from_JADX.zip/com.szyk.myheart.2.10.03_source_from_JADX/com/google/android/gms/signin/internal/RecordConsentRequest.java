package com.google.android.gms.signin.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.cfq;

public class RecordConsentRequest implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f900a;
    public final Account f901b;
    public final Scope[] f902c;
    public final String f903d;

    static {
        CREATOR = new cfq();
    }

    public RecordConsentRequest(int i, Account account, Scope[] scopeArr, String str) {
        this.f900a = i;
        this.f901b = account;
        this.f902c = scopeArr;
        this.f903d = str;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        cfq.m4311a(this, parcel, i);
    }
}
