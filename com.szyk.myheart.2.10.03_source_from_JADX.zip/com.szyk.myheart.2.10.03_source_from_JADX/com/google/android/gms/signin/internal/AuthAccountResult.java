package com.google.android.gms.signin.internal;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aof;
import happy.hacking.cff;

public class AuthAccountResult implements SafeParcelable, aof {
    public static final Creator CREATOR;
    public final int f894a;
    public int f895b;
    public Intent f896c;

    static {
        CREATOR = new cff();
    }

    public AuthAccountResult() {
        this(0);
    }

    public AuthAccountResult(int i) {
        this(2, i, null);
    }

    public AuthAccountResult(int i, int i2, Intent intent) {
        this.f894a = i;
        this.f895b = i2;
        this.f896c = intent;
    }

    public final Status m632a() {
        return this.f895b == 0 ? Status.f822a : Status.f826e;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        cff.m4284a(this, parcel, i);
    }
}
