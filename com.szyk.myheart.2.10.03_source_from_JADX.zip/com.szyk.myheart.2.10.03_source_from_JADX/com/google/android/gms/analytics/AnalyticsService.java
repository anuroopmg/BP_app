package com.google.android.gms.analytics;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import happy.hacking.aji;
import happy.hacking.akp;
import happy.hacking.akx;
import happy.hacking.alj;
import happy.hacking.aow;
import happy.hacking.aqw;
import happy.hacking.cdb;

public final class AnalyticsService extends Service {
    private static Boolean f791b;
    private final Handler f792a;

    public AnalyticsService() {
        this.f792a = new Handler();
    }

    public static boolean m612a(Context context) {
        aqw.m2253a((Object) context);
        if (f791b != null) {
            return f791b.booleanValue();
        }
        boolean a = akx.m1776a(context, AnalyticsService.class);
        f791b = Boolean.valueOf(a);
        return a;
    }

    public final IBinder onBind(Intent intent) {
        return null;
    }

    public final void onCreate() {
        super.onCreate();
        akp a = alj.m1802a((Context) this).m1805a();
        if (aow.f2076a) {
            a.m1669b("Device AnalyticsService is starting up");
        } else {
            a.m1669b("Local AnalyticsService is starting up");
        }
    }

    public final void onDestroy() {
        akp a = alj.m1802a((Context) this).m1805a();
        if (aow.f2076a) {
            a.m1669b("Device AnalyticsService is shutting down");
        } else {
            a.m1669b("Local AnalyticsService is shutting down");
        }
        super.onDestroy();
    }

    public final int onStartCommand(Intent intent, int i, int i2) {
        try {
            synchronized (AnalyticsReceiver.f788a) {
                cdb happy_hacking_cdb = AnalyticsReceiver.f789b;
                if (happy_hacking_cdb != null && happy_hacking_cdb.f4024a.isHeld()) {
                    happy_hacking_cdb.m4131b();
                }
            }
        } catch (SecurityException e) {
        }
        alj a = alj.m1802a((Context) this);
        akp a2 = a.m1805a();
        String action = intent.getAction();
        if (aow.f2076a) {
            a2.m1668a("Device AnalyticsService called. startId, action", Integer.valueOf(i2), action);
        } else {
            a2.m1668a("Local AnalyticsService called. startId, action", Integer.valueOf(i2), action);
        }
        if ("com.google.android.gms.analytics.ANALYTICS_DISPATCH".equals(action)) {
            a.m1807c().m1795a(new aji(this, i2, a, a2));
        }
        return 2;
    }
}
