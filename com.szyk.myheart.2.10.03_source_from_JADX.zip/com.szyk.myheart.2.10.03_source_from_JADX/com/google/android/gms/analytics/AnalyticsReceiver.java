package com.google.android.gms.analytics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import happy.hacking.akp;
import happy.hacking.akx;
import happy.hacking.alj;
import happy.hacking.aow;
import happy.hacking.aqw;
import happy.hacking.cdb;

public final class AnalyticsReceiver extends BroadcastReceiver {
    static Object f788a;
    static cdb f789b;
    static Boolean f790c;

    static {
        f788a = new Object();
    }

    public static boolean m610a(Context context) {
        aqw.m2253a((Object) context);
        if (f790c != null) {
            return f790c.booleanValue();
        }
        boolean a = akx.m1777a(context, AnalyticsReceiver.class, false);
        f790c = Boolean.valueOf(a);
        return a;
    }

    public final void onReceive(Context context, Intent intent) {
        akp a = alj.m1802a(context).m1805a();
        String action = intent.getAction();
        if (aow.f2076a) {
            a.m1667a("Device AnalyticsReceiver got", action);
        } else {
            a.m1667a("Local AnalyticsReceiver got", action);
        }
        if ("com.google.android.gms.analytics.ANALYTICS_DISPATCH".equals(action)) {
            boolean a2 = AnalyticsService.m612a(context);
            Intent intent2 = new Intent(context, AnalyticsService.class);
            intent2.setAction("com.google.android.gms.analytics.ANALYTICS_DISPATCH");
            synchronized (f788a) {
                context.startService(intent2);
                if (a2) {
                    try {
                        if (f789b == null) {
                            cdb happy_hacking_cdb = new cdb(context, "Analytics WakeLock", (byte) 0);
                            f789b = happy_hacking_cdb;
                            happy_hacking_cdb.m4132c();
                        }
                        f789b.m4130a();
                    } catch (SecurityException e) {
                        a.m1678e("Analytics service at risk of not starting. For more reliable analytics, add the WAKE_LOCK permission to your manifest. See http://goo.gl/8Rd3yj for instructions.");
                    }
                    return;
                }
            }
        }
    }
}
