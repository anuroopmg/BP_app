package com.google.android.gms.analytics.internal;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import happy.hacking.akg;

public class Command implements Parcelable {
    @Deprecated
    public static final Creator CREATOR;
    public String f793a;
    public String f794b;
    private String f795c;

    static {
        CREATOR = new akg();
    }

    @Deprecated
    public Command(Parcel parcel) {
        this.f793a = parcel.readString();
        this.f795c = parcel.readString();
        this.f794b = parcel.readString();
    }

    @Deprecated
    public int describeContents() {
        return 0;
    }

    @Deprecated
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f793a);
        parcel.writeString(this.f795c);
        parcel.writeString(this.f794b);
    }
}
