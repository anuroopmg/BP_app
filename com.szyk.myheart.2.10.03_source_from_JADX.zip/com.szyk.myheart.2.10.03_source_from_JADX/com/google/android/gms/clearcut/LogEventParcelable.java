package com.google.android.gms.clearcut;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.playlog.internal.PlayLoggerContext;
import happy.hacking.and;
import happy.hacking.ang;
import happy.hacking.aqt;
import happy.hacking.aqu;
import happy.hacking.cdt;
import java.util.Arrays;

public class LogEventParcelable implements SafeParcelable {
    public static final ang CREATOR;
    public final int f808a;
    public PlayLoggerContext f809b;
    public byte[] f810c;
    public int[] f811d;
    public final cdt f812e;
    public final and f813f;
    public final and f814g;

    static {
        CREATOR = new ang();
    }

    public LogEventParcelable(int i, PlayLoggerContext playLoggerContext, byte[] bArr, int[] iArr) {
        this.f808a = i;
        this.f809b = playLoggerContext;
        this.f810c = bArr;
        this.f811d = iArr;
        this.f812e = null;
        this.f813f = null;
        this.f814g = null;
    }

    public LogEventParcelable(PlayLoggerContext playLoggerContext, cdt happy_hacking_cdt, and happy_hacking_and, and happy_hacking_and2, int[] iArr) {
        this.f808a = 1;
        this.f809b = playLoggerContext;
        this.f812e = happy_hacking_cdt;
        this.f813f = happy_hacking_and;
        this.f814g = happy_hacking_and2;
        this.f811d = iArr;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LogEventParcelable)) {
            return false;
        }
        LogEventParcelable logEventParcelable = (LogEventParcelable) obj;
        return this.f808a == logEventParcelable.f808a && aqu.m2251a(this.f809b, logEventParcelable.f809b) && Arrays.equals(this.f810c, logEventParcelable.f810c) && Arrays.equals(this.f811d, logEventParcelable.f811d) && aqu.m2251a(this.f812e, logEventParcelable.f812e) && aqu.m2251a(this.f813f, logEventParcelable.f813f) && aqu.m2251a(this.f814g, logEventParcelable.f814g);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f808a), this.f809b, this.f810c, this.f811d, this.f812e, this.f813f, this.f814g});
    }

    public String toString() {
        String str = null;
        StringBuilder stringBuilder = new StringBuilder("LogEventParcelable[");
        stringBuilder.append(this.f808a);
        stringBuilder.append(", ");
        stringBuilder.append(this.f809b);
        stringBuilder.append(", ");
        stringBuilder.append(this.f810c == null ? null : new String(this.f810c));
        stringBuilder.append(", ");
        if (this.f811d != null) {
            str = new aqt(", ").m2249a(new StringBuilder(), Arrays.asList(new int[][]{this.f811d})).toString();
        }
        stringBuilder.append(str);
        stringBuilder.append(", ");
        stringBuilder.append(this.f812e);
        stringBuilder.append(", ");
        stringBuilder.append(this.f813f);
        stringBuilder.append(", ");
        stringBuilder.append(this.f814g);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        ang.m1976a(this, parcel, i);
    }
}
