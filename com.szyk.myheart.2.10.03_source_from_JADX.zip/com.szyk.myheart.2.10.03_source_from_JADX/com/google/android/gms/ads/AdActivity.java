package com.google.android.gms.ads;

import android.app.Activity;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import happy.hacking.ahd;
import happy.hacking.bqo;
import happy.hacking.bqq;

public class AdActivity extends Activity {
    private bqq f626a;

    private void m598a() {
        if (this.f626a != null) {
            try {
                this.f626a.m1116l();
            } catch (RemoteException e) {
                ahd.m1384a(5);
            }
        }
    }

    public void onBackPressed() {
        boolean z = true;
        try {
            if (this.f626a != null) {
                z = this.f626a.m1109e();
            }
        } catch (RemoteException e) {
            ahd.m1384a(5);
        }
        if (z) {
            super.onBackPressed();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f626a = bqo.m3292a((Activity) this);
        if (this.f626a == null) {
            ahd.m1384a(5);
            finish();
            return;
        }
        try {
            this.f626a.m1106a(bundle);
        } catch (RemoteException e) {
            ahd.m1384a(5);
            finish();
        }
    }

    protected void onDestroy() {
        try {
            if (this.f626a != null) {
                this.f626a.m1115k();
            }
        } catch (RemoteException e) {
            ahd.m1384a(5);
        }
        super.onDestroy();
    }

    protected void onPause() {
        try {
            if (this.f626a != null) {
                this.f626a.m1113i();
            }
        } catch (RemoteException e) {
            ahd.m1384a(5);
            finish();
        }
        super.onPause();
    }

    protected void onRestart() {
        super.onRestart();
        try {
            if (this.f626a != null) {
                this.f626a.m1110f();
            }
        } catch (RemoteException e) {
            ahd.m1384a(5);
            finish();
        }
    }

    protected void onResume() {
        super.onResume();
        try {
            if (this.f626a != null) {
                this.f626a.m1112h();
            }
        } catch (RemoteException e) {
            ahd.m1384a(5);
            finish();
        }
    }

    protected void onSaveInstanceState(Bundle bundle) {
        try {
            if (this.f626a != null) {
                this.f626a.m1107b(bundle);
            }
        } catch (RemoteException e) {
            ahd.m1384a(5);
            finish();
        }
        super.onSaveInstanceState(bundle);
    }

    protected void onStart() {
        super.onStart();
        try {
            if (this.f626a != null) {
                this.f626a.m1111g();
            }
        } catch (RemoteException e) {
            ahd.m1384a(5);
            finish();
        }
    }

    protected void onStop() {
        try {
            if (this.f626a != null) {
                this.f626a.m1114j();
            }
        } catch (RemoteException e) {
            ahd.m1384a(5);
            finish();
        }
        super.onStop();
    }

    public void setContentView(int i) {
        super.setContentView(i);
        m598a();
    }

    public void setContentView(View view) {
        super.setContentView(view);
        m598a();
    }

    public void setContentView(View view, LayoutParams layoutParams) {
        super.setContentView(view, layoutParams);
        m598a();
    }
}
