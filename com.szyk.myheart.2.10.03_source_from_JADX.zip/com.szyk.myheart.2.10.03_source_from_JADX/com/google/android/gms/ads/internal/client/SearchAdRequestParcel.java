package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.abl;
import happy.hacking.ajf;
import happy.hacking.btf;

@btf
public final class SearchAdRequestParcel implements SafeParcelable {
    public static final abl CREATOR;
    public final int f662a;
    public final int f663b;
    public final int f664c;
    public final int f665d;
    public final int f666e;
    public final int f667f;
    public final int f668g;
    public final int f669h;
    public final int f670i;
    public final String f671j;
    public final int f672k;
    public final String f673l;
    public final int f674m;
    public final int f675n;
    public final String f676o;

    static {
        CREATOR = new abl();
    }

    public SearchAdRequestParcel(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, String str, int i10, String str2, int i11, int i12, String str3) {
        this.f662a = i;
        this.f663b = i2;
        this.f664c = i3;
        this.f665d = i4;
        this.f666e = i5;
        this.f667f = i6;
        this.f668g = i7;
        this.f669h = i8;
        this.f670i = i9;
        this.f671j = str;
        this.f672k = i10;
        this.f673l = str2;
        this.f674m = i11;
        this.f675n = i12;
        this.f676o = str3;
    }

    public SearchAdRequestParcel(ajf happy_hacking_ajf) {
        this.f662a = 1;
        this.f663b = happy_hacking_ajf.f1687b;
        this.f664c = happy_hacking_ajf.f1688c;
        this.f665d = happy_hacking_ajf.f1689d;
        this.f666e = happy_hacking_ajf.f1690e;
        this.f667f = happy_hacking_ajf.f1691f;
        this.f668g = happy_hacking_ajf.f1692g;
        this.f669h = happy_hacking_ajf.f1693h;
        this.f670i = happy_hacking_ajf.f1694i;
        this.f671j = happy_hacking_ajf.f1695j;
        this.f672k = happy_hacking_ajf.f1696k;
        this.f673l = happy_hacking_ajf.f1697l;
        this.f674m = happy_hacking_ajf.f1698m;
        this.f675n = happy_hacking_ajf.f1699n;
        this.f676o = happy_hacking_ajf.f1700o;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        abl.m870a(this, parcel);
    }
}
