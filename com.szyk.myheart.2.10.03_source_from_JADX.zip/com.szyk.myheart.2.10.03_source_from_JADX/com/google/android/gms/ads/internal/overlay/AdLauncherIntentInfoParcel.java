package com.google.android.gms.ads.internal.overlay;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.ado;
import happy.hacking.btf;

@btf
public final class AdLauncherIntentInfoParcel implements SafeParcelable {
    public static final ado CREATOR;
    public final int f681a;
    public final String f682b;
    public final String f683c;
    public final String f684d;
    public final String f685e;
    public final String f686f;
    public final String f687g;
    public final String f688h;

    static {
        CREATOR = new ado();
    }

    public AdLauncherIntentInfoParcel(int i, String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this.f681a = i;
        this.f682b = str;
        this.f683c = str2;
        this.f684d = str3;
        this.f685e = str4;
        this.f686f = str5;
        this.f687g = str6;
        this.f688h = str7;
    }

    public AdLauncherIntentInfoParcel(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this(1, str, str2, str3, str4, str5, str6, str7);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        ado.m1076a(this, parcel);
    }
}
