package com.google.android.gms.ads.internal.purchase;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aer;
import happy.hacking.afd;
import happy.hacking.afe;
import happy.hacking.bee;
import happy.hacking.beg;
import happy.hacking.bre;
import happy.hacking.btf;

@btf
public final class GInAppPurchaseManagerInfoParcel implements SafeParcelable {
    public static final aer CREATOR;
    public final int f706a;
    public final afe f707b;
    public final bre f708c;
    public final Context f709d;
    public final afd f710e;

    static {
        CREATOR = new aer();
    }

    public GInAppPurchaseManagerInfoParcel(int i, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, IBinder iBinder4) {
        this.f706a = i;
        this.f707b = (afe) beg.m2520a(bee.m2518a(iBinder));
        this.f708c = (bre) beg.m2520a(bee.m2518a(iBinder2));
        this.f709d = (Context) beg.m2520a(bee.m2518a(iBinder3));
        this.f710e = (afd) beg.m2520a(bee.m2518a(iBinder4));
    }

    public GInAppPurchaseManagerInfoParcel(Context context, afe happy_hacking_afe, bre happy_hacking_bre, afd happy_hacking_afd) {
        this.f706a = 2;
        this.f709d = context;
        this.f707b = happy_hacking_afe;
        this.f708c = happy_hacking_bre;
        this.f710e = happy_hacking_afd;
    }

    public static GInAppPurchaseManagerInfoParcel m606a(Intent intent) {
        try {
            Bundle bundleExtra = intent.getBundleExtra("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo");
            bundleExtra.setClassLoader(GInAppPurchaseManagerInfoParcel.class.getClassLoader());
            return (GInAppPurchaseManagerInfoParcel) bundleExtra.getParcelable("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo");
        } catch (Exception e) {
            return null;
        }
    }

    public static void m607a(Intent intent, GInAppPurchaseManagerInfoParcel gInAppPurchaseManagerInfoParcel) {
        Bundle bundle = new Bundle(1);
        bundle.putParcelable("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo", gInAppPurchaseManagerInfoParcel);
        intent.putExtra("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo", bundle);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        aer.m1179a(this, parcel);
    }
}
