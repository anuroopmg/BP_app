package com.google.android.gms.ads.internal.client;

import android.location.Location;
import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.abr;
import happy.hacking.aqu;
import happy.hacking.btf;
import java.util.Arrays;
import java.util.List;

@btf
public final class AdRequestParcel implements SafeParcelable {
    public static final abr CREATOR;
    public final int f633a;
    public final long f634b;
    public final Bundle f635c;
    public final int f636d;
    public final List f637e;
    public final boolean f638f;
    public final int f639g;
    public final boolean f640h;
    public final String f641i;
    public final SearchAdRequestParcel f642j;
    public final Location f643k;
    public final String f644l;
    public final Bundle f645m;
    public final Bundle f646n;
    public final List f647o;
    public final String f648p;
    public final String f649q;
    public final boolean f650r;

    static {
        CREATOR = new abr();
    }

    public AdRequestParcel(int i, long j, Bundle bundle, int i2, List list, boolean z, int i3, boolean z2, String str, SearchAdRequestParcel searchAdRequestParcel, Location location, String str2, Bundle bundle2, Bundle bundle3, List list2, String str3, String str4, boolean z3) {
        this.f633a = i;
        this.f634b = j;
        if (bundle == null) {
            bundle = new Bundle();
        }
        this.f635c = bundle;
        this.f636d = i2;
        this.f637e = list;
        this.f638f = z;
        this.f639g = i3;
        this.f640h = z2;
        this.f641i = str;
        this.f642j = searchAdRequestParcel;
        this.f643k = location;
        this.f644l = str2;
        this.f645m = bundle2;
        this.f646n = bundle3;
        this.f647o = list2;
        this.f648p = str3;
        this.f649q = str4;
        this.f650r = z3;
    }

    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof AdRequestParcel)) {
            return false;
        }
        AdRequestParcel adRequestParcel = (AdRequestParcel) obj;
        return this.f633a == adRequestParcel.f633a && this.f634b == adRequestParcel.f634b && aqu.m2251a(this.f635c, adRequestParcel.f635c) && this.f636d == adRequestParcel.f636d && aqu.m2251a(this.f637e, adRequestParcel.f637e) && this.f638f == adRequestParcel.f638f && this.f639g == adRequestParcel.f639g && this.f640h == adRequestParcel.f640h && aqu.m2251a(this.f641i, adRequestParcel.f641i) && aqu.m2251a(this.f642j, adRequestParcel.f642j) && aqu.m2251a(this.f643k, adRequestParcel.f643k) && aqu.m2251a(this.f644l, adRequestParcel.f644l) && aqu.m2251a(this.f645m, adRequestParcel.f645m) && aqu.m2251a(this.f646n, adRequestParcel.f646n) && aqu.m2251a(this.f647o, adRequestParcel.f647o) && aqu.m2251a(this.f648p, adRequestParcel.f648p) && aqu.m2251a(this.f649q, adRequestParcel.f649q) && this.f650r == adRequestParcel.f650r;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f633a), Long.valueOf(this.f634b), this.f635c, Integer.valueOf(this.f636d), this.f637e, Boolean.valueOf(this.f638f), Integer.valueOf(this.f639g), Boolean.valueOf(this.f640h), this.f641i, this.f642j, this.f643k, this.f644l, this.f645m, this.f646n, this.f647o, this.f648p, this.f649q, Boolean.valueOf(this.f650r)});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        abr.m890a(this, parcel, i);
    }
}
