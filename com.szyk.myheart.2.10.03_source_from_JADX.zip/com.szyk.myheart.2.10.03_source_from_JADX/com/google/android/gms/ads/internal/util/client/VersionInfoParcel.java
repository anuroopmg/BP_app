package com.google.android.gms.ads.internal.util.client;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.ahe;
import happy.hacking.btf;

@btf
public final class VersionInfoParcel implements SafeParcelable {
    public static final ahe CREATOR;
    public final int f782a;
    public String f783b;
    public int f784c;
    public int f785d;
    public boolean f786e;

    static {
        CREATOR = new ahe();
    }

    public VersionInfoParcel() {
        this(1, "afma-sdk-a-v8298000.8298000.0", 8298000, 8298000, true);
    }

    public VersionInfoParcel(int i, String str, int i2, int i3, boolean z) {
        this.f782a = i;
        this.f783b = str;
        this.f784c = i2;
        this.f785d = i3;
        this.f786e = z;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        ahe.m1386a(this, parcel);
    }
}
