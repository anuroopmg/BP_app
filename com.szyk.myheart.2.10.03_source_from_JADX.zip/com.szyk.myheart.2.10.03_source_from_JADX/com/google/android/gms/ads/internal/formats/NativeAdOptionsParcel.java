package com.google.android.gms.ads.internal.formats;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aay;
import happy.hacking.adm;
import happy.hacking.btf;

@btf
public class NativeAdOptionsParcel implements SafeParcelable {
    public static final adm CREATOR;
    public final int f677a;
    public final boolean f678b;
    public final int f679c;
    public final boolean f680d;

    static {
        CREATOR = new adm();
    }

    public NativeAdOptionsParcel(int i, boolean z, int i2, boolean z2) {
        this.f677a = i;
        this.f678b = z;
        this.f679c = i2;
        this.f680d = z2;
    }

    public NativeAdOptionsParcel(aay happy_hacking_aay) {
        this(1, happy_hacking_aay.f1073a, happy_hacking_aay.f1074b, happy_hacking_aay.f1075c);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        adm.m1074a(this, parcel);
    }
}
