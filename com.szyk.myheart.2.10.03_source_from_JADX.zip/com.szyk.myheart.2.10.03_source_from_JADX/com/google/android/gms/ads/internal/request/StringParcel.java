package com.google.android.gms.ads.internal.request;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.ags;
import happy.hacking.btf;

@btf
public class StringParcel implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f777a;
    public String f778b;

    static {
        CREATOR = new ags();
    }

    public StringParcel(int i, String str) {
        this.f777a = i;
        this.f778b = str;
    }

    public StringParcel(String str) {
        this.f777a = 1;
        this.f778b = str;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        ags.m1341a(this, parcel);
    }
}
