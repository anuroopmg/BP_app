package com.google.android.gms.ads.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aic;
import happy.hacking.btf;

@btf
public final class InterstitialAdParameterParcel implements SafeParcelable {
    public static final aic CREATOR;
    public final int f627a;
    public final boolean f628b;
    public final boolean f629c;
    public final String f630d;
    public final boolean f631e;
    public final float f632f;

    static {
        CREATOR = new aic();
    }

    public InterstitialAdParameterParcel(int i, boolean z, boolean z2, String str, boolean z3, float f) {
        this.f627a = i;
        this.f628b = z;
        this.f629c = z2;
        this.f630d = str;
        this.f631e = z3;
        this.f632f = f;
    }

    public InterstitialAdParameterParcel(boolean z, boolean z2, String str, boolean z3, float f) {
        this(2, z, z2, str, z3, f);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        aic.m1542a(this, parcel);
    }
}
