package com.google.android.gms.ads.internal.request;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.os.Messenger;
import android.os.Parcel;
import com.google.android.gms.ads.internal.client.AdRequestParcel;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.formats.NativeAdOptionsParcel;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.afg;
import happy.hacking.afy;
import happy.hacking.btf;
import java.util.Collections;
import java.util.List;

@btf
public final class AdRequestInfoParcel implements SafeParcelable {
    public static final afy CREATOR;
    public final List f711A;
    public final long f712B;
    public final CapabilityParcel f713C;
    public final String f714D;
    public final int f715a;
    public final Bundle f716b;
    public final AdRequestParcel f717c;
    public final AdSizeParcel f718d;
    public final String f719e;
    public final ApplicationInfo f720f;
    public final PackageInfo f721g;
    public final String f722h;
    public final String f723i;
    public final String f724j;
    public final VersionInfoParcel f725k;
    public final Bundle f726l;
    public final int f727m;
    public final List f728n;
    public final Bundle f729o;
    public final boolean f730p;
    public final Messenger f731q;
    public final int f732r;
    public final int f733s;
    public final float f734t;
    public final String f735u;
    public final long f736v;
    public final String f737w;
    public final List f738x;
    public final String f739y;
    public final NativeAdOptionsParcel f740z;

    static {
        CREATOR = new afy();
    }

    public AdRequestInfoParcel(int i, Bundle bundle, AdRequestParcel adRequestParcel, AdSizeParcel adSizeParcel, String str, ApplicationInfo applicationInfo, PackageInfo packageInfo, String str2, String str3, String str4, VersionInfoParcel versionInfoParcel, Bundle bundle2, int i2, List list, Bundle bundle3, boolean z, Messenger messenger, int i3, int i4, float f, String str5, long j, String str6, List list2, String str7, NativeAdOptionsParcel nativeAdOptionsParcel, List list3, long j2, CapabilityParcel capabilityParcel, String str8) {
        this.f715a = i;
        this.f716b = bundle;
        this.f717c = adRequestParcel;
        this.f718d = adSizeParcel;
        this.f719e = str;
        this.f720f = applicationInfo;
        this.f721g = packageInfo;
        this.f722h = str2;
        this.f723i = str3;
        this.f724j = str4;
        this.f725k = versionInfoParcel;
        this.f726l = bundle2;
        this.f727m = i2;
        this.f728n = list;
        this.f711A = list3 == null ? Collections.emptyList() : Collections.unmodifiableList(list3);
        this.f729o = bundle3;
        this.f730p = z;
        this.f731q = messenger;
        this.f732r = i3;
        this.f733s = i4;
        this.f734t = f;
        this.f735u = str5;
        this.f736v = j;
        this.f737w = str6;
        this.f738x = list2 == null ? Collections.emptyList() : Collections.unmodifiableList(list2);
        this.f739y = str7;
        this.f740z = nativeAdOptionsParcel;
        this.f712B = j2;
        this.f713C = capabilityParcel;
        this.f714D = str8;
    }

    private AdRequestInfoParcel(Bundle bundle, AdRequestParcel adRequestParcel, AdSizeParcel adSizeParcel, String str, ApplicationInfo applicationInfo, PackageInfo packageInfo, String str2, String str3, String str4, VersionInfoParcel versionInfoParcel, Bundle bundle2, int i, List list, List list2, Bundle bundle3, boolean z, Messenger messenger, int i2, int i3, float f, String str5, long j, String str6, List list3, String str7, NativeAdOptionsParcel nativeAdOptionsParcel, long j2, CapabilityParcel capabilityParcel, String str8) {
        this(12, bundle, adRequestParcel, adSizeParcel, str, applicationInfo, packageInfo, str2, str3, str4, versionInfoParcel, bundle2, i, list, bundle3, z, messenger, i2, i3, f, str5, j, str6, list3, str7, nativeAdOptionsParcel, list2, j2, capabilityParcel, str8);
    }

    public AdRequestInfoParcel(afg happy_hacking_afg, String str, long j) {
        String str2 = str;
        long j2 = j;
        this(happy_hacking_afg.f1394a, happy_hacking_afg.f1395b, happy_hacking_afg.f1396c, happy_hacking_afg.f1397d, happy_hacking_afg.f1398e, happy_hacking_afg.f1399f, str2, happy_hacking_afg.f1400g, happy_hacking_afg.f1401h, happy_hacking_afg.f1403j, happy_hacking_afg.f1402i, happy_hacking_afg.f1404k, happy_hacking_afg.f1405l, happy_hacking_afg.f1406m, happy_hacking_afg.f1407n, happy_hacking_afg.f1408o, happy_hacking_afg.f1409p, happy_hacking_afg.f1410q, happy_hacking_afg.f1411r, happy_hacking_afg.f1412s, happy_hacking_afg.f1413t, happy_hacking_afg.f1414u, happy_hacking_afg.f1415v, happy_hacking_afg.f1416w, happy_hacking_afg.f1417x, happy_hacking_afg.f1418y, j2, happy_hacking_afg.f1419z, happy_hacking_afg.f1393A);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        afy.m1310a(this, parcel, i);
    }
}
