package com.google.android.gms.ads.internal.client;

import android.content.Context;
import android.os.Parcel;
import android.util.DisplayMetrics;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aan;
import happy.hacking.abt;
import happy.hacking.abv;
import happy.hacking.ahc;
import happy.hacking.ajh;
import happy.hacking.btf;

@btf
public class AdSizeParcel implements SafeParcelable {
    public static final abt CREATOR;
    public final int f651a;
    public final String f652b;
    public final int f653c;
    public final int f654d;
    public final boolean f655e;
    public final int f656f;
    public final int f657g;
    public final AdSizeParcel[] f658h;
    public final boolean f659i;
    public final boolean f660j;
    public boolean f661k;

    static {
        CREATOR = new abt();
    }

    public AdSizeParcel() {
        this(5, "interstitial_mb", 0, 0, true, 0, 0, null, false, false, false);
    }

    public AdSizeParcel(int i, String str, int i2, int i3, boolean z, int i4, int i5, AdSizeParcel[] adSizeParcelArr, boolean z2, boolean z3, boolean z4) {
        this.f651a = i;
        this.f652b = str;
        this.f653c = i2;
        this.f654d = i3;
        this.f655e = z;
        this.f656f = i4;
        this.f657g = i5;
        this.f658h = adSizeParcelArr;
        this.f659i = z2;
        this.f660j = z3;
        this.f661k = z4;
    }

    public AdSizeParcel(Context context, aan happy_hacking_aan) {
        this(context, new aan[]{happy_hacking_aan});
    }

    public AdSizeParcel(Context context, aan[] happy_hacking_aanArr) {
        boolean z;
        int i;
        int i2;
        aan happy_hacking_aan = happy_hacking_aanArr[0];
        this.f651a = 5;
        this.f655e = false;
        boolean z2 = happy_hacking_aan.f1066i == -3 && happy_hacking_aan.f1067j == -4;
        this.f660j = z2;
        if (this.f660j) {
            this.f656f = aan.f1058a.f1066i;
            this.f653c = aan.f1058a.f1067j;
        } else {
            this.f656f = happy_hacking_aan.f1066i;
            this.f653c = happy_hacking_aan.f1067j;
        }
        if (this.f656f == -1) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (this.f653c == -2) {
            z = true;
        } else {
            z = false;
        }
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        if (z2) {
            double d;
            abv.m897a();
            if (ahc.m1379c(context)) {
                abv.m897a();
                if (ahc.m1380d(context)) {
                    i = displayMetrics.widthPixels;
                    abv.m897a();
                    this.f657g = i - ahc.m1381e(context);
                    d = (double) (((float) this.f657g) / displayMetrics.density);
                    i = (int) d;
                    if (d - ((double) ((int) d)) >= 0.01d) {
                        i++;
                    }
                    i2 = i;
                }
            }
            this.f657g = displayMetrics.widthPixels;
            d = (double) (((float) this.f657g) / displayMetrics.density);
            i = (int) d;
            if (d - ((double) ((int) d)) >= 0.01d) {
                i++;
            }
            i2 = i;
        } else {
            i = this.f656f;
            abv.m897a();
            this.f657g = ahc.m1370a(displayMetrics, this.f656f);
            i2 = i;
        }
        i = z ? m602c(displayMetrics) : this.f653c;
        abv.m897a();
        this.f654d = ahc.m1370a(displayMetrics, i);
        if (z2 || z) {
            this.f652b = i2 + "x" + i + "_as";
        } else if (this.f660j) {
            this.f652b = "320x50_mb";
        } else {
            this.f652b = happy_hacking_aan.toString();
        }
        if (happy_hacking_aanArr.length > 1) {
            this.f658h = new AdSizeParcel[happy_hacking_aanArr.length];
            for (int i3 = 0; i3 < happy_hacking_aanArr.length; i3++) {
                this.f658h[i3] = new AdSizeParcel(context, happy_hacking_aanArr[i3]);
            }
        } else {
            this.f658h = null;
        }
        this.f659i = false;
        this.f661k = false;
    }

    public AdSizeParcel(AdSizeParcel adSizeParcel, AdSizeParcel[] adSizeParcelArr) {
        this(5, adSizeParcel.f652b, adSizeParcel.f653c, adSizeParcel.f654d, adSizeParcel.f655e, adSizeParcel.f656f, adSizeParcel.f657g, adSizeParcelArr, adSizeParcel.f659i, adSizeParcel.f660j, adSizeParcel.f661k);
    }

    public static int m599a(DisplayMetrics displayMetrics) {
        return displayMetrics.widthPixels;
    }

    public static AdSizeParcel m600a() {
        return new AdSizeParcel(5, "320x50_mb", 0, 0, false, 0, 0, null, true, false, false);
    }

    public static int m601b(DisplayMetrics displayMetrics) {
        return (int) (((float) m602c(displayMetrics)) * displayMetrics.density);
    }

    private static int m602c(DisplayMetrics displayMetrics) {
        int i = (int) (((float) displayMetrics.heightPixels) / displayMetrics.density);
        return i <= 400 ? 32 : i <= 720 ? 50 : 90;
    }

    public final aan m603b() {
        return ajh.m1628a(this.f656f, this.f653c, this.f652b);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        abt.m894a(this, parcel, i);
    }
}
