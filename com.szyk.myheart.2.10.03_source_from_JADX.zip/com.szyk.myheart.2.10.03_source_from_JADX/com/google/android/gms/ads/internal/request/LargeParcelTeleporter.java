package com.google.android.gms.ads.internal.request;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.ParcelFileDescriptor.AutoCloseInputStream;
import android.os.ParcelFileDescriptor.AutoCloseOutputStream;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.afh;
import happy.hacking.agi;
import happy.hacking.ahd;
import happy.hacking.ail;
import happy.hacking.btf;
import happy.hacking.cbw;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;

@btf
public final class LargeParcelTeleporter implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f773a;
    public ParcelFileDescriptor f774b;
    private Parcelable f775c;
    private boolean f776d;

    static {
        CREATOR = new agi();
    }

    public LargeParcelTeleporter(int i, ParcelFileDescriptor parcelFileDescriptor) {
        this.f773a = i;
        this.f774b = parcelFileDescriptor;
        this.f775c = null;
        this.f776d = true;
    }

    public LargeParcelTeleporter(SafeParcelable safeParcelable) {
        this.f773a = 1;
        this.f774b = null;
        this.f775c = safeParcelable;
        this.f776d = false;
    }

    private ParcelFileDescriptor m608a(byte[] bArr) {
        Closeable autoCloseOutputStream;
        Throwable e;
        ParcelFileDescriptor parcelFileDescriptor = null;
        try {
            ParcelFileDescriptor[] createPipe = ParcelFileDescriptor.createPipe();
            autoCloseOutputStream = new AutoCloseOutputStream(createPipe[1]);
            try {
                new Thread(new afh(this, autoCloseOutputStream, bArr)).start();
                return createPipe[0];
            } catch (IOException e2) {
                e = e2;
            }
        } catch (IOException e3) {
            e = e3;
            autoCloseOutputStream = parcelFileDescriptor;
            ahd.m1383a("Error transporting the ad response", e);
            ail.m1574h().m3465a(e, true);
            cbw.m4081a(autoCloseOutputStream);
            return parcelFileDescriptor;
        }
    }

    public final SafeParcelable m609a(Creator creator) {
        if (this.f776d) {
            if (this.f774b == null) {
                ahd.m1382a("File descriptor is empty, returning null.");
                return null;
            }
            Closeable dataInputStream = new DataInputStream(new AutoCloseInputStream(this.f774b));
            try {
                byte[] bArr = new byte[dataInputStream.readInt()];
                dataInputStream.readFully(bArr, 0, bArr.length);
                cbw.m4081a(dataInputStream);
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.unmarshall(bArr, 0, bArr.length);
                    obtain.setDataPosition(0);
                    this.f775c = (SafeParcelable) creator.createFromParcel(obtain);
                    this.f776d = false;
                } finally {
                    obtain.recycle();
                }
            } catch (Throwable e) {
                throw new IllegalStateException("Could not read from parcel file descriptor", e);
            } catch (Throwable th) {
                cbw.m4081a(dataInputStream);
            }
        }
        return (SafeParcelable) this.f775c;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        if (this.f774b == null) {
            Parcel obtain = Parcel.obtain();
            try {
                this.f775c.writeToParcel(obtain, 0);
                byte[] marshall = obtain.marshall();
                this.f774b = m608a(marshall);
            } finally {
                obtain.recycle();
            }
        }
        agi.m1322a(this, parcel, i);
    }
}
