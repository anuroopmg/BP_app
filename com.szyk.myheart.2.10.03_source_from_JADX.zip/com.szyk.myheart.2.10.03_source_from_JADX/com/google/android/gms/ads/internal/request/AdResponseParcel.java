package com.google.android.gms.ads.internal.request;

import android.os.Parcel;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aga;
import happy.hacking.btf;
import java.util.Collections;
import java.util.List;

@btf
public final class AdResponseParcel implements SafeParcelable {
    public static final aga CREATOR;
    public String f741A;
    public boolean f742B;
    private AdRequestInfoParcel f743C;
    public final int f744a;
    public final String f745b;
    public String f746c;
    public final List f747d;
    public final int f748e;
    public final List f749f;
    public final long f750g;
    public final boolean f751h;
    public final long f752i;
    public final List f753j;
    public final long f754k;
    public final int f755l;
    public final String f756m;
    public final long f757n;
    public final String f758o;
    public final boolean f759p;
    public final String f760q;
    public final String f761r;
    public final boolean f762s;
    public final boolean f763t;
    public final boolean f764u;
    public final boolean f765v;
    public final boolean f766w;
    public final int f767x;
    public LargeParcelTeleporter f768y;
    public String f769z;

    static {
        CREATOR = new aga();
    }

    public AdResponseParcel(int i) {
        this(14, null, null, null, i, null, -1, false, -1, null, -1, -1, null, -1, null, false, null, null, false, false, false, true, false, 0, null, null, null, false);
    }

    public AdResponseParcel(int i, long j) {
        this(14, null, null, null, i, null, -1, false, -1, null, j, -1, null, -1, null, false, null, null, false, false, false, true, false, 0, null, null, null, false);
    }

    public AdResponseParcel(int i, String str, String str2, List list, int i2, List list2, long j, boolean z, long j2, List list3, long j3, int i3, String str3, long j4, String str4, boolean z2, String str5, String str6, boolean z3, boolean z4, boolean z5, boolean z6, boolean z7, int i4, LargeParcelTeleporter largeParcelTeleporter, String str7, String str8, boolean z8) {
        this.f744a = i;
        this.f745b = str;
        this.f746c = str2;
        this.f747d = list != null ? Collections.unmodifiableList(list) : null;
        this.f748e = i2;
        this.f749f = list2 != null ? Collections.unmodifiableList(list2) : null;
        this.f750g = j;
        this.f751h = z;
        this.f752i = j2;
        this.f753j = list3 != null ? Collections.unmodifiableList(list3) : null;
        this.f754k = j3;
        this.f755l = i3;
        this.f756m = str3;
        this.f757n = j4;
        this.f758o = str4;
        this.f759p = z2;
        this.f760q = str5;
        this.f761r = str6;
        this.f762s = z3;
        this.f763t = z4;
        this.f764u = z5;
        this.f765v = z6;
        this.f766w = z7;
        this.f767x = i4;
        this.f768y = largeParcelTeleporter;
        this.f769z = str7;
        this.f741A = str8;
        if (this.f746c == null && this.f768y != null) {
            StringParcel stringParcel = (StringParcel) this.f768y.m609a(StringParcel.CREATOR);
            if (!(stringParcel == null || TextUtils.isEmpty(stringParcel.f778b))) {
                this.f746c = stringParcel.f778b;
            }
        }
        this.f742B = z8;
    }

    public AdResponseParcel(AdRequestInfoParcel adRequestInfoParcel, String str, String str2, List list, List list2, long j, boolean z, long j2, List list3, long j3, int i, String str3, long j4, String str4, boolean z2, String str5, String str6, boolean z3, boolean z4, boolean z5, boolean z6, boolean z7, int i2, String str7, boolean z8) {
        this(14, str, str2, list, -2, list2, j, z, j2, list3, j3, i, str3, j4, str4, z2, str5, str6, z3, z4, z5, z6, z7, i2, null, null, str7, z8);
        this.f743C = adRequestInfoParcel;
    }

    public AdResponseParcel(AdRequestInfoParcel adRequestInfoParcel, String str, String str2, List list, List list2, long j, boolean z, List list3, long j2, int i, String str3, long j3, String str4, String str5, boolean z2, boolean z3, boolean z4, boolean z5, int i2, String str6, boolean z6) {
        this(14, str, str2, list, -2, list2, j, z, -1, list3, j2, i, str3, j3, str4, false, null, str5, z2, z3, z4, z5, false, i2, null, null, str6, z6);
        this.f743C = adRequestInfoParcel;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        if (!(this.f743C == null || this.f743C.f715a < 9 || TextUtils.isEmpty(this.f746c))) {
            this.f768y = new LargeParcelTeleporter(new StringParcel(this.f746c));
            this.f746c = null;
        }
        aga.m1314a(this, parcel, i);
    }
}
