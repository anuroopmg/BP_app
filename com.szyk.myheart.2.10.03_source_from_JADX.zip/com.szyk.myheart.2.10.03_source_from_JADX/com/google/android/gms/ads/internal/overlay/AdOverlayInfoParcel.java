package com.google.android.gms.ads.internal.overlay;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.ads.internal.InterstitialAdParameterParcel;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.abi;
import happy.hacking.aef;
import happy.hacking.aeg;
import happy.hacking.aen;
import happy.hacking.bee;
import happy.hacking.beg;
import happy.hacking.bkq;
import happy.hacking.blm;
import happy.hacking.btf;
import happy.hacking.bxm;

@btf
public final class AdOverlayInfoParcel implements SafeParcelable {
    public static final aef CREATOR;
    public final int f689a;
    public final AdLauncherIntentInfoParcel f690b;
    public final abi f691c;
    public final aeg f692d;
    public final bxm f693e;
    public final bkq f694f;
    public final String f695g;
    public final boolean f696h;
    public final String f697i;
    public final aen f698j;
    public final int f699k;
    public final int f700l;
    public final String f701m;
    public final VersionInfoParcel f702n;
    public final blm f703o;
    public final String f704p;
    public final InterstitialAdParameterParcel f705q;

    static {
        CREATOR = new aef();
    }

    public AdOverlayInfoParcel(int i, AdLauncherIntentInfoParcel adLauncherIntentInfoParcel, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, IBinder iBinder4, String str, boolean z, String str2, IBinder iBinder5, int i2, int i3, String str3, VersionInfoParcel versionInfoParcel, IBinder iBinder6, String str4, InterstitialAdParameterParcel interstitialAdParameterParcel) {
        this.f689a = i;
        this.f690b = adLauncherIntentInfoParcel;
        this.f691c = (abi) beg.m2520a(bee.m2518a(iBinder));
        this.f692d = (aeg) beg.m2520a(bee.m2518a(iBinder2));
        this.f693e = (bxm) beg.m2520a(bee.m2518a(iBinder3));
        this.f694f = (bkq) beg.m2520a(bee.m2518a(iBinder4));
        this.f695g = str;
        this.f696h = z;
        this.f697i = str2;
        this.f698j = (aen) beg.m2520a(bee.m2518a(iBinder5));
        this.f699k = i2;
        this.f700l = i3;
        this.f701m = str3;
        this.f702n = versionInfoParcel;
        this.f703o = (blm) beg.m2520a(bee.m2518a(iBinder6));
        this.f704p = str4;
        this.f705q = interstitialAdParameterParcel;
    }

    public AdOverlayInfoParcel(AdLauncherIntentInfoParcel adLauncherIntentInfoParcel, abi happy_hacking_abi, aeg happy_hacking_aeg, aen happy_hacking_aen, VersionInfoParcel versionInfoParcel) {
        this.f689a = 4;
        this.f690b = adLauncherIntentInfoParcel;
        this.f691c = happy_hacking_abi;
        this.f692d = happy_hacking_aeg;
        this.f693e = null;
        this.f694f = null;
        this.f695g = null;
        this.f696h = false;
        this.f697i = null;
        this.f698j = happy_hacking_aen;
        this.f699k = -1;
        this.f700l = 4;
        this.f701m = null;
        this.f702n = versionInfoParcel;
        this.f703o = null;
        this.f704p = null;
        this.f705q = null;
    }

    public AdOverlayInfoParcel(abi happy_hacking_abi, aeg happy_hacking_aeg, aen happy_hacking_aen, bxm happy_hacking_bxm, int i, VersionInfoParcel versionInfoParcel, String str, InterstitialAdParameterParcel interstitialAdParameterParcel) {
        this.f689a = 4;
        this.f690b = null;
        this.f691c = happy_hacking_abi;
        this.f692d = happy_hacking_aeg;
        this.f693e = happy_hacking_bxm;
        this.f694f = null;
        this.f695g = null;
        this.f696h = false;
        this.f697i = null;
        this.f698j = happy_hacking_aen;
        this.f699k = i;
        this.f700l = 1;
        this.f701m = null;
        this.f702n = versionInfoParcel;
        this.f703o = null;
        this.f704p = str;
        this.f705q = interstitialAdParameterParcel;
    }

    public AdOverlayInfoParcel(abi happy_hacking_abi, aeg happy_hacking_aeg, aen happy_hacking_aen, bxm happy_hacking_bxm, boolean z, int i, VersionInfoParcel versionInfoParcel) {
        this.f689a = 4;
        this.f690b = null;
        this.f691c = happy_hacking_abi;
        this.f692d = happy_hacking_aeg;
        this.f693e = happy_hacking_bxm;
        this.f694f = null;
        this.f695g = null;
        this.f696h = z;
        this.f697i = null;
        this.f698j = happy_hacking_aen;
        this.f699k = i;
        this.f700l = 2;
        this.f701m = null;
        this.f702n = versionInfoParcel;
        this.f703o = null;
        this.f704p = null;
        this.f705q = null;
    }

    public AdOverlayInfoParcel(abi happy_hacking_abi, aeg happy_hacking_aeg, bkq happy_hacking_bkq, aen happy_hacking_aen, bxm happy_hacking_bxm, boolean z, int i, String str, VersionInfoParcel versionInfoParcel, blm happy_hacking_blm) {
        this.f689a = 4;
        this.f690b = null;
        this.f691c = happy_hacking_abi;
        this.f692d = happy_hacking_aeg;
        this.f693e = happy_hacking_bxm;
        this.f694f = happy_hacking_bkq;
        this.f695g = null;
        this.f696h = z;
        this.f697i = null;
        this.f698j = happy_hacking_aen;
        this.f699k = i;
        this.f700l = 3;
        this.f701m = str;
        this.f702n = versionInfoParcel;
        this.f703o = happy_hacking_blm;
        this.f704p = null;
        this.f705q = null;
    }

    public AdOverlayInfoParcel(abi happy_hacking_abi, aeg happy_hacking_aeg, bkq happy_hacking_bkq, aen happy_hacking_aen, bxm happy_hacking_bxm, boolean z, int i, String str, String str2, VersionInfoParcel versionInfoParcel, blm happy_hacking_blm) {
        this.f689a = 4;
        this.f690b = null;
        this.f691c = happy_hacking_abi;
        this.f692d = happy_hacking_aeg;
        this.f693e = happy_hacking_bxm;
        this.f694f = happy_hacking_bkq;
        this.f695g = str2;
        this.f696h = z;
        this.f697i = str;
        this.f698j = happy_hacking_aen;
        this.f699k = i;
        this.f700l = 3;
        this.f701m = null;
        this.f702n = versionInfoParcel;
        this.f703o = happy_hacking_blm;
        this.f704p = null;
        this.f705q = null;
    }

    public static AdOverlayInfoParcel m604a(Intent intent) {
        try {
            Bundle bundleExtra = intent.getBundleExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
            bundleExtra.setClassLoader(AdOverlayInfoParcel.class.getClassLoader());
            return (AdOverlayInfoParcel) bundleExtra.getParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
        } catch (Exception e) {
            return null;
        }
    }

    public static void m605a(Intent intent, AdOverlayInfoParcel adOverlayInfoParcel) {
        Bundle bundle = new Bundle(1);
        bundle.putParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", adOverlayInfoParcel);
        intent.putExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", bundle);
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        aef.m1152a(this, parcel, i);
    }
}
