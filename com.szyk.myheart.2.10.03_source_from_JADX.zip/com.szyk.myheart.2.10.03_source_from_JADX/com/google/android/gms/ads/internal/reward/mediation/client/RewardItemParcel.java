package com.google.android.gms.ads.internal.reward.mediation.client;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.ahb;
import happy.hacking.btf;

@btf
public final class RewardItemParcel implements SafeParcelable {
    public static final ahb CREATOR;
    public final int f779a;
    public final String f780b;
    public final int f781c;

    static {
        CREATOR = new ahb();
    }

    public RewardItemParcel(int i, String str, int i2) {
        this.f779a = i;
        this.f780b = str;
        this.f781c = i2;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        ahb.m1368a(this, parcel);
    }
}
