package com.google.android.gms.ads.internal.request;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.agb;
import happy.hacking.btf;

@btf
public class CapabilityParcel implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f770a;
    public final boolean f771b;
    public final boolean f772c;

    static {
        CREATOR = new agb();
    }

    public CapabilityParcel(int i, boolean z, boolean z2) {
        this.f770a = i;
        this.f771b = z;
        this.f772c = z2;
    }

    public CapabilityParcel(boolean z, boolean z2) {
        this(1, z, z2);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        agb.m1315a(this, parcel);
    }
}
