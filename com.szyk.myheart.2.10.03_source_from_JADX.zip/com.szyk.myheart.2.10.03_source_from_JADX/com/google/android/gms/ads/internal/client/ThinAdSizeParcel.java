package com.google.android.gms.ads.internal.client;

import android.os.Parcel;
import happy.hacking.aoq;
import happy.hacking.btf;

@btf
public class ThinAdSizeParcel extends AdSizeParcel {
    public ThinAdSizeParcel(AdSizeParcel adSizeParcel) {
        super(adSizeParcel.f651a, adSizeParcel.f652b, adSizeParcel.f653c, adSizeParcel.f654d, adSizeParcel.f655e, adSizeParcel.f656f, adSizeParcel.f657g, adSizeParcel.f658h, adSizeParcel.f659i, adSizeParcel.f660j, adSizeParcel.f661k);
    }

    public void writeToParcel(Parcel parcel, int i) {
        int a = aoq.m2061a(parcel, 20293);
        aoq.m2063a(parcel, 1, this.a);
        aoq.m2068a(parcel, 2, this.b);
        aoq.m2063a(parcel, 3, this.c);
        aoq.m2063a(parcel, 6, this.f);
        aoq.m2073b(parcel, a);
    }
}
