package com.google.android.gms.common;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aqu;
import happy.hacking.aqv;
import happy.hacking.arl;
import happy.hacking.py;
import happy.hacking.ug;
import java.util.Arrays;

public final class ConnectionResult implements SafeParcelable {
    public static final Creator CREATOR;
    public static final ConnectionResult f815a;
    public final int f816b;
    public final int f817c;
    public final PendingIntent f818d;
    public final String f819e;

    static {
        f815a = new ConnectionResult();
        CREATOR = new arl();
    }

    private ConnectionResult() {
        this(0, null, (byte) 0);
    }

    public ConnectionResult(int i, int i2, PendingIntent pendingIntent, String str) {
        this.f816b = i;
        this.f817c = i2;
        this.f818d = pendingIntent;
        this.f819e = str;
    }

    public ConnectionResult(int i, PendingIntent pendingIntent) {
        this(i, pendingIntent, (byte) 0);
    }

    private ConnectionResult(int i, PendingIntent pendingIntent, byte b) {
        this(1, i, pendingIntent, null);
    }

    public final boolean m615a() {
        return (this.f817c == 0 || this.f818d == null) ? false : true;
    }

    public final boolean m616b() {
        return this.f817c == 0;
    }

    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ConnectionResult)) {
            return false;
        }
        ConnectionResult connectionResult = (ConnectionResult) obj;
        return this.f817c == connectionResult.f817c && aqu.m2251a(this.f818d, connectionResult.f818d) && aqu.m2251a(this.f819e, connectionResult.f819e);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f817c), this.f818d, this.f819e});
    }

    public final String toString() {
        Object obj;
        aqv a = aqu.m2250a(this);
        String str = "statusCode";
        int i = this.f817c;
        switch (i) {
            case ug.RecyclerView_android_orientation /*0*/:
                obj = "SUCCESS";
                break;
            case ug.RecyclerView_layoutManager /*1*/:
                obj = "SERVICE_MISSING";
                break;
            case ug.RecyclerView_spanCount /*2*/:
                obj = "SERVICE_VERSION_UPDATE_REQUIRED";
                break;
            case ug.RecyclerView_reverseLayout /*3*/:
                obj = "SERVICE_DISABLED";
                break;
            case ug.RecyclerView_stackFromEnd /*4*/:
                obj = "SIGN_IN_REQUIRED";
                break;
            case py.Toolbar_contentInsetStart /*5*/:
                obj = "INVALID_ACCOUNT";
                break;
            case py.Toolbar_contentInsetEnd /*6*/:
                obj = "RESOLUTION_REQUIRED";
                break;
            case py.Toolbar_contentInsetLeft /*7*/:
                obj = "NETWORK_ERROR";
                break;
            case py.Toolbar_contentInsetRight /*8*/:
                obj = "INTERNAL_ERROR";
                break;
            case py.Toolbar_popupTheme /*9*/:
                obj = "SERVICE_INVALID";
                break;
            case py.Toolbar_titleTextAppearance /*10*/:
                obj = "DEVELOPER_ERROR";
                break;
            case py.Toolbar_subtitleTextAppearance /*11*/:
                obj = "LICENSE_CHECK_FAILED";
                break;
            case py.Toolbar_titleMarginStart /*13*/:
                obj = "CANCELED";
                break;
            case py.Toolbar_titleMarginEnd /*14*/:
                obj = "TIMEOUT";
                break;
            case py.Toolbar_titleMarginTop /*15*/:
                obj = "INTERRUPTED";
                break;
            case py.Toolbar_titleMarginBottom /*16*/:
                obj = "API_UNAVAILABLE";
                break;
            case py.Toolbar_maxButtonHeight /*17*/:
                obj = "SIGN_IN_FAILED";
                break;
            case py.Toolbar_collapseIcon /*18*/:
                obj = "SERVICE_UPDATING";
                break;
            case py.Toolbar_collapseContentDescription /*19*/:
                obj = "SERVICE_MISSING_PERMISSION";
                break;
            default:
                obj = "UNKNOWN_ERROR_CODE(" + i + ")";
                break;
        }
        return a.m2252a(str, obj).m2252a("resolution", this.f818d).m2252a("message", this.f819e).toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        arl.m2281a(this, parcel, i);
    }
}
