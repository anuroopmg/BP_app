package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.arg;
import happy.hacking.ari;
import java.util.List;

public final class WakeLockEvent extends arg implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f870a;
    public final long f871b;
    public int f872c;
    public final String f873d;
    public final int f874e;
    public final List f875f;
    public final String f876g;
    public final long f877h;
    public int f878i;
    public final String f879j;
    public final String f880k;
    public final float f881l;
    public final long f882m;
    private long f883n;

    static {
        CREATOR = new ari();
    }

    public WakeLockEvent(int i, long j, int i2, String str, int i3, List list, String str2, long j2, int i4, String str3, String str4, float f, long j3) {
        this.f870a = i;
        this.f871b = j;
        this.f872c = i2;
        this.f873d = str;
        this.f879j = str3;
        this.f874e = i3;
        this.f883n = -1;
        this.f875f = list;
        this.f876g = str2;
        this.f877h = j2;
        this.f878i = i4;
        this.f880k = str4;
        this.f881l = f;
        this.f882m = j3;
    }

    public WakeLockEvent(long j, int i, String str, int i2, List list, String str2, long j2, int i3, String str3, String str4, float f, long j3) {
        this(1, j, i, str, i2, list, str2, j2, i3, str3, str4, f, j3);
    }

    public final long m628a() {
        return this.f871b;
    }

    public final int m629b() {
        return this.f872c;
    }

    public final long m630c() {
        return this.f883n;
    }

    public final String m631d() {
        String str;
        StringBuilder append = new StringBuilder("\t").append(this.f873d).append("\t").append(this.f874e).append("\t").append(this.f875f == null ? "" : TextUtils.join(",", this.f875f)).append("\t").append(this.f878i).append("\t");
        if (this.f879j == null) {
            str = "";
        } else {
            str = this.f879j;
        }
        append = append.append(str).append("\t");
        if (this.f880k == null) {
            str = "";
        } else {
            str = this.f880k;
        }
        return append.append(str).append("\t").append(this.f881l).toString();
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        ari.m2276a(this, parcel);
    }
}
