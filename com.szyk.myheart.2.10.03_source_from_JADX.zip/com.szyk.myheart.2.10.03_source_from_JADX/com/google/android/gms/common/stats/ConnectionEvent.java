package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aqz;
import happy.hacking.arg;

public final class ConnectionEvent extends arg implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f858a;
    public final long f859b;
    public int f860c;
    public final String f861d;
    public final String f862e;
    public final String f863f;
    public final String f864g;
    public final String f865h;
    public final String f866i;
    public final long f867j;
    public final long f868k;
    private long f869l;

    static {
        CREATOR = new aqz();
    }

    public ConnectionEvent(int i, long j, int i2, String str, String str2, String str3, String str4, String str5, String str6, long j2, long j3) {
        this.f858a = i;
        this.f859b = j;
        this.f860c = i2;
        this.f861d = str;
        this.f862e = str2;
        this.f863f = str3;
        this.f864g = str4;
        this.f869l = -1;
        this.f865h = str5;
        this.f866i = str6;
        this.f867j = j2;
        this.f868k = j3;
    }

    public ConnectionEvent(long j, int i, String str, String str2, String str3, String str4, String str5, String str6, long j2, long j3) {
        this(1, j, i, str, str2, str3, str4, str5, str6, j2, j3);
    }

    public final long m624a() {
        return this.f859b;
    }

    public final int m625b() {
        return this.f860c;
    }

    public final long m626c() {
        return this.f869l;
    }

    public final String m627d() {
        return "\t" + this.f861d + "/" + this.f862e + "\t" + this.f863f + "/" + this.f864g + "\t" + (this.f865h == null ? "" : this.f865h) + "\t" + this.f868k;
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        aqz.m2265a(this, parcel);
    }
}
