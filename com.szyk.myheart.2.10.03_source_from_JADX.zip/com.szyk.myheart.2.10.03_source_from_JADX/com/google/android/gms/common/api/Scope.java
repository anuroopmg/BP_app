package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aok;
import happy.hacking.aqw;

public final class Scope implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f820a;
    public final String f821b;

    static {
        CREATOR = new aok();
    }

    public Scope(int i, String str) {
        aqw.m2256a(str, (Object) "scopeUri must not be null or empty");
        this.f820a = i;
        this.f821b = str;
    }

    public Scope(String str) {
        this(1, str);
    }

    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        return this == obj ? true : !(obj instanceof Scope) ? false : this.f821b.equals(((Scope) obj).f821b);
    }

    public final int hashCode() {
        return this.f821b.hashCode();
    }

    public final String toString() {
        return this.f821b;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        aok.m2044a(this, parcel);
    }
}
