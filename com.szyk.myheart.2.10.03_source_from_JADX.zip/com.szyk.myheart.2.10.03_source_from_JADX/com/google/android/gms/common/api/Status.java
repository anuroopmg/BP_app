package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v7.app.ActionBar.Tab;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aof;
import happy.hacking.aol;
import happy.hacking.aqu;
import happy.hacking.aqv;
import happy.hacking.py;
import happy.hacking.ug;
import java.util.Arrays;

public final class Status implements SafeParcelable, aof {
    public static final Creator CREATOR;
    public static final Status f822a;
    public static final Status f823b;
    public static final Status f824c;
    public static final Status f825d;
    public static final Status f826e;
    public final int f827f;
    public final int f828g;
    public final String f829h;
    public final PendingIntent f830i;

    static {
        f822a = new Status(0);
        f823b = new Status(14);
        f824c = new Status(8);
        f825d = new Status(15);
        f826e = new Status(16);
        CREATOR = new aol();
    }

    public Status(int i) {
        this(i, null);
    }

    public Status(int i, int i2, String str, PendingIntent pendingIntent) {
        this.f827f = i;
        this.f828g = i2;
        this.f829h = str;
        this.f830i = pendingIntent;
    }

    public Status(int i, String str) {
        this(1, i, str, null);
    }

    public Status(int i, String str, PendingIntent pendingIntent) {
        this(1, i, str, pendingIntent);
    }

    public final Status m618a() {
        return this;
    }

    public final boolean m619b() {
        return this.f828g <= 0;
    }

    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        return this.f827f == status.f827f && this.f828g == status.f828g && aqu.m2251a(this.f829h, status.f829h) && aqu.m2251a(this.f830i, status.f830i);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f827f), Integer.valueOf(this.f828g), this.f829h, this.f830i});
    }

    public final String toString() {
        Object obj;
        aqv a = aqu.m2250a(this);
        String str = "statusCode";
        if (this.f829h == null) {
            int i = this.f828g;
            switch (i) {
                case Tab.INVALID_POSITION /*-1*/:
                    obj = "SUCCESS_CACHE";
                    break;
                case ug.RecyclerView_android_orientation /*0*/:
                    obj = "SUCCESS";
                    break;
                case ug.RecyclerView_layoutManager /*1*/:
                    obj = "SERVICE_MISSING";
                    break;
                case ug.RecyclerView_spanCount /*2*/:
                    obj = "SERVICE_VERSION_UPDATE_REQUIRED";
                    break;
                case ug.RecyclerView_reverseLayout /*3*/:
                    obj = "SERVICE_DISABLED";
                    break;
                case ug.RecyclerView_stackFromEnd /*4*/:
                    obj = "SIGN_IN_REQUIRED";
                    break;
                case py.Toolbar_contentInsetStart /*5*/:
                    obj = "INVALID_ACCOUNT";
                    break;
                case py.Toolbar_contentInsetEnd /*6*/:
                    obj = "RESOLUTION_REQUIRED";
                    break;
                case py.Toolbar_contentInsetLeft /*7*/:
                    obj = "NETWORK_ERROR";
                    break;
                case py.Toolbar_contentInsetRight /*8*/:
                    obj = "INTERNAL_ERROR";
                    break;
                case py.Toolbar_popupTheme /*9*/:
                    obj = "SERVICE_INVALID";
                    break;
                case py.Toolbar_titleTextAppearance /*10*/:
                    obj = "DEVELOPER_ERROR";
                    break;
                case py.Toolbar_subtitleTextAppearance /*11*/:
                    obj = "LICENSE_CHECK_FAILED";
                    break;
                case py.Toolbar_titleMarginStart /*13*/:
                    obj = "ERROR";
                    break;
                case py.Toolbar_titleMarginEnd /*14*/:
                    obj = "INTERRUPTED";
                    break;
                case py.Toolbar_titleMarginTop /*15*/:
                    obj = "TIMEOUT";
                    break;
                case py.Toolbar_titleMarginBottom /*16*/:
                    obj = "CANCELED";
                    break;
                case py.Toolbar_maxButtonHeight /*17*/:
                    obj = "API_NOT_CONNECTED";
                    break;
                case 3000:
                    obj = "AUTH_API_INVALID_CREDENTIALS";
                    break;
                case 3001:
                    obj = "AUTH_API_ACCESS_FORBIDDEN";
                    break;
                case 3002:
                    obj = "AUTH_API_CLIENT_ERROR";
                    break;
                case 3003:
                    obj = "AUTH_API_SERVER_ERROR";
                    break;
                case 3004:
                    obj = "AUTH_TOKEN_ERROR";
                    break;
                case 3005:
                    obj = "AUTH_URL_RESOLUTION";
                    break;
                default:
                    obj = "unknown status code: " + i;
                    break;
            }
        }
        obj = this.f829h;
        return a.m2252a(str, obj).m2252a("resolution", this.f830i).toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        aol.m2045a(this, parcel, i);
    }
}
