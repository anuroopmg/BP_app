package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aqh;
import happy.hacking.aqy;

public class ResolveAccountResponse implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f847a;
    public IBinder f848b;
    public ConnectionResult f849c;
    public boolean f850d;
    public boolean f851e;

    static {
        CREATOR = new aqy();
    }

    public ResolveAccountResponse() {
        this(new ConnectionResult(8, null));
    }

    public ResolveAccountResponse(int i, IBinder iBinder, ConnectionResult connectionResult, boolean z, boolean z2) {
        this.f847a = i;
        this.f848b = iBinder;
        this.f849c = connectionResult;
        this.f850d = z;
        this.f851e = z2;
    }

    private ResolveAccountResponse(ConnectionResult connectionResult) {
        this(1, null, connectionResult, false, false);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ResolveAccountResponse)) {
            return false;
        }
        ResolveAccountResponse resolveAccountResponse = (ResolveAccountResponse) obj;
        return this.f849c.equals(resolveAccountResponse.f849c) && aqh.m2077a(this.f848b).equals(aqh.m2077a(resolveAccountResponse.f848b));
    }

    public void writeToParcel(Parcel parcel, int i) {
        aqy.m2264a(this, parcel, i);
    }
}
