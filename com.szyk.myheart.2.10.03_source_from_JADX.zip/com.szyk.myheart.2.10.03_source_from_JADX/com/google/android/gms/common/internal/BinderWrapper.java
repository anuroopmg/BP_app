package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import happy.hacking.aon;

public final class BinderWrapper implements Parcelable {
    public static final Creator CREATOR;
    private IBinder f834a;

    static {
        CREATOR = new aon();
    }

    public BinderWrapper() {
        this.f834a = null;
    }

    public BinderWrapper(IBinder iBinder) {
        this.f834a = null;
        this.f834a = iBinder;
    }

    private BinderWrapper(Parcel parcel) {
        this.f834a = null;
        this.f834a = parcel.readStrongBinder();
    }

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeStrongBinder(this.f834a);
    }
}
