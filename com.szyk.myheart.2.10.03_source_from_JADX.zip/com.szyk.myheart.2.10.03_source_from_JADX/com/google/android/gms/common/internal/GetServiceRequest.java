package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.ani;
import happy.hacking.aor;
import happy.hacking.apn;
import happy.hacking.aqh;

public class GetServiceRequest implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f835a;
    public final int f836b;
    public int f837c;
    public String f838d;
    public IBinder f839e;
    public Scope[] f840f;
    public Bundle f841g;
    public Account f842h;

    static {
        CREATOR = new apn();
    }

    public GetServiceRequest(int i) {
        this.f835a = 2;
        this.f837c = ani.f2022a;
        this.f836b = i;
    }

    public GetServiceRequest(int i, int i2, int i3, String str, IBinder iBinder, Scope[] scopeArr, Bundle bundle, Account account) {
        this.f835a = i;
        this.f836b = i2;
        this.f837c = i3;
        this.f838d = str;
        if (i < 2) {
            Account account2 = null;
            if (iBinder != null) {
                account2 = aor.m2078a(aqh.m2077a(iBinder));
            }
            this.f842h = account2;
        } else {
            this.f839e = iBinder;
            this.f842h = account;
        }
        this.f840f = scopeArr;
        this.f841g = bundle;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        apn.m2110a(this, parcel, i);
    }
}
