package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.ani;
import happy.hacking.aot;
import happy.hacking.aqg;

public class ValidateAccountRequest implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f852a;
    public final int f853b;
    public final IBinder f854c;
    public final Scope[] f855d;
    public final Bundle f856e;
    public final String f857f;

    static {
        CREATOR = new aot();
    }

    public ValidateAccountRequest(int i, int i2, IBinder iBinder, Scope[] scopeArr, Bundle bundle, String str) {
        this.f852a = i;
        this.f853b = i2;
        this.f854c = iBinder;
        this.f855d = scopeArr;
        this.f856e = bundle;
        this.f857f = str;
    }

    public ValidateAccountRequest(aqg happy_hacking_aqg, Scope[] scopeArr, String str) {
        this(1, ani.f2022a, happy_hacking_aqg == null ? null : happy_hacking_aqg.asBinder(), scopeArr, null, str);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        aot.m2083a(this, parcel, i);
    }
}
