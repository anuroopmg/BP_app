package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aov;
import happy.hacking.aqg;
import java.util.Set;

public class AuthAccountRequest implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f831a;
    public final IBinder f832b;
    public final Scope[] f833c;

    static {
        CREATOR = new aov();
    }

    public AuthAccountRequest(int i, IBinder iBinder, Scope[] scopeArr) {
        this.f831a = i;
        this.f832b = iBinder;
        this.f833c = scopeArr;
    }

    public AuthAccountRequest(aqg happy_hacking_aqg, Set set) {
        this(1, happy_hacking_aqg.asBinder(), (Scope[]) set.toArray(new Scope[set.size()]));
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        aov.m2085a(this, parcel, i);
    }
}
