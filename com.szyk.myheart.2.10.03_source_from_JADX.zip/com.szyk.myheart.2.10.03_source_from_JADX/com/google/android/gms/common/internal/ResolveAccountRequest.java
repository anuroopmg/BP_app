package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import happy.hacking.aqx;

public class ResolveAccountRequest implements SafeParcelable {
    public static final Creator CREATOR;
    public final int f843a;
    public final Account f844b;
    public final int f845c;
    public final GoogleSignInAccount f846d;

    static {
        CREATOR = new aqx();
    }

    public ResolveAccountRequest(int i, Account account, int i2, GoogleSignInAccount googleSignInAccount) {
        this.f843a = i;
        this.f844b = account;
        this.f845c = i2;
        this.f846d = googleSignInAccount;
    }

    public ResolveAccountRequest(Account account, int i, GoogleSignInAccount googleSignInAccount) {
        this(2, account, i, googleSignInAccount);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        aqx.m2263a(this, parcel, i);
    }
}
