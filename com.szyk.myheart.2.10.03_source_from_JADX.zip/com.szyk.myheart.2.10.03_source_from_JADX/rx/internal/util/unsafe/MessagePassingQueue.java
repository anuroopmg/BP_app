package rx.internal.util.unsafe;

interface MessagePassingQueue {
    boolean isEmpty();

    boolean offer(Object obj);

    Object peek();

    Object poll();

    int size();
}
