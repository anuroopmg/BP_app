package rx.internal.util.unsafe;

import happy.hacking.dch;
import java.util.Iterator;

abstract class BaseLinkedQueue extends BaseLinkedQueueConsumerNodeRef {
    long p00;
    long p01;
    long p02;
    long p03;
    long p04;
    long p05;
    long p06;
    long p07;
    long p30;
    long p31;
    long p32;
    long p33;
    long p34;
    long p35;
    long p36;
    long p37;

    BaseLinkedQueue() {
    }

    public final Iterator iterator() {
        throw new UnsupportedOperationException();
    }

    public final int size() {
        dch lvConsumerNode = lvConsumerNode();
        dch lvProducerNode = lvProducerNode();
        dch happy_hacking_dch = lvConsumerNode;
        int i = 0;
        while (happy_hacking_dch != lvProducerNode && i < Integer.MAX_VALUE) {
            dch happy_hacking_dch2;
            do {
                happy_hacking_dch2 = (dch) happy_hacking_dch.get();
            } while (happy_hacking_dch2 == null);
            i++;
            happy_hacking_dch = happy_hacking_dch2;
        }
        return i;
    }

    public final boolean isEmpty() {
        return lvConsumerNode() == lvProducerNode();
    }
}
