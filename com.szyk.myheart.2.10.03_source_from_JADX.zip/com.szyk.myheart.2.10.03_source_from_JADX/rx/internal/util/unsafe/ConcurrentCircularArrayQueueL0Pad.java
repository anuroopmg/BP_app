package rx.internal.util.unsafe;

import java.util.AbstractQueue;

abstract class ConcurrentCircularArrayQueueL0Pad extends AbstractQueue implements MessagePassingQueue {
    long p00;
    long p01;
    long p02;
    long p03;
    long p04;
    long p05;
    long p06;
    long p07;
    long p30;
    long p31;
    long p32;
    long p33;
    long p34;
    long p35;
    long p36;
    long p37;

    ConcurrentCircularArrayQueueL0Pad() {
    }
}
