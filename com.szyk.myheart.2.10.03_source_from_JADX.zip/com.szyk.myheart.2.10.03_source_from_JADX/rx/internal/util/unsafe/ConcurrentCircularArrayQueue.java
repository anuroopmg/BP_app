package rx.internal.util.unsafe;

import java.util.Iterator;

public abstract class ConcurrentCircularArrayQueue extends ConcurrentCircularArrayQueueL0Pad {
    protected static final int BUFFER_PAD = 32;
    private static final long REF_ARRAY_BASE;
    private static final int REF_ELEMENT_SHIFT;
    protected static final int SPARSE_SHIFT;
    protected final Object[] buffer;
    protected final long mask;

    static {
        SPARSE_SHIFT = Integer.getInteger("sparse.shift", 0).intValue();
        int arrayIndexScale = UnsafeAccess.UNSAFE.arrayIndexScale(Object[].class);
        if (4 == arrayIndexScale) {
            REF_ELEMENT_SHIFT = SPARSE_SHIFT + 2;
        } else if (8 == arrayIndexScale) {
            REF_ELEMENT_SHIFT = SPARSE_SHIFT + 3;
        } else {
            throw new IllegalStateException("Unknown pointer size");
        }
        REF_ARRAY_BASE = (long) (UnsafeAccess.UNSAFE.arrayBaseOffset(Object[].class) + (BUFFER_PAD << (REF_ELEMENT_SHIFT - SPARSE_SHIFT)));
    }

    public ConcurrentCircularArrayQueue(int i) {
        int roundToPowerOfTwo = Pow2.roundToPowerOfTwo(i);
        this.mask = (long) (roundToPowerOfTwo - 1);
        this.buffer = new Object[((roundToPowerOfTwo << SPARSE_SHIFT) + 64)];
    }

    protected final long calcElementOffset(long j) {
        return calcElementOffset(j, this.mask);
    }

    protected final long calcElementOffset(long j, long j2) {
        return REF_ARRAY_BASE + ((j & j2) << REF_ELEMENT_SHIFT);
    }

    protected final void spElement(long j, Object obj) {
        spElement(this.buffer, j, obj);
    }

    protected final void spElement(Object[] objArr, long j, Object obj) {
        UnsafeAccess.UNSAFE.putObject(objArr, j, obj);
    }

    protected final void soElement(long j, Object obj) {
        soElement(this.buffer, j, obj);
    }

    protected final void soElement(Object[] objArr, long j, Object obj) {
        UnsafeAccess.UNSAFE.putOrderedObject(objArr, j, obj);
    }

    protected final Object lpElement(long j) {
        return lpElement(this.buffer, j);
    }

    protected final Object lpElement(Object[] objArr, long j) {
        return UnsafeAccess.UNSAFE.getObject(objArr, j);
    }

    protected final Object lvElement(long j) {
        return lvElement(this.buffer, j);
    }

    protected final Object lvElement(Object[] objArr, long j) {
        return UnsafeAccess.UNSAFE.getObjectVolatile(objArr, j);
    }

    public Iterator iterator() {
        throw new UnsupportedOperationException();
    }

    public void clear() {
        while (true) {
            if (poll() == null && isEmpty()) {
                return;
            }
        }
    }
}
