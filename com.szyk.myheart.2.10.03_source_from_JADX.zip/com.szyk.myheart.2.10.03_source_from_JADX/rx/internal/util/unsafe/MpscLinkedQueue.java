package rx.internal.util.unsafe;

import happy.hacking.dch;

public final class MpscLinkedQueue extends BaseLinkedQueue {
    public MpscLinkedQueue() {
        this.consumerNode = new dch();
        xchgProducerNode(this.consumerNode);
    }

    protected final dch xchgProducerNode(dch happy_hacking_dch) {
        dch happy_hacking_dch2;
        do {
            happy_hacking_dch2 = this.producerNode;
        } while (!UnsafeAccess.UNSAFE.compareAndSwapObject(this, P_NODE_OFFSET, happy_hacking_dch2, happy_hacking_dch));
        return happy_hacking_dch2;
    }

    public final boolean offer(Object obj) {
        if (obj == null) {
            throw new NullPointerException("null elements not allowed");
        }
        dch happy_hacking_dch = new dch(obj);
        xchgProducerNode(happy_hacking_dch).lazySet(happy_hacking_dch);
        return true;
    }

    public final Object poll() {
        dch lpConsumerNode = lpConsumerNode();
        dch happy_hacking_dch = (dch) lpConsumerNode.get();
        Object a;
        if (happy_hacking_dch != null) {
            a = happy_hacking_dch.m5454a();
            spConsumerNode(happy_hacking_dch);
            return a;
        } else if (lpConsumerNode == lvProducerNode()) {
            return null;
        } else {
            do {
                happy_hacking_dch = (dch) lpConsumerNode.get();
            } while (happy_hacking_dch == null);
            a = happy_hacking_dch.m5454a();
            this.consumerNode = happy_hacking_dch;
            return a;
        }
    }

    public final Object peek() {
        dch happy_hacking_dch = this.consumerNode;
        dch happy_hacking_dch2 = (dch) happy_hacking_dch.get();
        if (happy_hacking_dch2 != null) {
            return happy_hacking_dch2.f5497a;
        }
        if (happy_hacking_dch == lvProducerNode()) {
            return null;
        }
        do {
            happy_hacking_dch2 = (dch) happy_hacking_dch.get();
        } while (happy_hacking_dch2 == null);
        return happy_hacking_dch2.f5497a;
    }
}
