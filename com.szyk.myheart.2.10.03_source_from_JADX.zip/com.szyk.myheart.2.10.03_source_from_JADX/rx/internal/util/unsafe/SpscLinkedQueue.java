package rx.internal.util.unsafe;

import happy.hacking.dch;

public final class SpscLinkedQueue extends BaseLinkedQueue {
    public SpscLinkedQueue() {
        spProducerNode(new dch());
        spConsumerNode(this.producerNode);
        this.consumerNode.lazySet(null);
    }

    public final boolean offer(Object obj) {
        if (obj == null) {
            throw new NullPointerException("null elements not allowed");
        }
        dch happy_hacking_dch = new dch(obj);
        this.producerNode.lazySet(happy_hacking_dch);
        this.producerNode = happy_hacking_dch;
        return true;
    }

    public final Object poll() {
        dch happy_hacking_dch = (dch) this.consumerNode.get();
        if (happy_hacking_dch == null) {
            return null;
        }
        Object a = happy_hacking_dch.m5454a();
        this.consumerNode = happy_hacking_dch;
        return a;
    }

    public final Object peek() {
        dch happy_hacking_dch = (dch) this.consumerNode.get();
        if (happy_hacking_dch != null) {
            return happy_hacking_dch.f5497a;
        }
        return null;
    }
}
