package rx.internal.util.unsafe;

import happy.hacking.dch;

abstract class BaseLinkedQueueConsumerNodeRef extends BaseLinkedQueuePad1 {
    protected static final long C_NODE_OFFSET;
    protected dch consumerNode;

    BaseLinkedQueueConsumerNodeRef() {
    }

    static {
        C_NODE_OFFSET = UnsafeAccess.addressOf(BaseLinkedQueueConsumerNodeRef.class, "consumerNode");
    }

    protected final void spConsumerNode(dch happy_hacking_dch) {
        this.consumerNode = happy_hacking_dch;
    }

    protected final dch lvConsumerNode() {
        return (dch) UnsafeAccess.UNSAFE.getObjectVolatile(this, C_NODE_OFFSET);
    }

    protected final dch lpConsumerNode() {
        return this.consumerNode;
    }
}
