package rx.internal.util.unsafe;

abstract class SpmcArrayQueueProducerField extends SpmcArrayQueueL1Pad {
    protected static final long P_INDEX_OFFSET;
    private volatile long producerIndex;

    static {
        P_INDEX_OFFSET = UnsafeAccess.addressOf(SpmcArrayQueueProducerField.class, "producerIndex");
    }

    protected final long lvProducerIndex() {
        return this.producerIndex;
    }

    protected final void soTail(long j) {
        UnsafeAccess.UNSAFE.putOrderedLong(this, P_INDEX_OFFSET, j);
    }

    public SpmcArrayQueueProducerField(int i) {
        super(i);
    }
}
