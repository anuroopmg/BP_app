package rx.internal.util.unsafe;

import happy.hacking.dch;

abstract class BaseLinkedQueueProducerNodeRef extends BaseLinkedQueuePad0 {
    protected static final long P_NODE_OFFSET;
    protected dch producerNode;

    BaseLinkedQueueProducerNodeRef() {
    }

    static {
        P_NODE_OFFSET = UnsafeAccess.addressOf(BaseLinkedQueueProducerNodeRef.class, "producerNode");
    }

    protected final void spProducerNode(dch happy_hacking_dch) {
        this.producerNode = happy_hacking_dch;
    }

    protected final dch lvProducerNode() {
        return (dch) UnsafeAccess.UNSAFE.getObjectVolatile(this, P_NODE_OFFSET);
    }

    protected final dch lpProducerNode() {
        return this.producerNode;
    }
}
