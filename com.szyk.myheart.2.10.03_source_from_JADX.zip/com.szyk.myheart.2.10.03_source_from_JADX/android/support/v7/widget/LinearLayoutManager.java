package android.support.v7.widget;

import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import happy.hacking.iv;
import happy.hacking.lo;
import happy.hacking.mt;
import happy.hacking.py;
import happy.hacking.ug;
import happy.hacking.wr;
import happy.hacking.ws;
import happy.hacking.wt;
import happy.hacking.wu;
import happy.hacking.xj;
import happy.hacking.xk;
import happy.hacking.xl;
import happy.hacking.ya;
import happy.hacking.yb;
import happy.hacking.yf;
import happy.hacking.yl;
import happy.hacking.yo;
import java.util.List;

public final class LinearLayoutManager extends ya {
    int f525a;
    public xj f526b;
    boolean f527c;
    int f528d;
    int f529e;
    SavedState f530f;
    final wr f531g;
    private wt f532l;
    private boolean f533m;
    private boolean f534n;
    private boolean f535o;
    private boolean f536p;
    private boolean f537q;

    public class SavedState implements Parcelable {
        public static final Creator CREATOR;
        int f517a;
        int f518b;
        boolean f519c;

        public SavedState(Parcel parcel) {
            boolean z = true;
            this.f517a = parcel.readInt();
            this.f518b = parcel.readInt();
            if (parcel.readInt() != 1) {
                z = false;
            }
            this.f519c = z;
        }

        public SavedState(SavedState savedState) {
            this.f517a = savedState.f517a;
            this.f518b = savedState.f518b;
            this.f519c = savedState.f519c;
        }

        final boolean m458a() {
            return this.f517a >= 0;
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f517a);
            parcel.writeInt(this.f518b);
            parcel.writeInt(this.f519c ? 1 : 0);
        }

        static {
            CREATOR = new wu();
        }
    }

    public LinearLayoutManager() {
        this((byte) 0);
    }

    private LinearLayoutManager(byte b) {
        this.f534n = false;
        this.f527c = false;
        this.f535o = false;
        this.f536p = true;
        this.f528d = -1;
        this.f529e = Integer.MIN_VALUE;
        this.f530f = null;
        this.f531g = new wr(this);
        m548a(null);
        if (1 != this.f525a) {
            this.f525a = 1;
            this.f526b = null;
            m503f();
        }
        m548a(null);
        if (this.f534n) {
            this.f534n = false;
            m503f();
        }
    }

    public final yb m543a() {
        return new yb();
    }

    public final void m545a(RecyclerView recyclerView, yf yfVar) {
        super.m480a(recyclerView, yfVar);
        if (this.f537q) {
            m491b(yfVar);
            yfVar.m7373a();
        }
    }

    public final void m546a(AccessibilityEvent accessibilityEvent) {
        int i = -1;
        super.m482a(accessibilityEvent);
        if (m504g() > 0) {
            int i2;
            mt a = lo.m6296a(accessibilityEvent);
            View a2 = m515a(0, m504g(), false);
            if (a2 == null) {
                i2 = -1;
            } else {
                i2 = ya.m460a(a2);
            }
            a.m6492b(i2);
            a2 = m515a(m504g() - 1, -1, false);
            if (a2 != null) {
                i = ya.m460a(a2);
            }
            a.m6493c(i);
        }
    }

    public final Parcelable m551b() {
        if (this.f530f != null) {
            return new SavedState(this.f530f);
        }
        Parcelable savedState = new SavedState();
        if (m504g() > 0) {
            m537q();
            boolean z = this.f533m ^ this.f527c;
            savedState.f519c = z;
            View s;
            if (z) {
                s = m539s();
                savedState.f518b = this.f526b.m7301c() - this.f526b.m7300b(s);
                savedState.f517a = ya.m460a(s);
                return savedState;
            }
            s = m538r();
            savedState.f517a = ya.m460a(s);
            savedState.f518b = this.f526b.m7297a(s) - this.f526b.m7299b();
            return savedState;
        }
        savedState.f517a = -1;
        return savedState;
    }

    public final void m544a(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            this.f530f = (SavedState) parcelable;
            m503f();
        }
    }

    public final boolean m555c() {
        return this.f525a == 0;
    }

    public final boolean m557d() {
        return this.f525a == 1;
    }

    private void m535o() {
        boolean z = true;
        if (this.f525a == 1 || !m536p()) {
            z = this.f534n;
        } else if (this.f534n) {
            z = false;
        }
        this.f527c = z;
    }

    public final View m542a(int i) {
        int g = m504g();
        if (g == 0) {
            return null;
        }
        int a = i - ya.m460a(m500e(0));
        if (a >= 0 && a < g) {
            View e = m500e(a);
            if (ya.m460a(e) == i) {
                return e;
            }
        }
        return super.m475a(i);
    }

    private int m527g(yl ylVar) {
        int i;
        if (ylVar.f6587a != -1) {
            i = 1;
        } else {
            i = 0;
        }
        if (i != 0) {
            return this.f526b.m7305e();
        }
        return 0;
    }

    public final void m547a(yf yfVar, yl ylVar) {
        if (!(this.f530f == null && this.f528d == -1) && ylVar.m7387a() == 0) {
            m491b(yfVar);
            return;
        }
        Object obj;
        View a;
        int b;
        int c;
        int b2;
        int min;
        int c2;
        if (this.f530f != null && this.f530f.m458a()) {
            this.f528d = this.f530f.f517a;
        }
        m537q();
        this.f532l.f6519a = false;
        m535o();
        wr wrVar = this.f531g;
        wrVar.f6511a = -1;
        wrVar.f6512b = Integer.MIN_VALUE;
        wrVar.f6513c = false;
        this.f531g.f6513c = this.f527c ^ this.f535o;
        wr wrVar2 = this.f531g;
        if (ylVar.f6592f || this.f528d == -1) {
            obj = null;
        } else if (this.f528d < 0 || this.f528d >= ylVar.m7387a()) {
            this.f528d = -1;
            this.f529e = Integer.MIN_VALUE;
            obj = null;
        } else {
            wrVar2.f6511a = this.f528d;
            if (this.f530f == null || !this.f530f.m458a()) {
                if (this.f529e == Integer.MIN_VALUE) {
                    a = m542a(this.f528d);
                    if (a == null) {
                        if (m504g() > 0) {
                            wrVar2.f6513c = (this.f528d < ya.m460a(m500e(0))) == this.f527c;
                        }
                        wrVar2.m7290a();
                    } else if (this.f526b.m7302c(a) > this.f526b.m7305e()) {
                        wrVar2.m7290a();
                    } else if (this.f526b.m7297a(a) - this.f526b.m7299b() < 0) {
                        wrVar2.f6512b = this.f526b.m7299b();
                        wrVar2.f6513c = false;
                    } else if (this.f526b.m7301c() - this.f526b.m7300b(a) < 0) {
                        wrVar2.f6512b = this.f526b.m7301c();
                        wrVar2.f6513c = true;
                    } else {
                        if (wrVar2.f6513c) {
                            b = this.f526b.m7300b(a) + this.f526b.m7296a();
                        } else {
                            b = this.f526b.m7297a(a);
                        }
                        wrVar2.f6512b = b;
                    }
                    obj = 1;
                } else {
                    wrVar2.f6513c = this.f527c;
                    if (this.f527c) {
                        wrVar2.f6512b = this.f526b.m7301c() - this.f529e;
                    } else {
                        wrVar2.f6512b = this.f526b.m7299b() + this.f529e;
                    }
                }
                obj = 1;
            } else {
                wrVar2.f6513c = this.f530f.f519c;
                if (wrVar2.f6513c) {
                    wrVar2.f6512b = this.f526b.m7301c() - this.f530f.f518b;
                } else {
                    wrVar2.f6512b = this.f526b.m7299b() + this.f530f.f518b;
                }
                obj = 1;
            }
        }
        if (obj == null) {
            if (m504g() != 0) {
                View view;
                if (this.f522i == null) {
                    view = null;
                } else {
                    a = this.f522i.getFocusedChild();
                    view = (a == null || this.f521h.m7236d(a)) ? null : a;
                }
                if (view != null) {
                    yb ybVar = (yb) view.getLayoutParams();
                    if (ybVar.f6557a.m4675m() || ybVar.f6557a.m4665c() < 0 || ybVar.f6557a.m4665c() >= ylVar.m7387a()) {
                        obj = null;
                    } else {
                        obj = 1;
                    }
                    if (obj != null) {
                        b = wrVar2.f6514d.f526b.m7296a();
                        if (b >= 0) {
                            wrVar2.m7291a(view);
                        } else {
                            wrVar2.f6511a = ya.m460a(view);
                            if (wrVar2.f6513c) {
                                b = (wrVar2.f6514d.f526b.m7301c() - b) - wrVar2.f6514d.f526b.m7300b(view);
                                wrVar2.f6512b = wrVar2.f6514d.f526b.m7301c() - b;
                                if (b > 0) {
                                    c = wrVar2.f6512b - wrVar2.f6514d.f526b.m7302c(view);
                                    b2 = wrVar2.f6514d.f526b.m7299b();
                                    min = c - (Math.min(wrVar2.f6514d.f526b.m7297a(view) - b2, 0) + b2);
                                    if (min < 0) {
                                        wrVar2.f6512b = Math.min(b, -min) + wrVar2.f6512b;
                                    }
                                }
                            } else {
                                c = wrVar2.f6514d.f526b.m7297a(view);
                                b2 = c - wrVar2.f6514d.f526b.m7299b();
                                wrVar2.f6512b = c;
                                if (b2 > 0) {
                                    b = (wrVar2.f6514d.f526b.m7301c() - Math.min(0, (wrVar2.f6514d.f526b.m7301c() - b) - wrVar2.f6514d.f526b.m7300b(view))) - (c + wrVar2.f6514d.f526b.m7302c(view));
                                    if (b < 0) {
                                        wrVar2.f6512b -= Math.min(b2, -b);
                                    }
                                }
                            }
                        }
                        obj = 1;
                        if (obj == null) {
                            wrVar2.m7290a();
                            if (this.f535o) {
                                b = ylVar.m7387a() - 1;
                            } else {
                                b = 0;
                            }
                            wrVar2.f6511a = b;
                        }
                    }
                }
                if (this.f533m == this.f535o) {
                    a = wrVar2.f6513c ? m531k(ylVar) : m532l(ylVar);
                    if (a != null) {
                        wrVar2.m7291a(a);
                        if (!ylVar.f6592f && m559e()) {
                            obj = (this.f526b.m7297a(a) >= this.f526b.m7301c() || this.f526b.m7300b(a) < this.f526b.m7299b()) ? 1 : null;
                            if (obj != null) {
                                wrVar2.f6512b = wrVar2.f6513c ? this.f526b.m7301c() : this.f526b.m7299b();
                            }
                        }
                        obj = 1;
                        if (obj == null) {
                            wrVar2.m7290a();
                            if (this.f535o) {
                                b = 0;
                            } else {
                                b = ylVar.m7387a() - 1;
                            }
                            wrVar2.f6511a = b;
                        }
                    }
                }
            }
            obj = null;
            if (obj == null) {
                wrVar2.m7290a();
                if (this.f535o) {
                    b = ylVar.m7387a() - 1;
                } else {
                    b = 0;
                }
                wrVar2.f6511a = b;
            }
        }
        b = m527g(ylVar);
        if (this.f532l.f6528j >= 0) {
            min = 0;
        } else {
            min = b;
            b = 0;
        }
        min += this.f526b.m7299b();
        b += this.f526b.m7306f();
        if (!(!ylVar.f6592f || this.f528d == -1 || this.f529e == Integer.MIN_VALUE)) {
            View a2 = m542a(this.f528d);
            if (a2 != null) {
                if (this.f527c) {
                    c2 = (this.f526b.m7301c() - this.f526b.m7300b(a2)) - this.f529e;
                } else {
                    c2 = this.f529e - (this.f526b.m7297a(a2) - this.f526b.m7299b());
                }
                if (c2 > 0) {
                    min += c2;
                } else {
                    b -= c2;
                }
            }
        }
        for (c2 = m504g() - 1; c2 >= 0; c2--) {
            View e = m500e(c2);
            yo b3 = RecyclerView.m29b(e);
            if (!b3.m4664b()) {
                if (!b3.m4672j() || b3.m4675m() || this.f522i.f75z.f4600e) {
                    m497d(c2);
                    yfVar.m7381c(e);
                } else {
                    m494c(c2);
                    yfVar.m7375a(b3);
                }
            }
        }
        this.f532l.f6527i = ylVar.f6592f;
        if (this.f531g.f6513c) {
            m525b(this.f531g);
            this.f532l.f6526h = min;
            m513a(yfVar, this.f532l, ylVar, false);
            min = this.f532l.f6520b;
            c = this.f532l.f6522d;
            if (this.f532l.f6521c > 0) {
                b += this.f532l.f6521c;
            }
            m519a(this.f531g);
            this.f532l.f6526h = b;
            wt wtVar = this.f532l;
            wtVar.f6522d += this.f532l.f6523e;
            m513a(yfVar, this.f532l, ylVar, false);
            c2 = this.f532l.f6520b;
            if (this.f532l.f6521c > 0) {
                b = this.f532l.f6521c;
                m524b(c, min);
                this.f532l.f6526h = b;
                m513a(yfVar, this.f532l, ylVar, false);
                b = this.f532l.f6520b;
            } else {
                b = min;
            }
            min = b;
            b = c2;
        } else {
            m519a(this.f531g);
            this.f532l.f6526h = b;
            m513a(yfVar, this.f532l, ylVar, false);
            b = this.f532l.f6520b;
            c2 = this.f532l.f6522d;
            if (this.f532l.f6521c > 0) {
                min += this.f532l.f6521c;
            }
            m525b(this.f531g);
            this.f532l.f6526h = min;
            wt wtVar2 = this.f532l;
            wtVar2.f6522d += this.f532l.f6523e;
            m513a(yfVar, this.f532l, ylVar, false);
            min = this.f532l.f6520b;
            if (this.f532l.f6521c > 0) {
                c = this.f532l.f6521c;
                m517a(c2, b);
                this.f532l.f6526h = c;
                m513a(yfVar, this.f532l, ylVar, false);
                b = this.f532l.f6520b;
            }
        }
        if (m504g() <= 0) {
            c2 = min;
            min = b;
        } else if ((this.f527c ^ this.f535o) != 0) {
            c2 = m512a(b, yfVar, ylVar, true);
            min += c2;
            b += c2;
            c2 = m522b(min, yfVar, ylVar, false);
            b += c2;
            c2 = min + c2;
            min = b;
        } else {
            c2 = m522b(min, yfVar, ylVar, true);
            min += c2;
            b += c2;
            c2 = m512a(b, yfVar, ylVar, false);
            b += c2;
            c2 = min + c2;
            min = b;
        }
        if (ylVar.f6594h && m504g() != 0 && !ylVar.f6592f && m559e()) {
            int i = 0;
            b2 = 0;
            List list = yfVar.f6567d;
            int size = list.size();
            int a3 = ya.m460a(m500e(0));
            int i2 = 0;
            while (i2 < size) {
                yo yoVar = (yo) list.get(i2);
                if (yoVar.m4675m()) {
                    b = b2;
                    c = i;
                } else {
                    if (((yoVar.m4665c() < a3) != this.f527c ? -1 : 1) == -1) {
                        c = this.f526b.m7302c(yoVar.f4548a) + i;
                        b = b2;
                    } else {
                        b = this.f526b.m7302c(yoVar.f4548a) + b2;
                        c = i;
                    }
                }
                i = c;
                i2++;
                b2 = b;
            }
            this.f532l.f6529k = list;
            if (i > 0) {
                m524b(ya.m460a(m538r()), c2);
                this.f532l.f6526h = i;
                this.f532l.f6521c = 0;
                this.f532l.m7292a(null);
                m513a(yfVar, this.f532l, ylVar, false);
            }
            if (b2 > 0) {
                m517a(ya.m460a(m539s()), min);
                this.f532l.f6526h = b2;
                this.f532l.f6521c = 0;
                this.f532l.m7292a(null);
                m513a(yfVar, this.f532l, ylVar, false);
            }
            this.f532l.f6529k = null;
        }
        if (!ylVar.f6592f) {
            this.f528d = -1;
            this.f529e = Integer.MIN_VALUE;
            xj xjVar = this.f526b;
            xjVar.f6546b = xjVar.m7305e();
        }
        this.f533m = this.f535o;
        this.f530f = null;
    }

    private int m512a(int i, yf yfVar, yl ylVar, boolean z) {
        int c = this.f526b.m7301c() - i;
        if (c <= 0) {
            return 0;
        }
        c = -m526d(-c, yfVar, ylVar);
        int i2 = i + c;
        if (!z) {
            return c;
        }
        i2 = this.f526b.m7301c() - i2;
        if (i2 <= 0) {
            return c;
        }
        this.f526b.m7298a(i2);
        return c + i2;
    }

    private int m522b(int i, yf yfVar, yl ylVar, boolean z) {
        int b = i - this.f526b.m7299b();
        if (b <= 0) {
            return 0;
        }
        b = -m526d(b, yfVar, ylVar);
        int i2 = i + b;
        if (!z) {
            return b;
        }
        i2 -= this.f526b.m7299b();
        if (i2 <= 0) {
            return b;
        }
        this.f526b.m7298a(-i2);
        return b - i2;
    }

    private void m519a(wr wrVar) {
        m517a(wrVar.f6511a, wrVar.f6512b);
    }

    private void m517a(int i, int i2) {
        this.f532l.f6521c = this.f526b.m7301c() - i2;
        this.f532l.f6523e = this.f527c ? -1 : 1;
        this.f532l.f6522d = i;
        this.f532l.f6524f = 1;
        this.f532l.f6520b = i2;
        this.f532l.f6525g = Integer.MIN_VALUE;
    }

    private void m525b(wr wrVar) {
        m524b(wrVar.f6511a, wrVar.f6512b);
    }

    private void m524b(int i, int i2) {
        this.f532l.f6521c = i2 - this.f526b.m7299b();
        this.f532l.f6522d = i;
        this.f532l.f6523e = this.f527c ? 1 : -1;
        this.f532l.f6524f = -1;
        this.f532l.f6520b = i2;
        this.f532l.f6525g = Integer.MIN_VALUE;
    }

    private boolean m536p() {
        return iv.m5931h(this.f522i) == 1;
    }

    private void m537q() {
        if (this.f532l == null) {
            this.f532l = new wt();
        }
        if (this.f526b == null) {
            xj xkVar;
            switch (this.f525a) {
                case ug.RecyclerView_android_orientation /*0*/:
                    xkVar = new xk(this);
                    break;
                case ug.RecyclerView_layoutManager /*1*/:
                    xkVar = new xl(this);
                    break;
                default:
                    throw new IllegalArgumentException("invalid orientation");
            }
            this.f526b = xkVar;
        }
    }

    public final void m552b(int i) {
        this.f528d = i;
        this.f529e = Integer.MIN_VALUE;
        if (this.f530f != null) {
            this.f530f.f517a = -1;
        }
        m503f();
    }

    public final int m540a(int i, yf yfVar, yl ylVar) {
        if (this.f525a == 1) {
            return 0;
        }
        return m526d(i, yfVar, ylVar);
    }

    public final int m549b(int i, yf yfVar, yl ylVar) {
        if (this.f525a == 0) {
            return 0;
        }
        return m526d(i, yfVar, ylVar);
    }

    public final int m541a(yl ylVar) {
        return m528h(ylVar);
    }

    public final int m550b(yl ylVar) {
        return m528h(ylVar);
    }

    public final int m553c(yl ylVar) {
        return m529i(ylVar);
    }

    public final int m556d(yl ylVar) {
        return m529i(ylVar);
    }

    public final int m558e(yl ylVar) {
        return m530j(ylVar);
    }

    public final int m560f(yl ylVar) {
        return m530j(ylVar);
    }

    private int m528h(yl ylVar) {
        boolean z = true;
        if (m504g() == 0) {
            return 0;
        }
        boolean z2;
        m537q();
        xj xjVar = this.f526b;
        if (this.f536p) {
            z2 = false;
        } else {
            z2 = true;
        }
        View a = m516a(z2);
        if (this.f536p) {
            z = false;
        }
        View b = m523b(z);
        boolean z3 = this.f536p;
        boolean z4 = this.f527c;
        if (m504g() == 0 || ylVar.m7387a() == 0 || a == null || b == null) {
            return 0;
        }
        int max = z4 ? Math.max(0, (ylVar.m7387a() - Math.max(ya.m460a(a), ya.m460a(b))) - 1) : Math.max(0, Math.min(ya.m460a(a), ya.m460a(b)));
        if (!z3) {
            return max;
        }
        return Math.round(((float) (xjVar.m7299b() - xjVar.m7297a(a))) + ((((float) Math.abs(xjVar.m7300b(b) - xjVar.m7297a(a))) / ((float) (Math.abs(ya.m460a(a) - ya.m460a(b)) + 1))) * ((float) max)));
    }

    private int m529i(yl ylVar) {
        boolean z = true;
        if (m504g() == 0) {
            return 0;
        }
        boolean z2;
        m537q();
        xj xjVar = this.f526b;
        if (this.f536p) {
            z2 = false;
        } else {
            z2 = true;
        }
        View a = m516a(z2);
        if (this.f536p) {
            z = false;
        }
        View b = m523b(z);
        boolean z3 = this.f536p;
        if (m504g() == 0 || ylVar.m7387a() == 0 || a == null || b == null) {
            return 0;
        }
        if (!z3) {
            return Math.abs(ya.m460a(a) - ya.m460a(b)) + 1;
        }
        return Math.min(xjVar.m7305e(), xjVar.m7300b(b) - xjVar.m7297a(a));
    }

    private int m530j(yl ylVar) {
        boolean z = true;
        if (m504g() == 0) {
            return 0;
        }
        boolean z2;
        m537q();
        xj xjVar = this.f526b;
        if (this.f536p) {
            z2 = false;
        } else {
            z2 = true;
        }
        View a = m516a(z2);
        if (this.f536p) {
            z = false;
        }
        View b = m523b(z);
        boolean z3 = this.f536p;
        if (m504g() == 0 || ylVar.m7387a() == 0 || a == null || b == null) {
            return 0;
        }
        if (!z3) {
            return ylVar.m7387a();
        }
        return (int) ((((float) (xjVar.m7300b(b) - xjVar.m7297a(a))) / ((float) (Math.abs(ya.m460a(a) - ya.m460a(b)) + 1))) * ((float) ylVar.m7387a()));
    }

    private void m518a(int i, int i2, boolean z, yl ylVar) {
        int i3 = -1;
        int i4 = 1;
        this.f532l.f6526h = m527g(ylVar);
        this.f532l.f6524f = i;
        View s;
        wt wtVar;
        if (i == 1) {
            wt wtVar2 = this.f532l;
            wtVar2.f6526h += this.f526b.m7306f();
            s = m539s();
            wtVar = this.f532l;
            if (!this.f527c) {
                i3 = 1;
            }
            wtVar.f6523e = i3;
            this.f532l.f6522d = ya.m460a(s) + this.f532l.f6523e;
            this.f532l.f6520b = this.f526b.m7300b(s);
            i3 = this.f526b.m7300b(s) - this.f526b.m7301c();
        } else {
            s = m538r();
            wtVar = this.f532l;
            wtVar.f6526h += this.f526b.m7299b();
            wtVar = this.f532l;
            if (!this.f527c) {
                i4 = -1;
            }
            wtVar.f6523e = i4;
            this.f532l.f6522d = ya.m460a(s) + this.f532l.f6523e;
            this.f532l.f6520b = this.f526b.m7297a(s);
            i3 = (-this.f526b.m7297a(s)) + this.f526b.m7299b();
        }
        this.f532l.f6521c = i2;
        if (z) {
            wt wtVar3 = this.f532l;
            wtVar3.f6521c -= i3;
        }
        this.f532l.f6525g = i3;
    }

    private int m526d(int i, yf yfVar, yl ylVar) {
        if (m504g() == 0 || i == 0) {
            return 0;
        }
        this.f532l.f6519a = true;
        m537q();
        int i2 = i > 0 ? 1 : -1;
        int abs = Math.abs(i);
        m518a(i2, abs, true, ylVar);
        int a = this.f532l.f6525g + m513a(yfVar, this.f532l, ylVar, false);
        if (a < 0) {
            return 0;
        }
        if (abs > a) {
            i = i2 * a;
        }
        this.f526b.m7298a(-i);
        this.f532l.f6528j = i;
        return i;
    }

    public final void m548a(String str) {
        if (this.f530f == null) {
            super.m485a(str);
        }
    }

    private void m520a(yf yfVar, int i, int i2) {
        if (i != i2) {
            if (i2 > i) {
                for (int i3 = i2 - 1; i3 >= i; i3--) {
                    m477a(i3, yfVar);
                }
                return;
            }
            while (i > i2) {
                m477a(i, yfVar);
                i--;
            }
        }
    }

    private void m521a(yf yfVar, wt wtVar) {
        if (!wtVar.f6519a) {
            return;
        }
        int i;
        int g;
        int d;
        if (wtVar.f6524f == -1) {
            i = wtVar.f6525g;
            g = m504g();
            if (i >= 0) {
                d = this.f526b.m7303d() - i;
                if (this.f527c) {
                    for (i = 0; i < g; i++) {
                        if (this.f526b.m7297a(m500e(i)) < d) {
                            m520a(yfVar, 0, i);
                            return;
                        }
                    }
                    return;
                }
                for (i = g - 1; i >= 0; i--) {
                    if (this.f526b.m7297a(m500e(i)) < d) {
                        m520a(yfVar, g - 1, i);
                        return;
                    }
                }
                return;
            }
            return;
        }
        g = wtVar.f6525g;
        if (g >= 0) {
            d = m504g();
            if (this.f527c) {
                for (i = d - 1; i >= 0; i--) {
                    if (this.f526b.m7300b(m500e(i)) > g) {
                        m520a(yfVar, d - 1, i);
                        return;
                    }
                }
                return;
            }
            for (i = 0; i < d; i++) {
                if (this.f526b.m7300b(m500e(i)) > g) {
                    m520a(yfVar, 0, i);
                    return;
                }
            }
        }
    }

    private int m513a(yf yfVar, wt wtVar, yl ylVar, boolean z) {
        int i = wtVar.f6521c;
        if (wtVar.f6525g != Integer.MIN_VALUE) {
            if (wtVar.f6521c < 0) {
                wtVar.f6525g += wtVar.f6521c;
            }
            m521a(yfVar, wtVar);
        }
        int i2 = wtVar.f6521c + wtVar.f6526h;
        ws wsVar = new ws();
        int i3 = i2;
        while (i3 > 0) {
            Object obj;
            if (wtVar.f6522d < 0 || wtVar.f6522d >= ylVar.m7387a()) {
                obj = null;
            } else {
                obj = 1;
            }
            if (obj == null) {
                break;
            }
            int size;
            int i4;
            yb ybVar;
            View view;
            wsVar.f6515a = 0;
            wsVar.f6516b = false;
            wsVar.f6517c = false;
            wsVar.f6518d = false;
            if (wtVar.f6529k != null) {
                size = wtVar.f6529k.size();
                for (i4 = 0; i4 < size; i4++) {
                    View view2 = ((yo) wtVar.f6529k.get(i4)).f4548a;
                    ybVar = (yb) view2.getLayoutParams();
                    if (!ybVar.f6557a.m4675m() && wtVar.f6522d == ybVar.f6557a.m4665c()) {
                        wtVar.m7292a(view2);
                        view = view2;
                        break;
                    }
                }
                view = null;
            } else {
                View a = yfVar.m7372a(wtVar.f6522d);
                wtVar.f6522d += wtVar.f6523e;
                view = a;
            }
            if (view == null) {
                wsVar.f6516b = true;
            } else {
                int i5;
                Rect rect;
                int h;
                int i6;
                ybVar = (yb) view.getLayoutParams();
                boolean z2;
                boolean z3;
                if (wtVar.f6529k == null) {
                    z2 = this.f527c;
                    if (wtVar.f6524f == -1) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    if (z2 == z3) {
                        super.m481a(view, -1, false);
                    } else {
                        super.m481a(view, 0, false);
                    }
                } else {
                    z2 = this.f527c;
                    if (wtVar.f6524f == -1) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    if (z2 == z3) {
                        super.m481a(view, -1, true);
                    } else {
                        super.m481a(view, 0, true);
                    }
                }
                yb ybVar2 = (yb) view.getLayoutParams();
                RecyclerView recyclerView = this.f522i;
                yb ybVar3 = (yb) view.getLayoutParams();
                if (ybVar3.f6559c) {
                    Rect rect2 = ybVar3.f6558b;
                    rect2.set(0, 0, 0, 0);
                    int size2 = recyclerView.f58g.size();
                    for (i5 = 0; i5 < size2; i5++) {
                        recyclerView.f56e.set(0, 0, 0, 0);
                        recyclerView.f58g.get(i5);
                        Rect rect3 = recyclerView.f56e;
                        ((yb) view.getLayoutParams()).f6557a.m4665c();
                        rect3.set(0, 0, 0, 0);
                        rect2.left += recyclerView.f56e.left;
                        rect2.top += recyclerView.f56e.top;
                        rect2.right += recyclerView.f56e.right;
                        rect2.bottom += recyclerView.f56e.bottom;
                    }
                    ybVar3.f6559c = false;
                    rect = rect2;
                } else {
                    rect = ybVar3.f6558b;
                }
                view.measure(ya.m459a(m505h(), ((rect.left + rect.right) + 0) + (((m507j() + m509l()) + ybVar2.leftMargin) + ybVar2.rightMargin), ybVar2.width, m495c()), ya.m459a(m506i(), ((rect.bottom + rect.top) + 0) + (((m508k() + m510m()) + ybVar2.topMargin) + ybVar2.bottomMargin), ybVar2.height, m498d()));
                wsVar.f6515a = this.f526b.m7302c(view);
                if (this.f525a == 1) {
                    if (m536p()) {
                        h = m505h() - m509l();
                        i4 = h - this.f526b.m7304d(view);
                    } else {
                        i4 = m507j();
                        h = this.f526b.m7304d(view) + i4;
                    }
                    if (wtVar.f6524f == -1) {
                        i6 = wtVar.f6520b;
                        size = i4;
                        i4 = wtVar.f6520b - wsVar.f6515a;
                    } else {
                        i6 = wtVar.f6520b + wsVar.f6515a;
                        int i7 = wtVar.f6520b;
                        size = i4;
                        i4 = i7;
                    }
                } else {
                    i4 = m508k();
                    i6 = i4 + this.f526b.m7304d(view);
                    if (wtVar.f6524f == -1) {
                        h = wtVar.f6520b;
                        size = wtVar.f6520b - wsVar.f6515a;
                    } else {
                        size = wtVar.f6520b;
                        h = wtVar.f6520b + wsVar.f6515a;
                    }
                }
                size += ybVar.leftMargin;
                i4 += ybVar.topMargin;
                i5 = h - ybVar.rightMargin;
                i6 -= ybVar.bottomMargin;
                Rect rect4 = ((yb) view.getLayoutParams()).f6558b;
                view.layout(size + rect4.left, i4 + rect4.top, i5 - rect4.right, i6 - rect4.bottom);
                if (ybVar.f6557a.m4675m() || ybVar.f6557a.m4681s()) {
                    wsVar.f6517c = true;
                }
                wsVar.f6518d = view.isFocusable();
            }
            if (!wsVar.f6516b) {
                wtVar.f6520b += wsVar.f6515a * wtVar.f6524f;
                if (wsVar.f6517c && this.f532l.f6529k == null && ylVar.f6592f) {
                    i2 = i3;
                } else {
                    wtVar.f6521c -= wsVar.f6515a;
                    i2 = i3 - wsVar.f6515a;
                }
                if (wtVar.f6525g != Integer.MIN_VALUE) {
                    wtVar.f6525g += wsVar.f6515a;
                    if (wtVar.f6521c < 0) {
                        wtVar.f6525g += wtVar.f6521c;
                    }
                    m521a(yfVar, wtVar);
                }
                if (z && wsVar.f6518d) {
                    break;
                }
                i3 = i2;
            } else {
                break;
            }
        }
        return i - wtVar.f6521c;
    }

    private View m538r() {
        return m500e(this.f527c ? m504g() - 1 : 0);
    }

    private View m539s() {
        return m500e(this.f527c ? 0 : m504g() - 1);
    }

    private View m516a(boolean z) {
        if (this.f527c) {
            return m515a(m504g() - 1, -1, z);
        }
        return m515a(0, m504g(), z);
    }

    private View m523b(boolean z) {
        if (this.f527c) {
            return m515a(0, m504g(), z);
        }
        return m515a(m504g() - 1, -1, z);
    }

    private View m531k(yl ylVar) {
        return this.f527c ? m533m(ylVar) : m534n(ylVar);
    }

    private View m532l(yl ylVar) {
        return this.f527c ? m534n(ylVar) : m533m(ylVar);
    }

    private View m533m(yl ylVar) {
        return m514a(0, m504g(), ylVar.m7387a());
    }

    private View m534n(yl ylVar) {
        return m514a(m504g() - 1, -1, ylVar.m7387a());
    }

    private View m514a(int i, int i2, int i3) {
        View view = null;
        m537q();
        int b = this.f526b.m7299b();
        int c = this.f526b.m7301c();
        int i4 = i2 > i ? 1 : -1;
        View view2 = null;
        while (i != i2) {
            View view3;
            View e = m500e(i);
            int a = ya.m460a(e);
            if (a >= 0 && a < i3) {
                if (((yb) e.getLayoutParams()).f6557a.m4675m()) {
                    if (view2 == null) {
                        view3 = view;
                        i += i4;
                        view = view3;
                        view2 = e;
                    }
                } else if (this.f526b.m7297a(e) < c && this.f526b.m7300b(e) >= b) {
                    return e;
                } else {
                    if (view == null) {
                        view3 = e;
                        e = view2;
                        i += i4;
                        view = view3;
                        view2 = e;
                    }
                }
            }
            view3 = view;
            e = view2;
            i += i4;
            view = view3;
            view2 = e;
        }
        return view != null ? view : view2;
    }

    private View m515a(int i, int i2, boolean z) {
        m537q();
        int b = this.f526b.m7299b();
        int c = this.f526b.m7301c();
        int i3 = i2 > i ? 1 : -1;
        View view = null;
        while (i != i2) {
            View e = m500e(i);
            int a = this.f526b.m7297a(e);
            int b2 = this.f526b.m7300b(e);
            if (a < c && b2 > b) {
                if (!z) {
                    return e;
                }
                if (a >= b && b2 <= c) {
                    return e;
                }
                if (view == null) {
                    i += i3;
                    view = e;
                }
            }
            e = view;
            i += i3;
            view = e;
        }
        return view;
    }

    public final View m554c(int i, yf yfVar, yl ylVar) {
        m535o();
        if (m504g() == 0) {
            return null;
        }
        int i2;
        switch (i) {
            case ug.RecyclerView_layoutManager /*1*/:
                i2 = -1;
                break;
            case ug.RecyclerView_spanCount /*2*/:
                i2 = 1;
                break;
            case py.Toolbar_maxButtonHeight /*17*/:
                if (this.f525a != 0) {
                    i2 = Integer.MIN_VALUE;
                    break;
                }
                i2 = -1;
                break;
            case py.Theme_actionModeCopyDrawable /*33*/:
                if (this.f525a != 1) {
                    i2 = Integer.MIN_VALUE;
                    break;
                }
                i2 = -1;
                break;
            case py.Theme_textAppearanceSearchResultSubtitle /*66*/:
                if (this.f525a != 0) {
                    i2 = Integer.MIN_VALUE;
                    break;
                }
                i2 = 1;
                break;
            case 130:
                if (this.f525a != 1) {
                    i2 = Integer.MIN_VALUE;
                    break;
                }
                i2 = 1;
                break;
            default:
                i2 = Integer.MIN_VALUE;
                break;
        }
        if (i2 == Integer.MIN_VALUE) {
            return null;
        }
        View l;
        m537q();
        if (i2 == -1) {
            l = m532l(ylVar);
        } else {
            l = m531k(ylVar);
        }
        if (l == null) {
            return null;
        }
        View r;
        m537q();
        m518a(i2, (int) (0.33f * ((float) this.f526b.m7305e())), false, ylVar);
        this.f532l.f6525g = Integer.MIN_VALUE;
        this.f532l.f6519a = false;
        m513a(yfVar, this.f532l, ylVar, true);
        if (i2 == -1) {
            r = m538r();
        } else {
            r = m539s();
        }
        if (r == l || !r.isFocusable()) {
            return null;
        }
        return r;
    }

    public final boolean m559e() {
        return this.f530f == null && this.f533m == this.f535o;
    }
}
