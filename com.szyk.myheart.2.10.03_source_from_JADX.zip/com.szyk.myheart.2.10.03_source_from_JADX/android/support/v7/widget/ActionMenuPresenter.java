package android.support.v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v7.internal.view.menu.ActionMenuItemView;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import happy.hacking.go;
import happy.hacking.gp;
import happy.hacking.jm;
import happy.hacking.pu;
import happy.hacking.pv;
import happy.hacking.qu;
import happy.hacking.ri;
import happy.hacking.rn;
import happy.hacking.rr;
import happy.hacking.sa;
import happy.hacking.se;
import happy.hacking.sf;
import happy.hacking.si;
import happy.hacking.uk;
import happy.hacking.ul;
import happy.hacking.um;
import happy.hacking.un;
import happy.hacking.up;
import happy.hacking.uq;
import happy.hacking.ur;
import java.util.ArrayList;

public final class ActionMenuPresenter extends ri implements gp {
    private final SparseBooleanArray f484A;
    private View f485B;
    private ul f486C;
    public un f487i;
    Drawable f488j;
    boolean f489k;
    public int f490l;
    public boolean f491m;
    public boolean f492n;
    public up f493o;
    public uk f494p;
    public um f495q;
    public final uq f496r;
    public int f497s;
    private boolean f498t;
    private boolean f499u;
    private int f500v;
    private int f501w;
    private boolean f502x;
    private boolean f503y;
    private int f504z;

    public class SavedState implements Parcelable {
        public static final Creator CREATOR;
        public int f473a;

        SavedState() {
        }

        public SavedState(Parcel parcel) {
            this.f473a = parcel.readInt();
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f473a);
        }

        static {
            CREATOR = new ur();
        }
    }

    public ActionMenuPresenter(Context context) {
        super(context, pv.abc_action_menu_layout, pv.abc_action_menu_item_layout);
        this.f484A = new SparseBooleanArray();
        this.f496r = new uq();
    }

    public final void m426a(Context context, rn rnVar) {
        boolean z = true;
        super.m412a(context, rnVar);
        Resources resources = context.getResources();
        qu a = qu.m6836a(context);
        if (!this.f499u) {
            if (VERSION.SDK_INT < 19 && jm.m6163b(ViewConfiguration.get(a.f5998a))) {
                z = false;
            }
            this.f498t = z;
        }
        if (!this.f503y) {
            this.f500v = a.f5998a.getResources().getDisplayMetrics().widthPixels / 2;
        }
        if (!this.f491m) {
            this.f490l = a.f5998a.getResources().getInteger(pu.abc_max_action_buttons);
        }
        int i = this.f500v;
        if (this.f498t) {
            if (this.f487i == null) {
                this.f487i = new un(this, this.a);
                if (this.f489k) {
                    this.f487i.setImageDrawable(this.f488j);
                    this.f488j = null;
                    this.f489k = false;
                }
                int makeMeasureSpec = MeasureSpec.makeMeasureSpec(0, 0);
                this.f487i.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i -= this.f487i.getMeasuredWidth();
        } else {
            this.f487i = null;
        }
        this.f501w = i;
        this.f504z = (int) (56.0f * resources.getDisplayMetrics().density);
        this.f485B = null;
    }

    public final void m438d() {
        this.f498t = true;
        this.f499u = true;
    }

    public final se m425a(ViewGroup viewGroup) {
        se a = super.m411a(viewGroup);
        ((ActionMenuView) a).setPresenter(this);
        return a;
    }

    public final View m424a(rr rrVar, View view, ViewGroup viewGroup) {
        View actionView = rrVar.getActionView();
        if (actionView == null || rrVar.m6922i()) {
            actionView = super.m410a(rrVar, view, viewGroup);
        }
        actionView.setVisibility(rrVar.isActionViewExpanded() ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(ActionMenuView.m446a(layoutParams));
        }
        return actionView;
    }

    public final void m430a(rr rrVar, sf sfVar) {
        sfVar.m10a(rrVar);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) sfVar;
        actionMenuItemView.setItemInvoker((ActionMenuView) this.g);
        if (this.f486C == null) {
            this.f486C = new ul();
        }
        actionMenuItemView.setPopupCallback(this.f486C);
    }

    public final boolean m437c(rr rrVar) {
        return rrVar.m6919f();
    }

    public final void m431a(boolean z) {
        int i;
        int i2 = 1;
        int i3 = 0;
        ((View) this.g).getParent();
        super.m415a(z);
        ((View) this.g).requestLayout();
        if (this.c != null) {
            rn rnVar = this.c;
            rnVar.m6115i();
            ArrayList arrayList = rnVar.f5690d;
            int size = arrayList.size();
            for (i = 0; i < size; i++) {
                go goVar = ((rr) arrayList.get(i)).f6112d;
                if (goVar != null) {
                    goVar.f5659a = this;
                }
            }
        }
        ArrayList j = this.c != null ? this.c.m6116j() : null;
        if (this.f498t && j != null) {
            i = j.size();
            if (i == 1) {
                int i4;
                if (((rr) j.get(0)).isActionViewExpanded()) {
                    i4 = 0;
                } else {
                    i4 = 1;
                }
                i3 = i4;
            } else {
                if (i <= 0) {
                    i2 = 0;
                }
                i3 = i2;
            }
        }
        if (i3 != 0) {
            if (this.f487i == null) {
                this.f487i = new un(this, this.a);
            }
            ViewGroup viewGroup = (ViewGroup) this.f487i.getParent();
            if (viewGroup != this.g) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.f487i);
                }
                ((ActionMenuView) this.g).addView(this.f487i, ActionMenuView.m445a());
            }
        } else if (this.f487i != null && this.f487i.getParent() == this.g) {
            ((ViewGroup) this.g).removeView(this.f487i);
        }
        ((ActionMenuView) this.g).setOverflowReserved(this.f498t);
    }

    public final boolean m433a(ViewGroup viewGroup, int i) {
        if (viewGroup.getChildAt(i) == this.f487i) {
            return false;
        }
        return super.m417a(viewGroup, i);
    }

    public final boolean m434a(si siVar) {
        if (!siVar.hasVisibleItems()) {
            return false;
        }
        View view;
        si siVar2 = siVar;
        while (siVar2.f6161l != this.c) {
            siVar2 = (si) siVar2.f6161l;
        }
        rr item = siVar2.getItem();
        ViewGroup viewGroup = (ViewGroup) this.g;
        if (viewGroup != null) {
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = viewGroup.getChildAt(i);
                if ((childAt instanceof sf) && ((sf) childAt).getItemData() == item) {
                    view = childAt;
                    break;
                }
            }
        }
        view = null;
        if (view == null) {
            if (this.f487i == null) {
                return false;
            }
            view = this.f487i;
        }
        this.f497s = siVar.getItem().getItemId();
        this.f494p = new uk(this, this.b, siVar);
        this.f494p.f6141b = view;
        if (this.f494p.m6951d()) {
            super.m419a(siVar);
            return true;
        }
        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
    }

    public final boolean m439e() {
        if (!this.f498t || m443i() || this.c == null || this.g == null || this.f495q != null || this.c.m6116j().isEmpty()) {
            return false;
        }
        this.f495q = new um(this, new up(this, this.b, this.c, this.f487i));
        ((View) this.g).post(this.f495q);
        super.m419a(null);
        return true;
    }

    public final boolean m440f() {
        if (this.f495q == null || this.g == null) {
            sa saVar = this.f493o;
            if (saVar == null) {
                return false;
            }
            saVar.m6952e();
            return true;
        }
        ((View) this.g).removeCallbacks(this.f495q);
        this.f495q = null;
        return true;
    }

    public final boolean m441g() {
        return m440f() | m442h();
    }

    public final boolean m442h() {
        if (this.f494p == null) {
            return false;
        }
        this.f494p.m6952e();
        return true;
    }

    public final boolean m443i() {
        return this.f493o != null && this.f493o.m6953f();
    }

    public final boolean m432a() {
        int i;
        ArrayList h = this.c.m6114h();
        int size = h.size();
        int i2 = this.f490l;
        int i3 = this.f501w;
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) this.g;
        int i4 = 0;
        int i5 = 0;
        Object obj = null;
        int i6 = 0;
        while (i6 < size) {
            rr rrVar = (rr) h.get(i6);
            if (rrVar.m6921h()) {
                i4++;
            } else if (rrVar.m6920g()) {
                i5++;
            } else {
                obj = 1;
            }
            if (this.f492n && rrVar.isActionViewExpanded()) {
                i = 0;
            } else {
                i = i2;
            }
            i6++;
            i2 = i;
        }
        if (this.f498t && (r4 != null || i4 + i5 > i2)) {
            i2--;
        }
        i6 = i2 - i4;
        SparseBooleanArray sparseBooleanArray = this.f484A;
        sparseBooleanArray.clear();
        if (this.f502x) {
            int i7 = i3 / this.f504z;
            i5 = ((i3 % this.f504z) / i7) + this.f504z;
            i = i7;
        } else {
            i5 = 0;
            i = 0;
        }
        i2 = 0;
        int i8 = 0;
        i4 = i;
        while (i8 < size) {
            rr rrVar2 = (rr) h.get(i8);
            View a;
            int i9;
            if (rrVar2.m6921h()) {
                a = m424a(rrVar2, this.f485B, viewGroup);
                if (this.f485B == null) {
                    this.f485B = a;
                }
                if (this.f502x) {
                    i = i4 - ActionMenuView.m444a(a, i5, i4, makeMeasureSpec, 0);
                } else {
                    a.measure(makeMeasureSpec, makeMeasureSpec);
                    i = i4;
                }
                i4 = a.getMeasuredWidth();
                i9 = i3 - i4;
                if (i2 != 0) {
                    i4 = i2;
                }
                i2 = rrVar2.getGroupId();
                if (i2 != 0) {
                    sparseBooleanArray.put(i2, true);
                }
                rrVar2.m6915c(true);
                i7 = i9;
                i2 = i6;
            } else if (rrVar2.m6920g()) {
                boolean z;
                int groupId = rrVar2.getGroupId();
                boolean z2 = sparseBooleanArray.get(groupId);
                boolean z3 = (i6 > 0 || z2) && i3 > 0 && (!this.f502x || i4 > 0);
                if (z3) {
                    a = m424a(rrVar2, this.f485B, viewGroup);
                    if (this.f485B == null) {
                        this.f485B = a;
                    }
                    if (this.f502x) {
                        int a2 = ActionMenuView.m444a(a, i5, i4, makeMeasureSpec, 0);
                        i4 -= a2;
                        if (a2 == 0) {
                            i = 0;
                        }
                    } else {
                        a.measure(makeMeasureSpec, makeMeasureSpec);
                    }
                    i9 = a.getMeasuredWidth();
                    i3 -= i9;
                    if (i2 == 0) {
                        i2 = i9;
                    }
                    if (this.f502x) {
                        z = i & (i3 >= 0 ? 1 : 0);
                        i9 = i4;
                    } else {
                        z = i & (i3 + i2 > 0 ? 1 : 0);
                        i9 = i4;
                    }
                } else {
                    z = z3;
                    i9 = i4;
                }
                if (z && groupId != 0) {
                    sparseBooleanArray.put(groupId, true);
                    i = i6;
                } else if (z2) {
                    sparseBooleanArray.put(groupId, false);
                    i4 = i6;
                    for (i6 = 0; i6 < i8; i6++) {
                        rrVar = (rr) h.get(i6);
                        if (rrVar.getGroupId() == groupId) {
                            if (rrVar.m6919f()) {
                                i4++;
                            }
                            rrVar.m6915c(false);
                        }
                    }
                    i = i4;
                } else {
                    i = i6;
                }
                if (z) {
                    i--;
                }
                rrVar2.m6915c(z);
                i4 = i2;
                i7 = i3;
                i2 = i;
                i = i9;
            } else {
                rrVar2.m6915c(false);
                i = i4;
                i7 = i3;
                i4 = i2;
                i2 = i6;
            }
            i8++;
            i3 = i7;
            i6 = i2;
            i2 = i4;
            i4 = i;
        }
        return true;
    }

    public final void m429a(rn rnVar, boolean z) {
        m441g();
        super.m413a(rnVar, z);
    }

    public final Parcelable m436c() {
        Parcelable savedState = new SavedState();
        savedState.f473a = this.f497s;
        return savedState;
    }

    public final void m427a(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        if (savedState.f473a > 0) {
            MenuItem findItem = this.c.findItem(savedState.f473a);
            if (findItem != null) {
                m434a((si) findItem.getSubMenu());
            }
        }
    }

    public final void m435b(boolean z) {
        if (z) {
            super.m419a(null);
        } else {
            this.c.m6098a(false);
        }
    }

    public final void m428a(ActionMenuView actionMenuView) {
        this.g = actionMenuView;
        actionMenuView.f505a = this.c;
    }
}
