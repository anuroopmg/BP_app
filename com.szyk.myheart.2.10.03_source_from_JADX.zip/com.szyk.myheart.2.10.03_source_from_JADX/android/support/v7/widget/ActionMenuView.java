package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v7.internal.view.menu.ActionMenuItemView;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.accessibility.AccessibilityEvent;
import happy.hacking.ri;
import happy.hacking.rn;
import happy.hacking.ro;
import happy.hacking.rp;
import happy.hacking.rr;
import happy.hacking.sd;
import happy.hacking.se;
import happy.hacking.ue;
import happy.hacking.us;
import happy.hacking.ut;
import happy.hacking.uu;
import happy.hacking.uv;
import happy.hacking.uw;
import happy.hacking.wp;
import happy.hacking.wq;

public class ActionMenuView extends wp implements rp, se {
    public rn f505a;
    public boolean f506b;
    public ActionMenuPresenter f507c;
    sd f508d;
    ro f509e;
    private Context f510f;
    private int f511g;
    private boolean f512h;
    private int f513i;
    private int f514j;
    private int f515k;
    private uw f516l;

    public final /* synthetic */ wq m452a(AttributeSet attributeSet) {
        return m450b(attributeSet);
    }

    protected final /* synthetic */ wq m455b(LayoutParams layoutParams) {
        return m446a(layoutParams);
    }

    protected final /* synthetic */ wq m457c() {
        return m451d();
    }

    protected /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        return m451d();
    }

    public /* synthetic */ LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return m450b(attributeSet);
    }

    protected /* synthetic */ LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return m446a(layoutParams);
    }

    public ActionMenuView(Context context) {
        this(context, null);
    }

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f = context.getResources().getDisplayMetrics().density;
        this.f514j = (int) (56.0f * f);
        this.f515k = (int) (f * 4.0f);
        this.f510f = context;
        this.f511g = 0;
    }

    public void setPopupTheme(int i) {
        if (this.f511g != i) {
            this.f511g = i;
            if (i == 0) {
                this.f510f = getContext();
            } else {
                this.f510f = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public int getPopupTheme() {
        return this.f511g;
    }

    public void setPresenter(ActionMenuPresenter actionMenuPresenter) {
        this.f507c = actionMenuPresenter;
        this.f507c.m428a(this);
    }

    public void onConfigurationChanged(Configuration configuration) {
        if (VERSION.SDK_INT >= 8) {
            super.onConfigurationChanged(configuration);
        }
        if (this.f507c != null) {
            this.f507c.m431a(false);
            if (this.f507c.m443i()) {
                this.f507c.m440f();
                this.f507c.m439e();
            }
        }
    }

    public void setOnMenuItemClickListener(uw uwVar) {
        this.f516l = uwVar;
    }

    protected void onMeasure(int i, int i2) {
        boolean z = this.f512h;
        this.f512h = MeasureSpec.getMode(i) == 1073741824;
        if (z != this.f512h) {
            this.f513i = 0;
        }
        int size = MeasureSpec.getSize(i);
        if (!(!this.f512h || this.f505a == null || size == this.f513i)) {
            this.f513i = size;
            this.f505a.m6104b(true);
        }
        int childCount = getChildCount();
        int i3;
        if (!this.f512h || childCount <= 0) {
            for (i3 = 0; i3 < childCount; i3++) {
                uu uuVar = (uu) getChildAt(i3).getLayoutParams();
                uuVar.rightMargin = 0;
                uuVar.leftMargin = 0;
            }
            super.onMeasure(i, i2);
            return;
        }
        int mode = MeasureSpec.getMode(i2);
        size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        i3 = getPaddingLeft() + getPaddingRight();
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int childMeasureSpec = getChildMeasureSpec(i2, paddingTop, -2);
        int i4 = size - i3;
        int i5 = i4 / this.f514j;
        size = i4 % this.f514j;
        if (i5 == 0) {
            setMeasuredDimension(i4, 0);
            return;
        }
        Object obj;
        Object obj2;
        int i6 = this.f514j + (size / i5);
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        i3 = 0;
        Object obj3 = null;
        long j = 0;
        int childCount2 = getChildCount();
        int i10 = 0;
        while (i10 < childCount2) {
            int i11;
            int i12;
            int i13;
            long j2;
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                boolean z2 = childAt instanceof ActionMenuItemView;
                i11 = i3 + 1;
                if (z2) {
                    childAt.setPadding(this.f515k, 0, this.f515k, 0);
                }
                uuVar = (uu) childAt.getLayoutParams();
                uuVar.f6329f = false;
                uuVar.f6326c = 0;
                uuVar.f6325b = 0;
                uuVar.f6327d = false;
                uuVar.leftMargin = 0;
                uuVar.rightMargin = 0;
                z = z2 && ((ActionMenuItemView) childAt).m336b();
                uuVar.f6328e = z;
                if (uuVar.f6324a) {
                    i3 = 1;
                } else {
                    i3 = i5;
                }
                int a = m444a(childAt, i6, i3, childMeasureSpec, paddingTop);
                i8 = Math.max(i8, a);
                if (uuVar.f6327d) {
                    i3 = i9 + 1;
                } else {
                    i3 = i9;
                }
                if (uuVar.f6324a) {
                    obj = 1;
                } else {
                    obj = obj3;
                }
                int i14 = i5 - a;
                i9 = Math.max(i7, childAt.getMeasuredHeight());
                if (a == 1) {
                    long j3 = ((long) (1 << i10)) | j;
                    i12 = i9;
                    i13 = i14;
                    i9 = i3;
                    obj3 = obj;
                    j2 = j3;
                    i5 = i8;
                    childCount = i11;
                } else {
                    childCount = i11;
                    i5 = i8;
                    long j4 = j;
                    i12 = i9;
                    i13 = i14;
                    obj3 = obj;
                    i9 = i3;
                    j2 = j4;
                }
            } else {
                childCount = i3;
                j2 = j;
                i12 = i7;
                i13 = i5;
                i5 = i8;
            }
            i10++;
            i8 = i5;
            i7 = i12;
            i5 = i13;
            j = j2;
            i3 = childCount;
        }
        if (obj3 == null || i3 != 2) {
            obj2 = null;
        } else {
            obj2 = 1;
        }
        Object obj4 = null;
        long j5 = j;
        paddingTop = i5;
        while (i9 > 0 && paddingTop > 0) {
            i11 = Integer.MAX_VALUE;
            j = 0;
            i5 = 0;
            int i15 = 0;
            while (i15 < childCount2) {
                uuVar = (uu) getChildAt(i15).getLayoutParams();
                if (uuVar.f6327d) {
                    int i16 = uuVar.f6325b;
                    if (r0 < i11) {
                        i5 = uuVar.f6325b;
                        j = (long) (1 << i15);
                        size = 1;
                    } else if (uuVar.f6325b == i11) {
                        j |= (long) (1 << i15);
                        size = i5 + 1;
                        i5 = i11;
                    }
                    i15++;
                    i11 = i5;
                    i5 = size;
                }
                size = i5;
                i5 = i11;
                i15++;
                i11 = i5;
                i5 = size;
            }
            j5 |= j;
            if (i5 > paddingTop) {
                break;
            }
            i15 = i11 + 1;
            i11 = 0;
            i5 = paddingTop;
            long j6 = j5;
            while (i11 < childCount2) {
                View childAt2 = getChildAt(i11);
                uuVar = (uu) childAt2.getLayoutParams();
                if ((((long) (1 << i11)) & j) != 0) {
                    if (obj2 != null && uuVar.f6328e && i5 == 1) {
                        childAt2.setPadding(this.f515k + i6, 0, this.f515k, 0);
                    }
                    uuVar.f6325b++;
                    uuVar.f6329f = true;
                    size = i5 - 1;
                } else if (uuVar.f6325b == i15) {
                    j6 |= (long) (1 << i11);
                    size = i5;
                } else {
                    size = i5;
                }
                i11++;
                i5 = size;
            }
            j5 = j6;
            i10 = 1;
            paddingTop = i5;
        }
        j = j5;
        obj = (obj3 == null && i3 == 1) ? 1 : null;
        if (paddingTop <= 0 || j == 0 || (paddingTop >= i3 - 1 && obj == null && i8 <= 1)) {
            obj2 = obj4;
        } else {
            float f;
            View childAt3;
            float bitCount = (float) Long.bitCount(j);
            if (obj == null) {
                if (!((1 & j) == 0 || ((uu) getChildAt(0).getLayoutParams()).f6328e)) {
                    bitCount -= 0.5f;
                }
                if (!((((long) (1 << (childCount2 - 1))) & j) == 0 || ((uu) getChildAt(childCount2 - 1).getLayoutParams()).f6328e)) {
                    f = bitCount - 0.5f;
                    if (f <= 0.0f) {
                        i3 = (int) (((float) (paddingTop * i6)) / f);
                    } else {
                        i3 = 0;
                    }
                    i5 = 0;
                    obj2 = obj4;
                    while (i5 < childCount2) {
                        if ((((long) (1 << i5)) & j) != 0) {
                            childAt3 = getChildAt(i5);
                            uuVar = (uu) childAt3.getLayoutParams();
                            if (childAt3 instanceof ActionMenuItemView) {
                                uuVar.f6326c = i3;
                                uuVar.f6329f = true;
                                if (i5 == 0 && !uuVar.f6328e) {
                                    uuVar.leftMargin = (-i3) / 2;
                                }
                                obj = 1;
                            } else if (uuVar.f6324a) {
                                if (i5 != 0) {
                                    uuVar.leftMargin = i3 / 2;
                                }
                                if (i5 != childCount2 - 1) {
                                    uuVar.rightMargin = i3 / 2;
                                }
                            } else {
                                uuVar.f6326c = i3;
                                uuVar.f6329f = true;
                                uuVar.rightMargin = (-i3) / 2;
                                obj = 1;
                            }
                            i5++;
                            obj2 = obj;
                        }
                        obj = obj2;
                        i5++;
                        obj2 = obj;
                    }
                }
            }
            f = bitCount;
            if (f <= 0.0f) {
                i3 = 0;
            } else {
                i3 = (int) (((float) (paddingTop * i6)) / f);
            }
            i5 = 0;
            obj2 = obj4;
            while (i5 < childCount2) {
                if ((((long) (1 << i5)) & j) != 0) {
                    childAt3 = getChildAt(i5);
                    uuVar = (uu) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        uuVar.f6326c = i3;
                        uuVar.f6329f = true;
                        uuVar.leftMargin = (-i3) / 2;
                        obj = 1;
                    } else if (uuVar.f6324a) {
                        if (i5 != 0) {
                            uuVar.leftMargin = i3 / 2;
                        }
                        if (i5 != childCount2 - 1) {
                            uuVar.rightMargin = i3 / 2;
                        }
                    } else {
                        uuVar.f6326c = i3;
                        uuVar.f6329f = true;
                        uuVar.rightMargin = (-i3) / 2;
                        obj = 1;
                    }
                    i5++;
                    obj2 = obj;
                }
                obj = obj2;
                i5++;
                obj2 = obj;
            }
        }
        if (obj2 != null) {
            for (i3 = 0; i3 < childCount2; i3++) {
                childAt = getChildAt(i3);
                uuVar = (uu) childAt.getLayoutParams();
                if (uuVar.f6329f) {
                    childAt.measure(MeasureSpec.makeMeasureSpec(uuVar.f6326c + (uuVar.f6325b * i6), 1073741824), childMeasureSpec);
                }
            }
        }
        if (mode == 1073741824) {
            i7 = size2;
        }
        setMeasuredDimension(i4, i7);
    }

    static int m444a(View view, int i, int i2, int i3, int i4) {
        boolean z;
        int i5;
        boolean z2 = false;
        uu uuVar = (uu) view.getLayoutParams();
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(i3) - i4, MeasureSpec.getMode(i3));
        ActionMenuItemView actionMenuItemView = view instanceof ActionMenuItemView ? (ActionMenuItemView) view : null;
        if (actionMenuItemView == null || !actionMenuItemView.m336b()) {
            z = false;
        } else {
            z = true;
        }
        if (i2 <= 0 || (z && i2 < 2)) {
            i5 = 0;
        } else {
            view.measure(MeasureSpec.makeMeasureSpec(i * i2, Integer.MIN_VALUE), makeMeasureSpec);
            int measuredWidth = view.getMeasuredWidth();
            i5 = measuredWidth / i;
            if (measuredWidth % i != 0) {
                i5++;
            }
            if (z && r1 < 2) {
                i5 = 2;
            }
        }
        if (!uuVar.f6324a && z) {
            z2 = true;
        }
        uuVar.f6327d = z2;
        uuVar.f6325b = i5;
        view.measure(MeasureSpec.makeMeasureSpec(i5 * i, 1073741824), makeMeasureSpec);
        return i5;
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (this.f512h) {
            uu uuVar;
            int measuredWidth;
            int paddingLeft;
            int i5;
            int childCount = getChildCount();
            int i6 = (i4 - i2) / 2;
            int dividerWidth = getDividerWidth();
            int i7 = 0;
            int paddingRight = ((i3 - i) - getPaddingRight()) - getPaddingLeft();
            Object obj = null;
            boolean a = ue.m7133a(this);
            int i8 = 0;
            while (i8 < childCount) {
                View childAt = getChildAt(i8);
                if (childAt.getVisibility() != 8) {
                    uuVar = (uu) childAt.getLayoutParams();
                    if (uuVar.f6324a) {
                        measuredWidth = childAt.getMeasuredWidth();
                        if (m448a(i8)) {
                            measuredWidth += dividerWidth;
                        }
                        int measuredHeight = childAt.getMeasuredHeight();
                        if (a) {
                            paddingLeft = uuVar.leftMargin + getPaddingLeft();
                            i5 = paddingLeft + measuredWidth;
                        } else {
                            i5 = (getWidth() - getPaddingRight()) - uuVar.rightMargin;
                            paddingLeft = i5 - measuredWidth;
                        }
                        int i9 = i6 - (measuredHeight / 2);
                        childAt.layout(paddingLeft, i9, i5, measuredHeight + i9);
                        paddingLeft = paddingRight - measuredWidth;
                        obj = 1;
                        measuredWidth = i7;
                    } else {
                        paddingLeft = paddingRight - (uuVar.rightMargin + (childAt.getMeasuredWidth() + uuVar.leftMargin));
                        m448a(i8);
                        measuredWidth = i7 + 1;
                    }
                } else {
                    paddingLeft = paddingRight;
                    measuredWidth = i7;
                }
                i8++;
                i7 = measuredWidth;
                paddingRight = paddingLeft;
            }
            if (childCount == 1 && obj == null) {
                View childAt2 = getChildAt(0);
                measuredWidth = childAt2.getMeasuredWidth();
                i5 = childAt2.getMeasuredHeight();
                paddingRight = ((i3 - i) / 2) - (measuredWidth / 2);
                i7 = i6 - (i5 / 2);
                childAt2.layout(paddingRight, i7, measuredWidth + paddingRight, i5 + i7);
                return;
            }
            paddingLeft = i7 - (obj != null ? 0 : 1);
            paddingRight = Math.max(0, paddingLeft > 0 ? paddingRight / paddingLeft : 0);
            View childAt3;
            int i10;
            if (a) {
                measuredWidth = getWidth() - getPaddingRight();
                i5 = 0;
                while (i5 < childCount) {
                    childAt3 = getChildAt(i5);
                    uuVar = (uu) childAt3.getLayoutParams();
                    if (childAt3.getVisibility() == 8 || uuVar.f6324a) {
                        paddingLeft = measuredWidth;
                    } else {
                        measuredWidth -= uuVar.rightMargin;
                        i8 = childAt3.getMeasuredWidth();
                        dividerWidth = childAt3.getMeasuredHeight();
                        i10 = i6 - (dividerWidth / 2);
                        childAt3.layout(measuredWidth - i8, i10, measuredWidth, dividerWidth + i10);
                        paddingLeft = measuredWidth - ((uuVar.leftMargin + i8) + paddingRight);
                    }
                    i5++;
                    measuredWidth = paddingLeft;
                }
                return;
            }
            measuredWidth = getPaddingLeft();
            i5 = 0;
            while (i5 < childCount) {
                childAt3 = getChildAt(i5);
                uuVar = (uu) childAt3.getLayoutParams();
                if (childAt3.getVisibility() == 8 || uuVar.f6324a) {
                    paddingLeft = measuredWidth;
                } else {
                    measuredWidth += uuVar.leftMargin;
                    i8 = childAt3.getMeasuredWidth();
                    dividerWidth = childAt3.getMeasuredHeight();
                    i10 = i6 - (dividerWidth / 2);
                    childAt3.layout(measuredWidth, i10, measuredWidth + i8, dividerWidth + i10);
                    paddingLeft = ((uuVar.rightMargin + i8) + paddingRight) + measuredWidth;
                }
                i5++;
                measuredWidth = paddingLeft;
            }
            return;
        }
        super.onLayout(z, i, i2, i3, i4);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        m456b();
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        ActionMenuPresenter actionMenuPresenter = this.f507c;
        if (actionMenuPresenter.f487i != null) {
            actionMenuPresenter.f487i.setImageDrawable(drawable);
            return;
        }
        actionMenuPresenter.f489k = true;
        actionMenuPresenter.f488j = drawable;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        ActionMenuPresenter actionMenuPresenter = this.f507c;
        if (actionMenuPresenter.f487i != null) {
            return actionMenuPresenter.f487i.getDrawable();
        }
        if (actionMenuPresenter.f489k) {
            return actionMenuPresenter.f488j;
        }
        return null;
    }

    public void setOverflowReserved(boolean z) {
        this.f506b = z;
    }

    private static uu m451d() {
        uu uuVar = new uu();
        uuVar.h = 16;
        return uuVar;
    }

    private uu m450b(AttributeSet attributeSet) {
        return new uu(getContext(), attributeSet);
    }

    protected static uu m446a(LayoutParams layoutParams) {
        if (layoutParams == null) {
            return m451d();
        }
        uu uuVar = layoutParams instanceof uu ? new uu((uu) layoutParams) : new uu(layoutParams);
        if (uuVar.h > 0) {
            return uuVar;
        }
        uuVar.h = 16;
        return uuVar;
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams != null && (layoutParams instanceof uu);
    }

    public static uu m445a() {
        uu d = m451d();
        d.f6324a = true;
        return d;
    }

    public final boolean m454a(rr rrVar) {
        return this.f505a.m6099a((MenuItem) rrVar, null, 0);
    }

    public int getWindowAnimations() {
        return 0;
    }

    public final void m453a(rn rnVar) {
        this.f505a = rnVar;
    }

    public Menu getMenu() {
        if (this.f505a == null) {
            sd sdVar;
            Context context = getContext();
            this.f505a = new rn(context);
            this.f505a.m6094a(new uv());
            this.f507c = new ActionMenuPresenter(context);
            this.f507c.m438d();
            ri riVar = this.f507c;
            if (this.f508d != null) {
                sdVar = this.f508d;
            } else {
                sdVar = new ut();
            }
            riVar.f479f = sdVar;
            this.f505a.m6096a(this.f507c, this.f510f);
            this.f507c.m428a(this);
        }
        return this.f505a;
    }

    public final void m456b() {
        if (this.f507c != null) {
            this.f507c.m441g();
        }
    }

    private boolean m448a(int i) {
        boolean z = false;
        if (i == 0) {
            return false;
        }
        View childAt = getChildAt(i - 1);
        View childAt2 = getChildAt(i);
        if (i < getChildCount() && (childAt instanceof us)) {
            z = ((us) childAt).m329d() | 0;
        }
        return (i <= 0 || !(childAt2 instanceof us)) ? z : ((us) childAt2).m328c() | z;
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    public void setExpandedActionViewsExclusive(boolean z) {
        this.f507c.f492n = z;
    }
}
