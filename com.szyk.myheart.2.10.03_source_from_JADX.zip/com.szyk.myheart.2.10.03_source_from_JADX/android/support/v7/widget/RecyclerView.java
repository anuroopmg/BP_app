package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.SystemClock;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.NotificationCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import happy.hacking.ex;
import happy.hacking.fk;
import happy.hacking.fn;
import happy.hacking.hu;
import happy.hacking.ia;
import happy.hacking.ib;
import happy.hacking.ip;
import happy.hacking.iv;
import happy.hacking.jm;
import happy.hacking.lo;
import happy.hacking.oc;
import happy.hacking.py;
import happy.hacking.ug;
import happy.hacking.ux;
import happy.hacking.uz;
import happy.hacking.wa;
import happy.hacking.wb;
import happy.hacking.wd;
import happy.hacking.xm;
import happy.hacking.xn;
import happy.hacking.xo;
import happy.hacking.xp;
import happy.hacking.xq;
import happy.hacking.xr;
import happy.hacking.xs;
import happy.hacking.xv;
import happy.hacking.xw;
import happy.hacking.xx;
import happy.hacking.xy;
import happy.hacking.xz;
import happy.hacking.ya;
import happy.hacking.yb;
import happy.hacking.yc;
import happy.hacking.yd;
import happy.hacking.ye;
import happy.hacking.yf;
import happy.hacking.yg;
import happy.hacking.yh;
import happy.hacking.yi;
import happy.hacking.yl;
import happy.hacking.ym;
import happy.hacking.yn;
import happy.hacking.yo;
import happy.hacking.yp;
import happy.hacking.zf;
import happy.hacking.zg;
import happy.hacking.zh;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

public class RecyclerView extends ViewGroup implements ia, ip {
    private static final Interpolator ao;
    private static final boolean f27t;
    private static final Class[] f28u;
    private yg f29A;
    private final ArrayList f30B;
    private yc f31C;
    private boolean f32D;
    private boolean f33E;
    private boolean f34F;
    private boolean f35G;
    private boolean f36H;
    private int f37I;
    private boolean f38J;
    private final boolean f39K;
    private final AccessibilityManager f40L;
    private List f41M;
    private int f42N;
    private int f43O;
    private int f44P;
    private VelocityTracker f45Q;
    private int f46R;
    private int f47S;
    private int f48T;
    private int f49U;
    private int f50V;
    private final int f51W;
    public final yf f52a;
    private final int aa;
    private float ab;
    private yd ac;
    private List ad;
    private xx ae;
    private boolean af;
    private yp ag;
    private xv ah;
    private final int[] ai;
    private final ib aj;
    private final int[] ak;
    private final int[] al;
    private final int[] am;
    private Runnable an;
    private final zh ap;
    public ux f53b;
    public wa f54c;
    public final zf f55d;
    final Rect f56e;
    ya f57f;
    final ArrayList f58g;
    public boolean f59h;
    boolean f60i;
    public boolean f61j;
    public oc f62k;
    public oc f63l;
    public oc f64m;
    public oc f65n;
    public xw f66o;
    final yn f67p;
    public final yl f68q;
    public boolean f69r;
    public boolean f70s;
    private final yh f71v;
    private SavedState f72w;
    private boolean f73x;
    private final Runnable f74y;
    private xs f75z;

    public class SavedState extends BaseSavedState {
        public static final Creator CREATOR;
        Parcelable f538a;

        public SavedState(Parcel parcel) {
            super(parcel);
            this.f538a = parcel.readParcelable(ya.class.getClassLoader());
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeParcelable(this.f538a, 0);
        }

        static {
            CREATOR = new yi();
        }
    }

    public static /* synthetic */ boolean m38c(RecyclerView recyclerView, View view) {
        boolean z = true;
        recyclerView.m78a();
        wa waVar = recyclerView.f54c;
        int a = waVar.f6453a.m7245a(view);
        if (a == -1) {
            waVar.m7232b(view);
        } else if (waVar.f6454b.m7241c(a)) {
            waVar.f6454b.m7242d(a);
            waVar.m7232b(view);
            waVar.f6453a.m7246a(a);
        } else {
            z = false;
        }
        if (z) {
            yo b = m29b(view);
            recyclerView.f52a.m7379b(b);
            recyclerView.f52a.m7375a(b);
        }
        recyclerView.m81a(false);
        return z;
    }

    public static /* synthetic */ void m59o(RecyclerView recyclerView) {
        if (!recyclerView.f61j) {
            int i;
            recyclerView.f61j = true;
            int b = recyclerView.f54c.m7230b();
            for (i = 0; i < b; i++) {
                yo b2 = m29b(recyclerView.f54c.m7234c(i));
                if (!(b2 == null || b2.m4664b())) {
                    b2.m4663b((int) NotificationCompat.FLAG_GROUP_SUMMARY);
                }
            }
            yf yfVar = recyclerView.f52a;
            int size = yfVar.f6566c.size();
            for (i = 0; i < size; i++) {
                yo yoVar = (yo) yfVar.f6566c.get(i);
                if (yoVar != null) {
                    yoVar.m4663b((int) NotificationCompat.FLAG_GROUP_SUMMARY);
                }
            }
        }
    }

    static {
        boolean z;
        if (VERSION.SDK_INT == 18 || VERSION.SDK_INT == 19 || VERSION.SDK_INT == 20) {
            z = true;
        } else {
            z = false;
        }
        f27t = z;
        f28u = new Class[]{Context.class, AttributeSet.class, Integer.TYPE, Integer.TYPE};
        ao = new xo();
    }

    public RecyclerView(Context context) {
        this(context, null);
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public RecyclerView(Context context, AttributeSet attributeSet, int i) {
        boolean z;
        String str;
        super(context, attributeSet, i);
        this.f71v = new yh();
        this.f52a = new yf(this);
        this.f55d = new zf();
        this.f74y = new xm(this);
        this.f56e = new Rect();
        this.f58g = new ArrayList();
        this.f30B = new ArrayList();
        this.f61j = false;
        this.f42N = 0;
        this.f66o = new wd();
        this.f43O = 0;
        this.f44P = -1;
        this.ab = Float.MIN_VALUE;
        this.f67p = new yn(this);
        this.f68q = new yl();
        this.f69r = false;
        this.f70s = false;
        this.ae = new xz();
        this.af = false;
        this.ai = new int[2];
        this.ak = new int[2];
        this.al = new int[2];
        this.am = new int[2];
        this.an = new xn(this);
        this.ap = new xp(this);
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        this.f39K = VERSION.SDK_INT >= 16;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f50V = viewConfiguration.getScaledTouchSlop();
        this.f51W = viewConfiguration.getScaledMinimumFlingVelocity();
        this.aa = viewConfiguration.getScaledMaximumFlingVelocity();
        if (iv.m5901a(this) == 2) {
            z = true;
        } else {
            z = false;
        }
        setWillNotDraw(z);
        this.f66o.f6459h = this.ae;
        this.f53b = new ux(new xr(this));
        this.f54c = new wa(new xq(this));
        if (iv.m5925e(this) == 0) {
            iv.m5920c((View) this, 1);
        }
        this.f40L = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new yp(this));
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ug.RecyclerView, i, 0);
            String string = obtainStyledAttributes.getString(ug.RecyclerView_layoutManager);
            obtainStyledAttributes.recycle();
            if (string != null) {
                String trim = string.trim();
                if (trim.length() != 0) {
                    if (trim.charAt(0) == '.') {
                        str = context.getPackageName() + trim;
                    } else if (trim.contains(".")) {
                        str = trim;
                    } else {
                        str = RecyclerView.class.getPackage().getName() + '.' + trim;
                    }
                    try {
                        ClassLoader classLoader;
                        Object[] objArr;
                        Constructor constructor;
                        if (isInEditMode()) {
                            classLoader = getClass().getClassLoader();
                        } else {
                            classLoader = context.getClassLoader();
                        }
                        Class asSubclass = classLoader.loadClass(str).asSubclass(ya.class);
                        try {
                            objArr = new Object[]{context, attributeSet, Integer.valueOf(i), Integer.valueOf(0)};
                            constructor = asSubclass.getConstructor(f28u);
                        } catch (Throwable e) {
                            constructor = asSubclass.getConstructor(new Class[0]);
                            objArr = null;
                        }
                        constructor.setAccessible(true);
                        setLayoutManager((ya) constructor.newInstance(objArr));
                    } catch (Throwable e2) {
                        e2.initCause(e);
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + str, e2);
                    } catch (Throwable e3) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + str, e3);
                    } catch (Throwable e32) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e32);
                    } catch (Throwable e322) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e322);
                    } catch (Throwable e3222) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + str, e3222);
                    } catch (Throwable e32222) {
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + str, e32222);
                    }
                }
            }
        }
        this.aj = new ib(this);
        setNestedScrollingEnabled(true);
    }

    public yp getCompatAccessibilityDelegate() {
        return this.ag;
    }

    public void setAccessibilityDelegateCompat(yp ypVar) {
        this.ag = ypVar;
        iv.m5908a((View) this, this.ag);
    }

    public void setHasFixedSize(boolean z) {
        this.f33E = z;
    }

    public void setClipToPadding(boolean z) {
        if (z != this.f73x) {
            m55m();
        }
        this.f73x = z;
        super.setClipToPadding(z);
        if (this.f59h) {
            requestLayout();
        }
    }

    public void setScrollingTouchSlop(int i) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        switch (i) {
            case ug.RecyclerView_android_orientation /*0*/:
                break;
            case ug.RecyclerView_layoutManager /*1*/:
                this.f50V = jm.m6162a(viewConfiguration);
                return;
            default:
                new StringBuilder("setScrollingTouchSlop(): bad argument constant ").append(i).append("; using default value");
                break;
        }
        this.f50V = viewConfiguration.getScaledTouchSlop();
    }

    public void setAdapter(xs xsVar) {
        xs xsVar2;
        setLayoutFrozen(false);
        if (this.f75z != null) {
            xsVar2 = this.f75z;
            xsVar2.f4599d.unregisterObserver(this.f71v);
        }
        if (this.f66o != null) {
            this.f66o.m7263d();
        }
        if (this.f57f != null) {
            this.f57f.m491b(this.f52a);
            this.f57f.m483a(this.f52a);
        }
        this.f52a.m7373a();
        this.f53b.m7152a();
        xsVar2 = this.f75z;
        this.f75z = xsVar;
        if (xsVar != null) {
            xsVar.f4599d.registerObserver(this.f71v);
        }
        yf yfVar = this.f52a;
        xs xsVar3 = this.f75z;
        yfVar.m7373a();
        ye c = yfVar.m7380c();
        if (xsVar2 != null) {
            c.m7366b();
        }
        if (c.f6563c == 0) {
            c.f6561a.clear();
        }
        if (xsVar3 != null) {
            c.m7365a();
        }
        this.f68q.f6591e = true;
        m75w();
        requestLayout();
    }

    public xs getAdapter() {
        return this.f75z;
    }

    public void setRecyclerListener(yg ygVar) {
        this.f29A = ygVar;
    }

    public int getBaseline() {
        if (this.f57f != null) {
            return -1;
        }
        return super.getBaseline();
    }

    public void setLayoutManager(ya yaVar) {
        if (yaVar != this.f57f) {
            if (this.f57f != null) {
                if (this.f32D) {
                    this.f57f.m490b(this, this.f52a);
                }
                this.f57f.m479a(null);
            }
            this.f52a.m7373a();
            wa waVar = this.f54c;
            wb wbVar = waVar.f6454b;
            while (true) {
                wbVar.f6456a = 0;
                if (wbVar.f6457b == null) {
                    break;
                }
                wbVar = wbVar.f6457b;
            }
            for (int size = waVar.f6455c.size() - 1; size >= 0; size--) {
                waVar.f6453a.m7254d((View) waVar.f6455c.get(size));
                waVar.f6455c.remove(size);
            }
            waVar.f6453a.m7251b();
            this.f57f = yaVar;
            if (yaVar != null) {
                if (yaVar.f522i != null) {
                    throw new IllegalArgumentException("LayoutManager " + yaVar + " is already attached to a RecyclerView: " + yaVar.f522i);
                }
                this.f57f.m479a(this);
                if (this.f32D) {
                    this.f57f.f524k = true;
                }
            }
            requestLayout();
        }
    }

    protected Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        if (this.f72w != null) {
            savedState.f538a = this.f72w.f538a;
        } else if (this.f57f != null) {
            savedState.f538a = this.f57f.m488b();
        } else {
            savedState.f538a = null;
        }
        return savedState;
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        this.f72w = (SavedState) parcelable;
        super.onRestoreInstanceState(this.f72w.getSuperState());
        if (this.f57f != null && this.f72w.f538a != null) {
            this.f57f.m478a(this.f72w.f538a);
        }
    }

    protected void dispatchSaveInstanceState(SparseArray sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    protected void dispatchRestoreInstanceState(SparseArray sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    private void m22a(yo yoVar) {
        View view = yoVar.f4548a;
        boolean z = view.getParent() == this;
        this.f52a.m7379b(m77a(view));
        if (yoVar.m4676n()) {
            this.f54c.m7228a(view, -1, view.getLayoutParams(), true);
        } else if (z) {
            wa waVar = this.f54c;
            int a = waVar.f6453a.m7245a(view);
            if (a < 0) {
                throw new IllegalArgumentException("view is not a child, cannot hide " + view);
            }
            waVar.f6454b.m7238a(a);
            waVar.m7227a(view);
        } else {
            this.f54c.m7229a(view, -1, true);
        }
    }

    public ya getLayoutManager() {
        return this.f57f;
    }

    public ye getRecycledViewPool() {
        return this.f52a.m7380c();
    }

    public void setRecycledViewPool(ye yeVar) {
        yf yfVar = this.f52a;
        if (yfVar.f6569f != null) {
            yfVar.f6569f.m7366b();
        }
        yfVar.f6569f = yeVar;
        if (yeVar != null) {
            ye yeVar2 = yfVar.f6569f;
            yfVar.f6571h.getAdapter();
            yeVar2.m7365a();
        }
    }

    public void setViewCacheExtension(ym ymVar) {
        this.f52a.f6570g = ymVar;
    }

    public void setItemViewCacheSize(int i) {
        yf yfVar = this.f52a;
        yfVar.f6568e = i;
        for (int size = yfVar.f6566c.size() - 1; size >= 0 && yfVar.f6566c.size() > i; size--) {
            yfVar.m7377b(size);
        }
    }

    public int getScrollState() {
        return this.f43O;
    }

    private void setScrollState(int i) {
        if (i != this.f43O) {
            this.f43O = i;
            if (i != 2) {
                m52l();
            }
            if (this.ad != null) {
                for (int size = this.ad.size() - 1; size >= 0; size--) {
                    this.ad.get(size);
                }
            }
        }
    }

    public void setChildDrawingOrderCallback(xv xvVar) {
        if (xvVar != this.ah) {
            this.ah = xvVar;
            setChildrenDrawingOrderEnabled(this.ah != null);
        }
    }

    @Deprecated
    public void setOnScrollListener(yd ydVar) {
        this.ac = ydVar;
    }

    public void scrollTo(int i, int i2) {
    }

    public void scrollBy(int i, int i2) {
        if (this.f57f == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.f60i) {
            boolean c = this.f57f.m495c();
            boolean d = this.f57f.m498d();
            if (c || d) {
                if (!c) {
                    i = 0;
                }
                if (!d) {
                    i2 = 0;
                }
                m24a(i, i2, null);
            }
        }
    }

    private void m48j() {
        boolean z = false;
        if (!this.f59h) {
            return;
        }
        if (this.f61j) {
            ex.m5598a("RV FullInvalidate");
            m71u();
            ex.m5597a();
        } else if (!this.f53b.m7158d()) {
        } else {
            if (this.f53b.m7154a(4) && !this.f53b.m7154a(11)) {
                ex.m5598a("RV PartialInvalidate");
                m78a();
                this.f53b.m7156b();
                if (!this.f35G) {
                    int a = this.f54c.m7225a();
                    for (int i = 0; i < a; i++) {
                        yo b = m29b(this.f54c.m7231b(i));
                        if (b != null && !b.m4664b() && b.m4681s()) {
                            z = true;
                            break;
                        }
                    }
                    if (z) {
                        m71u();
                    } else {
                        this.f53b.m7157c();
                    }
                }
                m81a(true);
                ex.m5597a();
            } else if (this.f53b.m7158d()) {
                ex.m5598a("RV FullInvalidate");
                m71u();
                ex.m5597a();
            }
        }
    }

    private boolean m24a(int i, int i2, MotionEvent motionEvent) {
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        m48j();
        if (this.f75z != null) {
            m78a();
            m60p();
            ex.m5598a("RV Scroll");
            if (i != 0) {
                i5 = this.f57f.m473a(i, this.f52a, this.f68q);
                i3 = i - i5;
            }
            if (i2 != 0) {
                i6 = this.f57f.m486b(i2, this.f52a, this.f68q);
                i4 = i2 - i6;
            }
            ex.m5597a();
            m76x();
            m62q();
            m81a(false);
        }
        int i7 = i4;
        i4 = i5;
        i5 = i6;
        if (!this.f58g.isEmpty()) {
            invalidate();
        }
        if (dispatchNestedScroll(i4, i5, i3, i7, this.ak)) {
            this.f48T -= this.ak[0];
            this.f49U -= this.ak[1];
            if (motionEvent != null) {
                motionEvent.offsetLocation((float) this.ak[0], (float) this.ak[1]);
            }
            int[] iArr = this.am;
            iArr[0] = iArr[0] + this.ak[0];
            iArr = this.am;
            iArr[1] = iArr[1] + this.ak[1];
        } else if (iv.m5901a(this) != 2) {
            if (motionEvent != null) {
                float x = motionEvent.getX();
                float f = (float) i3;
                float y = motionEvent.getY();
                float f2 = (float) i7;
                Object obj = null;
                if (f < 0.0f) {
                    m82b();
                    if (this.f62k.m6616a((-f) / ((float) getWidth()), 1.0f - (y / ((float) getHeight())))) {
                        obj = 1;
                    }
                } else if (f > 0.0f) {
                    m83c();
                    if (this.f64m.m6616a(f / ((float) getWidth()), y / ((float) getHeight()))) {
                        obj = 1;
                    }
                }
                if (f2 < 0.0f) {
                    m84d();
                    if (this.f63l.m6616a((-f2) / ((float) getHeight()), x / ((float) getWidth()))) {
                        obj = 1;
                    }
                } else if (f2 > 0.0f) {
                    m85e();
                    if (this.f65n.m6616a(f2 / ((float) getHeight()), 1.0f - (x / ((float) getWidth())))) {
                        obj = 1;
                    }
                }
                if (!(obj == null && f == 0.0f && f2 == 0.0f)) {
                    iv.m5922d(this);
                }
            }
            m14a(i, i2);
        }
        if (!(i4 == 0 && i5 == 0)) {
            m87g();
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        if (i4 == 0 && i5 == 0) {
            return false;
        }
        return true;
    }

    public int computeHorizontalScrollOffset() {
        return this.f57f.m495c() ? this.f57f.m474a(this.f68q) : 0;
    }

    public int computeHorizontalScrollExtent() {
        return this.f57f.m495c() ? this.f57f.m492c(this.f68q) : 0;
    }

    public int computeHorizontalScrollRange() {
        return this.f57f.m495c() ? this.f57f.m499e(this.f68q) : 0;
    }

    public int computeVerticalScrollOffset() {
        return this.f57f.m498d() ? this.f57f.m487b(this.f68q) : 0;
    }

    public int computeVerticalScrollExtent() {
        return this.f57f.m498d() ? this.f57f.m496d(this.f68q) : 0;
    }

    public int computeVerticalScrollRange() {
        return this.f57f.m498d() ? this.f57f.m502f(this.f68q) : 0;
    }

    public final void m78a() {
        if (!this.f34F) {
            this.f34F = true;
            if (!this.f60i) {
                this.f35G = false;
            }
        }
    }

    public final void m81a(boolean z) {
        if (this.f34F) {
            if (!(!z || !this.f35G || this.f60i || this.f57f == null || this.f75z == null)) {
                m71u();
            }
            this.f34F = false;
            if (!this.f60i) {
                this.f35G = false;
            }
        }
    }

    public void setLayoutFrozen(boolean z) {
        if (z != this.f60i) {
            m80a("Do not setLayoutFrozen in layout or scroll");
            if (z) {
                long uptimeMillis = SystemClock.uptimeMillis();
                onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0));
                this.f60i = z;
                this.f36H = true;
                m50k();
                return;
            }
            this.f60i = z;
            if (!(!this.f35G || this.f57f == null || this.f75z == null)) {
                requestLayout();
            }
            this.f35G = false;
        }
    }

    private void m50k() {
        setScrollState(0);
        m52l();
    }

    private void m52l() {
        Object obj = this.f67p;
        obj.f6600d.removeCallbacks(obj);
        obj.f6599c.m6683h();
        if (this.f57f != null) {
            this.f57f.m511n();
        }
    }

    public int getMinFlingVelocity() {
        return this.f51W;
    }

    public int getMaxFlingVelocity() {
        return this.aa;
    }

    private void m14a(int i, int i2) {
        int i3 = 0;
        if (!(this.f62k == null || this.f62k.m6614a() || i <= 0)) {
            i3 = this.f62k.m6620c();
        }
        if (!(this.f64m == null || this.f64m.m6614a() || i >= 0)) {
            i3 |= this.f64m.m6620c();
        }
        if (!(this.f63l == null || this.f63l.m6614a() || i2 <= 0)) {
            i3 |= this.f63l.m6620c();
        }
        if (!(this.f65n == null || this.f65n.m6614a() || i2 >= 0)) {
            i3 |= this.f65n.m6620c();
        }
        if (i3 != 0) {
            iv.m5922d(this);
        }
    }

    public final void m82b() {
        if (this.f62k == null) {
            this.f62k = new oc(getContext());
            if (this.f73x) {
                this.f62k.m6613a((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
            } else {
                this.f62k.m6613a(getMeasuredHeight(), getMeasuredWidth());
            }
        }
    }

    public final void m83c() {
        if (this.f64m == null) {
            this.f64m = new oc(getContext());
            if (this.f73x) {
                this.f64m.m6613a((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
            } else {
                this.f64m.m6613a(getMeasuredHeight(), getMeasuredWidth());
            }
        }
    }

    public final void m84d() {
        if (this.f63l == null) {
            this.f63l = new oc(getContext());
            if (this.f73x) {
                this.f63l.m6613a((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
            } else {
                this.f63l.m6613a(getMeasuredWidth(), getMeasuredHeight());
            }
        }
    }

    public final void m85e() {
        if (this.f65n == null) {
            this.f65n = new oc(getContext());
            if (this.f73x) {
                this.f65n.m6613a((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
            } else {
                this.f65n.m6613a(getMeasuredWidth(), getMeasuredHeight());
            }
        }
    }

    private void m55m() {
        this.f65n = null;
        this.f63l = null;
        this.f64m = null;
        this.f62k = null;
    }

    public View focusSearch(View view, int i) {
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, view, i);
        if (!(findNextFocus != null || this.f75z == null || this.f57f == null || m64r() || this.f60i)) {
            m78a();
            findNextFocus = this.f57f.m493c(i, this.f52a, this.f68q);
            m81a(false);
        }
        return findNextFocus != null ? findNextFocus : super.focusSearch(view, i);
    }

    public void requestChildFocus(View view, View view2) {
        int i;
        ya yaVar = this.f57f;
        if (yaVar.f523j == null || !yaVar.f523j.f6575c) {
            i = 0;
        } else {
            i = 1;
        }
        if (i != 0 || m64r()) {
            i = 1;
        } else {
            i = 0;
        }
        if (i == 0 && view2 != null) {
            this.f56e.set(0, 0, view2.getWidth(), view2.getHeight());
            LayoutParams layoutParams = view2.getLayoutParams();
            if (layoutParams instanceof yb) {
                yb ybVar = (yb) layoutParams;
                if (!ybVar.f6559c) {
                    Rect rect = ybVar.f6558b;
                    Rect rect2 = this.f56e;
                    rect2.left -= rect.left;
                    rect2 = this.f56e;
                    rect2.right += rect.right;
                    rect2 = this.f56e;
                    rect2.top -= rect.top;
                    rect2 = this.f56e;
                    rect2.bottom = rect.bottom + rect2.bottom;
                }
            }
            offsetDescendantRectToMyCoords(view2, this.f56e);
            offsetRectIntoDescendantCoords(view, this.f56e);
            requestChildRectangleOnScreen(view, this.f56e, !this.f59h);
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        ya yaVar = this.f57f;
        int j = yaVar.m507j();
        int k = yaVar.m508k();
        int h = yaVar.m505h() - yaVar.m509l();
        int i = yaVar.m506i() - yaVar.m510m();
        int left = view.getLeft() + rect.left;
        int top = view.getTop() + rect.top;
        int width = left + rect.width();
        int height = top + rect.height();
        int min = Math.min(0, left - j);
        int min2 = Math.min(0, top - k);
        int max = Math.max(0, width - h);
        i = Math.max(0, height - i);
        if (iv.m5931h(yaVar.f522i) != 1) {
            max = min != 0 ? min : Math.min(left - j, max);
        } else if (max == 0) {
            max = Math.max(min, width - h);
        }
        if (min2 != 0) {
            min = min2;
        } else {
            min = Math.min(top - k, i);
        }
        if (max == 0 && min == 0) {
            return false;
        }
        if (z) {
            scrollBy(max, min);
        } else if (this.f57f == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.f60i) {
            if (!this.f57f.m495c()) {
                max = 0;
            }
            if (!this.f57f.m498d()) {
                min = 0;
            }
            if (!(max == 0 && min == 0)) {
                this.f67p.m7390a(max, min);
            }
        }
        return true;
    }

    public void addFocusables(ArrayList arrayList, int i, int i2) {
        super.addFocusables(arrayList, i, i2);
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f42N = 0;
        this.f32D = true;
        this.f59h = false;
        if (this.f57f != null) {
            this.f57f.f524k = true;
        }
        this.af = false;
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.f66o != null) {
            this.f66o.m7263d();
        }
        this.f59h = false;
        m50k();
        this.f32D = false;
        if (this.f57f != null) {
            this.f57f.m490b(this, this.f52a);
        }
        removeCallbacks(this.an);
        zg.m7435b();
    }

    public boolean isAttachedToWindow() {
        return this.f32D;
    }

    public final void m80a(String str) {
        if (!m64r()) {
            return;
        }
        if (str == null) {
            throw new IllegalStateException("Cannot call this method while RecyclerView is computing a layout or scrolling");
        }
        throw new IllegalStateException(str);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int i = -1;
        if (this.f60i) {
            return false;
        }
        int i2;
        boolean z;
        int action = motionEvent.getAction();
        if (action == 3 || action == 0) {
            this.f31C = null;
        }
        int size = this.f30B.size();
        for (i2 = 0; i2 < size; i2++) {
            yc ycVar = (yc) this.f30B.get(i2);
            if (ycVar.m7364a() && action != 3) {
                this.f31C = ycVar;
                z = true;
                break;
            }
        }
        z = false;
        if (z) {
            m58o();
            return true;
        } else if (this.f57f == null) {
            return false;
        } else {
            z = this.f57f.m495c();
            boolean d = this.f57f.m498d();
            if (this.f45Q == null) {
                this.f45Q = VelocityTracker.obtain();
            }
            this.f45Q.addMovement(motionEvent);
            action = hu.m5837a(motionEvent);
            size = hu.m5839b(motionEvent);
            int i3;
            switch (action) {
                case ug.RecyclerView_android_orientation /*0*/:
                    if (this.f36H) {
                        this.f36H = false;
                    }
                    this.f44P = hu.m5840b(motionEvent, 0);
                    i = (int) (motionEvent.getX() + 0.5f);
                    this.f48T = i;
                    this.f46R = i;
                    i = (int) (motionEvent.getY() + 0.5f);
                    this.f49U = i;
                    this.f47S = i;
                    if (this.f43O == 2) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                        setScrollState(1);
                    }
                    int[] iArr = this.am;
                    this.am[1] = 0;
                    iArr[0] = 0;
                    if (z) {
                        i3 = 1;
                    } else {
                        i3 = 0;
                    }
                    if (d) {
                        i3 |= 2;
                    }
                    startNestedScroll(i3);
                    break;
                case ug.RecyclerView_layoutManager /*1*/:
                    this.f45Q.clear();
                    stopNestedScroll();
                    break;
                case ug.RecyclerView_spanCount /*2*/:
                    action = hu.m5838a(motionEvent, this.f44P);
                    if (action >= 0) {
                        size = (int) (hu.m5841c(motionEvent, action) + 0.5f);
                        action = (int) (hu.m5843d(motionEvent, action) + 0.5f);
                        if (this.f43O != 1) {
                            size -= this.f46R;
                            action -= this.f47S;
                            if (!z || Math.abs(size) <= this.f50V) {
                                z = false;
                            } else {
                                this.f48T = ((size < 0 ? -1 : 1) * this.f50V) + this.f46R;
                                z = true;
                            }
                            if (d && Math.abs(action) > this.f50V) {
                                i3 = this.f47S;
                                i2 = this.f50V;
                                if (action >= 0) {
                                    i = 1;
                                }
                                this.f49U = i3 + (i * i2);
                                z = true;
                            }
                            if (z) {
                                setScrollState(1);
                                break;
                            }
                        }
                    }
                    Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f44P + " not found. Did any MotionEvents get skipped?");
                    return false;
                    break;
                case ug.RecyclerView_reverseLayout /*3*/:
                    m58o();
                    break;
                case py.Toolbar_contentInsetStart /*5*/:
                    this.f44P = hu.m5840b(motionEvent, size);
                    i3 = (int) (hu.m5841c(motionEvent, size) + 0.5f);
                    this.f48T = i3;
                    this.f46R = i3;
                    i3 = (int) (hu.m5843d(motionEvent, size) + 0.5f);
                    this.f49U = i3;
                    this.f47S = i3;
                    break;
                case py.Toolbar_contentInsetEnd /*6*/:
                    m21a(motionEvent);
                    break;
            }
            if (this.f43O != 1) {
                return false;
            }
            return true;
        }
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        int size = this.f30B.size();
        for (int i = 0; i < size; i++) {
            this.f30B.get(i);
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r13) {
        /*
        r12 = this;
        r4 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r2 = 0;
        r11 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r8 = 1;
        r1 = 0;
        r0 = r12.f60i;
        if (r0 != 0) goto L_0x000f;
    L_0x000b:
        r0 = r12.f36H;
        if (r0 == 0) goto L_0x0010;
    L_0x000f:
        return r1;
    L_0x0010:
        r0 = r13.getAction();
        r3 = r12.f31C;
        if (r3 == 0) goto L_0x001d;
    L_0x0018:
        if (r0 != 0) goto L_0x0040;
    L_0x001a:
        r3 = 0;
        r12.f31C = r3;
    L_0x001d:
        if (r0 == 0) goto L_0x004e;
    L_0x001f:
        r0 = r12.f30B;
        r5 = r0.size();
        r3 = r1;
    L_0x0026:
        if (r3 >= r5) goto L_0x004e;
    L_0x0028:
        r0 = r12.f30B;
        r0 = r0.get(r3);
        r0 = (happy.hacking.yc) r0;
        r6 = r0.m7364a();
        if (r6 == 0) goto L_0x004a;
    L_0x0036:
        r12.f31C = r0;
        r0 = r8;
    L_0x0039:
        if (r0 == 0) goto L_0x0050;
    L_0x003b:
        r12.m58o();
        r1 = r8;
        goto L_0x000f;
    L_0x0040:
        r3 = 3;
        if (r0 == r3) goto L_0x0045;
    L_0x0043:
        if (r0 != r8) goto L_0x0048;
    L_0x0045:
        r0 = 0;
        r12.f31C = r0;
    L_0x0048:
        r0 = r8;
        goto L_0x0039;
    L_0x004a:
        r0 = r3 + 1;
        r3 = r0;
        goto L_0x0026;
    L_0x004e:
        r0 = r1;
        goto L_0x0039;
    L_0x0050:
        r0 = r12.f57f;
        if (r0 == 0) goto L_0x000f;
    L_0x0054:
        r0 = r12.f57f;
        r5 = r0.m495c();
        r0 = r12.f57f;
        r6 = r0.m498d();
        r0 = r12.f45Q;
        if (r0 != 0) goto L_0x006a;
    L_0x0064:
        r0 = android.view.VelocityTracker.obtain();
        r12.f45Q = r0;
    L_0x006a:
        r9 = android.view.MotionEvent.obtain(r13);
        r0 = happy.hacking.hu.m5837a(r13);
        r3 = happy.hacking.hu.m5839b(r13);
        if (r0 != 0) goto L_0x0080;
    L_0x0078:
        r7 = r12.am;
        r10 = r12.am;
        r10[r8] = r1;
        r7[r1] = r1;
    L_0x0080:
        r7 = r12.am;
        r7 = r7[r1];
        r7 = (float) r7;
        r10 = r12.am;
        r10 = r10[r8];
        r10 = (float) r10;
        r9.offsetLocation(r7, r10);
        switch(r0) {
            case 0: goto L_0x009d;
            case 1: goto L_0x01ae;
            case 2: goto L_0x00dd;
            case 3: goto L_0x0271;
            case 4: goto L_0x0090;
            case 5: goto L_0x00c2;
            case 6: goto L_0x01a9;
            default: goto L_0x0090;
        };
    L_0x0090:
        if (r1 != 0) goto L_0x0097;
    L_0x0092:
        r0 = r12.f45Q;
        r0.addMovement(r9);
    L_0x0097:
        r9.recycle();
        r1 = r8;
        goto L_0x000f;
    L_0x009d:
        r0 = happy.hacking.hu.m5840b(r13, r1);
        r12.f44P = r0;
        r0 = r13.getX();
        r0 = r0 + r11;
        r0 = (int) r0;
        r12.f48T = r0;
        r12.f46R = r0;
        r0 = r13.getY();
        r0 = r0 + r11;
        r0 = (int) r0;
        r12.f49U = r0;
        r12.f47S = r0;
        if (r5 == 0) goto L_0x027b;
    L_0x00b9:
        r0 = r8;
    L_0x00ba:
        if (r6 == 0) goto L_0x00be;
    L_0x00bc:
        r0 = r0 | 2;
    L_0x00be:
        r12.startNestedScroll(r0);
        goto L_0x0090;
    L_0x00c2:
        r0 = happy.hacking.hu.m5840b(r13, r3);
        r12.f44P = r0;
        r0 = happy.hacking.hu.m5841c(r13, r3);
        r0 = r0 + r11;
        r0 = (int) r0;
        r12.f48T = r0;
        r12.f46R = r0;
        r0 = happy.hacking.hu.m5843d(r13, r3);
        r0 = r0 + r11;
        r0 = (int) r0;
        r12.f49U = r0;
        r12.f47S = r0;
        goto L_0x0090;
    L_0x00dd:
        r0 = r12.f44P;
        r0 = happy.hacking.hu.m5838a(r13, r0);
        if (r0 >= 0) goto L_0x0103;
    L_0x00e5:
        r0 = "RecyclerView";
        r2 = new java.lang.StringBuilder;
        r3 = "Error processing scroll; pointer index for id ";
        r2.<init>(r3);
        r3 = r12.f44P;
        r2 = r2.append(r3);
        r3 = " not found. Did any MotionEvents get skipped?";
        r2 = r2.append(r3);
        r2 = r2.toString();
        android.util.Log.e(r0, r2);
        goto L_0x000f;
    L_0x0103:
        r2 = happy.hacking.hu.m5841c(r13, r0);
        r2 = r2 + r11;
        r4 = (int) r2;
        r0 = happy.hacking.hu.m5843d(r13, r0);
        r0 = r0 + r11;
        r7 = (int) r0;
        r0 = r12.f48T;
        r2 = r0 - r4;
        r0 = r12.f49U;
        r0 = r0 - r7;
        r3 = r12.al;
        r10 = r12.ak;
        r3 = r12.dispatchNestedPreScroll(r2, r0, r3, r10);
        if (r3 == 0) goto L_0x014d;
    L_0x0120:
        r3 = r12.al;
        r3 = r3[r1];
        r2 = r2 - r3;
        r3 = r12.al;
        r3 = r3[r8];
        r0 = r0 - r3;
        r3 = r12.ak;
        r3 = r3[r1];
        r3 = (float) r3;
        r10 = r12.ak;
        r10 = r10[r8];
        r10 = (float) r10;
        r9.offsetLocation(r3, r10);
        r3 = r12.am;
        r10 = r3[r1];
        r11 = r12.ak;
        r11 = r11[r1];
        r10 = r10 + r11;
        r3[r1] = r10;
        r3 = r12.am;
        r10 = r3[r8];
        r11 = r12.ak;
        r11 = r11[r8];
        r10 = r10 + r11;
        r3[r8] = r10;
    L_0x014d:
        r3 = r12.f43O;
        if (r3 == r8) goto L_0x0176;
    L_0x0151:
        if (r5 == 0) goto L_0x0278;
    L_0x0153:
        r3 = java.lang.Math.abs(r2);
        r10 = r12.f50V;
        if (r3 <= r10) goto L_0x0278;
    L_0x015b:
        if (r2 <= 0) goto L_0x019d;
    L_0x015d:
        r3 = r12.f50V;
        r2 = r2 - r3;
    L_0x0160:
        r3 = r8;
    L_0x0161:
        if (r6 == 0) goto L_0x0171;
    L_0x0163:
        r10 = java.lang.Math.abs(r0);
        r11 = r12.f50V;
        if (r10 <= r11) goto L_0x0171;
    L_0x016b:
        if (r0 <= 0) goto L_0x01a1;
    L_0x016d:
        r3 = r12.f50V;
        r0 = r0 - r3;
    L_0x0170:
        r3 = r8;
    L_0x0171:
        if (r3 == 0) goto L_0x0176;
    L_0x0173:
        r12.setScrollState(r8);
    L_0x0176:
        r3 = r12.f43O;
        if (r3 != r8) goto L_0x0090;
    L_0x017a:
        r3 = r12.ak;
        r3 = r3[r1];
        r3 = r4 - r3;
        r12.f48T = r3;
        r3 = r12.ak;
        r3 = r3[r8];
        r3 = r7 - r3;
        r12.f49U = r3;
        if (r5 == 0) goto L_0x01a5;
    L_0x018c:
        if (r6 == 0) goto L_0x01a7;
    L_0x018e:
        r0 = r12.m24a(r2, r0, r9);
        if (r0 == 0) goto L_0x0090;
    L_0x0194:
        r0 = r12.getParent();
        r0.requestDisallowInterceptTouchEvent(r8);
        goto L_0x0090;
    L_0x019d:
        r3 = r12.f50V;
        r2 = r2 + r3;
        goto L_0x0160;
    L_0x01a1:
        r3 = r12.f50V;
        r0 = r0 + r3;
        goto L_0x0170;
    L_0x01a5:
        r2 = r1;
        goto L_0x018c;
    L_0x01a7:
        r0 = r1;
        goto L_0x018e;
    L_0x01a9:
        r12.m21a(r13);
        goto L_0x0090;
    L_0x01ae:
        r0 = r12.f45Q;
        r0.addMovement(r9);
        r0 = r12.f45Q;
        r3 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;
        r7 = r12.aa;
        r7 = (float) r7;
        r0.computeCurrentVelocity(r3, r7);
        if (r5 == 0) goto L_0x01f5;
    L_0x01bf:
        r0 = r12.f45Q;
        r3 = r12.f44P;
        r0 = happy.hacking.ir.m5883a(r0, r3);
        r0 = -r0;
        r3 = r0;
    L_0x01c9:
        if (r6 == 0) goto L_0x01f7;
    L_0x01cb:
        r0 = r12.f45Q;
        r5 = r12.f44P;
        r0 = happy.hacking.ir.m5884b(r0, r5);
        r0 = -r0;
    L_0x01d4:
        r5 = (r3 > r2 ? 1 : (r3 == r2 ? 0 : -1));
        if (r5 != 0) goto L_0x01dc;
    L_0x01d8:
        r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1));
        if (r2 == 0) goto L_0x01ec;
    L_0x01dc:
        r2 = (int) r3;
        r0 = (int) r0;
        r3 = r12.f57f;
        if (r3 != 0) goto L_0x01f9;
    L_0x01e2:
        r0 = "RecyclerView";
        r2 = "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.";
        android.util.Log.e(r0, r2);
    L_0x01e9:
        r0 = r1;
    L_0x01ea:
        if (r0 != 0) goto L_0x01ef;
    L_0x01ec:
        r12.setScrollState(r1);
    L_0x01ef:
        r12.m56n();
        r1 = r8;
        goto L_0x0090;
    L_0x01f5:
        r3 = r2;
        goto L_0x01c9;
    L_0x01f7:
        r0 = r2;
        goto L_0x01d4;
    L_0x01f9:
        r3 = r12.f60i;
        if (r3 != 0) goto L_0x01e9;
    L_0x01fd:
        r3 = r12.f57f;
        r5 = r3.m495c();
        r3 = r12.f57f;
        r6 = r3.m498d();
        if (r5 == 0) goto L_0x0213;
    L_0x020b:
        r3 = java.lang.Math.abs(r2);
        r7 = r12.f51W;
        if (r3 >= r7) goto L_0x0214;
    L_0x0213:
        r2 = r1;
    L_0x0214:
        if (r6 == 0) goto L_0x021e;
    L_0x0216:
        r3 = java.lang.Math.abs(r0);
        r7 = r12.f51W;
        if (r3 >= r7) goto L_0x0276;
    L_0x021e:
        r3 = r1;
    L_0x021f:
        if (r2 != 0) goto L_0x0223;
    L_0x0221:
        if (r3 == 0) goto L_0x01e9;
    L_0x0223:
        r0 = (float) r2;
        r7 = (float) r3;
        r0 = r12.dispatchNestedPreFling(r0, r7);
        if (r0 != 0) goto L_0x01e9;
    L_0x022b:
        if (r5 != 0) goto L_0x022f;
    L_0x022d:
        if (r6 == 0) goto L_0x026f;
    L_0x022f:
        r0 = r8;
    L_0x0230:
        r5 = (float) r2;
        r6 = (float) r3;
        r12.dispatchNestedFling(r5, r6, r0);
        if (r0 == 0) goto L_0x01e9;
    L_0x0237:
        r0 = r12.aa;
        r0 = -r0;
        r5 = r12.aa;
        r2 = java.lang.Math.min(r2, r5);
        r2 = java.lang.Math.max(r0, r2);
        r0 = r12.aa;
        r0 = -r0;
        r5 = r12.aa;
        r3 = java.lang.Math.min(r3, r5);
        r3 = java.lang.Math.max(r0, r3);
        r10 = r12.f67p;
        r0 = r10.f6600d;
        r5 = 2;
        r0.setScrollState(r5);
        r10.f6598b = r1;
        r10.f6597a = r1;
        r0 = r10.f6599c;
        r5 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        r7 = 2147483647; // 0x7fffffff float:NaN double:1.060997895E-314;
        r6 = r4;
        r0.m6674a(r1, r2, r3, r4, r5, r6, r7);
        r10.m7389a();
        r0 = r8;
        goto L_0x01ea;
    L_0x026f:
        r0 = r1;
        goto L_0x0230;
    L_0x0271:
        r12.m58o();
        goto L_0x0090;
    L_0x0276:
        r3 = r0;
        goto L_0x021f;
    L_0x0278:
        r3 = r1;
        goto L_0x0161;
    L_0x027b:
        r0 = r1;
        goto L_0x00ba;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    private void m56n() {
        if (this.f45Q != null) {
            this.f45Q.clear();
        }
        stopNestedScroll();
        int i = 0;
        if (this.f62k != null) {
            i = this.f62k.m6620c();
        }
        if (this.f63l != null) {
            i |= this.f63l.m6620c();
        }
        if (this.f64m != null) {
            i |= this.f64m.m6620c();
        }
        if (this.f65n != null) {
            i |= this.f65n.m6620c();
        }
        if (i != 0) {
            iv.m5922d(this);
        }
    }

    private void m58o() {
        m56n();
        setScrollState(0);
    }

    private void m21a(MotionEvent motionEvent) {
        int b = hu.m5839b(motionEvent);
        if (hu.m5840b(motionEvent, b) == this.f44P) {
            b = b == 0 ? 1 : 0;
            this.f44P = hu.m5840b(motionEvent, b);
            int c = (int) (hu.m5841c(motionEvent, b) + 0.5f);
            this.f48T = c;
            this.f46R = c;
            b = (int) (hu.m5843d(motionEvent, b) + 0.5f);
            this.f49U = b;
            this.f47S = b;
        }
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if (!(this.f57f == null || this.f60i || (hu.m5844d(motionEvent) & 2) == 0 || motionEvent.getAction() != 8)) {
            float f;
            float e;
            if (this.f57f.m498d()) {
                f = -hu.m5845e(motionEvent, 9);
            } else {
                f = 0.0f;
            }
            if (this.f57f.m495c()) {
                e = hu.m5845e(motionEvent, 10);
            } else {
                e = 0.0f;
            }
            if (!(f == 0.0f && e == 0.0f)) {
                float scrollFactor = getScrollFactor();
                m24a((int) (e * scrollFactor), (int) (f * scrollFactor), motionEvent);
            }
        }
        return false;
    }

    private float getScrollFactor() {
        if (this.ab == Float.MIN_VALUE) {
            TypedValue typedValue = new TypedValue();
            if (!getContext().getTheme().resolveAttribute(16842829, typedValue, true)) {
                return 0.0f;
            }
            this.ab = typedValue.getDimension(getContext().getResources().getDisplayMetrics());
        }
        return this.ab;
    }

    protected void onMeasure(int i, int i2) {
        if (this.f38J) {
            m78a();
            m68t();
            if (this.f68q.f6594h) {
                this.f68q.f6592f = true;
            } else {
                this.f53b.m7159e();
                this.f68q.f6592f = false;
            }
            this.f38J = false;
            m81a(false);
        }
        if (this.f75z != null) {
            this.f68q.f6588b = this.f75z.m4706a();
        } else {
            this.f68q.f6588b = 0;
        }
        if (this.f57f == null) {
            m30b(i, i2);
        } else {
            this.f57f.f522i.m30b(i, i2);
        }
        this.f68q.f6592f = false;
    }

    private void m30b(int i, int i2) {
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        switch (mode) {
            case Integer.MIN_VALUE:
            case 1073741824:
                break;
            default:
                size = iv.m5942s(this);
                break;
        }
        switch (mode2) {
            case Integer.MIN_VALUE:
            case 1073741824:
                break;
            default:
                size2 = iv.m5943t(this);
                break;
        }
        setMeasuredDimension(size, size2);
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3 || i2 != i4) {
            m55m();
        }
    }

    public void setItemAnimator(xw xwVar) {
        if (this.f66o != null) {
            this.f66o.m7263d();
            this.f66o.f6459h = null;
        }
        this.f66o = xwVar;
        if (this.f66o != null) {
            this.f66o.f6459h = this.ae;
        }
    }

    private void m60p() {
        this.f42N++;
    }

    private void m62q() {
        this.f42N--;
        if (this.f42N <= 0) {
            this.f42N = 0;
            int i = this.f37I;
            this.f37I = 0;
            if (i != 0 && m86f()) {
                AccessibilityEvent obtain = AccessibilityEvent.obtain();
                obtain.setEventType(2048);
                lo.m6297a(obtain, i);
                sendAccessibilityEventUnchecked(obtain);
            }
        }
    }

    public final boolean m86f() {
        return this.f40L != null && this.f40L.isEnabled();
    }

    private boolean m64r() {
        return this.f42N > 0;
    }

    public void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        int i = 0;
        if (m64r()) {
            int b;
            if (accessibilityEvent != null) {
                b = lo.m6298b(accessibilityEvent);
            } else {
                b = 0;
            }
            if (b != 0) {
                i = b;
            }
            this.f37I = i | this.f37I;
            i = 1;
        }
        if (i == 0) {
            super.sendAccessibilityEventUnchecked(accessibilityEvent);
        }
    }

    public xw getItemAnimator() {
        return this.f66o;
    }

    private void m67s() {
        if (!this.af && this.f32D) {
            iv.m5910a((View) this, this.an);
            this.af = true;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m68t() {
        /*
        r5 = this;
        r2 = 1;
        r1 = 0;
        r0 = r5.f61j;
        if (r0 == 0) goto L_0x000e;
    L_0x0006:
        r0 = r5.f53b;
        r0.m7152a();
        r5.m75w();
    L_0x000e:
        r0 = r5.f66o;
        if (r0 == 0) goto L_0x006d;
    L_0x0012:
        r0 = r5.f57f;
        r0 = r0.m501e();
        if (r0 == 0) goto L_0x006d;
    L_0x001a:
        r0 = r5.f53b;
        r0.m7156b();
    L_0x001f:
        r0 = r5.f69r;
        if (r0 != 0) goto L_0x0027;
    L_0x0023:
        r0 = r5.f70s;
        if (r0 == 0) goto L_0x0073;
    L_0x0027:
        r0 = r2;
    L_0x0028:
        r4 = r5.f68q;
        r3 = r5.f59h;
        if (r3 == 0) goto L_0x0075;
    L_0x002e:
        r3 = r5.f66o;
        if (r3 == 0) goto L_0x0075;
    L_0x0032:
        r3 = r5.f61j;
        if (r3 != 0) goto L_0x0040;
    L_0x0036:
        if (r0 != 0) goto L_0x0040;
    L_0x0038:
        r3 = r5.f57f;
        r3 = r3.f520a;
        if (r3 == 0) goto L_0x0075;
    L_0x0040:
        r3 = r5.f61j;
        if (r3 == 0) goto L_0x004a;
    L_0x0044:
        r3 = r5.f75z;
        r3 = r3.f4600e;
        if (r3 == 0) goto L_0x0075;
    L_0x004a:
        r3 = r2;
    L_0x004b:
        r4.f6593g = r3;
        r3 = r5.f68q;
        r4 = r5.f68q;
        r4 = r4.f6593g;
        if (r4 == 0) goto L_0x0079;
    L_0x0055:
        if (r0 == 0) goto L_0x0079;
    L_0x0057:
        r0 = r5.f61j;
        if (r0 != 0) goto L_0x0079;
    L_0x005b:
        r0 = r5.f66o;
        if (r0 == 0) goto L_0x0077;
    L_0x005f:
        r0 = r5.f57f;
        r0 = r0.m501e();
        if (r0 == 0) goto L_0x0077;
    L_0x0067:
        r0 = r2;
    L_0x0068:
        if (r0 == 0) goto L_0x0079;
    L_0x006a:
        r3.f6594h = r2;
        return;
    L_0x006d:
        r0 = r5.f53b;
        r0.m7159e();
        goto L_0x001f;
    L_0x0073:
        r0 = r1;
        goto L_0x0028;
    L_0x0075:
        r3 = r1;
        goto L_0x004b;
    L_0x0077:
        r0 = r1;
        goto L_0x0068;
    L_0x0079:
        r2 = r1;
        goto L_0x006a;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.RecyclerView.t():void");
    }

    private void m71u() {
        boolean z = false;
        if (this.f75z == null) {
            Log.e("RecyclerView", "No adapter attached; skipping layout");
        } else if (this.f57f == null) {
            Log.e("RecyclerView", "No layout manager attached; skipping layout");
        } else {
            boolean z2;
            int i;
            int i2;
            int i3;
            yo b;
            int c;
            yo b2;
            zg zgVar;
            this.f55d.m7427a();
            m78a();
            m60p();
            m68t();
            yl ylVar = this.f68q;
            if (this.f68q.f6593g && this.f70s) {
                z2 = true;
            } else {
                z2 = false;
            }
            ylVar.f6595i = z2;
            this.f70s = false;
            this.f69r = false;
            this.f68q.f6592f = this.f68q.f6594h;
            this.f68q.f6588b = this.f75z.m4706a();
            int[] iArr = this.ai;
            int a = this.f54c.m7225a();
            if (a == 0) {
                iArr[0] = 0;
                iArr[1] = 0;
            } else {
                i = Integer.MAX_VALUE;
                i2 = Integer.MIN_VALUE;
                i3 = 0;
                while (i3 < a) {
                    b = m29b(this.f54c.m7231b(i3));
                    if (!b.m4664b()) {
                        c = b.m4665c();
                        if (c < i) {
                            i = c;
                        }
                        if (c > i2) {
                            i2 = i;
                            i3++;
                            i = i2;
                            i2 = c;
                        }
                    }
                    c = i2;
                    i2 = i;
                    i3++;
                    i = i2;
                    i2 = c;
                }
                iArr[0] = i;
                iArr[1] = i2;
            }
            if (this.f68q.f6593g) {
                i2 = this.f54c.m7225a();
                for (c = 0; c < i2; c++) {
                    b2 = m29b(this.f54c.m7231b(c));
                    if (!b2.m4664b() && (!b2.m4672j() || this.f75z.f4600e)) {
                        xw.m7255d(b2);
                        b2.m4678p();
                        this.f55d.m7430a(b2, new xy().m7362a(b2));
                        if (!(!this.f68q.f6595i || !b2.m4681s() || b2.m4675m() || b2.m4664b() || b2.m4672j())) {
                            this.f55d.m7428a(m28b(b2), b2);
                        }
                    }
                }
            }
            if (this.f68q.f6594h) {
                i2 = this.f54c.m7230b();
                for (c = 0; c < i2; c++) {
                    b2 = m29b(this.f54c.m7234c(c));
                    if (!b2.m4664b() && b2.f4550c == -1) {
                        b2.f4550c = b2.f4549b;
                    }
                }
                z2 = this.f68q.f6591e;
                this.f68q.f6591e = false;
                this.f57f.m484a(this.f52a, this.f68q);
                this.f68q.f6591e = z2;
                for (i2 = 0; i2 < this.f54c.m7225a(); i2++) {
                    b2 = m29b(this.f54c.m7231b(i2));
                    if (!b2.m4664b()) {
                        zgVar = (zg) this.f55d.f6639a.get(b2);
                        if (zgVar == null || (zgVar.f6642a & 4) == 0) {
                            z2 = false;
                        } else {
                            c = 1;
                        }
                        if (c == 0) {
                            xw.m7255d(b2);
                            z2 = b2.m4662a((int) FragmentTransaction.TRANSIT_EXIT_MASK);
                            b2.m4678p();
                            xy a2 = new xy().m7362a(b2);
                            if (z2) {
                                m23a(b2, a2);
                            } else {
                                zf zfVar = this.f55d;
                                zgVar = (zg) zfVar.f6639a.get(b2);
                                if (zgVar == null) {
                                    zgVar = zg.m7433a();
                                    zfVar.f6639a.put(b2, zgVar);
                                }
                                zgVar.f6642a |= 2;
                                zgVar.f6643b = a2;
                            }
                        }
                    }
                }
                m73v();
                this.f53b.m7157c();
            } else {
                m73v();
            }
            this.f68q.f6588b = this.f75z.m4706a();
            this.f68q.f6590d = 0;
            this.f68q.f6592f = false;
            this.f57f.m484a(this.f52a, this.f68q);
            this.f68q.f6591e = false;
            this.f72w = null;
            ylVar = this.f68q;
            if (!this.f68q.f6593g || this.f66o == null) {
                z2 = false;
            } else {
                z2 = true;
            }
            ylVar.f6593g = z2;
            if (this.f68q.f6593g) {
                zg zgVar2;
                int a3 = this.f54c.m7225a();
                for (i3 = 0; i3 < a3; i3++) {
                    yo b3 = m29b(this.f54c.m7231b(i3));
                    if (!b3.m4664b()) {
                        Object obj;
                        long b4 = m28b(b3);
                        xy a4 = new xy().m7362a(b3);
                        fn fnVar = this.f55d.f6640b;
                        c = fk.m5649a(fnVar.f5619c, fnVar.f5621e, b4);
                        if (c < 0 || fnVar.f5620d[c] == fn.f5617a) {
                            obj = null;
                        } else {
                            obj = fnVar.f5620d[c];
                        }
                        b = (yo) obj;
                        if (b == null || b.m4664b()) {
                            zf zfVar2 = this.f55d;
                            zgVar = (zg) zfVar2.f6639a.get(b3);
                            if (zgVar == null) {
                                zgVar = zg.m7433a();
                                zfVar2.f6639a.put(b3, zgVar);
                            }
                            zgVar.f6644c = a4;
                            zgVar.f6642a |= 8;
                        } else {
                            xy xyVar;
                            zf zfVar3 = this.f55d;
                            int a5 = zfVar3.f6639a.m5617a((Object) b);
                            if (a5 >= 0) {
                                zgVar2 = (zg) zfVar3.f6639a.m5622c(a5);
                                if (!(zgVar2 == null || (zgVar2.f6642a & 4) == 0)) {
                                    zgVar2.f6642a &= -5;
                                    xy xyVar2 = zgVar2.f6643b;
                                    if (zgVar2.f6642a == 0) {
                                        zfVar3.f6639a.m5623d(a5);
                                        zg.m7434a(zgVar2);
                                    }
                                    xyVar = xyVar2;
                                    b.m4661a(false);
                                    if (b != b3) {
                                        b.f4554g = b3;
                                        m22a(b);
                                        this.f52a.m7379b(b);
                                        b3.m4661a(false);
                                        b3.f4555h = b;
                                    }
                                    if (this.f66o.m7258a(b, b3, xyVar, a4)) {
                                        m67s();
                                    }
                                }
                            }
                            xyVar = null;
                            b.m4661a(false);
                            if (b != b3) {
                                b.f4554g = b3;
                                m22a(b);
                                this.f52a.m7379b(b);
                                b3.m4661a(false);
                                b3.f4555h = b;
                            }
                            if (this.f66o.m7258a(b, b3, xyVar, a4)) {
                                m67s();
                            }
                        }
                    }
                }
                zf zfVar4 = this.f55d;
                zh zhVar = this.ap;
                for (i = zfVar4.f6639a.size() - 1; i >= 0; i--) {
                    b = (yo) zfVar4.f6639a.m5621b(i);
                    zgVar2 = (zg) zfVar4.f6639a.m5623d(i);
                    if ((zgVar2.f6642a & 3) == 3) {
                        zhVar.m7327a(b);
                    } else if ((zgVar2.f6642a & 1) != 0) {
                        zhVar.m7328a(b, zgVar2.f6643b, zgVar2.f6644c);
                    } else if ((zgVar2.f6642a & 14) == 14) {
                        zhVar.m7329b(b, zgVar2.f6643b, zgVar2.f6644c);
                    } else if ((zgVar2.f6642a & 12) == 12) {
                        zhVar.m7330c(b, zgVar2.f6643b, zgVar2.f6644c);
                    } else if ((zgVar2.f6642a & 4) != 0) {
                        zhVar.m7328a(b, zgVar2.f6643b, null);
                    } else if ((zgVar2.f6642a & 8) != 0) {
                        zhVar.m7329b(b, zgVar2.f6643b, zgVar2.f6644c);
                    } else {
                        c = zgVar2.f6642a;
                    }
                    zg.m7434a(zgVar2);
                }
            }
            m81a(false);
            this.f57f.m483a(this.f52a);
            this.f68q.f6589c = this.f68q.f6588b;
            this.f61j = false;
            this.f68q.f6593g = false;
            this.f68q.f6594h = false;
            m62q();
            this.f57f.f520a = false;
            if (this.f52a.f6565b != null) {
                this.f52a.f6565b.clear();
            }
            this.f55d.m7427a();
            i2 = this.ai[0];
            i = this.ai[1];
            int a6 = this.f54c.m7225a();
            if (a6 != 0) {
                for (c = 0; c < a6; c++) {
                    yo b5 = m29b(this.f54c.m7231b(c));
                    if (!b5.m4664b()) {
                        i3 = b5.m4665c();
                        if (i3 < i2 || i3 > i) {
                            z = true;
                            break;
                        }
                    }
                }
            } else if (!(i2 == 0 && i == 0)) {
                z = true;
            }
            if (z) {
                m87g();
            }
        }
    }

    private void m23a(yo yoVar, xy xyVar) {
        yoVar.m4657a(0, (int) FragmentTransaction.TRANSIT_EXIT_MASK);
        if (this.f68q.f6595i && yoVar.m4681s() && !yoVar.m4675m() && !yoVar.m4664b()) {
            this.f55d.m7428a(m28b(yoVar), yoVar);
        }
        this.f55d.m7430a(yoVar, xyVar);
    }

    public void removeDetachedView(View view, boolean z) {
        yo b = m29b(view);
        if (b != null) {
            if (b.m4676n()) {
                b.m4671i();
            } else if (!b.m4664b()) {
                throw new IllegalArgumentException("Called removeDetachedView with a view which is not flagged as tmp detached." + b);
            }
        }
        m40d(view);
        super.removeDetachedView(view, z);
    }

    private long m28b(yo yoVar) {
        if (this.f75z.f4600e) {
            return yoVar.f4551d;
        }
        return (long) yoVar.f4549b;
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        m78a();
        ex.m5598a("RV OnLayout");
        m71u();
        ex.m5597a();
        m81a(false);
        this.f59h = true;
    }

    public void requestLayout() {
        if (this.f34F || this.f60i) {
            this.f35G = true;
        } else {
            super.requestLayout();
        }
    }

    public void draw(Canvas canvas) {
        int i;
        int i2 = 1;
        int i3 = 0;
        super.draw(canvas);
        int size = this.f58g.size();
        for (i = 0; i < size; i++) {
            this.f58g.get(i);
        }
        if (this.f62k == null || this.f62k.m6614a()) {
            i = 0;
        } else {
            size = canvas.save();
            i = this.f73x ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((float) (i + (-getHeight())), 0.0f);
            if (this.f62k == null || !this.f62k.m6618a(canvas)) {
                i = 0;
            } else {
                i = 1;
            }
            canvas.restoreToCount(size);
        }
        if (!(this.f63l == null || this.f63l.m6614a())) {
            int save = canvas.save();
            if (this.f73x) {
                canvas.translate((float) getPaddingLeft(), (float) getPaddingTop());
            }
            if (this.f63l == null || !this.f63l.m6618a(canvas)) {
                size = 0;
            } else {
                size = 1;
            }
            i |= size;
            canvas.restoreToCount(save);
        }
        if (!(this.f64m == null || this.f64m.m6614a())) {
            save = canvas.save();
            int width = getWidth();
            if (this.f73x) {
                size = getPaddingTop();
            } else {
                size = 0;
            }
            canvas.rotate(90.0f);
            canvas.translate((float) (-size), (float) (-width));
            if (this.f64m == null || !this.f64m.m6618a(canvas)) {
                size = 0;
            } else {
                size = 1;
            }
            i |= size;
            canvas.restoreToCount(save);
        }
        if (!(this.f65n == null || this.f65n.m6614a())) {
            size = canvas.save();
            canvas.rotate(180.0f);
            if (this.f73x) {
                canvas.translate((float) ((-getWidth()) + getPaddingRight()), (float) ((-getHeight()) + getPaddingBottom()));
            } else {
                canvas.translate((float) (-getWidth()), (float) (-getHeight()));
            }
            if (this.f65n != null && this.f65n.m6618a(canvas)) {
                i3 = 1;
            }
            i |= i3;
            canvas.restoreToCount(size);
        }
        if (i != 0 || this.f66o == null || this.f58g.size() <= 0 || !this.f66o.m7259b()) {
            i2 = i;
        }
        if (i2 != 0) {
            iv.m5922d(this);
        }
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int size = this.f58g.size();
        for (int i = 0; i < size; i++) {
            this.f58g.get(i);
        }
    }

    public boolean checkLayoutParams(LayoutParams layoutParams) {
        return (layoutParams instanceof yb) && ya.m465a((yb) layoutParams);
    }

    public LayoutParams generateDefaultLayoutParams() {
        if (this.f57f != null) {
            return this.f57f.m476a();
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager");
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        if (this.f57f != null) {
            return ya.m461a(getContext(), attributeSet);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager");
    }

    public LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        if (this.f57f != null) {
            return ya.m462a(layoutParams);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager");
    }

    private void m73v() {
        int i = 0;
        int b = this.f54c.m7230b();
        for (int i2 = 0; i2 < b; i2++) {
            yo b2 = m29b(this.f54c.m7234c(i2));
            if (!b2.m4664b()) {
                b2.m4656a();
            }
        }
        yf yfVar = this.f52a;
        int size = yfVar.f6566c.size();
        for (b = 0; b < size; b++) {
            ((yo) yfVar.f6566c.get(b)).m4656a();
        }
        size = yfVar.f6564a.size();
        for (b = 0; b < size; b++) {
            ((yo) yfVar.f6564a.get(b)).m4656a();
        }
        if (yfVar.f6565b != null) {
            b = yfVar.f6565b.size();
            while (i < b) {
                ((yo) yfVar.f6565b.get(i)).m4656a();
                i++;
            }
        }
    }

    public final void m79a(int i, int i2, boolean z) {
        int i3 = i + i2;
        int b = this.f54c.m7230b();
        for (int i4 = 0; i4 < b; i4++) {
            yo b2 = m29b(this.f54c.m7234c(i4));
            if (!(b2 == null || b2.m4664b())) {
                if (b2.f4549b >= i3) {
                    b2.m4658a(-i2, z);
                    this.f68q.f6591e = true;
                } else if (b2.f4549b >= i) {
                    int i5 = i - 1;
                    int i6 = -i2;
                    b2.m4663b(8);
                    b2.m4658a(i6, z);
                    b2.f4549b = i5;
                    this.f68q.f6591e = true;
                }
            }
        }
        yf yfVar = this.f52a;
        int i7 = i + i2;
        for (i3 = yfVar.f6566c.size() - 1; i3 >= 0; i3--) {
            yo yoVar = (yo) yfVar.f6566c.get(i3);
            if (yoVar != null) {
                if (yoVar.m4665c() >= i7) {
                    yoVar.m4658a(-i2, z);
                } else if (yoVar.m4665c() >= i) {
                    yoVar.m4663b(8);
                    yfVar.m7377b(i3);
                }
            }
        }
        requestLayout();
    }

    private void m75w() {
        int i = 0;
        int b = this.f54c.m7230b();
        for (int i2 = 0; i2 < b; i2++) {
            yo b2 = m29b(this.f54c.m7234c(i2));
            if (!(b2 == null || b2.m4664b())) {
                b2.m4663b(6);
            }
        }
        int b3 = this.f54c.m7230b();
        for (b = 0; b < b3; b++) {
            ((yb) this.f54c.m7234c(b).getLayoutParams()).f6559c = true;
        }
        yf yfVar = this.f52a;
        int size = yfVar.f6566c.size();
        for (b = 0; b < size; b++) {
            yb ybVar = (yb) ((yo) yfVar.f6566c.get(b)).f4548a.getLayoutParams();
            if (ybVar != null) {
                ybVar.f6559c = true;
            }
        }
        yf yfVar2 = this.f52a;
        if (yfVar2.f6571h.f75z == null || !yfVar2.f6571h.f75z.f4600e) {
            yfVar2.m7376b();
            return;
        }
        b3 = yfVar2.f6566c.size();
        while (i < b3) {
            yo yoVar = (yo) yfVar2.f6566c.get(i);
            if (yoVar != null) {
                yoVar.m4663b(6);
                yoVar.m4660a(null);
            }
            i++;
        }
    }

    public final yo m77a(View view) {
        Object parent = view.getParent();
        if (parent == null || parent == this) {
            return m29b(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    public static yo m29b(View view) {
        if (view == null) {
            return null;
        }
        return ((yb) view.getLayoutParams()).f6557a;
    }

    public static int m35c(View view) {
        yo b = m29b(view);
        return b != null ? b.m4665c() : -1;
    }

    public boolean drawChild(Canvas canvas, View view, long j) {
        return super.drawChild(canvas, view, j);
    }

    public final void m87g() {
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX, scrollY);
        if (this.ad != null) {
            for (scrollX = this.ad.size() - 1; scrollX >= 0; scrollX--) {
                this.ad.get(scrollX);
            }
        }
    }

    private void m76x() {
        int a = this.f54c.m7225a();
        for (int i = 0; i < a; i++) {
            View b = this.f54c.m7231b(i);
            yo a2 = m77a(b);
            if (!(a2 == null || a2.f4555h == null)) {
                View view = a2.f4555h.f4548a;
                int left = b.getLeft();
                int top = b.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
    }

    private void m40d(View view) {
        m29b(view);
        if (this.f41M != null) {
            for (int size = this.f41M.size() - 1; size >= 0; size--) {
                this.f41M.get(size);
            }
        }
    }

    public void setNestedScrollingEnabled(boolean z) {
        this.aj.m5867a(z);
    }

    public boolean isNestedScrollingEnabled() {
        return this.aj.f5672a;
    }

    public boolean startNestedScroll(int i) {
        return this.aj.m5871a(i);
    }

    public void stopNestedScroll() {
        this.aj.m5874b();
    }

    public boolean hasNestedScrollingParent() {
        return this.aj.m5868a();
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.aj.m5872a(i, i2, i3, i4, iArr);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return this.aj.m5873a(i, i2, iArr, iArr2);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.aj.m5870a(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.aj.m5869a(f, f2);
    }

    protected int getChildDrawingOrder(int i, int i2) {
        if (this.ah == null) {
            return super.getChildDrawingOrder(i, i2);
        }
        return this.ah.m7360a();
    }

    public static /* synthetic */ void m20a(RecyclerView recyclerView, yo yoVar, xy xyVar, xy xyVar2) {
        recyclerView.m22a(yoVar);
        yoVar.m4661a(false);
        if (recyclerView.f66o.m7257a(yoVar, xyVar, xyVar2)) {
            recyclerView.m67s();
        }
    }

    public static /* synthetic */ void m33b(RecyclerView recyclerView, yo yoVar, xy xyVar, xy xyVar2) {
        yoVar.m4661a(false);
        if (recyclerView.f66o.m7260b(yoVar, xyVar, xyVar2)) {
            recyclerView.m67s();
        }
    }

    public static /* synthetic */ void m17a(RecyclerView recyclerView, View view) {
        m29b(view);
        if (recyclerView.f41M != null) {
            for (int size = recyclerView.f41M.size() - 1; size >= 0; size--) {
                recyclerView.f41M.get(size);
            }
        }
    }

    public static /* synthetic */ boolean m26a(RecyclerView recyclerView, yo yoVar) {
        return recyclerView.f66o == null || recyclerView.f66o.m7266f(yoVar);
    }

    public static /* synthetic */ int m27b(RecyclerView recyclerView, yo yoVar) {
        if (yoVar.m4662a(524) || !yoVar.m4674l()) {
            return -1;
        }
        ux uxVar = recyclerView.f53b;
        int i = yoVar.f4549b;
        int size = uxVar.f6331a.size();
        for (int i2 = 0; i2 < size; i2++) {
            uz uzVar = (uz) uxVar.f6331a.get(i2);
            switch (uzVar.f6339a) {
                case ug.RecyclerView_layoutManager /*1*/:
                    if (uzVar.f6340b > i) {
                        break;
                    }
                    i += uzVar.f6342d;
                    break;
                case ug.RecyclerView_spanCount /*2*/:
                    if (uzVar.f6340b <= i) {
                        if (uzVar.f6340b + uzVar.f6342d <= i) {
                            i -= uzVar.f6342d;
                            break;
                        }
                        return -1;
                    }
                    continue;
                case py.Toolbar_contentInsetRight /*8*/:
                    if (uzVar.f6340b != i) {
                        if (uzVar.f6340b < i) {
                            i--;
                        }
                        if (uzVar.f6342d > i) {
                            break;
                        }
                        i++;
                        break;
                    }
                    i = uzVar.f6342d;
                    break;
                default:
                    break;
            }
        }
        return i;
    }

    public static /* synthetic */ void m36c(RecyclerView recyclerView, int i) {
        if (recyclerView.f57f != null) {
            recyclerView.f57f.m489b(i);
            recyclerView.awakenScrollBars();
        }
    }
}
