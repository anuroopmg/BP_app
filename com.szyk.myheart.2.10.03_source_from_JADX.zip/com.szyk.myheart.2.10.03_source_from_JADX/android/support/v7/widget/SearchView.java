package android.support.v7.widget;

import android.app.SearchableInfo;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.KeyEvent.DispatcherState;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import happy.hacking.nk;
import happy.hacking.po;
import happy.hacking.pr;
import happy.hacking.ug;
import happy.hacking.uj;
import happy.hacking.va;
import happy.hacking.wp;
import happy.hacking.yr;
import happy.hacking.ys;
import happy.hacking.yt;
import happy.hacking.yu;
import happy.hacking.yw;
import java.util.WeakHashMap;

public final class SearchView extends wp implements uj {
    static final yr f545a;
    private static final boolean f546b;
    private boolean f547A;
    private boolean f548B;
    private int f549C;
    private boolean f550D;
    private CharSequence f551E;
    private boolean f552F;
    private int f553G;
    private SearchableInfo f554H;
    private Bundle f555I;
    private Runnable f556J;
    private final Runnable f557K;
    private Runnable f558L;
    private final WeakHashMap f559M;
    private final SearchAutoComplete f560c;
    private final View f561d;
    private final View f562e;
    private final ImageView f563f;
    private final ImageView f564g;
    private final ImageView f565h;
    private final ImageView f566i;
    private final ImageView f567j;
    private final Drawable f568k;
    private final int f569l;
    private final int f570m;
    private final Intent f571n;
    private final Intent f572o;
    private final CharSequence f573p;
    private yt f574q;
    private ys f575r;
    private OnFocusChangeListener f576s;
    private yu f577t;
    private OnClickListener f578u;
    private boolean f579v;
    private boolean f580w;
    private nk f581x;
    private boolean f582y;
    private CharSequence f583z;

    public class SearchAutoComplete extends va {
        private int f543a;
        private SearchView f544b;

        public SearchAutoComplete(Context context) {
            this(context, null);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, po.autoCompleteTextViewStyle);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
            this.f543a = getThreshold();
        }

        void setSearchView(SearchView searchView) {
            this.f544b = searchView;
        }

        public void setThreshold(int i) {
            super.setThreshold(i);
            this.f543a = i;
        }

        protected void replaceText(CharSequence charSequence) {
        }

        public void performCompletion() {
        }

        public void onWindowFocusChanged(boolean z) {
            super.onWindowFocusChanged(z);
            if (z && this.f544b.hasFocus() && getVisibility() == 0) {
                ((InputMethodManager) getContext().getSystemService("input_method")).showSoftInput(this, 0);
                if (SearchView.m566a(getContext())) {
                    yr yrVar = SearchView.f545a;
                    if (yrVar.f6609c != null) {
                        try {
                            yrVar.f6609c.invoke(this, new Object[]{Boolean.valueOf(true)});
                        } catch (Exception e) {
                        }
                    }
                }
            }
        }

        protected void onFocusChanged(boolean z, int i, Rect rect) {
            super.onFocusChanged(z, i, rect);
            this.f544b.m572d();
        }

        public boolean enoughToFilter() {
            return this.f543a <= 0 || super.enoughToFilter();
        }

        public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
            if (i == 4) {
                DispatcherState keyDispatcherState;
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState == null) {
                        return true;
                    }
                    keyDispatcherState.startTracking(keyEvent, this);
                    return true;
                } else if (keyEvent.getAction() == 1) {
                    keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f544b.clearFocus();
                        this.f544b.setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i, keyEvent);
        }
    }

    static {
        boolean z;
        if (VERSION.SDK_INT >= 8) {
            z = true;
        } else {
            z = false;
        }
        f546b = z;
        f545a = new yr();
    }

    public final int getSuggestionRowLayout() {
        return this.f569l;
    }

    public final int getSuggestionCommitIconResId() {
        return this.f570m;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void setSearchableInfo(android.app.SearchableInfo r9) {
        /*
        r8 = this;
        r4 = 0;
        r7 = 65536; // 0x10000 float:9.18355E-41 double:3.2379E-319;
        r3 = 0;
        r2 = 1;
        r8.f554H = r9;
        r0 = r8.f554H;
        if (r0 == 0) goto L_0x0079;
    L_0x000b:
        r0 = f546b;
        if (r0 == 0) goto L_0x0076;
    L_0x000f:
        r0 = r8.f560c;
        r1 = r8.f554H;
        r1 = r1.getSuggestThreshold();
        r0.setThreshold(r1);
        r0 = r8.f560c;
        r1 = r8.f554H;
        r1 = r1.getImeOptions();
        r0.setImeOptions(r1);
        r0 = r8.f554H;
        r0 = r0.getInputType();
        r1 = r0 & 15;
        if (r1 != r2) goto L_0x003f;
    L_0x002f:
        r1 = -65537; // 0xfffffffffffeffff float:NaN double:NaN;
        r0 = r0 & r1;
        r1 = r8.f554H;
        r1 = r1.getSuggestAuthority();
        if (r1 == 0) goto L_0x003f;
    L_0x003b:
        r0 = r0 | r7;
        r1 = 524288; // 0x80000 float:7.34684E-40 double:2.590327E-318;
        r0 = r0 | r1;
    L_0x003f:
        r1 = r8.f560c;
        r1.setInputType(r0);
        r0 = r8.f581x;
        if (r0 == 0) goto L_0x004d;
    L_0x0048:
        r0 = r8.f581x;
        r0.m6571a(r4);
    L_0x004d:
        r0 = r8.f554H;
        r0 = r0.getSuggestAuthority();
        if (r0 == 0) goto L_0x0076;
    L_0x0055:
        r0 = new happy.hacking.yw;
        r1 = r8.getContext();
        r5 = r8.f554H;
        r6 = r8.f559M;
        r0.<init>(r1, r8, r5, r6);
        r8.f581x = r0;
        r0 = r8.f560c;
        r1 = r8.f581x;
        r0.setAdapter(r1);
        r0 = r8.f581x;
        r0 = (happy.hacking.yw) r0;
        r1 = r8.f547A;
        if (r1 == 0) goto L_0x00b9;
    L_0x0073:
        r1 = 2;
    L_0x0074:
        r0.f6611j = r1;
    L_0x0076:
        r8.m569g();
    L_0x0079:
        r0 = f546b;
        if (r0 == 0) goto L_0x00ca;
    L_0x007d:
        r0 = r8.f554H;
        if (r0 == 0) goto L_0x00c8;
    L_0x0081:
        r0 = r8.f554H;
        r0 = r0.getVoiceSearchEnabled();
        if (r0 == 0) goto L_0x00c8;
    L_0x0089:
        r0 = r8.f554H;
        r0 = r0.getVoiceSearchLaunchWebSearch();
        if (r0 == 0) goto L_0x00bb;
    L_0x0091:
        r0 = r8.f571n;
    L_0x0093:
        if (r0 == 0) goto L_0x00c8;
    L_0x0095:
        r1 = r8.getContext();
        r1 = r1.getPackageManager();
        r0 = r1.resolveActivity(r0, r7);
        if (r0 == 0) goto L_0x00c6;
    L_0x00a3:
        r0 = r2;
    L_0x00a4:
        if (r0 == 0) goto L_0x00ca;
    L_0x00a6:
        r8.f550D = r2;
        r0 = r8.f550D;
        if (r0 == 0) goto L_0x00b3;
    L_0x00ac:
        r0 = r8.f560c;
        r1 = "nm";
        r0.setPrivateImeOptions(r1);
    L_0x00b3:
        r0 = r8.f580w;
        r8.m565a(r0);
        return;
    L_0x00b9:
        r1 = r2;
        goto L_0x0074;
    L_0x00bb:
        r0 = r8.f554H;
        r0 = r0.getVoiceSearchLaunchRecognizer();
        if (r0 == 0) goto L_0x00cc;
    L_0x00c3:
        r0 = r8.f572o;
        goto L_0x0093;
    L_0x00c6:
        r0 = r3;
        goto L_0x00a4;
    L_0x00c8:
        r0 = r3;
        goto L_0x00a4;
    L_0x00ca:
        r2 = r3;
        goto L_0x00a6;
    L_0x00cc:
        r0 = r4;
        goto L_0x0093;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.widget.SearchView.setSearchableInfo(android.app.SearchableInfo):void");
    }

    public final void setAppSearchData(Bundle bundle) {
        this.f555I = bundle;
    }

    public final void setImeOptions(int i) {
        this.f560c.setImeOptions(i);
    }

    public final int getImeOptions() {
        return this.f560c.getImeOptions();
    }

    public final void setInputType(int i) {
        this.f560c.setInputType(i);
    }

    public final int getInputType() {
        return this.f560c.getInputType();
    }

    public final boolean requestFocus(int i, Rect rect) {
        if (this.f548B || !isFocusable()) {
            return false;
        }
        if (this.f580w) {
            return super.requestFocus(i, rect);
        }
        boolean requestFocus = this.f560c.requestFocus(i, rect);
        if (requestFocus) {
            m565a(false);
        }
        return requestFocus;
    }

    public final void clearFocus() {
        this.f548B = true;
        setImeVisibility(false);
        super.clearFocus();
        this.f560c.clearFocus();
        this.f548B = false;
    }

    public final void setOnQueryTextListener(yt ytVar) {
        this.f574q = ytVar;
    }

    public final void setOnCloseListener(ys ysVar) {
        this.f575r = ysVar;
    }

    public final void setOnQueryTextFocusChangeListener(OnFocusChangeListener onFocusChangeListener) {
        this.f576s = onFocusChangeListener;
    }

    public final void setOnSuggestionListener(yu yuVar) {
        this.f577t = yuVar;
    }

    public final void setOnSearchClickListener(OnClickListener onClickListener) {
        this.f578u = onClickListener;
    }

    public final CharSequence getQuery() {
        return this.f560c.getText();
    }

    public final void setQueryHint(CharSequence charSequence) {
        this.f583z = charSequence;
        m569g();
    }

    public final CharSequence getQueryHint() {
        if (this.f583z != null) {
            return this.f583z;
        }
        if (!f546b || this.f554H == null || this.f554H.getHintId() == 0) {
            return this.f573p;
        }
        return getContext().getText(this.f554H.getHintId());
    }

    public final void setIconifiedByDefault(boolean z) {
        if (this.f579v != z) {
            this.f579v = z;
            m565a(z);
            m569g();
        }
    }

    public final void setIconified(boolean z) {
        if (!z) {
            m565a(false);
            this.f560c.requestFocus();
            setImeVisibility(true);
            if (this.f578u != null) {
                this.f578u.onClick(this);
            }
        } else if (!TextUtils.isEmpty(this.f560c.getText())) {
            this.f560c.setText("");
            this.f560c.requestFocus();
            setImeVisibility(true);
        } else if (!this.f579v) {
        } else {
            if (this.f575r == null || !this.f575r.m7399a()) {
                clearFocus();
                m565a(true);
            }
        }
    }

    public final void setSubmitButtonEnabled(boolean z) {
        this.f582y = z;
        m565a(this.f580w);
    }

    public final void setQueryRefinementEnabled(boolean z) {
        this.f547A = z;
        if (this.f581x instanceof yw) {
            int i;
            yw ywVar = (yw) this.f581x;
            if (z) {
                i = 2;
            } else {
                i = 1;
            }
            ywVar.f6611j = i;
        }
    }

    public final void setSuggestionsAdapter(nk nkVar) {
        this.f581x = nkVar;
        this.f560c.setAdapter(this.f581x);
    }

    public final nk getSuggestionsAdapter() {
        return this.f581x;
    }

    public final void setMaxWidth(int i) {
        this.f549C = i;
        requestLayout();
    }

    public final int getMaxWidth() {
        return this.f549C;
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(pr.abc_search_view_preferred_width);
    }

    private void m565a(boolean z) {
        Object obj;
        Object obj2;
        Object obj3 = 1;
        int i = 8;
        this.f580w = z;
        int i2 = z ? 0 : 8;
        if (TextUtils.isEmpty(this.f560c.getText())) {
            obj = null;
        } else {
            obj = 1;
        }
        this.f563f.setVisibility(i2);
        if (this.f582y && m567e() && hasFocus() && (obj != null || !this.f550D)) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        this.f564g.setVisibility(i2);
        View view = this.f561d;
        if (z) {
            i2 = 8;
        } else {
            i2 = 0;
        }
        view.setVisibility(i2);
        if (this.f567j.getDrawable() == null || this.f579v) {
            i2 = 8;
        } else {
            i2 = 0;
        }
        this.f567j.setVisibility(i2);
        Object obj4 = !TextUtils.isEmpty(this.f560c.getText()) ? 1 : null;
        if (obj4 != null || (this.f579v && !this.f552F)) {
            obj2 = 1;
        } else {
            obj2 = null;
        }
        ImageView imageView = this.f565h;
        if (obj2 != null) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        imageView.setVisibility(i2);
        Drawable drawable = this.f565h.getDrawable();
        if (drawable != null) {
            int[] iArr;
            if (obj4 != null) {
                iArr = ENABLED_STATE_SET;
            } else {
                iArr = EMPTY_STATE_SET;
            }
            drawable.setState(iArr);
        }
        if (obj != null) {
            obj3 = null;
        }
        if (!this.f550D || this.f580w || r4 == null) {
            i2 = 8;
        } else {
            this.f564g.setVisibility(8);
            i2 = 0;
        }
        this.f566i.setVisibility(i2);
        if (m567e() && (this.f564g.getVisibility() == 0 || this.f566i.getVisibility() == 0)) {
            i = 0;
        }
        this.f562e.setVisibility(i);
    }

    private boolean m567e() {
        return (this.f582y || this.f550D) && !this.f580w;
    }

    private void m568f() {
        post(this.f557K);
    }

    protected final void onDetachedFromWindow() {
        removeCallbacks(this.f557K);
        post(this.f558L);
        super.onDetachedFromWindow();
    }

    private void setImeVisibility(boolean z) {
        if (z) {
            post(this.f556J);
            return;
        }
        removeCallbacks(this.f556J);
        InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
        }
    }

    private void m569g() {
        CharSequence queryHint = getQueryHint();
        SearchAutoComplete searchAutoComplete = this.f560c;
        if (queryHint == null) {
            queryHint = "";
        }
        if (this.f579v && this.f568k != null) {
            int textSize = (int) (((double) this.f560c.getTextSize()) * 1.25d);
            this.f568k.setBounds(0, 0, textSize, textSize);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
            spannableStringBuilder.setSpan(new ImageSpan(this.f568k), 1, 2, 33);
            spannableStringBuilder.append(queryHint);
            Object obj = spannableStringBuilder;
        }
        searchAutoComplete.setHint(queryHint);
    }

    public final void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        m568f();
    }

    public final void m571b() {
        CharSequence charSequence = "";
        this.f560c.setText(charSequence);
        this.f560c.setSelection(this.f560c.length());
        this.f551E = charSequence;
        clearFocus();
        m565a(true);
        this.f560c.setImeOptions(this.f553G);
        this.f552F = false;
    }

    public final void m570a() {
        if (!this.f552F) {
            this.f552F = true;
            this.f553G = this.f560c.getImeOptions();
            this.f560c.setImeOptions(this.f553G | 33554432);
            this.f560c.setText("");
            setIconified(false);
        }
    }

    public final void setQuery(CharSequence charSequence) {
        this.f560c.setText(charSequence);
        this.f560c.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    static boolean m566a(Context context) {
        return context.getResources().getConfiguration().orientation == 2;
    }

    protected final void onMeasure(int i, int i2) {
        if (this.f580w) {
            super.onMeasure(i, i2);
            return;
        }
        int mode = MeasureSpec.getMode(i);
        int size = MeasureSpec.getSize(i);
        switch (mode) {
            case Integer.MIN_VALUE:
                if (this.f549C <= 0) {
                    size = Math.min(getPreferredWidth(), size);
                    break;
                } else {
                    size = Math.min(this.f549C, size);
                    break;
                }
            case ug.RecyclerView_android_orientation /*0*/:
                if (this.f549C <= 0) {
                    size = getPreferredWidth();
                    break;
                } else {
                    size = this.f549C;
                    break;
                }
            case 1073741824:
                if (this.f549C > 0) {
                    size = Math.min(this.f549C, size);
                    break;
                }
                break;
        }
        super.onMeasure(MeasureSpec.makeMeasureSpec(size, 1073741824), i2);
    }

    final void m572d() {
        m565a(this.f580w);
        m568f();
        if (this.f560c.hasFocus()) {
            yr yrVar = f545a;
            SearchAutoComplete searchAutoComplete = this.f560c;
            if (yrVar.f6607a != null) {
                try {
                    yrVar.f6607a.invoke(searchAutoComplete, new Object[0]);
                } catch (Exception e) {
                }
            }
            yrVar = f545a;
            searchAutoComplete = this.f560c;
            if (yrVar.f6608b != null) {
                try {
                    yrVar.f6608b.invoke(searchAutoComplete, new Object[0]);
                } catch (Exception e2) {
                }
            }
        }
    }
}
