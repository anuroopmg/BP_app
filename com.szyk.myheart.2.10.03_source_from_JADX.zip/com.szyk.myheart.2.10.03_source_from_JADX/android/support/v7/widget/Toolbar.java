package android.support.v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v7.app.ActionBar;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import happy.hacking.gr;
import happy.hacking.hk;
import happy.hacking.ho;
import happy.hacking.hu;
import happy.hacking.iv;
import happy.hacking.po;
import happy.hacking.py;
import happy.hacking.qz;
import happy.hacking.rn;
import happy.hacking.ro;
import happy.hacking.rr;
import happy.hacking.sd;
import happy.hacking.tg;
import happy.hacking.tm;
import happy.hacking.tx;
import happy.hacking.tz;
import happy.hacking.ua;
import happy.hacking.ue;
import happy.hacking.ug;
import happy.hacking.uw;
import happy.hacking.yy;
import happy.hacking.yz;
import happy.hacking.za;
import happy.hacking.zb;
import happy.hacking.zc;
import happy.hacking.zd;
import happy.hacking.ze;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup {
    private CharSequence f586A;
    private CharSequence f587B;
    private int f588C;
    private int f589D;
    private boolean f590E;
    private boolean f591F;
    private final ArrayList f592G;
    private final int[] f593H;
    private zd f594I;
    private final uw f595J;
    private ua f596K;
    private boolean f597L;
    private final Runnable f598M;
    private final tx f599N;
    public ActionMenuView f600a;
    public TextView f601b;
    public TextView f602c;
    public View f603d;
    public Context f604e;
    public int f605f;
    public int f606g;
    public int f607h;
    public final tm f608i;
    public final ArrayList f609j;
    public ActionMenuPresenter f610k;
    public zb f611l;
    public sd f612m;
    public ro f613n;
    private ImageButton f614o;
    private ImageView f615p;
    private Drawable f616q;
    private CharSequence f617r;
    private ImageButton f618s;
    private int f619t;
    private int f620u;
    private int f621v;
    private int f622w;
    private int f623x;
    private int f624y;
    private int f625z;

    public class SavedState extends BaseSavedState {
        public static final Creator CREATOR;
        int f584a;
        boolean f585b;

        public SavedState(Parcel parcel) {
            super(parcel);
            this.f584a = parcel.readInt();
            this.f585b = parcel.readInt() != 0;
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f584a);
            parcel.writeInt(this.f585b ? 1 : 0);
        }

        static {
            CREATOR = new ze();
        }
    }

    protected /* synthetic */ LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return m577a(layoutParams);
    }

    public Toolbar(Context context) {
        this(context, null);
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, po.toolbarStyle);
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f608i = new tm();
        this.f625z = 8388627;
        this.f592G = new ArrayList();
        this.f609j = new ArrayList();
        this.f593H = new int[2];
        this.f595J = new yy(this);
        this.f598M = new yz(this);
        tz a = tz.m7065a(getContext(), attributeSet, py.Toolbar, i);
        this.f606g = a.m7076e(py.Toolbar_titleTextAppearance, 0);
        this.f607h = a.m7076e(py.Toolbar_subtitleTextAppearance, 0);
        this.f625z = a.f6280a.getInteger(py.Toolbar_android_gravity, this.f625z);
        this.f619t = 48;
        int b = a.m7070b(py.Toolbar_titleMargins, 0);
        this.f624y = b;
        this.f623x = b;
        this.f622w = b;
        this.f621v = b;
        b = a.m7070b(py.Toolbar_titleMarginStart, -1);
        if (b >= 0) {
            this.f621v = b;
        }
        b = a.m7070b(py.Toolbar_titleMarginEnd, -1);
        if (b >= 0) {
            this.f622w = b;
        }
        b = a.m7070b(py.Toolbar_titleMarginTop, -1);
        if (b >= 0) {
            this.f623x = b;
        }
        b = a.m7070b(py.Toolbar_titleMarginBottom, -1);
        if (b >= 0) {
            this.f624y = b;
        }
        this.f620u = a.m7072c(py.Toolbar_maxButtonHeight, -1);
        b = a.m7070b(py.Toolbar_contentInsetStart, Integer.MIN_VALUE);
        int b2 = a.m7070b(py.Toolbar_contentInsetEnd, Integer.MIN_VALUE);
        int c = a.m7072c(py.Toolbar_contentInsetLeft, 0);
        int c2 = a.m7072c(py.Toolbar_contentInsetRight, 0);
        tm tmVar = this.f608i;
        tmVar.f6225h = false;
        if (c != Integer.MIN_VALUE) {
            tmVar.f6222e = c;
            tmVar.f6218a = c;
        }
        if (c2 != Integer.MIN_VALUE) {
            tmVar.f6223f = c2;
            tmVar.f6219b = c2;
        }
        if (!(b == Integer.MIN_VALUE && b2 == Integer.MIN_VALUE)) {
            this.f608i.m7038a(b, b2);
        }
        this.f616q = a.m7067a(py.Toolbar_collapseIcon);
        this.f617r = a.m7073c(py.Toolbar_collapseContentDescription);
        CharSequence c3 = a.m7073c(py.Toolbar_title);
        if (!TextUtils.isEmpty(c3)) {
            setTitle(c3);
        }
        c3 = a.m7073c(py.Toolbar_subtitle);
        if (!TextUtils.isEmpty(c3)) {
            setSubtitle(c3);
        }
        this.f604e = getContext();
        setPopupTheme(a.m7076e(py.Toolbar_popupTheme, 0));
        Drawable a2 = a.m7067a(py.Toolbar_navigationIcon);
        if (a2 != null) {
            setNavigationIcon(a2);
        }
        c3 = a.m7073c(py.Toolbar_navigationContentDescription);
        if (!TextUtils.isEmpty(c3)) {
            setNavigationContentDescription(c3);
        }
        a2 = a.m7067a(py.Toolbar_logo);
        if (a2 != null) {
            setLogo(a2);
        }
        c3 = a.m7073c(py.Toolbar_logoDescription);
        if (!TextUtils.isEmpty(c3)) {
            setLogoDescription(c3);
        }
        if (a.m7077e(py.Toolbar_titleTextColor)) {
            setTitleTextColor(a.m7074d(py.Toolbar_titleTextColor));
        }
        if (a.m7077e(py.Toolbar_subtitleTextColor)) {
            setSubtitleTextColor(a.m7074d(py.Toolbar_subtitleTextColor));
        }
        a.f6280a.recycle();
        this.f599N = a.m7068a();
    }

    public void setPopupTheme(int i) {
        if (this.f605f != i) {
            this.f605f = i;
            if (i == 0) {
                this.f604e = getContext();
            } else {
                this.f604e = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public int getPopupTheme() {
        return this.f605f;
    }

    public void onRtlPropertiesChanged(int i) {
        boolean z = true;
        if (VERSION.SDK_INT >= 17) {
            super.onRtlPropertiesChanged(i);
        }
        tm tmVar = this.f608i;
        if (i != 1) {
            z = false;
        }
        if (z != tmVar.f6224g) {
            tmVar.f6224g = z;
            if (!tmVar.f6225h) {
                tmVar.f6218a = tmVar.f6222e;
                tmVar.f6219b = tmVar.f6223f;
            } else if (z) {
                tmVar.f6218a = tmVar.f6221d != Integer.MIN_VALUE ? tmVar.f6221d : tmVar.f6222e;
                tmVar.f6219b = tmVar.f6220c != Integer.MIN_VALUE ? tmVar.f6220c : tmVar.f6223f;
            } else {
                tmVar.f6218a = tmVar.f6220c != Integer.MIN_VALUE ? tmVar.f6220c : tmVar.f6222e;
                tmVar.f6219b = tmVar.f6221d != Integer.MIN_VALUE ? tmVar.f6221d : tmVar.f6223f;
            }
        }
    }

    public void setLogo(int i) {
        setLogo(this.f599N.m7061a(i, false));
    }

    public final boolean m594a() {
        if (this.f600a != null) {
            boolean z;
            ActionMenuView actionMenuView = this.f600a;
            if (actionMenuView.f507c == null || !actionMenuView.f507c.m443i()) {
                z = false;
            } else {
                z = true;
            }
            if (z) {
                return true;
            }
        }
        return false;
    }

    public final boolean m595b() {
        if (this.f600a != null) {
            boolean z;
            ActionMenuView actionMenuView = this.f600a;
            if (actionMenuView.f507c == null || !actionMenuView.f507c.m439e()) {
                z = false;
            } else {
                z = true;
            }
            if (z) {
                return true;
            }
        }
        return false;
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            m591f();
            if (!m589d(this.f615p)) {
                m580a(this.f615p, true);
            }
        } else if (this.f615p != null && m589d(this.f615p)) {
            removeView(this.f615p);
            this.f609j.remove(this.f615p);
        }
        if (this.f615p != null) {
            this.f615p.setImageDrawable(drawable);
        }
    }

    public Drawable getLogo() {
        return this.f615p != null ? this.f615p.getDrawable() : null;
    }

    public void setLogoDescription(int i) {
        setLogoDescription(getContext().getText(i));
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            m591f();
        }
        if (this.f615p != null) {
            this.f615p.setContentDescription(charSequence);
        }
    }

    public CharSequence getLogoDescription() {
        return this.f615p != null ? this.f615p.getContentDescription() : null;
    }

    private void m591f() {
        if (this.f615p == null) {
            this.f615p = new ImageView(getContext());
        }
    }

    public final void m596c() {
        rr rrVar = this.f611l == null ? null : this.f611l.f6636b;
        if (rrVar != null) {
            rrVar.collapseActionView();
        }
    }

    public CharSequence getTitle() {
        return this.f586A;
    }

    public void setTitle(int i) {
        setTitle(getContext().getText(i));
    }

    public void setTitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f601b == null) {
                Context context = getContext();
                this.f601b = new TextView(context);
                this.f601b.setSingleLine();
                this.f601b.setEllipsize(TruncateAt.END);
                if (this.f606g != 0) {
                    this.f601b.setTextAppearance(context, this.f606g);
                }
                if (this.f588C != 0) {
                    this.f601b.setTextColor(this.f588C);
                }
            }
            if (!m589d(this.f601b)) {
                m580a(this.f601b, true);
            }
        } else if (this.f601b != null && m589d(this.f601b)) {
            removeView(this.f601b);
            this.f609j.remove(this.f601b);
        }
        if (this.f601b != null) {
            this.f601b.setText(charSequence);
        }
        this.f586A = charSequence;
    }

    public CharSequence getSubtitle() {
        return this.f587B;
    }

    public void setSubtitle(int i) {
        setSubtitle(getContext().getText(i));
    }

    public void setSubtitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f602c == null) {
                Context context = getContext();
                this.f602c = new TextView(context);
                this.f602c.setSingleLine();
                this.f602c.setEllipsize(TruncateAt.END);
                if (this.f607h != 0) {
                    this.f602c.setTextAppearance(context, this.f607h);
                }
                if (this.f589D != 0) {
                    this.f602c.setTextColor(this.f589D);
                }
            }
            if (!m589d(this.f602c)) {
                m580a(this.f602c, true);
            }
        } else if (this.f602c != null && m589d(this.f602c)) {
            removeView(this.f602c);
            this.f609j.remove(this.f602c);
        }
        if (this.f602c != null) {
            this.f602c.setText(charSequence);
        }
        this.f587B = charSequence;
    }

    public void setTitleTextColor(int i) {
        this.f588C = i;
        if (this.f601b != null) {
            this.f601b.setTextColor(i);
        }
    }

    public void setSubtitleTextColor(int i) {
        this.f589D = i;
        if (this.f602c != null) {
            this.f602c.setTextColor(i);
        }
    }

    public CharSequence getNavigationContentDescription() {
        return this.f614o != null ? this.f614o.getContentDescription() : null;
    }

    public void setNavigationContentDescription(int i) {
        setNavigationContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            m593h();
        }
        if (this.f614o != null) {
            this.f614o.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(int i) {
        setNavigationIcon(this.f599N.m7061a(i, false));
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            m593h();
            if (!m589d(this.f614o)) {
                m580a(this.f614o, true);
            }
        } else if (this.f614o != null && m589d(this.f614o)) {
            removeView(this.f614o);
            this.f609j.remove(this.f614o);
        }
        if (this.f614o != null) {
            this.f614o.setImageDrawable(drawable);
        }
    }

    public Drawable getNavigationIcon() {
        return this.f614o != null ? this.f614o.getDrawable() : null;
    }

    public void setNavigationOnClickListener(OnClickListener onClickListener) {
        m593h();
        this.f614o.setOnClickListener(onClickListener);
    }

    public Menu getMenu() {
        m592g();
        return this.f600a.getMenu();
    }

    public void setOverflowIcon(Drawable drawable) {
        m592g();
        this.f600a.setOverflowIcon(drawable);
    }

    public Drawable getOverflowIcon() {
        m592g();
        return this.f600a.getOverflowIcon();
    }

    private void m592g() {
        m597d();
        if (this.f600a.f505a == null) {
            rn rnVar = (rn) this.f600a.getMenu();
            if (this.f611l == null) {
                this.f611l = new zb();
            }
            this.f600a.setExpandedActionViewsExclusive(true);
            rnVar.m6096a(this.f611l, this.f604e);
        }
    }

    public final void m597d() {
        if (this.f600a == null) {
            this.f600a = new ActionMenuView(getContext());
            this.f600a.setPopupTheme(this.f605f);
            this.f600a.setOnMenuItemClickListener(this.f595J);
            ActionMenuView actionMenuView = this.f600a;
            sd sdVar = this.f612m;
            ro roVar = this.f613n;
            actionMenuView.f508d = sdVar;
            actionMenuView.f509e = roVar;
            LayoutParams zcVar = new zc();
            zcVar.gravity = 8388613 | (this.f619t & 112);
            this.f600a.setLayoutParams(zcVar);
            m580a(this.f600a, false);
        }
    }

    private MenuInflater getMenuInflater() {
        return new qz(getContext());
    }

    public void setOnMenuItemClickListener(zd zdVar) {
        this.f594I = zdVar;
    }

    public int getContentInsetStart() {
        tm tmVar = this.f608i;
        return tmVar.f6224g ? tmVar.f6219b : tmVar.f6218a;
    }

    public int getContentInsetEnd() {
        tm tmVar = this.f608i;
        return tmVar.f6224g ? tmVar.f6218a : tmVar.f6219b;
    }

    public int getContentInsetLeft() {
        return this.f608i.f6218a;
    }

    public int getContentInsetRight() {
        return this.f608i.f6219b;
    }

    private void m593h() {
        if (this.f614o == null) {
            this.f614o = new ImageButton(getContext(), null, po.toolbarNavigationButtonStyle);
            LayoutParams zcVar = new zc();
            zcVar.gravity = 8388611 | (this.f619t & 112);
            this.f614o.setLayoutParams(zcVar);
        }
    }

    private void m580a(View view, boolean z) {
        LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            layoutParams = new zc();
        } else if (checkLayoutParams(layoutParams)) {
            zc zcVar = (zc) layoutParams;
        } else {
            layoutParams = m577a(layoutParams);
        }
        layoutParams.f6638a = 1;
        if (!z || this.f603d == null) {
            addView(view, layoutParams);
            return;
        }
        view.setLayoutParams(layoutParams);
        this.f609j.add(view);
    }

    protected Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        if (!(this.f611l == null || this.f611l.f6636b == null)) {
            savedState.f584a = this.f611l.f6636b.getItemId();
        }
        savedState.f585b = m594a();
        return savedState;
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        Menu menu;
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        if (this.f600a != null) {
            menu = this.f600a.f505a;
        } else {
            menu = null;
        }
        if (!(savedState.f584a == 0 || this.f611l == null || menu == null)) {
            MenuItem findItem = menu.findItem(savedState.f584a);
            if (findItem != null) {
                ho.m5813b(findItem);
            }
        }
        if (savedState.f585b) {
            removeCallbacks(this.f598M);
            post(this.f598M);
        }
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f598M);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int a = hu.m5837a(motionEvent);
        if (a == 0) {
            this.f590E = false;
        }
        if (!this.f590E) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (a == 0 && !onTouchEvent) {
                this.f590E = true;
            }
        }
        if (a == 1 || a == 3) {
            this.f590E = false;
        }
        return true;
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int a = hu.m5837a(motionEvent);
        if (a == 9) {
            this.f591F = false;
        }
        if (!this.f591F) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (a == 9 && !onHoverEvent) {
                this.f591F = true;
            }
        }
        if (a == 10 || a == 3) {
            this.f591F = false;
        }
        return true;
    }

    private void m579a(View view, int i, int i2, int i3, int i4) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = getChildMeasureSpec(i, (((getPaddingLeft() + getPaddingRight()) + marginLayoutParams.leftMargin) + marginLayoutParams.rightMargin) + i2, marginLayoutParams.width);
        int childMeasureSpec2 = getChildMeasureSpec(i3, (((getPaddingTop() + getPaddingBottom()) + marginLayoutParams.topMargin) + marginLayoutParams.bottomMargin) + 0, marginLayoutParams.height);
        int mode = MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i4 >= 0) {
            if (mode != 0) {
                i4 = Math.min(MeasureSpec.getSize(childMeasureSpec2), i4);
            }
            childMeasureSpec2 = MeasureSpec.makeMeasureSpec(i4, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    private int m575a(View view, int i, int i2, int i3, int i4, int[] iArr) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        int i5 = marginLayoutParams.leftMargin - iArr[0];
        int i6 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i5) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i5);
        iArr[1] = Math.max(0, -i6);
        view.measure(getChildMeasureSpec(i, ((getPaddingLeft() + getPaddingRight()) + max) + i2, marginLayoutParams.width), getChildMeasureSpec(i3, (((getPaddingTop() + getPaddingBottom()) + marginLayoutParams.topMargin) + marginLayoutParams.bottomMargin) + i4, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    protected void onMeasure(int i, int i2) {
        int i3;
        int i4;
        int max;
        int a;
        int i5;
        Object obj;
        int[] iArr = this.f593H;
        if (ue.m7133a(this)) {
            i3 = 0;
            i4 = 1;
        } else {
            i3 = 1;
            i4 = 0;
        }
        int i6 = 0;
        if (m582a(this.f614o)) {
            m579a(this.f614o, i, 0, i2, this.f620u);
            i6 = this.f614o.getMeasuredWidth() + m583b(this.f614o);
            max = Math.max(0, this.f614o.getMeasuredHeight() + m586c(this.f614o));
            a = ue.m7131a(0, iv.m5936m(this.f614o));
            i5 = max;
        } else {
            a = 0;
            i5 = 0;
        }
        if (m582a(this.f618s)) {
            m579a(this.f618s, i, 0, i2, this.f620u);
            i6 = this.f618s.getMeasuredWidth() + m583b(this.f618s);
            i5 = Math.max(i5, this.f618s.getMeasuredHeight() + m586c(this.f618s));
            a = ue.m7131a(a, iv.m5936m(this.f618s));
        }
        int contentInsetStart = getContentInsetStart();
        int max2 = Math.max(contentInsetStart, i6) + 0;
        iArr[i4] = Math.max(0, contentInsetStart - i6);
        i6 = 0;
        if (m582a(this.f600a)) {
            m579a(this.f600a, i, max2, i2, this.f620u);
            i6 = this.f600a.getMeasuredWidth() + m583b(this.f600a);
            i5 = Math.max(i5, this.f600a.getMeasuredHeight() + m586c(this.f600a));
            a = ue.m7131a(a, iv.m5936m(this.f600a));
        }
        contentInsetStart = getContentInsetEnd();
        max2 += Math.max(contentInsetStart, i6);
        iArr[i3] = Math.max(0, contentInsetStart - i6);
        if (m582a(this.f603d)) {
            max2 += m575a(this.f603d, i, max2, i2, 0, iArr);
            i5 = Math.max(i5, this.f603d.getMeasuredHeight() + m586c(this.f603d));
            a = ue.m7131a(a, iv.m5936m(this.f603d));
        }
        if (m582a(this.f615p)) {
            max2 += m575a(this.f615p, i, max2, i2, 0, iArr);
            i5 = Math.max(i5, this.f615p.getMeasuredHeight() + m586c(this.f615p));
            a = ue.m7131a(a, iv.m5936m(this.f615p));
        }
        i4 = getChildCount();
        i3 = 0;
        int i7 = a;
        int i8 = i5;
        while (i3 < i4) {
            View childAt = getChildAt(i3);
            if (((zc) childAt.getLayoutParams()).f6638a == 0 && m582a(childAt)) {
                max2 += m575a(childAt, i, max2, i2, 0, iArr);
                max = Math.max(i8, childAt.getMeasuredHeight() + m586c(childAt));
                i6 = ue.m7131a(i7, iv.m5936m(childAt));
                contentInsetStart = max;
            } else {
                i6 = i7;
                contentInsetStart = i8;
            }
            i3++;
            i7 = i6;
            i8 = contentInsetStart;
        }
        contentInsetStart = 0;
        i6 = 0;
        int i9 = this.f623x + this.f624y;
        max = this.f621v + this.f622w;
        if (m582a(this.f601b)) {
            m575a(this.f601b, i, max2 + max, i2, i9, iArr);
            contentInsetStart = m583b(this.f601b) + this.f601b.getMeasuredWidth();
            i6 = this.f601b.getMeasuredHeight() + m586c(this.f601b);
            i7 = ue.m7131a(i7, iv.m5936m(this.f601b));
        }
        if (m582a(this.f602c)) {
            contentInsetStart = Math.max(contentInsetStart, m575a(this.f602c, i, max2 + max, i2, i9 + i6, iArr));
            i6 += this.f602c.getMeasuredHeight() + m586c(this.f602c);
            i7 = ue.m7131a(i7, iv.m5936m(this.f602c));
        }
        contentInsetStart += max2;
        i6 = Math.max(i8, i6) + (getPaddingTop() + getPaddingBottom());
        int i10 = i;
        max = iv.m5900a(Math.max(contentInsetStart + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), i10, -16777216 & i7);
        i6 = iv.m5900a(Math.max(i6, getSuggestedMinimumHeight()), i2, i7 << 16);
        if (this.f597L) {
            max2 = getChildCount();
            for (contentInsetStart = 0; contentInsetStart < max2; contentInsetStart++) {
                View childAt2 = getChildAt(contentInsetStart);
                if (m582a(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                    obj = null;
                    break;
                }
            }
            obj = 1;
        } else {
            obj = null;
        }
        if (obj != null) {
            i6 = 0;
        }
        setMeasuredDimension(max, i6);
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        Object obj;
        int i5;
        int i6;
        int i7;
        int measuredHeight;
        int paddingTop;
        int measuredWidth;
        if (iv.m5931h(this) == 1) {
            obj = 1;
        } else {
            obj = null;
        }
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i8 = width - paddingRight;
        int[] iArr = this.f593H;
        iArr[1] = 0;
        iArr[0] = 0;
        int t = iv.m5943t(this);
        if (!m582a(this.f614o)) {
            i5 = paddingLeft;
        } else if (obj != null) {
            i8 = m584b(this.f614o, i8, iArr, t);
            i5 = paddingLeft;
        } else {
            i5 = m576a(this.f614o, paddingLeft, iArr, t);
        }
        if (m582a(this.f618s)) {
            if (obj != null) {
                i8 = m584b(this.f618s, i8, iArr, t);
            } else {
                i5 = m576a(this.f618s, i5, iArr, t);
            }
        }
        if (m582a(this.f600a)) {
            if (obj != null) {
                i5 = m576a(this.f600a, i5, iArr, t);
            } else {
                i8 = m584b(this.f600a, i8, iArr, t);
            }
        }
        iArr[0] = Math.max(0, getContentInsetLeft() - i5);
        iArr[1] = Math.max(0, getContentInsetRight() - ((width - paddingRight) - i8));
        i5 = Math.max(i5, getContentInsetLeft());
        i8 = Math.min(i8, (width - paddingRight) - getContentInsetRight());
        if (m582a(this.f603d)) {
            if (obj != null) {
                i8 = m584b(this.f603d, i8, iArr, t);
            } else {
                i5 = m576a(this.f603d, i5, iArr, t);
            }
        }
        if (!m582a(this.f615p)) {
            i6 = i8;
            i7 = i5;
        } else if (obj != null) {
            i6 = m584b(this.f615p, i8, iArr, t);
            i7 = i5;
        } else {
            i6 = i8;
            i7 = m576a(this.f615p, i5, iArr, t);
        }
        boolean a = m582a(this.f601b);
        boolean a2 = m582a(this.f602c);
        i5 = 0;
        if (a) {
            zc zcVar = (zc) this.f601b.getLayoutParams();
            i5 = (zcVar.bottomMargin + (zcVar.topMargin + this.f601b.getMeasuredHeight())) + 0;
        }
        if (a2) {
            zcVar = (zc) this.f602c.getLayoutParams();
            measuredHeight = (zcVar.bottomMargin + (zcVar.topMargin + this.f602c.getMeasuredHeight())) + i5;
        } else {
            measuredHeight = i5;
        }
        if (a || a2) {
            zcVar = (zc) (a ? this.f601b : this.f602c).getLayoutParams();
            zc zcVar2 = (zc) (a2 ? this.f602c : this.f601b).getLayoutParams();
            Object obj2 = ((!a || this.f601b.getMeasuredWidth() <= 0) && (!a2 || this.f602c.getMeasuredWidth() <= 0)) ? null : 1;
            switch (this.f625z & 112) {
                case py.Theme_homeAsUpIndicator /*48*/:
                    paddingTop = (zcVar.topMargin + getPaddingTop()) + this.f623x;
                    break;
                case py.Theme_panelMenuListTheme /*80*/:
                    paddingTop = (((height - paddingBottom) - zcVar2.bottomMargin) - this.f624y) - measuredHeight;
                    break;
                default:
                    paddingTop = (((height - paddingTop2) - paddingBottom) - measuredHeight) / 2;
                    if (paddingTop < zcVar.topMargin + this.f623x) {
                        i8 = zcVar.topMargin + this.f623x;
                    } else {
                        measuredHeight = (((height - paddingBottom) - measuredHeight) - paddingTop) - paddingTop2;
                        if (measuredHeight < zcVar.bottomMargin + this.f624y) {
                            i8 = Math.max(0, paddingTop - ((zcVar2.bottomMargin + this.f624y) - measuredHeight));
                        } else {
                            i8 = paddingTop;
                        }
                    }
                    paddingTop = paddingTop2 + i8;
                    break;
            }
            if (obj != null) {
                i8 = (obj2 != null ? this.f621v : 0) - iArr[1];
                i5 = i6 - Math.max(0, i8);
                iArr[1] = Math.max(0, -i8);
                if (a) {
                    zcVar = (zc) this.f601b.getLayoutParams();
                    measuredWidth = i5 - this.f601b.getMeasuredWidth();
                    i6 = this.f601b.getMeasuredHeight() + paddingTop;
                    this.f601b.layout(measuredWidth, paddingTop, i5, i6);
                    paddingTop = i6 + zcVar.bottomMargin;
                    i6 = measuredWidth - this.f622w;
                } else {
                    i6 = i5;
                }
                if (a2) {
                    zcVar = (zc) this.f602c.getLayoutParams();
                    measuredWidth = zcVar.topMargin + paddingTop;
                    this.f602c.layout(i5 - this.f602c.getMeasuredWidth(), measuredWidth, i5, this.f602c.getMeasuredHeight() + measuredWidth);
                    measuredWidth = i5 - this.f622w;
                    i8 = zcVar.bottomMargin;
                    i8 = measuredWidth;
                } else {
                    i8 = i5;
                }
                if (obj2 != null) {
                    i8 = Math.min(i6, i8);
                } else {
                    i8 = i5;
                }
                i6 = i8;
            } else {
                i8 = (obj2 != null ? this.f621v : 0) - iArr[0];
                i7 += Math.max(0, i8);
                iArr[0] = Math.max(0, -i8);
                if (a) {
                    zcVar = (zc) this.f601b.getLayoutParams();
                    i5 = this.f601b.getMeasuredWidth() + i7;
                    measuredWidth = this.f601b.getMeasuredHeight() + paddingTop;
                    this.f601b.layout(i7, paddingTop, i5, measuredWidth);
                    i8 = zcVar.bottomMargin + measuredWidth;
                    measuredWidth = i5 + this.f622w;
                    i5 = i8;
                } else {
                    measuredWidth = i7;
                    i5 = paddingTop;
                }
                if (a2) {
                    zcVar = (zc) this.f602c.getLayoutParams();
                    i5 += zcVar.topMargin;
                    paddingTop = this.f602c.getMeasuredWidth() + i7;
                    this.f602c.layout(i7, i5, paddingTop, this.f602c.getMeasuredHeight() + i5);
                    i5 = this.f622w + paddingTop;
                    i8 = zcVar.bottomMargin;
                    i8 = i5;
                } else {
                    i8 = i7;
                }
                if (obj2 != null) {
                    i7 = Math.max(measuredWidth, i8);
                }
            }
        }
        m581a(this.f592G, 3);
        int size = this.f592G.size();
        measuredWidth = i7;
        for (i5 = 0; i5 < size; i5++) {
            measuredWidth = m576a((View) this.f592G.get(i5), measuredWidth, iArr, t);
        }
        m581a(this.f592G, 5);
        i7 = this.f592G.size();
        i5 = 0;
        measuredHeight = i6;
        while (i5 < i7) {
            i6 = m584b((View) this.f592G.get(i5), measuredHeight, iArr, t);
            i5++;
            measuredHeight = i6;
        }
        m581a(this.f592G, 1);
        List list = this.f592G;
        i6 = iArr[0];
        i7 = iArr[1];
        paddingTop2 = list.size();
        size = i6;
        paddingTop = i7;
        i6 = 0;
        i7 = 0;
        while (i6 < paddingTop2) {
            View view = (View) list.get(i6);
            zcVar = (zc) view.getLayoutParams();
            size = zcVar.leftMargin - size;
            i8 = zcVar.rightMargin - paddingTop;
            paddingBottom = Math.max(0, size);
            int max = Math.max(0, i8);
            size = Math.max(0, -size);
            paddingTop = Math.max(0, -i8);
            i6++;
            i7 += (view.getMeasuredWidth() + paddingBottom) + max;
        }
        i8 = ((((width - paddingLeft) - paddingRight) / 2) + paddingLeft) - (i7 / 2);
        i5 = i8 + i7;
        if (i8 < measuredWidth) {
            i8 = measuredWidth;
        } else if (i5 > measuredHeight) {
            i8 -= i5 - measuredHeight;
        }
        paddingLeft = this.f592G.size();
        measuredWidth = 0;
        i5 = i8;
        while (measuredWidth < paddingLeft) {
            i8 = m576a((View) this.f592G.get(measuredWidth), i5, iArr, t);
            measuredWidth++;
            i5 = i8;
        }
        this.f592G.clear();
    }

    private int m576a(View view, int i, int[] iArr, int i2) {
        zc zcVar = (zc) view.getLayoutParams();
        int i3 = zcVar.leftMargin - iArr[0];
        int max = Math.max(0, i3) + i;
        iArr[0] = Math.max(0, -i3);
        i3 = m574a(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, i3, max + measuredWidth, view.getMeasuredHeight() + i3);
        return (zcVar.rightMargin + measuredWidth) + max;
    }

    private int m584b(View view, int i, int[] iArr, int i2) {
        zc zcVar = (zc) view.getLayoutParams();
        int i3 = zcVar.rightMargin - iArr[1];
        int max = i - Math.max(0, i3);
        iArr[1] = Math.max(0, -i3);
        i3 = m574a(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, i3, max, view.getMeasuredHeight() + i3);
        return max - (zcVar.leftMargin + measuredWidth);
    }

    private int m574a(View view, int i) {
        zc zcVar = (zc) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i2 = i > 0 ? (measuredHeight - i) / 2 : 0;
        int i3 = zcVar.gravity & 112;
        switch (i3) {
            case py.Toolbar_titleMarginBottom /*16*/:
            case py.Theme_homeAsUpIndicator /*48*/:
            case py.Theme_panelMenuListTheme /*80*/:
                break;
            default:
                i3 = this.f625z & 112;
                break;
        }
        switch (i3) {
            case py.Theme_homeAsUpIndicator /*48*/:
                return getPaddingTop() - i2;
            case py.Theme_panelMenuListTheme /*80*/:
                return (((getHeight() - getPaddingBottom()) - measuredHeight) - zcVar.bottomMargin) - i2;
            default:
                int i4;
                i3 = getPaddingTop();
                int paddingBottom = getPaddingBottom();
                int height = getHeight();
                i2 = (((height - i3) - paddingBottom) - measuredHeight) / 2;
                if (i2 < zcVar.topMargin) {
                    i4 = zcVar.topMargin;
                } else {
                    measuredHeight = (((height - paddingBottom) - measuredHeight) - i2) - i3;
                    i4 = measuredHeight < zcVar.bottomMargin ? Math.max(0, i2 - (zcVar.bottomMargin - measuredHeight)) : i2;
                }
                return i4 + i3;
        }
    }

    private void m581a(List list, int i) {
        int i2 = 1;
        int i3 = 0;
        if (iv.m5931h(this) != 1) {
            i2 = 0;
        }
        int childCount = getChildCount();
        int a = gr.m5763a(i, iv.m5931h(this));
        list.clear();
        zc zcVar;
        if (i2 != 0) {
            for (i3 = childCount - 1; i3 >= 0; i3--) {
                View childAt = getChildAt(i3);
                zcVar = (zc) childAt.getLayoutParams();
                if (zcVar.f6638a == 0 && m582a(childAt) && m573a(zcVar.gravity) == a) {
                    list.add(childAt);
                }
            }
            return;
        }
        while (i3 < childCount) {
            View childAt2 = getChildAt(i3);
            zcVar = (zc) childAt2.getLayoutParams();
            if (zcVar.f6638a == 0 && m582a(childAt2) && m573a(zcVar.gravity) == a) {
                list.add(childAt2);
            }
            i3++;
        }
    }

    private int m573a(int i) {
        int h = iv.m5931h(this);
        int a = gr.m5763a(i, h) & 7;
        switch (a) {
            case ug.RecyclerView_layoutManager /*1*/:
            case ug.RecyclerView_reverseLayout /*3*/:
            case py.Toolbar_contentInsetStart /*5*/:
                return a;
            default:
                return h == 1 ? 5 : 3;
        }
    }

    private boolean m582a(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    private static int m583b(View view) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        return hk.m5794b(marginLayoutParams) + hk.m5792a(marginLayoutParams);
    }

    private static int m586c(View view) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.bottomMargin + marginLayoutParams.topMargin;
    }

    private static zc m577a(LayoutParams layoutParams) {
        if (layoutParams instanceof zc) {
            return new zc((zc) layoutParams);
        }
        if (layoutParams instanceof ActionBar.LayoutParams) {
            return new zc((ActionBar.LayoutParams) layoutParams);
        }
        if (layoutParams instanceof MarginLayoutParams) {
            return new zc((MarginLayoutParams) layoutParams);
        }
        return new zc(layoutParams);
    }

    public static zc m590e() {
        return new zc();
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof zc);
    }

    public tg getWrapper() {
        if (this.f596K == null) {
            this.f596K = new ua(this, true);
        }
        return this.f596K;
    }

    private boolean m589d(View view) {
        return view.getParent() == this || this.f609j.contains(view);
    }

    public void setCollapsible(boolean z) {
        this.f597L = z;
        requestLayout();
    }

    protected /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        return new zc();
    }

    public /* synthetic */ LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new zc(getContext(), attributeSet);
    }

    public static /* synthetic */ void m585b(Toolbar toolbar) {
        if (toolbar.f618s == null) {
            toolbar.f618s = new ImageButton(toolbar.getContext(), null, po.toolbarNavigationButtonStyle);
            toolbar.f618s.setImageDrawable(toolbar.f616q);
            toolbar.f618s.setContentDescription(toolbar.f617r);
            LayoutParams zcVar = new zc();
            zcVar.gravity = 8388611 | (toolbar.f619t & 112);
            zcVar.f6638a = 2;
            toolbar.f618s.setLayoutParams(zcVar);
            toolbar.f618s.setOnClickListener(new za(toolbar));
        }
    }
}
