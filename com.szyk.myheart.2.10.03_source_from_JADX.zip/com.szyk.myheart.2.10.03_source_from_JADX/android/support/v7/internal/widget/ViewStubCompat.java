package android.support.v7.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import happy.hacking.py;
import happy.hacking.ud;
import java.lang.ref.WeakReference;

public final class ViewStubCompat extends View {
    private int f468a;
    private int f469b;
    private WeakReference f470c;
    private LayoutInflater f471d;
    private ud f472e;

    public ViewStubCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ViewStubCompat(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f468a = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, py.ViewStubCompat, i, 0);
        this.f469b = obtainStyledAttributes.getResourceId(py.ViewStubCompat_android_inflatedId, -1);
        this.f468a = obtainStyledAttributes.getResourceId(py.ViewStubCompat_android_layout, 0);
        setId(obtainStyledAttributes.getResourceId(py.ViewStubCompat_android_id, -1));
        obtainStyledAttributes.recycle();
        setVisibility(8);
        setWillNotDraw(true);
    }

    public final int getInflatedId() {
        return this.f469b;
    }

    public final void setInflatedId(int i) {
        this.f469b = i;
    }

    public final int getLayoutResource() {
        return this.f468a;
    }

    public final void setLayoutResource(int i) {
        this.f468a = i;
    }

    public final void setLayoutInflater(LayoutInflater layoutInflater) {
        this.f471d = layoutInflater;
    }

    public final LayoutInflater getLayoutInflater() {
        return this.f471d;
    }

    protected final void onMeasure(int i, int i2) {
        setMeasuredDimension(0, 0);
    }

    public final void draw(Canvas canvas) {
    }

    protected final void dispatchDraw(Canvas canvas) {
    }

    public final void setVisibility(int i) {
        if (this.f470c != null) {
            View view = (View) this.f470c.get();
            if (view != null) {
                view.setVisibility(i);
                return;
            }
            throw new IllegalStateException("setVisibility called on un-referenced view");
        }
        super.setVisibility(i);
        if (i == 0 || i == 4) {
            m399a();
        }
    }

    public final View m399a() {
        ViewParent parent = getParent();
        if (parent == null || !(parent instanceof ViewGroup)) {
            throw new IllegalStateException("ViewStub must have a non-null ViewGroup viewParent");
        } else if (this.f468a != 0) {
            LayoutInflater layoutInflater;
            ViewGroup viewGroup = (ViewGroup) parent;
            if (this.f471d != null) {
                layoutInflater = this.f471d;
            } else {
                layoutInflater = LayoutInflater.from(getContext());
            }
            View inflate = layoutInflater.inflate(this.f468a, viewGroup, false);
            if (this.f469b != -1) {
                inflate.setId(this.f469b);
            }
            int indexOfChild = viewGroup.indexOfChild(this);
            viewGroup.removeViewInLayout(this);
            LayoutParams layoutParams = getLayoutParams();
            if (layoutParams != null) {
                viewGroup.addView(inflate, indexOfChild, layoutParams);
            } else {
                viewGroup.addView(inflate, indexOfChild);
            }
            this.f470c = new WeakReference(inflate);
            return inflate;
        } else {
            throw new IllegalArgumentException("ViewStub must have a valid layoutResource");
        }
    }

    public final void setOnInflateListener(ud udVar) {
        this.f472e = udVar;
    }
}
