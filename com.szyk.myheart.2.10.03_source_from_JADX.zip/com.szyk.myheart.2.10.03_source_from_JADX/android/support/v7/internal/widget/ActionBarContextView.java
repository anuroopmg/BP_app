package android.support.v7.internal.widget;

import android.content.Context;
import android.os.Build.VERSION;
import android.support.v7.widget.ActionMenuPresenter;
import android.support.v7.widget.ActionMenuView;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import happy.hacking.kt;
import happy.hacking.po;
import happy.hacking.pt;
import happy.hacking.pv;
import happy.hacking.py;
import happy.hacking.rn;
import happy.hacking.sk;
import happy.hacking.so;
import happy.hacking.tz;
import happy.hacking.ue;
import happy.hacking.uh;

public class ActionBarContextView extends sk {
    public View f408g;
    public boolean f409h;
    private CharSequence f410i;
    private CharSequence f411j;
    private View f412k;
    private LinearLayout f413l;
    private TextView f414m;
    private TextView f415n;
    private int f416o;
    private int f417p;
    private int f418q;

    public final /* bridge */ /* synthetic */ kt m356a(int i, long j) {
        return super.m353a(i, j);
    }

    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public /* bridge */ /* synthetic */ boolean onHoverEvent(MotionEvent motionEvent) {
        return super.onHoverEvent(motionEvent);
    }

    public /* bridge */ /* synthetic */ boolean onTouchEvent(MotionEvent motionEvent) {
        return super.onTouchEvent(motionEvent);
    }

    public /* bridge */ /* synthetic */ void setVisibility(int i) {
        super.setVisibility(i);
    }

    public ActionBarContextView(Context context) {
        this(context, null);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, po.actionModeStyle);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        tz a = tz.m7065a(context, attributeSet, py.ActionMode, i);
        setBackgroundDrawable(a.m7067a(py.ActionMode_background));
        this.f416o = a.m7076e(py.ActionMode_titleTextStyle, 0);
        this.f417p = a.m7076e(py.ActionMode_subtitleTextStyle, 0);
        this.e = a.m7075d(py.ActionMode_height, 0);
        this.f418q = a.m7076e(py.ActionMode_closeItemLayout, pv.abc_action_mode_close_item_material);
        a.f6280a.recycle();
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.d != null) {
            this.d.m440f();
            this.d.m442h();
        }
    }

    public void setContentHeight(int i) {
        this.e = i;
    }

    public void setCustomView(View view) {
        if (this.f412k != null) {
            removeView(this.f412k);
        }
        this.f412k = view;
        if (!(view == null || this.f413l == null)) {
            removeView(this.f413l);
            this.f413l = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setTitle(CharSequence charSequence) {
        this.f410i = charSequence;
        m355c();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f411j = charSequence;
        m355c();
    }

    public CharSequence getTitle() {
        return this.f410i;
    }

    public CharSequence getSubtitle() {
        return this.f411j;
    }

    private void m355c() {
        int i;
        int i2 = 8;
        Object obj = 1;
        if (this.f413l == null) {
            LayoutInflater.from(getContext()).inflate(pv.abc_action_bar_title_item, this);
            this.f413l = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f414m = (TextView) this.f413l.findViewById(pt.action_bar_title);
            this.f415n = (TextView) this.f413l.findViewById(pt.action_bar_subtitle);
            if (this.f416o != 0) {
                this.f414m.setTextAppearance(getContext(), this.f416o);
            }
            if (this.f417p != 0) {
                this.f415n.setTextAppearance(getContext(), this.f417p);
            }
        }
        this.f414m.setText(this.f410i);
        this.f415n.setText(this.f411j);
        Object obj2 = !TextUtils.isEmpty(this.f410i) ? 1 : null;
        if (TextUtils.isEmpty(this.f411j)) {
            obj = null;
        }
        TextView textView = this.f415n;
        if (obj != null) {
            i = 0;
        } else {
            i = 8;
        }
        textView.setVisibility(i);
        LinearLayout linearLayout = this.f413l;
        if (!(obj2 == null && obj == null)) {
            i2 = 0;
        }
        linearLayout.setVisibility(i2);
        if (this.f413l.getParent() == null) {
            addView(this.f413l);
        }
    }

    public final void m357a(uh uhVar) {
        if (this.f408g == null) {
            this.f408g = LayoutInflater.from(getContext()).inflate(this.f418q, this, false);
            addView(this.f408g);
        } else if (this.f408g.getParent() == null) {
            addView(this.f408g);
        }
        this.f408g.findViewById(pt.action_mode_close_button).setOnClickListener(new so(this, uhVar));
        rn rnVar = (rn) uhVar.m6812b();
        if (this.d != null) {
            this.d.m441g();
        }
        this.d = new ActionMenuPresenter(getContext());
        this.d.m438d();
        LayoutParams layoutParams = new LayoutParams(-2, -1);
        rnVar.m6096a(this.d, this.b);
        this.c = (ActionMenuView) this.d.m425a((ViewGroup) this);
        this.c.setBackgroundDrawable(null);
        addView(this.c, layoutParams);
    }

    public final void m359b() {
        removeAllViews();
        this.f412k = null;
        this.c = null;
    }

    public final boolean m358a() {
        if (this.d != null) {
            return this.d.m439e();
        }
        return false;
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new MarginLayoutParams(-1, -2);
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new MarginLayoutParams(getContext(), attributeSet);
    }

    protected void onMeasure(int i, int i2) {
        int i3 = 1073741824;
        int i4 = 0;
        if (MeasureSpec.getMode(i) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        } else if (MeasureSpec.getMode(i2) == 0) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        } else {
            int a;
            int size = MeasureSpec.getSize(i);
            int size2 = this.e > 0 ? this.e : MeasureSpec.getSize(i2);
            int paddingTop = getPaddingTop() + getPaddingBottom();
            int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
            int i5 = size2 - paddingTop;
            int makeMeasureSpec = MeasureSpec.makeMeasureSpec(i5, Integer.MIN_VALUE);
            if (this.f408g != null) {
                a = sk.m349a(this.f408g, paddingLeft, makeMeasureSpec);
                MarginLayoutParams marginLayoutParams = (MarginLayoutParams) this.f408g.getLayoutParams();
                paddingLeft = a - (marginLayoutParams.rightMargin + marginLayoutParams.leftMargin);
            }
            if (this.c != null && this.c.getParent() == this) {
                paddingLeft = sk.m349a(this.c, paddingLeft, makeMeasureSpec);
            }
            if (this.f413l != null && this.f412k == null) {
                if (this.f409h) {
                    this.f413l.measure(MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                    a = this.f413l.getMeasuredWidth();
                    makeMeasureSpec = a <= paddingLeft ? 1 : 0;
                    if (makeMeasureSpec != 0) {
                        paddingLeft -= a;
                    }
                    this.f413l.setVisibility(makeMeasureSpec != 0 ? 0 : 8);
                } else {
                    paddingLeft = sk.m349a(this.f413l, paddingLeft, makeMeasureSpec);
                }
            }
            if (this.f412k != null) {
                int min;
                LayoutParams layoutParams = this.f412k.getLayoutParams();
                if (layoutParams.width != -2) {
                    makeMeasureSpec = 1073741824;
                } else {
                    makeMeasureSpec = Integer.MIN_VALUE;
                }
                if (layoutParams.width >= 0) {
                    paddingLeft = Math.min(layoutParams.width, paddingLeft);
                }
                if (layoutParams.height == -2) {
                    i3 = Integer.MIN_VALUE;
                }
                if (layoutParams.height >= 0) {
                    min = Math.min(layoutParams.height, i5);
                } else {
                    min = i5;
                }
                this.f412k.measure(MeasureSpec.makeMeasureSpec(paddingLeft, makeMeasureSpec), MeasureSpec.makeMeasureSpec(min, i3));
            }
            if (this.e <= 0) {
                makeMeasureSpec = getChildCount();
                size2 = 0;
                while (i4 < makeMeasureSpec) {
                    paddingLeft = getChildAt(i4).getMeasuredHeight() + paddingTop;
                    if (paddingLeft <= size2) {
                        paddingLeft = size2;
                    }
                    i4++;
                    size2 = paddingLeft;
                }
                setMeasuredDimension(size, size2);
                return;
            }
            setMeasuredDimension(size, size2);
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        boolean a = ue.m7133a(this);
        int paddingRight = a ? (i3 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        if (!(this.f408g == null || this.f408g.getVisibility() == 8)) {
            MarginLayoutParams marginLayoutParams = (MarginLayoutParams) this.f408g.getLayoutParams();
            int i6 = a ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            i5 = a ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            paddingRight = sk.m348a(paddingRight, i6, a);
            paddingRight = sk.m348a(paddingRight + sk.m350a(this.f408g, paddingRight, paddingTop, paddingTop2, a), i5, a);
        }
        if (!(this.f413l == null || this.f412k != null || this.f413l.getVisibility() == 8)) {
            paddingRight += sk.m350a(this.f413l, paddingRight, paddingTop, paddingTop2, a);
        }
        if (this.f412k != null) {
            sk.m350a(this.f412k, paddingRight, paddingTop, paddingTop2, a);
        }
        i5 = a ? getPaddingLeft() : (i3 - i) - getPaddingRight();
        if (this.c != null) {
            sk.m350a(this.c, i5, paddingTop, paddingTop2, !a);
        }
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (VERSION.SDK_INT < 14) {
            return;
        }
        if (accessibilityEvent.getEventType() == 32) {
            accessibilityEvent.setSource(this);
            accessibilityEvent.setClassName(getClass().getName());
            accessibilityEvent.setPackageName(getContext().getPackageName());
            accessibilityEvent.setContentDescription(this.f410i);
            return;
        }
        super.onInitializeAccessibilityEvent(accessibilityEvent);
    }

    public void setTitleOptional(boolean z) {
        if (z != this.f409h) {
            requestLayout();
        }
        this.f409h = z;
    }
}
