package android.support.v7.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import happy.hacking.pt;
import happy.hacking.py;
import happy.hacking.sm;
import happy.hacking.sn;
import happy.hacking.tn;

public class ActionBarContainer extends FrameLayout {
    public Drawable f390a;
    public Drawable f391b;
    public Drawable f392c;
    public boolean f393d;
    public boolean f394e;
    private boolean f395f;
    private View f396g;
    private View f397h;
    private View f398i;
    private int f399j;

    public ActionBarContainer(Context context) {
        this(context, null);
    }

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        boolean z;
        Drawable snVar;
        super(context, attributeSet);
        if (VERSION.SDK_INT >= 21) {
            z = true;
        } else {
            z = false;
        }
        if (z) {
            snVar = new sn(this);
        } else {
            snVar = new sm(this);
        }
        setBackgroundDrawable(snVar);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, py.ActionBar);
        this.f390a = obtainStyledAttributes.getDrawable(py.ActionBar_background);
        this.f391b = obtainStyledAttributes.getDrawable(py.ActionBar_backgroundStacked);
        this.f399j = obtainStyledAttributes.getDimensionPixelSize(py.ActionBar_height, -1);
        if (getId() == pt.split_action_bar) {
            this.f393d = true;
            this.f392c = obtainStyledAttributes.getDrawable(py.ActionBar_backgroundSplit);
        }
        obtainStyledAttributes.recycle();
        z = this.f393d ? this.f392c == null : this.f390a == null && this.f391b == null;
        setWillNotDraw(z);
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.f397h = findViewById(pt.action_bar);
        this.f398i = findViewById(pt.action_context_bar);
    }

    public void setPrimaryBackground(Drawable drawable) {
        boolean z = true;
        if (this.f390a != null) {
            this.f390a.setCallback(null);
            unscheduleDrawable(this.f390a);
        }
        this.f390a = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f397h != null) {
                this.f390a.setBounds(this.f397h.getLeft(), this.f397h.getTop(), this.f397h.getRight(), this.f397h.getBottom());
            }
        }
        if (this.f393d) {
            if (this.f392c != null) {
                z = false;
            }
        } else if (!(this.f390a == null && this.f391b == null)) {
            z = false;
        }
        setWillNotDraw(z);
        invalidate();
    }

    public void setStackedBackground(Drawable drawable) {
        boolean z = true;
        if (this.f391b != null) {
            this.f391b.setCallback(null);
            unscheduleDrawable(this.f391b);
        }
        this.f391b = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f394e && this.f391b != null) {
                this.f391b.setBounds(this.f396g.getLeft(), this.f396g.getTop(), this.f396g.getRight(), this.f396g.getBottom());
            }
        }
        if (this.f393d) {
            if (this.f392c != null) {
                z = false;
            }
        } else if (!(this.f390a == null && this.f391b == null)) {
            z = false;
        }
        setWillNotDraw(z);
        invalidate();
    }

    public void setSplitBackground(Drawable drawable) {
        boolean z = true;
        if (this.f392c != null) {
            this.f392c.setCallback(null);
            unscheduleDrawable(this.f392c);
        }
        this.f392c = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f393d && this.f392c != null) {
                this.f392c.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (this.f393d) {
            if (this.f392c != null) {
                z = false;
            }
        } else if (!(this.f390a == null && this.f391b == null)) {
            z = false;
        }
        setWillNotDraw(z);
        invalidate();
    }

    public void setVisibility(int i) {
        boolean z;
        super.setVisibility(i);
        if (i == 0) {
            z = true;
        } else {
            z = false;
        }
        if (this.f390a != null) {
            this.f390a.setVisible(z, false);
        }
        if (this.f391b != null) {
            this.f391b.setVisible(z, false);
        }
        if (this.f392c != null) {
            this.f392c.setVisible(z, false);
        }
    }

    protected boolean verifyDrawable(Drawable drawable) {
        return (drawable == this.f390a && !this.f393d) || ((drawable == this.f391b && this.f394e) || ((drawable == this.f392c && this.f393d) || super.verifyDrawable(drawable)));
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f390a != null && this.f390a.isStateful()) {
            this.f390a.setState(getDrawableState());
        }
        if (this.f391b != null && this.f391b.isStateful()) {
            this.f391b.setState(getDrawableState());
        }
        if (this.f392c != null && this.f392c.isStateful()) {
            this.f392c.setState(getDrawableState());
        }
    }

    public void jumpDrawablesToCurrentState() {
        if (VERSION.SDK_INT >= 11) {
            super.jumpDrawablesToCurrentState();
            if (this.f390a != null) {
                this.f390a.jumpToCurrentState();
            }
            if (this.f391b != null) {
                this.f391b.jumpToCurrentState();
            }
            if (this.f392c != null) {
                this.f392c.jumpToCurrentState();
            }
        }
    }

    public void setTransitioning(boolean z) {
        this.f395f = z;
        setDescendantFocusability(z ? 393216 : 262144);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f395f || super.onInterceptTouchEvent(motionEvent);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setTabContainer(tn tnVar) {
        if (this.f396g != null) {
            removeView(this.f396g);
        }
        this.f396g = tnVar;
        if (tnVar != null) {
            addView(tnVar);
            LayoutParams layoutParams = tnVar.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            tnVar.setAllowCollapse(false);
        }
    }

    public View getTabContainer() {
        return this.f396g;
    }

    public ActionMode startActionModeForChild(View view, Callback callback) {
        return null;
    }

    private static boolean m346a(View view) {
        return view == null || view.getVisibility() == 8 || view.getMeasuredHeight() == 0;
    }

    private static int m347b(View view) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        return layoutParams.bottomMargin + (view.getMeasuredHeight() + layoutParams.topMargin);
    }

    public void onMeasure(int i, int i2) {
        if (this.f397h == null && MeasureSpec.getMode(i2) == Integer.MIN_VALUE && this.f399j >= 0) {
            i2 = MeasureSpec.makeMeasureSpec(Math.min(this.f399j, MeasureSpec.getSize(i2)), Integer.MIN_VALUE);
        }
        super.onMeasure(i, i2);
        if (this.f397h != null) {
            int mode = MeasureSpec.getMode(i2);
            if (this.f396g != null && this.f396g.getVisibility() != 8 && mode != 1073741824) {
                int b;
                if (!m346a(this.f397h)) {
                    b = m347b(this.f397h);
                } else if (m346a(this.f398i)) {
                    b = 0;
                } else {
                    b = m347b(this.f398i);
                }
                setMeasuredDimension(getMeasuredWidth(), Math.min(b + m347b(this.f396g), mode == Integer.MIN_VALUE ? MeasureSpec.getSize(i2) : Integer.MAX_VALUE));
            }
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5 = 1;
        super.onLayout(z, i, i2, i3, i4);
        View view = this.f396g;
        boolean z2 = (view == null || view.getVisibility() == 8) ? false : true;
        if (!(view == null || view.getVisibility() == 8)) {
            int measuredHeight = getMeasuredHeight();
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
            view.layout(i, (measuredHeight - view.getMeasuredHeight()) - layoutParams.bottomMargin, i3, measuredHeight - layoutParams.bottomMargin);
        }
        if (!this.f393d) {
            int i6;
            if (this.f390a != null) {
                if (this.f397h.getVisibility() == 0) {
                    this.f390a.setBounds(this.f397h.getLeft(), this.f397h.getTop(), this.f397h.getRight(), this.f397h.getBottom());
                } else if (this.f398i == null || this.f398i.getVisibility() != 0) {
                    this.f390a.setBounds(0, 0, 0, 0);
                } else {
                    this.f390a.setBounds(this.f398i.getLeft(), this.f398i.getTop(), this.f398i.getRight(), this.f398i.getBottom());
                }
                i6 = 1;
            } else {
                i6 = 0;
            }
            this.f394e = z2;
            if (!z2 || this.f391b == null) {
                i5 = i6;
            } else {
                this.f391b.setBounds(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            }
        } else if (this.f392c != null) {
            this.f392c.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
        } else {
            i5 = 0;
        }
        if (i5 != 0) {
            invalidate();
        }
    }
}
