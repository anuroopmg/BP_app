package android.support.v7.internal.widget;

import android.content.Context;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupWindow.OnDismissListener;
import happy.hacking.go;
import happy.hacking.pw;
import happy.hacking.su;
import happy.hacking.ta;
import happy.hacking.tb;
import happy.hacking.tz;
import happy.hacking.wp;
import happy.hacking.wv;

public final class ActivityChooserView extends ViewGroup {
    public go f448a;
    private final ta f449b;
    private final tb f450c;
    private final wp f451d;
    private final FrameLayout f452e;
    private final ImageView f453f;
    private final FrameLayout f454g;
    private final int f455h;
    private final DataSetObserver f456i;
    private final OnGlobalLayoutListener f457j;
    private wv f458k;
    private OnDismissListener f459l;
    private boolean f460m;
    private int f461n;
    private boolean f462o;
    private int f463p;

    public class InnerLayout extends wp {
        private static final int[] f447a;

        static {
            f447a = new int[]{16842964};
        }

        public InnerLayout(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            tz a = tz.m7064a(context, attributeSet, f447a);
            setBackgroundDrawable(a.m7067a(0));
            a.f6280a.recycle();
        }
    }

    public final void setActivityChooserModel(su suVar) {
        ta taVar = this.f449b;
        su suVar2 = taVar.f6197c.f449b.f6195a;
        if (suVar2 != null && taVar.f6197c.isShown()) {
            suVar2.unregisterObserver(taVar.f6197c.f456i);
        }
        taVar.f6195a = suVar;
        if (suVar != null && taVar.f6197c.isShown()) {
            suVar.registerObserver(taVar.f6197c.f456i);
        }
        taVar.notifyDataSetChanged();
        if (getListPopupWindow().f6410c.isShowing()) {
            m397a();
            if (!getListPopupWindow().f6410c.isShowing() && this.f462o) {
                this.f460m = false;
                m388a(this.f461n);
            }
        }
    }

    public final void setExpandActivityOverflowButtonDrawable(Drawable drawable) {
        this.f453f.setImageDrawable(drawable);
    }

    public final void setExpandActivityOverflowButtonContentDescription(int i) {
        this.f453f.setContentDescription(getContext().getString(i));
    }

    public final void setProvider(go goVar) {
        this.f448a = goVar;
    }

    private void m388a(int i) {
        if (this.f449b.f6195a == null) {
            throw new IllegalStateException("No data model. Did you call #setDataModel?");
        }
        getViewTreeObserver().addOnGlobalLayoutListener(this.f457j);
        boolean z = this.f454g.getVisibility() == 0;
        int a = this.f449b.f6195a.m6975a();
        int i2;
        if (z) {
            i2 = 1;
        } else {
            i2 = 0;
        }
        if (i == Integer.MAX_VALUE || a <= r3 + i) {
            this.f449b.m6986a(false);
            this.f449b.m6985a(i);
        } else {
            this.f449b.m6986a(true);
            this.f449b.m6985a(i - 1);
        }
        wv listPopupWindow = getListPopupWindow();
        if (!listPopupWindow.f6410c.isShowing()) {
            if (this.f460m || !z) {
                this.f449b.m6987a(true, z);
            } else {
                this.f449b.m6987a(false, false);
            }
            listPopupWindow.m7200a(Math.min(this.f449b.m6984a(), this.f455h));
            listPopupWindow.m7204b();
            if (this.f448a != null) {
                this.f448a.m5757a(true);
            }
            listPopupWindow.f6411d.setContentDescription(getContext().getString(pw.abc_activitychooserview_choose_application));
        }
    }

    private boolean m391b() {
        return getListPopupWindow().f6410c.isShowing();
    }

    protected final void onAttachedToWindow() {
        super.onAttachedToWindow();
        su suVar = this.f449b.f6195a;
        if (suVar != null) {
            suVar.registerObserver(this.f456i);
        }
        this.f462o = true;
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        su suVar = this.f449b.f6195a;
        if (suVar != null) {
            suVar.unregisterObserver(this.f456i);
        }
        ViewTreeObserver viewTreeObserver = getViewTreeObserver();
        if (viewTreeObserver.isAlive()) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f457j);
        }
        if (m391b()) {
            m397a();
        }
        this.f462o = false;
    }

    protected final void onMeasure(int i, int i2) {
        View view = this.f451d;
        if (this.f454g.getVisibility() != 0) {
            i2 = MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(i2), 1073741824);
        }
        measureChild(view, i, i2);
        setMeasuredDimension(view.getMeasuredWidth(), view.getMeasuredHeight());
    }

    protected final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.f451d.layout(0, 0, i3 - i, i4 - i2);
        if (!m391b()) {
            m397a();
        }
    }

    public final su getDataModel() {
        return this.f449b.f6195a;
    }

    public final void setOnDismissListener(OnDismissListener onDismissListener) {
        this.f459l = onDismissListener;
    }

    public final void setInitialActivityCount(int i) {
        this.f461n = i;
    }

    public final void setDefaultActionButtonContentDescription(int i) {
        this.f463p = i;
    }

    private wv getListPopupWindow() {
        if (this.f458k == null) {
            this.f458k = new wv(getContext());
            this.f458k.m7202a(this.f449b);
            this.f458k.f6419l = this;
            this.f458k.m7205c();
            this.f458k.f6420m = this.f450c;
            this.f458k.m7203a(this.f450c);
        }
        return this.f458k;
    }

    public final boolean m397a() {
        if (getListPopupWindow().f6410c.isShowing()) {
            getListPopupWindow().m7206d();
            ViewTreeObserver viewTreeObserver = getViewTreeObserver();
            if (viewTreeObserver.isAlive()) {
                viewTreeObserver.removeGlobalOnLayoutListener(this.f457j);
            }
        }
        return true;
    }
}
