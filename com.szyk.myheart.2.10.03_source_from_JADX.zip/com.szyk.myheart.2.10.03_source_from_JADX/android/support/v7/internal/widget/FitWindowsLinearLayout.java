package android.support.v7.internal.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import happy.hacking.th;
import happy.hacking.ti;

public class FitWindowsLinearLayout extends LinearLayout implements th {
    private ti f467a;

    public FitWindowsLinearLayout(Context context) {
        super(context);
    }

    public FitWindowsLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public void setOnFitSystemWindowsListener(ti tiVar) {
        this.f467a = tiVar;
    }

    protected boolean fitSystemWindows(Rect rect) {
        if (this.f467a != null) {
            this.f467a.onFitSystemWindows(rect);
        }
        return super.fitSystemWindows(rect);
    }
}
