package android.support.v7.internal.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v4.app.NotificationCompat;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window.Callback;
import happy.hacking.ic;
import happy.hacking.id;
import happy.hacking.iv;
import happy.hacking.kt;
import happy.hacking.lj;
import happy.hacking.ow;
import happy.hacking.po;
import happy.hacking.pt;
import happy.hacking.py;
import happy.hacking.sd;
import happy.hacking.sp;
import happy.hacking.sq;
import happy.hacking.sr;
import happy.hacking.ss;
import happy.hacking.st;
import happy.hacking.tf;
import happy.hacking.tg;
import happy.hacking.ue;
import happy.hacking.ug;

public class ActionBarOverlayLayout extends ViewGroup implements ic, tf {
    static final int[] f419c;
    private final Runnable f420A;
    private final id f421B;
    public boolean f422a;
    public boolean f423b;
    private int f424d;
    private int f425e;
    private ContentFrameLayout f426f;
    private ActionBarContainer f427g;
    private tg f428h;
    private Drawable f429i;
    private boolean f430j;
    private boolean f431k;
    private boolean f432l;
    private int f433m;
    private int f434n;
    private final Rect f435o;
    private final Rect f436p;
    private final Rect f437q;
    private final Rect f438r;
    private final Rect f439s;
    private final Rect f440t;
    private ss f441u;
    private final int f442v;
    private ow f443w;
    private kt f444x;
    private final lj f445y;
    private final Runnable f446z;

    static {
        f419c = new int[]{po.actionBarSize, 16842841};
    }

    public ActionBarOverlayLayout(Context context) {
        this(context, null);
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f425e = 0;
        this.f435o = new Rect();
        this.f436p = new Rect();
        this.f437q = new Rect();
        this.f438r = new Rect();
        this.f439s = new Rect();
        this.f440t = new Rect();
        this.f442v = 600;
        this.f445y = new sp(this);
        this.f446z = new sq(this);
        this.f420A = new sr(this);
        m370a(context);
        this.f421B = new id(this);
    }

    private void m370a(Context context) {
        boolean z = true;
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f419c);
        this.f424d = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        this.f429i = obtainStyledAttributes.getDrawable(1);
        setWillNotDraw(this.f429i == null);
        obtainStyledAttributes.recycle();
        if (context.getApplicationInfo().targetSdkVersion >= 19) {
            z = false;
        }
        this.f430j = z;
        this.f443w = ow.m6672a(context, null);
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        m377i();
    }

    public void setActionBarVisibilityCallback(ss ssVar) {
        this.f441u = ssVar;
        if (getWindowToken() != null) {
            this.f441u.m6778a(this.f425e);
            if (this.f434n != 0) {
                onWindowSystemUiVisibilityChanged(this.f434n);
                iv.m5947x(this);
            }
        }
    }

    public void setOverlayMode(boolean z) {
        this.f422a = z;
        boolean z2 = z && getContext().getApplicationInfo().targetSdkVersion < 19;
        this.f430j = z2;
    }

    public void setHasNonEmbeddedTabs(boolean z) {
        this.f431k = z;
    }

    public void setShowingForActionMode(boolean z) {
    }

    protected void onConfigurationChanged(Configuration configuration) {
        if (VERSION.SDK_INT >= 8) {
            super.onConfigurationChanged(configuration);
        }
        m370a(getContext());
        iv.m5947x(this);
    }

    public void onWindowSystemUiVisibilityChanged(int i) {
        boolean z;
        boolean z2 = true;
        if (VERSION.SDK_INT >= 16) {
            super.onWindowSystemUiVisibilityChanged(i);
        }
        m376h();
        int i2 = this.f434n ^ i;
        this.f434n = i;
        boolean z3 = (i & 4) == 0;
        if ((i & NotificationCompat.FLAG_LOCAL_ONLY) != 0) {
            z = true;
        } else {
            z = false;
        }
        if (this.f441u != null) {
            ss ssVar = this.f441u;
            if (z) {
                z2 = false;
            }
            ssVar.m6779a(z2);
            if (z3 || !z) {
                this.f441u.m6777a();
            } else {
                this.f441u.m6780b();
            }
        }
        if ((i2 & NotificationCompat.FLAG_LOCAL_ONLY) != 0 && this.f441u != null) {
            iv.m5947x(this);
        }
    }

    protected void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.f425e = i;
        if (this.f441u != null) {
            this.f441u.m6778a(i);
        }
    }

    private static boolean m372a(View view, Rect rect, boolean z) {
        boolean z2 = false;
        st stVar = (st) view.getLayoutParams();
        if (stVar.leftMargin != rect.left) {
            stVar.leftMargin = rect.left;
            z2 = true;
        }
        if (stVar.topMargin != rect.top) {
            stVar.topMargin = rect.top;
            z2 = true;
        }
        if (stVar.rightMargin != rect.right) {
            stVar.rightMargin = rect.right;
            z2 = true;
        }
        if (!z || stVar.bottomMargin == rect.bottom) {
            return z2;
        }
        stVar.bottomMargin = rect.bottom;
        return true;
    }

    protected boolean fitSystemWindows(Rect rect) {
        m376h();
        iv.m5946w(this);
        boolean a = m372a(this.f427g, rect, false);
        this.f438r.set(rect);
        ue.m7132a(this, this.f438r, this.f435o);
        if (!this.f436p.equals(this.f435o)) {
            this.f436p.set(this.f435o);
            a = true;
        }
        if (a) {
            requestLayout();
        }
        return true;
    }

    protected LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return new st(layoutParams);
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof st;
    }

    protected void onMeasure(int i, int i2) {
        int i3;
        m376h();
        measureChildWithMargins(this.f427g, i, 0, i2, 0);
        st stVar = (st) this.f427g.getLayoutParams();
        int max = Math.max(0, (this.f427g.getMeasuredWidth() + stVar.leftMargin) + stVar.rightMargin);
        int max2 = Math.max(0, stVar.bottomMargin + (this.f427g.getMeasuredHeight() + stVar.topMargin));
        int a = ue.m7131a(0, iv.m5936m(this.f427g));
        boolean z = (iv.m5946w(this) & NotificationCompat.FLAG_LOCAL_ONLY) != 0;
        if (z) {
            i3 = this.f424d;
            if (this.f431k && this.f427g.getTabContainer() != null) {
                i3 += this.f424d;
            }
        } else {
            i3 = this.f427g.getVisibility() != 8 ? this.f427g.getMeasuredHeight() : 0;
        }
        this.f437q.set(this.f435o);
        this.f439s.set(this.f438r);
        Rect rect;
        Rect rect2;
        if (this.f422a || z) {
            rect = this.f439s;
            rect.top = i3 + rect.top;
            rect2 = this.f439s;
            rect2.bottom += 0;
        } else {
            rect = this.f437q;
            rect.top = i3 + rect.top;
            rect2 = this.f437q;
            rect2.bottom += 0;
        }
        m372a(this.f426f, this.f437q, true);
        if (!this.f440t.equals(this.f439s)) {
            this.f440t.set(this.f439s);
            this.f426f.dispatchFitSystemWindows(this.f439s);
        }
        measureChildWithMargins(this.f426f, i, 0, i2, 0);
        stVar = (st) this.f426f.getLayoutParams();
        int max3 = Math.max(max, (this.f426f.getMeasuredWidth() + stVar.leftMargin) + stVar.rightMargin);
        i3 = Math.max(max2, stVar.bottomMargin + (this.f426f.getMeasuredHeight() + stVar.topMargin));
        int a2 = ue.m7131a(a, iv.m5936m(this.f426f));
        setMeasuredDimension(iv.m5900a(Math.max(max3 + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), i, a2), iv.m5900a(Math.max(i3 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i2, a2 << 16));
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        getPaddingRight();
        int paddingTop = getPaddingTop();
        getPaddingBottom();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                st stVar = (st) childAt.getLayoutParams();
                int i6 = stVar.leftMargin + paddingLeft;
                int i7 = stVar.topMargin + paddingTop;
                childAt.layout(i6, i7, childAt.getMeasuredWidth() + i6, childAt.getMeasuredHeight() + i7);
            }
        }
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f429i != null && !this.f430j) {
            int bottom = this.f427g.getVisibility() == 0 ? (int) ((((float) this.f427g.getBottom()) + iv.m5941r(this.f427g)) + 0.5f) : 0;
            this.f429i.setBounds(0, bottom, getWidth(), this.f429i.getIntrinsicHeight() + bottom);
            this.f429i.draw(canvas);
        }
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) == 0 || this.f427g.getVisibility() != 0) {
            return false;
        }
        return this.f423b;
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.f421B.f5676a = i;
        this.f433m = getActionBarHideOffset();
        m377i();
        if (this.f441u != null) {
            this.f441u.m6781c();
        }
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        this.f433m += i2;
        setActionBarHideOffset(this.f433m);
    }

    public void onStopNestedScroll(View view) {
        if (this.f423b && !this.f432l) {
            if (this.f433m <= this.f427g.getHeight()) {
                m377i();
                postDelayed(this.f446z, 600);
                return;
            }
            m377i();
            postDelayed(this.f420A, 600);
        }
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        boolean z2 = false;
        if (!this.f423b || !z) {
            return false;
        }
        this.f443w.m6674a(0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f443w.m6680e() > this.f427g.getHeight()) {
            z2 = true;
        }
        if (z2) {
            m377i();
            this.f420A.run();
        } else {
            m377i();
            this.f446z.run();
        }
        this.f432l = true;
        return true;
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    public int getNestedScrollAxes() {
        return this.f421B.f5676a;
    }

    private void m376h() {
        if (this.f426f == null) {
            tg tgVar;
            this.f426f = (ContentFrameLayout) findViewById(pt.action_bar_activity_content);
            this.f427g = (ActionBarContainer) findViewById(pt.action_bar_container);
            View findViewById = findViewById(pt.action_bar);
            if (findViewById instanceof tg) {
                tgVar = (tg) findViewById;
            } else if (findViewById instanceof Toolbar) {
                tgVar = ((Toolbar) findViewById).getWrapper();
            } else {
                throw new IllegalStateException("Can't make a decor toolbar out of " + findViewById.getClass().getSimpleName());
            }
            this.f428h = tgVar;
        }
    }

    public void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.f423b) {
            this.f423b = z;
            if (!z) {
                m377i();
                setActionBarHideOffset(0);
            }
        }
    }

    public int getActionBarHideOffset() {
        return this.f427g != null ? -((int) iv.m5941r(this.f427g)) : 0;
    }

    public void setActionBarHideOffset(int i) {
        m377i();
        iv.m5915b(this.f427g, (float) (-Math.max(0, Math.min(i, this.f427g.getHeight()))));
    }

    private void m377i() {
        removeCallbacks(this.f446z);
        removeCallbacks(this.f420A);
        if (this.f444x != null) {
            this.f444x.m6234a();
        }
    }

    public void setWindowCallback(Callback callback) {
        m376h();
        this.f428h.m6994a(callback);
    }

    public void setWindowTitle(CharSequence charSequence) {
        m376h();
        this.f428h.m6998a(charSequence);
    }

    public CharSequence getTitle() {
        m376h();
        return this.f428h.m7012e();
    }

    public final void m378a(int i) {
        m376h();
        switch (i) {
            case ug.RecyclerView_spanCount /*2*/:
                this.f428h.m7016g();
            case py.Toolbar_contentInsetStart /*5*/:
                this.f428h.m7018h();
            case py.Theme_switchStyle /*109*/:
                setOverlayMode(true);
            default:
        }
    }

    public void setUiOptions(int i) {
    }

    public void setIcon(int i) {
        m376h();
        this.f428h.m6990a(i);
    }

    public void setIcon(Drawable drawable) {
        m376h();
        this.f428h.m6991a(drawable);
    }

    public void setLogo(int i) {
        m376h();
        this.f428h.m7001b(i);
    }

    public final boolean m380a() {
        m376h();
        return this.f428h.m7020i();
    }

    public final boolean m381b() {
        m376h();
        return this.f428h.m7021j();
    }

    public final boolean m382c() {
        m376h();
        return this.f428h.m7022k();
    }

    public final boolean m383d() {
        m376h();
        return this.f428h.m7023l();
    }

    public final boolean m384e() {
        m376h();
        return this.f428h.m7024m();
    }

    public final void m385f() {
        m376h();
        this.f428h.m7025n();
    }

    public final void m379a(Menu menu, sd sdVar) {
        m376h();
        this.f428h.m6992a(menu, sdVar);
    }

    public final void m386g() {
        m376h();
        this.f428h.m7026o();
    }

    protected /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        return new st();
    }

    public /* synthetic */ LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new st(getContext(), attributeSet);
    }
}
