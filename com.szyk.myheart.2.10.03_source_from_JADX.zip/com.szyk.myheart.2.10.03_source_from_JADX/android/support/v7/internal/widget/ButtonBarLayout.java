package android.support.v7.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.widget.LinearLayout;
import happy.hacking.pt;
import happy.hacking.py;

public class ButtonBarLayout extends LinearLayout {
    private boolean f464a;
    private int f465b;

    public ButtonBarLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f465b = -1;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, py.ButtonBarLayout);
        this.f464a = obtainStyledAttributes.getBoolean(py.ButtonBarLayout_allowStacking, false);
        obtainStyledAttributes.recycle();
    }

    public void setAllowStacking(boolean z) {
        if (this.f464a != z) {
            this.f464a = z;
            if (!this.f464a && getOrientation() == 1) {
                setStacked(false);
            }
            requestLayout();
        }
    }

    protected void onMeasure(int i, int i2) {
        boolean z = false;
        int size = MeasureSpec.getSize(i);
        if (this.f464a) {
            if (size > this.f465b && m398a()) {
                setStacked(false);
            }
            this.f465b = size;
        }
        if (m398a() || MeasureSpec.getMode(i) != 1073741824) {
            size = i;
        } else {
            size = MeasureSpec.makeMeasureSpec(size, Integer.MIN_VALUE);
            z = true;
        }
        super.onMeasure(size, i2);
        if (this.f464a && !m398a() && (getMeasuredWidthAndState() & -16777216) == 16777216) {
            setStacked(true);
            z = true;
        }
        if (z) {
            super.onMeasure(i, i2);
        }
    }

    private void setStacked(boolean z) {
        setOrientation(z ? 1 : 0);
        setGravity(z ? 5 : 80);
        View findViewById = findViewById(pt.spacer);
        if (findViewById != null) {
            findViewById.setVisibility(z ? 8 : 4);
        }
        for (int childCount = getChildCount() - 2; childCount >= 0; childCount--) {
            bringChildToFront(getChildAt(childCount));
        }
    }

    private boolean m398a() {
        return getOrientation() == 1;
    }
}
