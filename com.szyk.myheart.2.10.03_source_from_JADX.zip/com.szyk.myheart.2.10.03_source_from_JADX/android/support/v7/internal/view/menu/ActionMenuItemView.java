package android.support.v7.internal.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.Toast;
import happy.hacking.iv;
import happy.hacking.pp;
import happy.hacking.py;
import happy.hacking.rg;
import happy.hacking.rh;
import happy.hacking.rp;
import happy.hacking.rr;
import happy.hacking.sf;
import happy.hacking.us;
import happy.hacking.vz;
import happy.hacking.wz;

public class ActionMenuItemView extends vz implements OnClickListener, OnLongClickListener, sf, us {
    private rr f362a;
    private CharSequence f363b;
    private Drawable f364c;
    private rp f365d;
    private wz f366e;
    private rh f367f;
    private boolean f368g;
    private boolean f369h;
    private int f370i;
    private int f371j;
    private int f372k;

    public ActionMenuItemView(Context context) {
        this(context, null);
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Resources resources = context.getResources();
        this.f368g = resources.getBoolean(pp.abc_config_allowActionMenuItemTextWithIcon);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, py.ActionMenuItemView, i, 0);
        this.f370i = obtainStyledAttributes.getDimensionPixelSize(py.ActionMenuItemView_android_minWidth, 0);
        obtainStyledAttributes.recycle();
        this.f372k = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        setOnLongClickListener(this);
        this.f371j = -1;
    }

    public void onConfigurationChanged(Configuration configuration) {
        if (VERSION.SDK_INT >= 8) {
            super.onConfigurationChanged(configuration);
        }
        this.f368g = getContext().getResources().getBoolean(pp.abc_config_allowActionMenuItemTextWithIcon);
        m333e();
    }

    public void setPadding(int i, int i2, int i3, int i4) {
        this.f371j = i;
        super.setPadding(i, i2, i3, i4);
    }

    public rr getItemData() {
        return this.f362a;
    }

    public final void m334a(rr rrVar) {
        this.f362a = rrVar;
        setIcon(rrVar.getIcon());
        setTitle(rrVar.m6909a((sf) this));
        setId(rrVar.getItemId());
        setVisibility(rrVar.isVisible() ? 0 : 8);
        setEnabled(rrVar.isEnabled());
        if (rrVar.hasSubMenu() && this.f366e == null) {
            this.f366e = new rg(this);
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.f362a.hasSubMenu() && this.f366e != null && this.f366e.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void onClick(View view) {
        if (this.f365d != null) {
            this.f365d.m339a(this.f362a);
        }
    }

    public void setItemInvoker(rp rpVar) {
        this.f365d = rpVar;
    }

    public void setPopupCallback(rh rhVar) {
        this.f367f = rhVar;
    }

    public final boolean m335a() {
        return true;
    }

    public void setCheckable(boolean z) {
    }

    public void setChecked(boolean z) {
    }

    public void setExpandedFormat(boolean z) {
        if (this.f369h != z) {
            this.f369h = z;
            if (this.f362a != null) {
                this.f362a.f6110b.m6113g();
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m333e() {
        /*
        r5 = this;
        r1 = 1;
        r2 = 0;
        r0 = r5.f363b;
        r0 = android.text.TextUtils.isEmpty(r0);
        if (r0 != 0) goto L_0x002d;
    L_0x000a:
        r0 = r1;
    L_0x000b:
        r3 = r5.f364c;
        if (r3 == 0) goto L_0x0023;
    L_0x000f:
        r3 = r5.f362a;
        r3 = r3.f6111c;
        r3 = r3 & 4;
        r4 = 4;
        if (r3 != r4) goto L_0x002f;
    L_0x0018:
        r3 = r1;
    L_0x0019:
        if (r3 == 0) goto L_0x0024;
    L_0x001b:
        r3 = r5.f368g;
        if (r3 != 0) goto L_0x0023;
    L_0x001f:
        r3 = r5.f369h;
        if (r3 == 0) goto L_0x0024;
    L_0x0023:
        r2 = r1;
    L_0x0024:
        r0 = r0 & r2;
        if (r0 == 0) goto L_0x0031;
    L_0x0027:
        r0 = r5.f363b;
    L_0x0029:
        r5.setText(r0);
        return;
    L_0x002d:
        r0 = r2;
        goto L_0x000b;
    L_0x002f:
        r3 = r2;
        goto L_0x0019;
    L_0x0031:
        r0 = 0;
        goto L_0x0029;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.internal.view.menu.ActionMenuItemView.e():void");
    }

    public void setIcon(Drawable drawable) {
        this.f364c = drawable;
        if (drawable != null) {
            float f;
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            if (intrinsicWidth > this.f372k) {
                f = ((float) this.f372k) / ((float) intrinsicWidth);
                intrinsicWidth = this.f372k;
                intrinsicHeight = (int) (((float) intrinsicHeight) * f);
            }
            if (intrinsicHeight > this.f372k) {
                f = ((float) this.f372k) / ((float) intrinsicHeight);
                intrinsicHeight = this.f372k;
                intrinsicWidth = (int) (((float) intrinsicWidth) * f);
            }
            drawable.setBounds(0, 0, intrinsicWidth, intrinsicHeight);
        }
        setCompoundDrawables(drawable, null, null, null);
        m333e();
    }

    public final boolean m336b() {
        return !TextUtils.isEmpty(getText());
    }

    public void setTitle(CharSequence charSequence) {
        this.f363b = charSequence;
        setContentDescription(this.f363b);
        m333e();
    }

    public final boolean m337c() {
        return m336b() && this.f362a.getIcon() == null;
    }

    public final boolean m338d() {
        return m336b();
    }

    public boolean onLongClick(View view) {
        if (m336b()) {
            return false;
        }
        int[] iArr = new int[2];
        Rect rect = new Rect();
        getLocationOnScreen(iArr);
        getWindowVisibleDisplayFrame(rect);
        Context context = getContext();
        int width = getWidth();
        int height = getHeight();
        int i = iArr[1] + (height / 2);
        width = (width / 2) + iArr[0];
        if (iv.m5931h(view) == 0) {
            width = context.getResources().getDisplayMetrics().widthPixels - width;
        }
        Toast makeText = Toast.makeText(context, this.f362a.getTitle(), 0);
        if (i < rect.height()) {
            makeText.setGravity(8388661, width, (iArr[1] + height) - rect.top);
        } else {
            makeText.setGravity(81, 0, height);
        }
        makeText.show();
        return true;
    }

    protected void onMeasure(int i, int i2) {
        boolean b = m336b();
        if (b && this.f371j >= 0) {
            super.setPadding(this.f371j, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i, i2);
        int mode = MeasureSpec.getMode(i);
        int size = MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        size = mode == Integer.MIN_VALUE ? Math.min(size, this.f370i) : this.f370i;
        if (mode != 1073741824 && this.f370i > 0 && measuredWidth < size) {
            super.onMeasure(MeasureSpec.makeMeasureSpec(size, 1073741824), i2);
        }
        if (!b && this.f364c != null) {
            super.setPadding((getMeasuredWidth() - this.f364c.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
    }
}
