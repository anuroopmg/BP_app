package android.support.v7.internal.view.menu;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import happy.hacking.rn;
import happy.hacking.rp;
import happy.hacking.rr;
import happy.hacking.se;
import happy.hacking.tz;

public final class ExpandedMenuView extends ListView implements OnItemClickListener, rp, se {
    private static final int[] f373a;
    private rn f374b;
    private int f375c;

    static {
        f373a = new int[]{16842964, 16843049};
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842868);
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        tz a = tz.m7065a(context, attributeSet, f373a, i);
        if (a.m7077e(0)) {
            setBackgroundDrawable(a.m7067a(0));
        }
        if (a.m7077e(1)) {
            setDivider(a.m7067a(1));
        }
        a.f6280a.recycle();
    }

    public final void m340a(rn rnVar) {
        this.f374b = rnVar;
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    public final boolean m341a(rr rrVar) {
        return this.f374b.m6099a((MenuItem) rrVar, null, 0);
    }

    public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
        m341a((rr) getAdapter().getItem(i));
    }

    public final int getWindowAnimations() {
        return this.f375c;
    }
}
