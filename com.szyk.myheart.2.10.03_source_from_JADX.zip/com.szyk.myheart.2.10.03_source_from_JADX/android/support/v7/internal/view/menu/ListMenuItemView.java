package android.support.v7.internal.view.menu;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewGroup.LayoutParams;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import happy.hacking.pt;
import happy.hacking.pv;
import happy.hacking.py;
import happy.hacking.rr;
import happy.hacking.sf;

public class ListMenuItemView extends LinearLayout implements sf {
    private rr f376a;
    private ImageView f377b;
    private RadioButton f378c;
    private TextView f379d;
    private CheckBox f380e;
    private TextView f381f;
    private Drawable f382g;
    private int f383h;
    private Context f384i;
    private boolean f385j;
    private int f386k;
    private Context f387l;
    private LayoutInflater f388m;
    private boolean f389n;

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        this.f387l = context;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, py.MenuView, i, 0);
        this.f382g = obtainStyledAttributes.getDrawable(py.MenuView_android_itemBackground);
        this.f383h = obtainStyledAttributes.getResourceId(py.MenuView_android_itemTextAppearance, -1);
        this.f385j = obtainStyledAttributes.getBoolean(py.MenuView_preserveIconSpacing, false);
        this.f384i = context;
        obtainStyledAttributes.recycle();
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        setBackgroundDrawable(this.f382g);
        this.f379d = (TextView) findViewById(pt.title);
        if (this.f383h != -1) {
            this.f379d.setTextAppearance(this.f384i, this.f383h);
        }
        this.f381f = (TextView) findViewById(pt.shortcut);
    }

    public final void m344a(rr rrVar) {
        int i = 0;
        this.f376a = rrVar;
        this.f386k = 0;
        setVisibility(rrVar.isVisible() ? 0 : 8);
        setTitle(rrVar.m6909a((sf) this));
        setCheckable(rrVar.isCheckable());
        boolean d = rrVar.m6917d();
        rrVar.m6914c();
        if (!(d && this.f376a.m6917d())) {
            i = 8;
        }
        if (i == 0) {
            CharSequence charSequence;
            TextView textView = this.f381f;
            char c = this.f376a.m6914c();
            if (c == '\u0000') {
                charSequence = "";
            } else {
                StringBuilder stringBuilder = new StringBuilder(rr.f6105f);
                switch (c) {
                    case py.Toolbar_contentInsetRight /*8*/:
                        stringBuilder.append(rr.f6107h);
                        break;
                    case py.Toolbar_titleTextAppearance /*10*/:
                        stringBuilder.append(rr.f6106g);
                        break;
                    case py.Theme_actionModeCutDrawable /*32*/:
                        stringBuilder.append(rr.f6108i);
                        break;
                    default:
                        stringBuilder.append(c);
                        break;
                }
                charSequence = stringBuilder.toString();
            }
            textView.setText(charSequence);
        }
        if (this.f381f.getVisibility() != i) {
            this.f381f.setVisibility(i);
        }
        setIcon(rrVar.getIcon());
        setEnabled(rrVar.isEnabled());
    }

    public void setForceShowIcon(boolean z) {
        this.f389n = z;
        this.f385j = z;
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence != null) {
            this.f379d.setText(charSequence);
            if (this.f379d.getVisibility() != 0) {
                this.f379d.setVisibility(0);
            }
        } else if (this.f379d.getVisibility() != 8) {
            this.f379d.setVisibility(8);
        }
    }

    public rr getItemData() {
        return this.f376a;
    }

    public void setCheckable(boolean z) {
        if (z || this.f378c != null || this.f380e != null) {
            CompoundButton compoundButton;
            CompoundButton compoundButton2;
            if (this.f376a.m6918e()) {
                if (this.f378c == null) {
                    m342b();
                }
                compoundButton = this.f378c;
                compoundButton2 = this.f380e;
            } else {
                if (this.f380e == null) {
                    m343c();
                }
                compoundButton = this.f380e;
                compoundButton2 = this.f378c;
            }
            if (z) {
                int i;
                compoundButton.setChecked(this.f376a.isChecked());
                if (z) {
                    i = 0;
                } else {
                    i = 8;
                }
                if (compoundButton.getVisibility() != i) {
                    compoundButton.setVisibility(i);
                }
                if (compoundButton2 != null && compoundButton2.getVisibility() != 8) {
                    compoundButton2.setVisibility(8);
                    return;
                }
                return;
            }
            if (this.f380e != null) {
                this.f380e.setVisibility(8);
            }
            if (this.f378c != null) {
                this.f378c.setVisibility(8);
            }
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.f376a.m6918e()) {
            if (this.f378c == null) {
                m342b();
            }
            compoundButton = this.f378c;
        } else {
            if (this.f380e == null) {
                m343c();
            }
            compoundButton = this.f380e;
        }
        compoundButton.setChecked(z);
    }

    private void setShortcut$25d965e(boolean z) {
        int i;
        if (z && this.f376a.m6917d()) {
            i = 0;
        } else {
            i = 8;
        }
        if (i == 0) {
            CharSequence charSequence;
            TextView textView = this.f381f;
            char c = this.f376a.m6914c();
            if (c == '\u0000') {
                charSequence = "";
            } else {
                StringBuilder stringBuilder = new StringBuilder(rr.f6105f);
                switch (c) {
                    case py.Toolbar_contentInsetRight /*8*/:
                        stringBuilder.append(rr.f6107h);
                        break;
                    case py.Toolbar_titleTextAppearance /*10*/:
                        stringBuilder.append(rr.f6106g);
                        break;
                    case py.Theme_actionModeCutDrawable /*32*/:
                        stringBuilder.append(rr.f6108i);
                        break;
                    default:
                        stringBuilder.append(c);
                        break;
                }
                charSequence = stringBuilder.toString();
            }
            textView.setText(charSequence);
        }
        if (this.f381f.getVisibility() != i) {
            this.f381f.setVisibility(i);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z = this.f376a.f6110b.f5695i || this.f389n;
        if (!z && !this.f385j) {
            return;
        }
        if (this.f377b != null || drawable != null || this.f385j) {
            if (this.f377b == null) {
                this.f377b = (ImageView) getInflater().inflate(pv.abc_list_menu_item_icon, this, false);
                addView(this.f377b, 0);
            }
            if (drawable != null || this.f385j) {
                ImageView imageView = this.f377b;
                if (!z) {
                    drawable = null;
                }
                imageView.setImageDrawable(drawable);
                if (this.f377b.getVisibility() != 0) {
                    this.f377b.setVisibility(0);
                    return;
                }
                return;
            }
            this.f377b.setVisibility(8);
        }
    }

    protected void onMeasure(int i, int i2) {
        if (this.f377b != null && this.f385j) {
            LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f377b.getLayoutParams();
            if (layoutParams.height > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = layoutParams.height;
            }
        }
        super.onMeasure(i, i2);
    }

    private void m342b() {
        this.f378c = (RadioButton) getInflater().inflate(pv.abc_list_menu_item_radio, this, false);
        addView(this.f378c);
    }

    private void m343c() {
        this.f380e = (CheckBox) getInflater().inflate(pv.abc_list_menu_item_checkbox, this, false);
        addView(this.f380e);
    }

    public final boolean m345a() {
        return false;
    }

    private LayoutInflater getInflater() {
        if (this.f388m == null) {
            this.f388m = LayoutInflater.from(this.f387l);
        }
        return this.f388m;
    }
}
