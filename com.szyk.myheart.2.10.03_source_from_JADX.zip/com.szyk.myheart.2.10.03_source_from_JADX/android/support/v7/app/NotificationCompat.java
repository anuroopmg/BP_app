package android.support.v7.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.session.MediaSession;
import android.os.Build.VERSION;
import android.support.v4.app.NotificationBuilderWithBuilderAccessor;
import android.support.v4.app.NotificationCompat.BuilderExtender;
import android.support.v4.app.NotificationCompat.Style;
import android.support.v4.app.NotificationCompatBase.Action;
import android.support.v4.media.session.MediaSessionCompat.Token;
import android.widget.RemoteViews;
import happy.hacking.pt;
import happy.hacking.pu;
import happy.hacking.pv;
import happy.hacking.qf;
import java.util.List;

public class NotificationCompat extends android.support.v4.app.NotificationCompat {

    public class Builder extends android.support.v4.app.NotificationCompat.Builder {
        public Builder(Context context) {
            super(context);
        }

        protected BuilderExtender getExtender() {
            if (VERSION.SDK_INT >= 21) {
                return new LollipopExtender();
            }
            if (VERSION.SDK_INT >= 16) {
                return new JellybeanExtender();
            }
            if (VERSION.SDK_INT >= 14) {
                return new IceCreamSandwichExtender();
            }
            return super.getExtender();
        }
    }

    class IceCreamSandwichExtender extends BuilderExtender {
        private IceCreamSandwichExtender() {
        }

        public Notification build(android.support.v4.app.NotificationCompat.Builder builder, NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            NotificationCompat.addMediaStyleToBuilderIcs(notificationBuilderWithBuilderAccessor, builder);
            return notificationBuilderWithBuilderAccessor.build();
        }
    }

    class JellybeanExtender extends BuilderExtender {
        private JellybeanExtender() {
        }

        public Notification build(android.support.v4.app.NotificationCompat.Builder builder, NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            NotificationCompat.addMediaStyleToBuilderIcs(notificationBuilderWithBuilderAccessor, builder);
            Notification build = notificationBuilderWithBuilderAccessor.build();
            NotificationCompat.addBigMediaStyleToBuilderJellybean(build, builder);
            return build;
        }
    }

    class LollipopExtender extends BuilderExtender {
        private LollipopExtender() {
        }

        public Notification build(android.support.v4.app.NotificationCompat.Builder builder, NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            NotificationCompat.addMediaStyleToBuilderLollipop(notificationBuilderWithBuilderAccessor, builder.mStyle);
            return notificationBuilderWithBuilderAccessor.build();
        }
    }

    public class MediaStyle extends Style {
        int[] mActionsToShowInCompact;
        PendingIntent mCancelButtonIntent;
        boolean mShowCancelButton;
        Token mToken;

        public MediaStyle() {
            this.mActionsToShowInCompact = null;
        }

        public MediaStyle(android.support.v4.app.NotificationCompat.Builder builder) {
            this.mActionsToShowInCompact = null;
            setBuilder(builder);
        }

        public MediaStyle setShowActionsInCompactView(int... iArr) {
            this.mActionsToShowInCompact = iArr;
            return this;
        }

        public MediaStyle setMediaSession(Token token) {
            this.mToken = token;
            return this;
        }

        public MediaStyle setShowCancelButton(boolean z) {
            this.mShowCancelButton = z;
            return this;
        }

        public MediaStyle setCancelButtonIntent(PendingIntent pendingIntent) {
            this.mCancelButtonIntent = pendingIntent;
            return this;
        }
    }

    private static void addMediaStyleToBuilderLollipop(NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor, Style style) {
        if (style instanceof MediaStyle) {
            Object obj;
            MediaStyle mediaStyle = (MediaStyle) style;
            int[] iArr = mediaStyle.mActionsToShowInCompact;
            if (mediaStyle.mToken != null) {
                obj = mediaStyle.mToken.f203a;
            } else {
                obj = null;
            }
            android.app.Notification.MediaStyle mediaStyle2 = new android.app.Notification.MediaStyle(notificationBuilderWithBuilderAccessor.getBuilder());
            if (iArr != null) {
                mediaStyle2.setShowActionsInCompactView(iArr);
            }
            if (obj != null) {
                mediaStyle2.setMediaSession((MediaSession.Token) obj);
            }
        }
    }

    private static void addMediaStyleToBuilderIcs(NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor, android.support.v4.app.NotificationCompat.Builder builder) {
        if (builder.mStyle instanceof MediaStyle) {
            int i;
            MediaStyle mediaStyle = (MediaStyle) builder.mStyle;
            Context context = builder.mContext;
            CharSequence charSequence = builder.mContentTitle;
            CharSequence charSequence2 = builder.mContentText;
            CharSequence charSequence3 = builder.mContentInfo;
            int i2 = builder.mNumber;
            Bitmap bitmap = builder.mLargeIcon;
            CharSequence charSequence4 = builder.mSubText;
            boolean z = builder.mUseChronometer;
            long j = builder.mNotification.when;
            List list = builder.mActions;
            int[] iArr = mediaStyle.mActionsToShowInCompact;
            boolean z2 = mediaStyle.mShowCancelButton;
            PendingIntent pendingIntent = mediaStyle.mCancelButtonIntent;
            RemoteViews a = qf.m6768a(context, charSequence, charSequence2, charSequence3, i2, bitmap, charSequence4, z, j, pv.notification_template_media, true);
            int size = list.size();
            if (iArr == null) {
                i = 0;
            } else {
                i = Math.min(iArr.length, 3);
            }
            a.removeAllViews(pt.media_actions);
            if (i > 0) {
                for (int i3 = 0; i3 < i; i3++) {
                    if (i3 >= size) {
                        throw new IllegalArgumentException(String.format("setShowActionsInCompactView: action %d out of bounds (max %d)", new Object[]{Integer.valueOf(i3), Integer.valueOf(size - 1)}));
                    }
                    a.addView(pt.media_actions, qf.m6767a(context, (Action) list.get(iArr[i3])));
                }
            }
            if (z2) {
                a.setViewVisibility(pt.end_padder, 8);
                a.setViewVisibility(pt.cancel_action, 0);
                a.setOnClickPendingIntent(pt.cancel_action, pendingIntent);
                a.setInt(pt.cancel_action, "setAlpha", context.getResources().getInteger(pu.cancel_button_image_alpha));
            } else {
                a.setViewVisibility(pt.end_padder, 0);
                a.setViewVisibility(pt.cancel_action, 8);
            }
            notificationBuilderWithBuilderAccessor.getBuilder().setContent(a);
            if (z2) {
                notificationBuilderWithBuilderAccessor.getBuilder().setOngoing(true);
            }
        }
    }

    private static void addBigMediaStyleToBuilderJellybean(Notification notification, android.support.v4.app.NotificationCompat.Builder builder) {
        if (builder.mStyle instanceof MediaStyle) {
            int i;
            MediaStyle mediaStyle = (MediaStyle) builder.mStyle;
            Context context = builder.mContext;
            CharSequence charSequence = builder.mContentTitle;
            CharSequence charSequence2 = builder.mContentText;
            CharSequence charSequence3 = builder.mContentInfo;
            int i2 = builder.mNumber;
            Bitmap bitmap = builder.mLargeIcon;
            CharSequence charSequence4 = builder.mSubText;
            boolean z = builder.mUseChronometer;
            long j = builder.mNotification.when;
            List list = builder.mActions;
            boolean z2 = mediaStyle.mShowCancelButton;
            PendingIntent pendingIntent = mediaStyle.mCancelButtonIntent;
            int min = Math.min(list.size(), 5);
            if (min <= 3) {
                i = pv.notification_template_big_media_narrow;
            } else {
                i = pv.notification_template_big_media;
            }
            RemoteViews a = qf.m6768a(context, charSequence, charSequence2, charSequence3, i2, bitmap, charSequence4, z, j, i, false);
            a.removeAllViews(pt.media_actions);
            if (min > 0) {
                for (int i3 = 0; i3 < min; i3++) {
                    a.addView(pt.media_actions, qf.m6767a(context, (Action) list.get(i3)));
                }
            }
            if (z2) {
                a.setViewVisibility(pt.cancel_action, 0);
                a.setInt(pt.cancel_action, "setAlpha", context.getResources().getInteger(pu.cancel_button_image_alpha));
                a.setOnClickPendingIntent(pt.cancel_action, pendingIntent);
            } else {
                a.setViewVisibility(pt.cancel_action, 8);
            }
            notification.bigContentView = a;
            if (z2) {
                notification.flags |= 2;
            }
        }
    }
}
