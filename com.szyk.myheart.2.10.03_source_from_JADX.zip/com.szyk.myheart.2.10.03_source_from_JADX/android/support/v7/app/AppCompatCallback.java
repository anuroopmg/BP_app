package android.support.v7.app;

import happy.hacking.uh;
import happy.hacking.ui;

public interface AppCompatCallback {
    void onSupportActionModeFinished(uh uhVar);

    void onSupportActionModeStarted(uh uhVar);

    uh onWindowStartingSupportActionMode(ui uiVar);
}
