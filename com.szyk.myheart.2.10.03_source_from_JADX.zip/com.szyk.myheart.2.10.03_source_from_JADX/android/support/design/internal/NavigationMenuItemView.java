package android.support.design.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import happy.hacking.C0000i;
import happy.hacking.C0059c;
import happy.hacking.C0060d;
import happy.hacking.C0062e;
import happy.hacking.C0063f;
import happy.hacking.dx;
import happy.hacking.pb;
import happy.hacking.rr;
import happy.hacking.sf;

public class NavigationMenuItemView extends C0000i implements sf {
    private static final int[] f21e;
    public final CheckedTextView f22c;
    public FrameLayout f23d;
    private final int f24f;
    private rr f25g;
    private ColorStateList f26h;

    static {
        f21e = new int[]{16842912};
    }

    public NavigationMenuItemView(Context context) {
        this(context, null);
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setOrientation(0);
        LayoutInflater.from(context).inflate(C0063f.design_navigation_menu_item, this, true);
        this.f24f = context.getResources().getDimensionPixelSize(C0060d.design_navigation_icon_size);
        this.f22c = (CheckedTextView) findViewById(C0062e.design_menu_item_text);
        this.f22c.setDuplicateParentStateEnabled(true);
    }

    public final void m12a(rr rrVar) {
        this.f25g = rrVar;
        setVisibility(rrVar.isVisible() ? 0 : 8);
        if (getBackground() == null) {
            Drawable stateListDrawable;
            TypedValue typedValue = new TypedValue();
            if (getContext().getTheme().resolveAttribute(C0059c.colorControlHighlight, typedValue, true)) {
                stateListDrawable = new StateListDrawable();
                stateListDrawable.addState(f21e, new ColorDrawable(typedValue.data));
                stateListDrawable.addState(EMPTY_STATE_SET, new ColorDrawable(0));
            } else {
                stateListDrawable = null;
            }
            setBackgroundDrawable(stateListDrawable);
        }
        setCheckable(rrVar.isCheckable());
        setChecked(rrVar.isChecked());
        setEnabled(rrVar.isEnabled());
        setTitle(rrVar.getTitle());
        setIcon(rrVar.getIcon());
        setActionView(rrVar.getActionView());
    }

    private void setActionView(View view) {
        if (this.f23d == null) {
            this.f23d = (FrameLayout) ((ViewStub) findViewById(C0062e.design_menu_item_action_area_stub)).inflate();
        }
        this.f23d.removeAllViews();
        if (view != null) {
            this.f23d.addView(view);
        }
    }

    public rr getItemData() {
        return this.f25g;
    }

    public void setTitle(CharSequence charSequence) {
        this.f22c.setText(charSequence);
    }

    public void setCheckable(boolean z) {
        refreshDrawableState();
    }

    public void setChecked(boolean z) {
        refreshDrawableState();
        this.f22c.setChecked(z);
    }

    public void setIcon(Drawable drawable) {
        if (drawable != null) {
            ConstantState constantState = drawable.getConstantState();
            if (constantState != null) {
                drawable = constantState.newDrawable();
            }
            drawable = dx.m5543c(drawable).mutate();
            drawable.setBounds(0, 0, this.f24f, this.f24f);
            dx.m5538a(drawable, this.f26h);
        }
        pb.m6728a(this.f22c, drawable);
    }

    public final boolean m13a() {
        return false;
    }

    protected int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (this.f25g != null && this.f25g.isCheckable() && this.f25g.isChecked()) {
            mergeDrawableStates(onCreateDrawableState, f21e);
        }
        return onCreateDrawableState;
    }

    public void setIconTintList(ColorStateList colorStateList) {
        this.f26h = colorStateList;
        if (this.f25g != null) {
            setIcon(this.f25g.getIcon());
        }
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.f22c.setTextColor(colorStateList);
    }
}
