package android.support.design.widget;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import happy.hacking.ag;
import happy.hacking.bn;
import happy.hacking.bo;
import happy.hacking.hu;
import happy.hacking.pj;
import happy.hacking.pm;
import happy.hacking.ug;

public class SwipeDismissBehavior extends ag {
    private boolean f164a;
    public pj f165b;
    public bo f166c;
    public int f167d;
    public float f168e;
    public float f169f;
    private float f170g;
    private boolean f171h;
    private float f172i;
    private final pm f173j;

    public SwipeDismissBehavior() {
        this.f170g = 0.0f;
        this.f167d = 2;
        this.f172i = 0.5f;
        this.f168e = 0.0f;
        this.f169f = 0.5f;
        this.f173j = new bn(this);
    }

    public boolean m204a(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        switch (hu.m5837a(motionEvent)) {
            case ug.RecyclerView_layoutManager /*1*/:
            case ug.RecyclerView_reverseLayout /*3*/:
                if (this.f164a) {
                    this.f164a = false;
                    return false;
                }
                break;
            default:
                boolean z;
                if (coordinatorLayout.m172a(view, (int) motionEvent.getX(), (int) motionEvent.getY())) {
                    z = false;
                } else {
                    z = true;
                }
                this.f164a = z;
                break;
        }
        if (this.f164a) {
            return false;
        }
        if (this.f165b == null) {
            pj a;
            if (this.f171h) {
                a = pj.m6740a((ViewGroup) coordinatorLayout, this.f170g, this.f173j);
            } else {
                a = pj.m6741a((ViewGroup) coordinatorLayout, this.f173j);
            }
            this.f165b = a;
        }
        return this.f165b.m6757a(motionEvent);
    }

    public final boolean m205b(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        if (this.f165b == null) {
            return false;
        }
        this.f165b.m6760b(motionEvent);
        return true;
    }

    public static float m194a(float f) {
        return Math.min(Math.max(0.0f, f), 1.0f);
    }

    public static float m195a(float f, float f2, float f3) {
        return (f3 - f) / (f2 - f);
    }
}
