package android.support.design.widget;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.design.widget.Snackbar.SnackbarLayout;
import android.view.View;
import android.view.View.MeasureSpec;
import android.widget.ImageButton;
import happy.hacking.C0060d;
import happy.hacking.aa;
import happy.hacking.ag;
import happy.hacking.ah;
import happy.hacking.ai;
import happy.hacking.ao;
import happy.hacking.cq;
import happy.hacking.iv;
import happy.hacking.kt;
import happy.hacking.ug;
import java.util.List;

@ah(a = Behavior.class)
public final class FloatingActionButton extends ImageButton {
    final ao f136a;
    private ColorStateList f137b;
    private Mode f138c;
    private int f139d;
    private int f140e;
    private final Rect f141f;

    public class Behavior extends ag {
        private static final boolean f133a;
        private float f134b;
        private Rect f135c;

        public final /* synthetic */ boolean m174a(CoordinatorLayout coordinatorLayout, View view, int i) {
            int i2;
            int i3 = 0;
            view = (FloatingActionButton) view;
            List a = coordinatorLayout.m167a(view);
            int size = a.size();
            for (i2 = 0; i2 < size; i2++) {
                View view2 = (View) a.get(i2);
                if ((view2 instanceof AppBarLayout) && m173a(coordinatorLayout, (AppBarLayout) view2, (FloatingActionButton) view)) {
                    break;
                }
            }
            coordinatorLayout.m168a(view, i);
            Rect a2 = view.f141f;
            if (a2 != null && a2.centerX() > 0 && a2.centerY() > 0) {
                ai aiVar = (ai) view.getLayoutParams();
                if (view.getRight() >= coordinatorLayout.getWidth() - aiVar.rightMargin) {
                    i2 = a2.right;
                } else if (view.getLeft() <= aiVar.leftMargin) {
                    i2 = -a2.left;
                } else {
                    i2 = 0;
                }
                if (view.getBottom() >= coordinatorLayout.getBottom() - aiVar.bottomMargin) {
                    i3 = a2.bottom;
                } else if (view.getTop() <= aiVar.topMargin) {
                    i3 = -a2.top;
                }
                view.offsetTopAndBottom(i3);
                view.offsetLeftAndRight(i2);
            }
            return true;
        }

        public final /* synthetic */ boolean m175b(CoordinatorLayout coordinatorLayout, View view, View view2) {
            FloatingActionButton floatingActionButton = (FloatingActionButton) view;
            if (view2 instanceof SnackbarLayout) {
                if (floatingActionButton.getVisibility() == 0) {
                    View view3;
                    float f = 0.0f;
                    List a = coordinatorLayout.m167a((View) floatingActionButton);
                    int size = a.size();
                    int i = 0;
                    while (i < size) {
                        float min;
                        view3 = (View) a.get(i);
                        if (view3 instanceof SnackbarLayout) {
                            boolean z;
                            if (floatingActionButton.getVisibility() == 0 && view3.getVisibility() == 0) {
                                Rect rect = coordinatorLayout.f115h;
                                coordinatorLayout.m170a((View) floatingActionButton, floatingActionButton.getParent() != coordinatorLayout, rect);
                                Rect rect2 = coordinatorLayout.f116i;
                                if (view3.getParent() != coordinatorLayout) {
                                    z = true;
                                } else {
                                    z = false;
                                }
                                coordinatorLayout.m170a(view3, z, rect2);
                                if (rect.left > rect2.right || rect.top > rect2.bottom || rect.right < rect2.left || rect.bottom < rect2.top) {
                                    z = false;
                                } else {
                                    z = true;
                                }
                            } else {
                                z = false;
                            }
                            if (z) {
                                min = Math.min(f, iv.m5941r(view3) - ((float) view3.getHeight()));
                                i++;
                                f = min;
                            }
                        }
                        min = f;
                        i++;
                        f = min;
                    }
                    if (this.f134b != f) {
                        this.f134b = f;
                        if (Math.abs(iv.m5941r(floatingActionButton) - f) > ((float) floatingActionButton.getHeight()) * 0.667f) {
                            kt c = iv.m5944u(floatingActionButton).m6238c(f);
                            view3 = (View) c.f5751a.get();
                            if (view3 != null) {
                                kt.f5750b.m6243a(c, view3);
                            }
                            view3 = (View) c.f5751a.get();
                            if (view3 != null) {
                                kt.f5750b.m6247b(c, view3);
                            }
                            c.m6229a(1.0f).m6231a(aa.f1045b).m6232a(null);
                        } else {
                            iv.m5944u(floatingActionButton).m6234a();
                            iv.m5915b((View) floatingActionButton, f);
                        }
                    }
                }
            } else if (view2 instanceof AppBarLayout) {
                m173a(coordinatorLayout, (AppBarLayout) view2, floatingActionButton);
            }
            return false;
        }

        static {
            f133a = VERSION.SDK_INT >= 11;
        }

        private boolean m173a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, FloatingActionButton floatingActionButton) {
            if (((ai) floatingActionButton.getLayoutParams()).f1575f != appBarLayout.getId()) {
                return false;
            }
            if (this.f135c == null) {
                this.f135c = new Rect();
            }
            Rect rect = this.f135c;
            cq.m4950a(coordinatorLayout, appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                floatingActionButton.f136a.m2031g();
            } else {
                floatingActionButton.f136a.m2032h();
            }
            return true;
        }

        public final /* bridge */ /* synthetic */ boolean a_(View view) {
            return f133a && (view instanceof SnackbarLayout);
        }
    }

    protected final void onMeasure(int i, int i2) {
        int sizeDimension = getSizeDimension();
        sizeDimension = Math.min(m176a(sizeDimension, i), m176a(sizeDimension, i2));
        setMeasuredDimension((this.f141f.left + sizeDimension) + this.f141f.right, (sizeDimension + this.f141f.top) + this.f141f.bottom);
    }

    public final void setRippleColor(int i) {
        if (this.f139d != i) {
            this.f139d = i;
            this.f136a.m2028d();
        }
    }

    public final ColorStateList getBackgroundTintList() {
        return this.f137b;
    }

    public final void setBackgroundTintList(ColorStateList colorStateList) {
        if (this.f137b != colorStateList) {
            this.f137b = colorStateList;
            this.f136a.m2026b();
        }
    }

    public final Mode getBackgroundTintMode() {
        return this.f138c;
    }

    public final void setBackgroundTintMode(Mode mode) {
        if (this.f138c != mode) {
            this.f138c = mode;
            this.f136a.m2027c();
        }
    }

    public final void setBackgroundDrawable(Drawable drawable) {
        if (this.f136a != null) {
            this.f136a.m2025a();
        }
    }

    final int getSizeDimension() {
        switch (this.f140e) {
            case ug.RecyclerView_layoutManager /*1*/:
                return getResources().getDimensionPixelSize(C0060d.design_fab_size_mini);
            default:
                return getResources().getDimensionPixelSize(C0060d.design_fab_size_normal);
        }
    }

    protected final void drawableStateChanged() {
        super.drawableStateChanged();
        ao aoVar = this.f136a;
        getDrawableState();
        aoVar.m2029e();
    }

    @TargetApi(11)
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        this.f136a.m2030f();
    }

    private static int m176a(int i, int i2) {
        int mode = MeasureSpec.getMode(i2);
        int size = MeasureSpec.getSize(i2);
        switch (mode) {
            case Integer.MIN_VALUE:
                return Math.min(i, size);
            case 1073741824:
                return size;
            default:
                return i;
        }
    }
}
