package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import happy.hacking.C0064g;
import happy.hacking.C0065h;
import happy.hacking.aa;
import happy.hacking.ab;
import happy.hacking.ac;
import happy.hacking.ad;
import happy.hacking.ae;
import happy.hacking.af;
import happy.hacking.ag;
import happy.hacking.ah;
import happy.hacking.ai;
import happy.hacking.ap;
import happy.hacking.ar;
import happy.hacking.as;
import happy.hacking.ca;
import happy.hacking.cb;
import happy.hacking.cx;
import happy.hacking.et;
import happy.hacking.iv;
import happy.hacking.lm;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

@ah(a = Behavior.class)
public class AppBarLayout extends LinearLayout {
    boolean f99a;
    private int f100b;
    private int f101c;
    private int f102d;
    private float f103e;
    private int f104f;
    private lm f105g;
    private final List f106h;

    public class Behavior extends ap {
        private int f89b;
        private boolean f90c;
        private boolean f91d;
        private cb f92e;
        private int f93f;
        private boolean f94g;
        private float f95h;
        private WeakReference f96i;
        private ad f97j;

        public class SavedState extends BaseSavedState {
            public static final Creator CREATOR;
            int f76a;
            float f77b;
            boolean f78c;

            public SavedState(Parcel parcel) {
                super(parcel);
                this.f76a = parcel.readInt();
                this.f77b = parcel.readFloat();
                this.f78c = parcel.readByte() != null;
            }

            public SavedState(Parcelable parcelable) {
                super(parcelable);
            }

            public void writeToParcel(Parcel parcel, int i) {
                super.writeToParcel(parcel, i);
                parcel.writeInt(this.f76a);
                parcel.writeFloat(this.f77b);
                parcel.writeByte((byte) (this.f78c ? 1 : 0));
            }

            static {
                CREATOR = et.m5596a(new ae());
            }
        }

        final /* synthetic */ int m119a(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            int a = m118a();
            if (i2 == 0 || a < i2 || a > i3) {
                return 0;
            }
            int a2 = as.m2296a(i, i2, i3);
            if (a == a2) {
                return 0;
            }
            int abs;
            int i4;
            int height;
            if (appBarLayout.f99a) {
                abs = Math.abs(a2);
                int childCount = appBarLayout.getChildCount();
                i4 = 0;
                while (i4 < childCount) {
                    View childAt = appBarLayout.getChildAt(i4);
                    af afVar = (af) childAt.getLayoutParams();
                    Interpolator interpolator = afVar.f1388b;
                    if (abs < childAt.getTop() || abs > childAt.getBottom()) {
                        i4++;
                    } else {
                        if (interpolator != null) {
                            i4 = afVar.f1387a;
                            if ((i4 & 1) != 0) {
                                height = (afVar.bottomMargin + (childAt.getHeight() + afVar.topMargin)) + 0;
                                if ((i4 & 2) != 0) {
                                    height -= iv.m5943t(childAt);
                                }
                            } else {
                                height = 0;
                            }
                            if (iv.m5948y(childAt)) {
                                height -= appBarLayout.getTopInset();
                            }
                            if (height > 0) {
                                i4 = abs - childAt.getTop();
                                height = Math.round(interpolator.getInterpolation(((float) i4) / ((float) height)) * ((float) height));
                                height = (height + childAt.getTop()) * Integer.signum(a2);
                            }
                        }
                        height = a2;
                    }
                }
                height = a2;
            } else {
                height = a2;
            }
            boolean a3 = super.m102a(height);
            i4 = a - a2;
            this.f89b = a2 - height;
            if (!a3 && appBarLayout.f99a) {
                abs = coordinatorLayout.f114g.size();
                a = 0;
                a2 = 0;
                while (a < abs) {
                    View view2 = (View) coordinatorLayout.f114g.get(a);
                    if (view2 == appBarLayout) {
                        height = 1;
                    } else {
                        if (a2 != 0) {
                            ai aiVar = (ai) view2.getLayoutParams();
                            ag agVar = aiVar.f1570a;
                            if (agVar != null && aiVar.m1539a((View) appBarLayout)) {
                                agVar.m101b(coordinatorLayout, view2, (View) appBarLayout);
                            }
                        }
                        height = a2;
                    }
                    a++;
                    a2 = height;
                }
            }
            m116a(appBarLayout);
            return i4;
        }

        final /* synthetic */ int m120a(View view) {
            return ((AppBarLayout) view).getTotalScrollRange();
        }

        public final /* synthetic */ Parcelable m121a(CoordinatorLayout coordinatorLayout, View view) {
            boolean z = false;
            AppBarLayout appBarLayout = (AppBarLayout) view;
            Parcelable a = super.m90a(coordinatorLayout, appBarLayout);
            int c = super.m104c();
            int childCount = appBarLayout.getChildCount();
            int i = 0;
            while (i < childCount) {
                View childAt = appBarLayout.getChildAt(i);
                int bottom = childAt.getBottom() + c;
                if (childAt.getTop() + c > 0 || bottom < 0) {
                    i++;
                } else {
                    SavedState savedState = new SavedState(a);
                    savedState.f76a = i;
                    if (bottom == iv.m5943t(childAt)) {
                        z = true;
                    }
                    savedState.f78c = z;
                    savedState.f77b = ((float) bottom) / ((float) childAt.getHeight());
                    return savedState;
                }
            }
            return a;
        }

        public final /* synthetic */ void m122a(CoordinatorLayout coordinatorLayout, View view, int i, int[] iArr) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (i != 0 && !this.f90c) {
                int i2;
                int b;
                if (i < 0) {
                    i2 = -appBarLayout.getTotalScrollRange();
                    b = i2 + appBarLayout.getDownNestedPreScrollRange();
                } else {
                    i2 = -appBarLayout.getUpNestedPreScrollRange();
                    b = 0;
                }
                iArr[1] = m111b(coordinatorLayout, appBarLayout, i, i2, b);
            }
        }

        public final /* synthetic */ void m123a(CoordinatorLayout coordinatorLayout, View view, Parcelable parcelable) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (parcelable instanceof SavedState) {
                SavedState savedState = (SavedState) parcelable;
                super.m92a(coordinatorLayout, (View) appBarLayout, savedState.getSuperState());
                this.f93f = savedState.f76a;
                this.f95h = savedState.f77b;
                this.f94g = savedState.f78c;
                return;
            }
            super.m92a(coordinatorLayout, (View) appBarLayout, parcelable);
            this.f93f = -1;
        }

        public final /* synthetic */ void m124a(CoordinatorLayout coordinatorLayout, View view, View view2) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (!this.f91d) {
                int i;
                View view3;
                int a = m118a();
                int childCount = appBarLayout.getChildCount();
                for (i = 0; i < childCount; i++) {
                    View childAt = appBarLayout.getChildAt(i);
                    if (childAt.getTop() <= (-a) && childAt.getBottom() >= (-a)) {
                        view3 = childAt;
                        break;
                    }
                }
                view3 = null;
                if (view3 != null && (((af) view3.getLayoutParams()).f1387a & 17) == 17) {
                    i = -view3.getTop();
                    int i2 = -view3.getBottom();
                    if (a >= (i2 + i) / 2) {
                        i2 = i;
                    }
                    m117a(coordinatorLayout, appBarLayout, i2);
                }
            }
            this.f90c = false;
            this.f91d = false;
            this.f96i = new WeakReference(view2);
        }

        public final /* synthetic */ boolean m126a(CoordinatorLayout coordinatorLayout, View view, float f, boolean z) {
            boolean z2 = true;
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (z) {
                int b;
                if (f < 0.0f) {
                    b = (-appBarLayout.getTotalScrollRange()) + appBarLayout.getDownNestedPreScrollRange();
                    if (m118a() < b) {
                        m117a(coordinatorLayout, appBarLayout, b);
                    }
                } else {
                    b = -appBarLayout.getUpNestedPreScrollRange();
                    if (m118a() > b) {
                        m117a(coordinatorLayout, appBarLayout, b);
                    }
                }
                z2 = false;
            } else {
                z2 = m109a(coordinatorLayout, appBarLayout, -appBarLayout.getTotalScrollRange(), -f);
            }
            this.f91d = z2;
            return z2;
        }

        public final /* synthetic */ boolean m127a(CoordinatorLayout coordinatorLayout, View view, int i) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            boolean a = super.m103a(coordinatorLayout, appBarLayout, i);
            int e = appBarLayout.getPendingAction();
            int i2;
            int i3;
            if (e != 0) {
                i2 = (e & 4) != 0 ? 1 : 0;
                if ((e & 2) != 0) {
                    i3 = -appBarLayout.getUpNestedPreScrollRange();
                    if (i2 != 0) {
                        m117a(coordinatorLayout, appBarLayout, i3);
                    } else {
                        m115c(coordinatorLayout, appBarLayout, i3);
                    }
                } else if ((e & 1) != 0) {
                    if (i2 != 0) {
                        m117a(coordinatorLayout, appBarLayout, 0);
                    } else {
                        m115c(coordinatorLayout, appBarLayout, 0);
                    }
                }
            } else if (this.f93f >= 0) {
                View childAt = appBarLayout.getChildAt(this.f93f);
                i3 = -childAt.getBottom();
                if (this.f94g) {
                    i2 = iv.m5943t(childAt) + i3;
                } else {
                    i2 = Math.round(((float) childAt.getHeight()) * this.f95h) + i3;
                }
                super.m102a(i2);
            }
            appBarLayout.f104f = 0;
            this.f93f = -1;
            m116a(appBarLayout);
            return a;
        }

        public final /* synthetic */ boolean m128a(CoordinatorLayout coordinatorLayout, View view, View view2, int i) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            boolean z = (i & 2) != 0 && AppBarLayout.m148a(appBarLayout) && coordinatorLayout.getHeight() - view2.getHeight() <= appBarLayout.getHeight();
            if (z && this.f92e != null) {
                this.f92e.f3890a.m4431e();
            }
            this.f96i = null;
            return z;
        }

        final /* synthetic */ int m129b(View view) {
            return -((AppBarLayout) view).getDownNestedScrollRange();
        }

        public final /* synthetic */ void m130b(CoordinatorLayout coordinatorLayout, View view, int i) {
            AppBarLayout appBarLayout = (AppBarLayout) view;
            if (i < 0) {
                m111b(coordinatorLayout, appBarLayout, i, -appBarLayout.getDownNestedScrollRange(), 0);
                this.f90c = true;
                return;
            }
            this.f90c = false;
        }

        public final /* bridge */ /* synthetic */ int m132c() {
            return super.m104c();
        }

        public Behavior() {
            this.f93f = -1;
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f93f = -1;
        }

        private void m117a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i) {
            if (this.f92e == null) {
                this.f92e = cx.m5234a();
                this.f92e.m4026a(aa.f1046c);
                this.f92e.m4027a(new ac(this, coordinatorLayout, appBarLayout));
            } else {
                this.f92e.f3890a.m4431e();
            }
            this.f92e.m4025a(m118a(), i);
            this.f92e.f3890a.m4422a();
        }

        private static void m116a(AppBarLayout appBarLayout) {
            List h = appBarLayout.f106h;
            int size = h.size();
            for (int i = 0; i < size; i++) {
                h.get(i);
            }
        }

        final int m118a() {
            return super.m104c() + this.f89b;
        }

        final /* synthetic */ boolean m131b() {
            if (this.f97j != null) {
                return this.f97j.m988a();
            }
            if (this.f96i != null) {
                View view = (View) this.f96i.get();
                if (view == null || !view.isShown() || iv.m5918b(view, -1)) {
                    return false;
                }
            }
            return true;
        }
    }

    public class ScrollingViewBehavior extends ar {
        private int f98a;

        public final /* bridge */ /* synthetic */ boolean m140a(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3, int i4) {
            return super.m134a(coordinatorLayout, view, i, i2, i3, i4);
        }

        public final /* bridge */ /* synthetic */ int m143c() {
            return super.m104c();
        }

        public ScrollingViewBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0065h.ScrollingViewBehavior_Params);
            this.f98a = obtainStyledAttributes.getDimensionPixelSize(C0065h.ScrollingViewBehavior_Params_behavior_overlapTop, 0);
            obtainStyledAttributes.recycle();
        }

        public final boolean a_(View view) {
            return view instanceof AppBarLayout;
        }

        public final boolean m139a(CoordinatorLayout coordinatorLayout, View view, int i) {
            super.m103a(coordinatorLayout, view, i);
            List a = coordinatorLayout.m167a(view);
            int size = a.size();
            int i2 = 0;
            while (i2 < size && !m136c((View) a.get(i2))) {
                i2++;
            }
            return true;
        }

        public final boolean m142b(CoordinatorLayout coordinatorLayout, View view, View view2) {
            m136c(view2);
            return false;
        }

        private boolean m136c(View view) {
            ag agVar = ((ai) view.getLayoutParams()).f1570a;
            if (!(agVar instanceof Behavior)) {
                return false;
            }
            int a = ((Behavior) agVar).m118a();
            int height = view.getHeight() + a;
            if (this.f98a != 0 && (view instanceof AppBarLayout)) {
                AppBarLayout appBarLayout = (AppBarLayout) view;
                int totalScrollRange = appBarLayout.getTotalScrollRange();
                int b = appBarLayout.getDownNestedPreScrollRange();
                if (b == 0 || totalScrollRange + a > b) {
                    totalScrollRange -= b;
                    if (totalScrollRange != 0) {
                        a = as.m2296a(Math.round(((((float) a) / ((float) totalScrollRange)) + 1.0f) * ((float) this.f98a)), 0, this.f98a);
                        super.m102a(height - a);
                        return true;
                    }
                }
                a = 0;
                super.m102a(height - a);
                return true;
            }
            a = this.f98a;
            super.m102a(height - a);
            return true;
        }

        final View m137a(List list) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                View view = (View) list.get(i);
                if (view instanceof AppBarLayout) {
                    return view;
                }
            }
            return null;
        }

        final int m141b(View view) {
            if (view instanceof AppBarLayout) {
                return ((AppBarLayout) view).getTotalScrollRange();
            }
            return super.m135b(view);
        }
    }

    public /* synthetic */ LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return m144a(attributeSet);
    }

    protected /* synthetic */ LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return m145a(layoutParams);
    }

    public /* synthetic */ LinearLayout.LayoutParams m7478generateLayoutParams(AttributeSet attributeSet) {
        return m144a(attributeSet);
    }

    protected /* synthetic */ LinearLayout.LayoutParams m7479generateLayoutParams(LayoutParams layoutParams) {
        return m145a(layoutParams);
    }

    public AppBarLayout(Context context) {
        this(context, null);
    }

    public AppBarLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f100b = -1;
        this.f101c = -1;
        this.f102d = -1;
        this.f104f = 0;
        setOrientation(1);
        ca.m3958a(context);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0065h.AppBarLayout, 0, C0064g.Widget_Design_AppBarLayout);
        this.f103e = (float) obtainStyledAttributes.getDimensionPixelSize(C0065h.AppBarLayout_elevation, 0);
        setBackgroundDrawable(obtainStyledAttributes.getDrawable(C0065h.AppBarLayout_android_background));
        if (obtainStyledAttributes.hasValue(C0065h.AppBarLayout_expanded)) {
            setExpanded(obtainStyledAttributes.getBoolean(C0065h.AppBarLayout_expanded, false));
        }
        obtainStyledAttributes.recycle();
        cx.m5235a(this);
        this.f106h = new ArrayList();
        iv.m5926e((View) this, this.f103e);
        iv.m5909a((View) this, new ab(this));
    }

    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        m146a();
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        m146a();
        this.f99a = false;
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            if (((af) getChildAt(i5).getLayoutParams()).f1388b != null) {
                this.f99a = true;
                return;
            }
        }
    }

    private void m146a() {
        this.f100b = -1;
        this.f101c = -1;
        this.f102d = -1;
    }

    public void setOrientation(int i) {
        if (i != 1) {
            throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation");
        }
        super.setOrientation(i);
    }

    public void setExpanded(boolean z) {
        boolean E = iv.m5895E(this);
        this.f104f = (E ? 4 : 0) | (z ? 1 : 2);
        requestLayout();
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof af;
    }

    private af m144a(AttributeSet attributeSet) {
        return new af(getContext(), attributeSet);
    }

    private static af m145a(LayoutParams layoutParams) {
        if (layoutParams instanceof LinearLayout.LayoutParams) {
            return new af((LinearLayout.LayoutParams) layoutParams);
        }
        if (layoutParams instanceof MarginLayoutParams) {
            return new af((MarginLayoutParams) layoutParams);
        }
        return new af(layoutParams);
    }

    public final int getTotalScrollRange() {
        if (this.f100b != -1) {
            return this.f100b;
        }
        int t;
        int childCount = getChildCount();
        int i = 0;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            af afVar = (af) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i3 = afVar.f1387a;
            if ((i3 & 1) == 0) {
                break;
            }
            i += afVar.bottomMargin + (measuredHeight + afVar.topMargin);
            if ((i3 & 2) != 0) {
                t = i - iv.m5943t(childAt);
                break;
            }
        }
        t = i;
        t = Math.max(0, t - getTopInset());
        this.f100b = t;
        return t;
    }

    private int getUpNestedPreScrollRange() {
        return getTotalScrollRange();
    }

    private int getDownNestedPreScrollRange() {
        if (this.f101c != -1) {
            return this.f101c;
        }
        int i = 0;
        int childCount = getChildCount() - 1;
        while (childCount >= 0) {
            int i2;
            View childAt = getChildAt(childCount);
            af afVar = (af) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i3 = afVar.f1387a;
            if ((i3 & 5) != 5) {
                if (i > 0) {
                    break;
                }
                i2 = i;
            } else {
                i2 = (afVar.bottomMargin + afVar.topMargin) + i;
                if ((i3 & 8) != 0) {
                    i2 += iv.m5943t(childAt);
                } else {
                    i2 += measuredHeight;
                }
            }
            childCount--;
            i = i2;
        }
        this.f101c = i;
        return i;
    }

    private int getDownNestedScrollRange() {
        if (this.f102d != -1) {
            return this.f102d;
        }
        int i;
        int childCount = getChildCount();
        int i2 = 0;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            af afVar = (af) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight() + (afVar.topMargin + afVar.bottomMargin);
            i = afVar.f1387a;
            if ((i & 1) == 0) {
                break;
            }
            i2 += measuredHeight;
            if ((i & 2) != 0) {
                i = i2 - (iv.m5943t(childAt) + getTopInset());
                break;
            }
        }
        i = i2;
        i = Math.max(0, i);
        this.f102d = i;
        return i;
    }

    final int getMinimumHeightForVisibleOverlappingContent() {
        int b = this.f105g != null ? this.f105g.m6284b() : 0;
        int t = iv.m5943t(this);
        if (t != 0) {
            return (t * 2) + b;
        }
        t = getChildCount();
        if (t > 0) {
            return (iv.m5943t(getChildAt(t - 1)) * 2) + b;
        }
        return 0;
    }

    public void setTargetElevation(float f) {
        this.f103e = f;
    }

    public float getTargetElevation() {
        return this.f103e;
    }

    private int getPendingAction() {
        return this.f104f;
    }

    private int getTopInset() {
        return this.f105g != null ? this.f105g.m6284b() : 0;
    }

    private void setWindowInsets(lm lmVar) {
        this.f100b = -1;
        this.f105g = lmVar;
        int i = 0;
        int childCount = getChildCount();
        while (i < childCount) {
            lmVar = iv.m5914b(getChildAt(i), lmVar);
            if (!lmVar.m6287e()) {
                i++;
            } else {
                return;
            }
        }
    }

    protected /* synthetic */ LinearLayout.LayoutParams m7477generateDefaultLayoutParams() {
        return new af();
    }

    protected /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        return new af();
    }

    static /* synthetic */ boolean m148a(AppBarLayout appBarLayout) {
        return appBarLayout.getTotalScrollRange() != 0;
    }
}
