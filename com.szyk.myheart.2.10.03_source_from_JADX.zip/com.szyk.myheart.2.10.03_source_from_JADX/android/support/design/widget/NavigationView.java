package android.support.design.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.design.internal.NavigationMenuView;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.widget.LinearLayout;
import happy.hacking.C0001y;
import happy.hacking.C0059c;
import happy.hacking.C0063f;
import happy.hacking.C0064g;
import happy.hacking.C0065h;
import happy.hacking.C0066j;
import happy.hacking.C0067k;
import happy.hacking.C0071n;
import happy.hacking.at;
import happy.hacking.au;
import happy.hacking.av;
import happy.hacking.ca;
import happy.hacking.dm;
import happy.hacking.et;
import happy.hacking.iv;
import happy.hacking.qz;
import happy.hacking.rr;
import happy.hacking.ug;

public class NavigationView extends C0001y {
    private static final int[] f146b;
    private static final int[] f147c;
    public final C0067k f148a;
    private final C0066j f149d;
    private au f150e;
    private int f151f;
    private MenuInflater f152g;

    public class SavedState extends BaseSavedState {
        public static final Creator CREATOR;
        public Bundle f142a;

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel);
            this.f142a = parcel.readBundle(classLoader);
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeBundle(this.f142a);
        }

        static {
            CREATOR = et.m5596a(new av());
        }
    }

    static {
        f146b = new int[]{16842912};
        f147c = new int[]{-16842910};
    }

    public NavigationView(Context context) {
        this(context, null);
    }

    public NavigationView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NavigationView(Context context, AttributeSet attributeSet, int i) {
        ColorStateList colorStateList;
        int resourceId;
        super(context, attributeSet, i);
        this.f148a = new C0067k();
        ca.m3958a(context);
        this.f149d = new C0066j(context);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0065h.NavigationView, i, C0064g.Widget_Design_NavigationView);
        setBackgroundDrawable(obtainStyledAttributes.getDrawable(C0065h.NavigationView_android_background));
        if (obtainStyledAttributes.hasValue(C0065h.NavigationView_elevation)) {
            iv.m5926e((View) this, (float) obtainStyledAttributes.getDimensionPixelSize(C0065h.NavigationView_elevation, 0));
        }
        iv.m5912a((View) this, obtainStyledAttributes.getBoolean(C0065h.NavigationView_android_fitsSystemWindows, false));
        this.f151f = obtainStyledAttributes.getDimensionPixelSize(C0065h.NavigationView_android_maxWidth, 0);
        if (obtainStyledAttributes.hasValue(C0065h.NavigationView_itemIconTint)) {
            colorStateList = obtainStyledAttributes.getColorStateList(C0065h.NavigationView_itemIconTint);
        } else {
            colorStateList = m182b(16842808);
        }
        if (obtainStyledAttributes.hasValue(C0065h.NavigationView_itemTextAppearance)) {
            resourceId = obtainStyledAttributes.getResourceId(C0065h.NavigationView_itemTextAppearance, 0);
            int i2 = 1;
        } else {
            resourceId = 0;
            boolean z = false;
        }
        ColorStateList colorStateList2 = null;
        if (obtainStyledAttributes.hasValue(C0065h.NavigationView_itemTextColor)) {
            colorStateList2 = obtainStyledAttributes.getColorStateList(C0065h.NavigationView_itemTextColor);
        }
        if (i2 == 0 && r5 == null) {
            colorStateList2 = m182b(16842806);
        }
        Drawable drawable = obtainStyledAttributes.getDrawable(C0065h.NavigationView_itemBackground);
        this.f149d.m6094a(new at(this));
        this.f148a.f5723d = 1;
        this.f148a.m6176a(context, this.f149d);
        this.f148a.m6177a(colorStateList);
        if (i2 != 0) {
            this.f148a.m6175a(resourceId);
        }
        this.f148a.m6186b(colorStateList2);
        this.f148a.f5730k = drawable;
        this.f149d.m6095a(this.f148a);
        C0067k c0067k = this.f148a;
        if (c0067k.f5720a == null) {
            c0067k.f5720a = (NavigationMenuView) c0067k.f5725f.inflate(C0063f.design_navigation_menu, this, false);
            if (c0067k.f5724e == null) {
                c0067k.f5724e = new C0071n(c0067k);
            }
            c0067k.f5721b = (LinearLayout) c0067k.f5725f.inflate(C0063f.design_navigation_item_header, c0067k.f5720a, false);
            c0067k.f5720a.setAdapter(c0067k.f5724e);
        }
        addView(c0067k.f5720a);
        if (obtainStyledAttributes.hasValue(C0065h.NavigationView_menu)) {
            m183a(obtainStyledAttributes.getResourceId(C0065h.NavigationView_menu, 0));
        }
        if (obtainStyledAttributes.hasValue(C0065h.NavigationView_headerLayout)) {
            int resourceId2 = obtainStyledAttributes.getResourceId(C0065h.NavigationView_headerLayout, 0);
            c0067k = this.f148a;
            c0067k.m6179a(c0067k.f5725f.inflate(resourceId2, c0067k.f5721b, false));
        }
        obtainStyledAttributes.recycle();
    }

    protected Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        savedState.f142a = new Bundle();
        this.f149d.m6093a(savedState.f142a);
        return savedState;
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.f149d.m6102b(savedState.f142a);
    }

    public void setNavigationItemSelectedListener(au auVar) {
        this.f150e = auVar;
    }

    protected void onMeasure(int i, int i2) {
        switch (MeasureSpec.getMode(i)) {
            case Integer.MIN_VALUE:
                i = MeasureSpec.makeMeasureSpec(Math.min(MeasureSpec.getSize(i), this.f151f), 1073741824);
                break;
            case ug.RecyclerView_android_orientation /*0*/:
                i = MeasureSpec.makeMeasureSpec(this.f151f, 1073741824);
                break;
        }
        super.onMeasure(i, i2);
    }

    public final void m183a(int i) {
        this.f148a.m6187b(true);
        getMenuInflater().inflate(i, this.f149d);
        this.f148a.m6187b(false);
        this.f148a.m6181a(false);
    }

    public Menu getMenu() {
        return this.f149d;
    }

    public ColorStateList getItemIconTintList() {
        return this.f148a.f5729j;
    }

    public void setItemIconTintList(ColorStateList colorStateList) {
        this.f148a.m6177a(colorStateList);
    }

    public ColorStateList getItemTextColor() {
        return this.f148a.f5728i;
    }

    public void setItemTextColor(ColorStateList colorStateList) {
        this.f148a.m6186b(colorStateList);
    }

    public Drawable getItemBackground() {
        return this.f148a.f5730k;
    }

    public void setItemBackgroundResource(int i) {
        setItemBackground(dm.getDrawable(getContext(), i));
    }

    public void setItemBackground(Drawable drawable) {
        this.f148a.f5730k = drawable;
    }

    public void setCheckedItem(int i) {
        MenuItem findItem = this.f149d.findItem(i);
        if (findItem != null) {
            this.f148a.f5724e.m6525a((rr) findItem);
        }
    }

    public void setItemTextAppearance(int i) {
        this.f148a.m6175a(i);
    }

    private MenuInflater getMenuInflater() {
        if (this.f152g == null) {
            this.f152g = new qz(getContext());
        }
        return this.f152g;
    }

    private ColorStateList m182b(int i) {
        TypedValue typedValue = new TypedValue();
        if (!getContext().getTheme().resolveAttribute(i, typedValue, true)) {
            return null;
        }
        ColorStateList colorStateList = getResources().getColorStateList(typedValue.resourceId);
        if (!getContext().getTheme().resolveAttribute(C0059c.colorPrimary, typedValue, true)) {
            return null;
        }
        int i2 = typedValue.data;
        int defaultColor = colorStateList.getDefaultColor();
        return new ColorStateList(new int[][]{f147c, f146b, EMPTY_STATE_SET}, new int[]{colorStateList.getColorForState(f147c, defaultColor), i2, defaultColor});
    }
}
