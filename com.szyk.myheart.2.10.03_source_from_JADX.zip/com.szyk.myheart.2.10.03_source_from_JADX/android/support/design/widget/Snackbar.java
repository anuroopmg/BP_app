package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import happy.hacking.C0058b;
import happy.hacking.C0060d;
import happy.hacking.C0062e;
import happy.hacking.C0063f;
import happy.hacking.C0065h;
import happy.hacking.aa;
import happy.hacking.aw;
import happy.hacking.bc;
import happy.hacking.bd;
import happy.hacking.bg;
import happy.hacking.bh;
import happy.hacking.bi;
import happy.hacking.bj;
import happy.hacking.bl;
import happy.hacking.iv;

public final class Snackbar {
    private static final Handler f159d;
    public final ViewGroup f160a;
    public final SnackbarLayout f161b;
    public final bl f162c;
    private bg f163e;

    public class SnackbarLayout extends LinearLayout {
        public TextView f153a;
        public Button f154b;
        private int f155c;
        private int f156d;
        private bi f157e;
        private bh f158f;

        public SnackbarLayout(Context context) {
            this(context, null);
        }

        public SnackbarLayout(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0065h.SnackbarLayout);
            this.f155c = obtainStyledAttributes.getDimensionPixelSize(C0065h.SnackbarLayout_android_maxWidth, -1);
            this.f156d = obtainStyledAttributes.getDimensionPixelSize(C0065h.SnackbarLayout_maxActionInlineWidth, -1);
            if (obtainStyledAttributes.hasValue(C0065h.SnackbarLayout_elevation)) {
                iv.m5926e((View) this, (float) obtainStyledAttributes.getDimensionPixelSize(C0065h.SnackbarLayout_elevation, 0));
            }
            obtainStyledAttributes.recycle();
            setClickable(true);
            LayoutInflater.from(context).inflate(C0063f.design_layout_snackbar_include, this);
            iv.m5937n(this);
        }

        protected void onFinishInflate() {
            super.onFinishInflate();
            this.f153a = (TextView) findViewById(C0062e.snackbar_text);
            this.f154b = (Button) findViewById(C0062e.snackbar_action);
        }

        TextView getMessageView() {
            return this.f153a;
        }

        Button getActionView() {
            return this.f154b;
        }

        protected void onMeasure(int i, int i2) {
            super.onMeasure(i, i2);
            if (this.f155c > 0 && getMeasuredWidth() > this.f155c) {
                i = MeasureSpec.makeMeasureSpec(this.f155c, 1073741824);
                super.onMeasure(i, i2);
            }
            int dimensionPixelSize = getResources().getDimensionPixelSize(C0060d.design_snackbar_padding_vertical_2lines);
            int dimensionPixelSize2 = getResources().getDimensionPixelSize(C0060d.design_snackbar_padding_vertical);
            int i3 = this.f153a.getLayout().getLineCount() > 1 ? 1 : 0;
            if (i3 == 0 || this.f156d <= 0 || this.f154b.getMeasuredWidth() <= this.f156d) {
                if (i3 == 0) {
                    dimensionPixelSize = dimensionPixelSize2;
                }
                if (m184a(0, dimensionPixelSize, dimensionPixelSize)) {
                    dimensionPixelSize = 1;
                }
                dimensionPixelSize = 0;
            } else {
                if (m184a(1, dimensionPixelSize, dimensionPixelSize - dimensionPixelSize2)) {
                    dimensionPixelSize = 1;
                }
                dimensionPixelSize = 0;
            }
            if (dimensionPixelSize != 0) {
                super.onMeasure(i, i2);
            }
        }

        protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
            super.onLayout(z, i, i2, i3, i4);
            if (z && this.f157e != null) {
                this.f157e.m2459a();
            }
        }

        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
        }

        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (this.f158f != null) {
                this.f158f.m2422a();
            }
        }

        public void setOnLayoutChangeListener(bi biVar) {
            this.f157e = biVar;
        }

        public void setOnAttachStateChangeListener(bh bhVar) {
            this.f158f = bhVar;
        }

        private boolean m184a(int i, int i2, int i3) {
            boolean z = false;
            if (i != getOrientation()) {
                setOrientation(i);
                z = true;
            }
            if (this.f153a.getPaddingTop() == i2 && this.f153a.getPaddingBottom() == i3) {
                return z;
            }
            View view = this.f153a;
            if (iv.m5893C(view)) {
                iv.m5905a(view, iv.m5938o(view), i2, iv.m5939p(view), i3);
            } else {
                view.setPadding(view.getPaddingLeft(), i2, view.getPaddingRight(), i3);
            }
            return true;
        }
    }

    static {
        f159d = new Handler(Looper.getMainLooper(), new aw());
    }

    public final void m192a() {
        if (VERSION.SDK_INT >= 14) {
            iv.m5915b(this.f161b, (float) this.f161b.getHeight());
            iv.m5944u(this.f161b).m6238c(0.0f).m6231a(aa.f1045b).m6230a(250).m6232a(new bc(this)).m6237b();
            return;
        }
        Animation loadAnimation = AnimationUtils.loadAnimation(this.f161b.getContext(), C0058b.design_snackbar_in);
        loadAnimation.setInterpolator(aa.f1045b);
        loadAnimation.setDuration(250);
        loadAnimation.setAnimationListener(new bd(this));
        this.f161b.startAnimation(loadAnimation);
    }

    public final void m193b() {
        ViewParent parent = this.f161b.getParent();
        if (parent instanceof ViewGroup) {
            ((ViewGroup) parent).removeView(this.f161b);
        }
        bj a = bj.m2780a();
        bl blVar = this.f162c;
        synchronized (a.f2729a) {
            if (a.m2787e(blVar)) {
                a.f2730b = null;
                if (!(a.f2731c == null || a.f2731c == null)) {
                    a.f2730b = a.f2731c;
                    a.f2731c = null;
                    if (((bl) a.f2730b.f2823a.get()) == null) {
                        a.f2730b = null;
                    }
                }
            }
        }
    }

    public static /* synthetic */ void m185a(Snackbar snackbar) {
        bj a = bj.m2780a();
        bl blVar = snackbar.f162c;
        synchronized (a.f2729a) {
            if (a.m2787e(blVar)) {
                bj.m2781a(a.f2730b);
            } else if (a.m2788f(blVar)) {
                bj.m2781a(a.f2731c);
            }
        }
    }
}
