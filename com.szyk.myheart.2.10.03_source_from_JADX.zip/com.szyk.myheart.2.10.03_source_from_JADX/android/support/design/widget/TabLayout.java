package android.support.design.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout.LayoutParams;
import happy.hacking.C0020if;
import happy.hacking.C0060d;
import happy.hacking.C0064g;
import happy.hacking.C0065h;
import happy.hacking.aa;
import happy.hacking.bq;
import happy.hacking.br;
import happy.hacking.bs;
import happy.hacking.bt;
import happy.hacking.bw;
import happy.hacking.bx;
import happy.hacking.by;
import happy.hacking.bz;
import happy.hacking.ca;
import happy.hacking.cb;
import happy.hacking.cx;
import happy.hacking.iv;
import happy.hacking.ug;
import java.util.ArrayList;
import java.util.Iterator;

public class TabLayout extends HorizontalScrollView {
    private final ArrayList f174a;
    private bw f175b;
    private final bt f176c;
    private int f177d;
    private int f178e;
    private int f179f;
    private int f180g;
    private int f181h;
    private ColorStateList f182i;
    private float f183j;
    private float f184k;
    private final int f185l;
    private int f186m;
    private final int f187n;
    private final int f188o;
    private final int f189p;
    private int f190q;
    private int f191r;
    private int f192s;
    private bs f193t;
    private OnClickListener f194u;
    private cb f195v;
    private cb f196w;

    public TabLayout(Context context) {
        this(context, null);
    }

    public TabLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TabLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f174a = new ArrayList();
        this.f186m = Integer.MAX_VALUE;
        ca.m3958a(context);
        setHorizontalScrollBarEnabled(false);
        this.f176c = new bt(this, context);
        addView(this.f176c, -2, -1);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0065h.TabLayout, i, C0064g.Widget_Design_TabLayout);
        this.f176c.m3408b(obtainStyledAttributes.getDimensionPixelSize(C0065h.TabLayout_tabIndicatorHeight, 0));
        this.f176c.m3406a(obtainStyledAttributes.getColor(C0065h.TabLayout_tabIndicatorColor, 0));
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(C0065h.TabLayout_tabPadding, 0);
        this.f180g = dimensionPixelSize;
        this.f179f = dimensionPixelSize;
        this.f178e = dimensionPixelSize;
        this.f177d = dimensionPixelSize;
        this.f177d = obtainStyledAttributes.getDimensionPixelSize(C0065h.TabLayout_tabPaddingStart, this.f177d);
        this.f178e = obtainStyledAttributes.getDimensionPixelSize(C0065h.TabLayout_tabPaddingTop, this.f178e);
        this.f179f = obtainStyledAttributes.getDimensionPixelSize(C0065h.TabLayout_tabPaddingEnd, this.f179f);
        this.f180g = obtainStyledAttributes.getDimensionPixelSize(C0065h.TabLayout_tabPaddingBottom, this.f180g);
        this.f181h = obtainStyledAttributes.getResourceId(C0065h.TabLayout_tabTextAppearance, C0064g.TextAppearance_Design_Tab);
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(this.f181h, C0065h.TextAppearance);
        try {
            this.f183j = (float) obtainStyledAttributes2.getDimensionPixelSize(C0065h.TextAppearance_android_textSize, 0);
            this.f182i = obtainStyledAttributes2.getColorStateList(C0065h.TextAppearance_android_textColor);
            if (obtainStyledAttributes.hasValue(C0065h.TabLayout_tabTextColor)) {
                this.f182i = obtainStyledAttributes.getColorStateList(C0065h.TabLayout_tabTextColor);
            }
            if (obtainStyledAttributes.hasValue(C0065h.TabLayout_tabSelectedTextColor)) {
                dimensionPixelSize = obtainStyledAttributes.getColor(C0065h.TabLayout_tabSelectedTextColor, 0);
                int defaultColor = this.f182i.getDefaultColor();
                r3 = new int[2][];
                int[] iArr = new int[]{SELECTED_STATE_SET, dimensionPixelSize};
                r3[1] = EMPTY_STATE_SET;
                iArr[1] = defaultColor;
                this.f182i = new ColorStateList(r3, iArr);
            }
            this.f187n = obtainStyledAttributes.getDimensionPixelSize(C0065h.TabLayout_tabMinWidth, -1);
            this.f188o = obtainStyledAttributes.getDimensionPixelSize(C0065h.TabLayout_tabMaxWidth, -1);
            this.f185l = obtainStyledAttributes.getResourceId(C0065h.TabLayout_tabBackground, 0);
            this.f190q = obtainStyledAttributes.getDimensionPixelSize(C0065h.TabLayout_tabContentStart, 0);
            this.f192s = obtainStyledAttributes.getInt(C0065h.TabLayout_tabMode, 1);
            this.f191r = obtainStyledAttributes.getInt(C0065h.TabLayout_tabGravity, 0);
            obtainStyledAttributes.recycle();
            Resources resources = getResources();
            this.f184k = (float) resources.getDimensionPixelSize(C0060d.design_tab_text_size_2line);
            this.f189p = resources.getDimensionPixelSize(C0060d.design_tab_scrollable_min_width);
            m215b();
        } finally {
            obtainStyledAttributes2.recycle();
        }
    }

    public void setSelectedTabIndicatorColor(int i) {
        this.f176c.m3406a(i);
    }

    public void setSelectedTabIndicatorHeight(int i) {
        this.f176c.m3408b(i);
    }

    public final void m234a(int i, float f, boolean z) {
        if ((this.f196w == null || !this.f196w.f3890a.m4428b()) && i >= 0 && i < this.f176c.getChildCount()) {
            bt btVar = this.f176c;
            btVar.f3241a = i;
            btVar.f3242b = f;
            btVar.m3405a();
            scrollTo(m206a(i, f), 0);
            if (z) {
                setSelectedTabView(Math.round(((float) i) + f));
            }
        }
    }

    private float getScrollPosition() {
        bt btVar = this.f176c;
        return btVar.f3242b + ((float) btVar.f3241a);
    }

    public final void m235a(bw bwVar) {
        boolean isEmpty = this.f174a.isEmpty();
        if (bwVar.f3539f != this) {
            throw new IllegalArgumentException("Tab belongs to a different TabLayout.");
        }
        View byVar = new by(this, getContext(), bwVar);
        byVar.setFocusable(true);
        byVar.setMinimumWidth(getTabMinWidth());
        if (this.f194u == null) {
            this.f194u = new bq(this);
        }
        byVar.setOnClickListener(this.f194u);
        bt btVar = this.f176c;
        LayoutParams layoutParams = new LayoutParams(-2, -1);
        m210a(layoutParams);
        btVar.addView(byVar, layoutParams);
        if (isEmpty) {
            byVar.setSelected(true);
        }
        m211a(bwVar, this.f174a.size());
        if (isEmpty) {
            bwVar.m3594a();
        }
    }

    public void setOnTabSelectedListener(bs bsVar) {
        this.f193t = bsVar;
    }

    public final bw m232a() {
        return new bw(this);
    }

    public int getTabCount() {
        return this.f174a.size();
    }

    public final bw m233a(int i) {
        return (bw) this.f174a.get(i);
    }

    public int getSelectedTabPosition() {
        if (this.f175b != null) {
            return this.f175b.f3537d;
        }
        return -1;
    }

    public void setTabMode(int i) {
        if (i != this.f192s) {
            this.f192s = i;
            m215b();
        }
    }

    public int getTabMode() {
        return this.f192s;
    }

    public void setTabGravity(int i) {
        if (this.f191r != i) {
            this.f191r = i;
            m215b();
        }
    }

    public int getTabGravity() {
        return this.f191r;
    }

    public void setTabTextColors(ColorStateList colorStateList) {
        if (this.f182i != colorStateList) {
            this.f182i = colorStateList;
            int childCount = this.f176c.getChildCount();
            for (int i = 0; i < childCount; i++) {
                m216b(i);
            }
        }
    }

    public ColorStateList getTabTextColors() {
        return this.f182i;
    }

    public void setupWithViewPager(ViewPager viewPager) {
        C0020if adapter = viewPager.getAdapter();
        if (adapter == null) {
            throw new IllegalArgumentException("ViewPager does not have a PagerAdapter set");
        }
        setTabsFromPagerAdapter(adapter);
        viewPager.m274a(new bx(this));
        setOnTabSelectedListener(new bz(viewPager));
        if (adapter.getCount() > 0) {
            int currentItem = viewPager.getCurrentItem();
            if (getSelectedTabPosition() != currentItem) {
                m236a(m233a(currentItem), true);
            }
        }
    }

    private void m216b(int i) {
        by byVar = (by) this.f176c.getChildAt(i);
        if (byVar != null) {
            byVar.m3802a();
        }
    }

    private void m210a(LayoutParams layoutParams) {
        if (this.f192s == 1 && this.f191r == 0) {
            layoutParams.width = 0;
            layoutParams.weight = 1.0f;
            return;
        }
        layoutParams.width = -2;
        layoutParams.weight = 0.0f;
    }

    private int m217c(int i) {
        return Math.round(getResources().getDisplayMetrics().density * ((float) i));
    }

    protected void onMeasure(int i, int i2) {
        int i3 = 1;
        int c = (m217c(getDefaultHeight()) + getPaddingTop()) + getPaddingBottom();
        switch (MeasureSpec.getMode(i2)) {
            case Integer.MIN_VALUE:
                i2 = MeasureSpec.makeMeasureSpec(Math.min(c, MeasureSpec.getSize(i2)), 1073741824);
                break;
            case ug.RecyclerView_android_orientation /*0*/:
                i2 = MeasureSpec.makeMeasureSpec(c, 1073741824);
                break;
        }
        c = MeasureSpec.getSize(i);
        if (MeasureSpec.getMode(i) != 0) {
            if (this.f188o > 0) {
                c = this.f188o;
            } else {
                c -= m217c(56);
            }
            this.f186m = c;
        }
        super.onMeasure(i, i2);
        if (getChildCount() == 1) {
            View childAt = getChildAt(0);
            switch (this.f192s) {
                case ug.RecyclerView_android_orientation /*0*/:
                    if (childAt.getMeasuredWidth() >= getMeasuredWidth()) {
                        c = 0;
                        break;
                    } else {
                        c = 1;
                        break;
                    }
                case ug.RecyclerView_layoutManager /*1*/:
                    if (childAt.getMeasuredWidth() == getMeasuredWidth()) {
                        i3 = 0;
                    }
                    c = i3;
                    break;
                default:
                    c = 0;
                    break;
            }
            if (c != 0) {
                childAt.measure(MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), getChildMeasureSpec(i2, getPaddingTop() + getPaddingBottom(), childAt.getLayoutParams().height));
            }
        }
    }

    private void m220d(int i) {
        boolean z = false;
        if (i != -1) {
            if (getWindowToken() != null && iv.m5895E(this)) {
                bt btVar = this.f176c;
                int childCount = btVar.getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    if (btVar.getChildAt(i2).getWidth() <= 0) {
                        z = true;
                        break;
                    }
                }
                if (!z) {
                    int scrollX = getScrollX();
                    int a = m206a(i, 0.0f);
                    if (scrollX != a) {
                        if (this.f195v == null) {
                            this.f195v = cx.m5234a();
                            this.f195v.m4026a(aa.f1045b);
                            this.f195v.m4024a(300);
                            this.f195v.m4027a(new br(this));
                        }
                        this.f195v.m4025a(scrollX, a);
                        this.f195v.f3890a.m4422a();
                    }
                    this.f176c.m3407a(i, 300);
                    return;
                }
            }
            m234a(i, 0.0f, true);
        }
    }

    private void setSelectedTabView(int i) {
        int childCount = this.f176c.getChildCount();
        if (i < childCount && !this.f176c.getChildAt(i).isSelected()) {
            for (int i2 = 0; i2 < childCount; i2++) {
                boolean z;
                View childAt = this.f176c.getChildAt(i2);
                if (i2 == i) {
                    z = true;
                } else {
                    z = false;
                }
                childAt.setSelected(z);
            }
        }
    }

    public final void m236a(bw bwVar, boolean z) {
        if (this.f175b != bwVar) {
            if (z) {
                int i;
                if (bwVar != null) {
                    i = bwVar.f3537d;
                } else {
                    i = -1;
                }
                if (i != -1) {
                    setSelectedTabView(i);
                }
                if ((this.f175b == null || this.f175b.f3537d == -1) && i != -1) {
                    m234a(i, 0.0f, true);
                } else {
                    m220d(i);
                }
            }
            this.f175b = bwVar;
            if (this.f175b != null && this.f193t != null) {
                this.f193t.m3335a(this.f175b);
            }
        } else if (this.f175b != null) {
            m220d(bwVar.f3537d);
        }
    }

    private int m206a(int i, float f) {
        int i2 = 0;
        if (this.f192s != 0) {
            return 0;
        }
        int width;
        View childAt = this.f176c.getChildAt(i);
        View childAt2 = i + 1 < this.f176c.getChildCount() ? this.f176c.getChildAt(i + 1) : null;
        if (childAt != null) {
            width = childAt.getWidth();
        } else {
            width = 0;
        }
        if (childAt2 != null) {
            i2 = childAt2.getWidth();
        }
        return ((((int) ((((float) (i2 + width)) * f) * 0.5f)) + childAt.getLeft()) + (childAt.getWidth() / 2)) - (getWidth() / 2);
    }

    private void m215b() {
        int max;
        if (this.f192s == 0) {
            max = Math.max(0, this.f190q - this.f177d);
        } else {
            max = 0;
        }
        iv.m5905a(this.f176c, max, 0, 0, 0);
        switch (this.f192s) {
            case ug.RecyclerView_android_orientation /*0*/:
                this.f176c.setGravity(8388611);
                break;
            case ug.RecyclerView_layoutManager /*1*/:
                this.f176c.setGravity(1);
                break;
        }
        m212a(true);
    }

    private void m212a(boolean z) {
        for (int i = 0; i < this.f176c.getChildCount(); i++) {
            View childAt = this.f176c.getChildAt(i);
            childAt.setMinimumWidth(getTabMinWidth());
            m210a((LayoutParams) childAt.getLayoutParams());
            if (z) {
                childAt.requestLayout();
            }
        }
    }

    private int getDefaultHeight() {
        Object obj;
        int size = this.f174a.size();
        for (int i = 0; i < size; i++) {
            bw bwVar = (bw) this.f174a.get(i);
            if (bwVar != null && bwVar.f3534a != null && !TextUtils.isEmpty(bwVar.f3535b)) {
                obj = 1;
                break;
            }
        }
        obj = null;
        if (obj != null) {
            return 72;
        }
        return 48;
    }

    private int getTabMinWidth() {
        if (this.f187n != -1) {
            return this.f187n;
        }
        return this.f192s == 0 ? this.f189p : 0;
    }

    private int getTabMaxWidth() {
        return this.f186m;
    }

    public void setTabsFromPagerAdapter(C0020if c0020if) {
        this.f176c.removeAllViews();
        Iterator it = this.f174a.iterator();
        while (it.hasNext()) {
            ((bw) it.next()).f3537d = -1;
            it.remove();
        }
        this.f175b = null;
        int count = c0020if.getCount();
        for (int i = 0; i < count; i++) {
            m235a(m232a().m3593a(c0020if.getPageTitle(i)));
        }
    }

    private void m211a(bw bwVar, int i) {
        bwVar.f3537d = i;
        this.f174a.add(i, bwVar);
        int size = this.f174a.size();
        for (int i2 = i + 1; i2 < size; i2++) {
            ((bw) this.f174a.get(i2)).f3537d = i2;
        }
    }
}
