package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import happy.hacking.dm;
import happy.hacking.dx;
import happy.hacking.gr;
import happy.hacking.gv;
import happy.hacking.iv;
import happy.hacking.js;
import happy.hacking.np;
import happy.hacking.nq;
import happy.hacking.nr;
import happy.hacking.ns;
import happy.hacking.nt;
import happy.hacking.nu;
import happy.hacking.nv;
import happy.hacking.nw;
import happy.hacking.nx;
import happy.hacking.ob;
import happy.hacking.pj;
import happy.hacking.py;
import happy.hacking.ug;
import java.util.ArrayList;

public class DrawerLayout extends ViewGroup implements ob {
    static final nr f292h;
    private static final int[] f293i;
    private static final boolean f294j;
    private static final boolean f295k;
    private Drawable f296A;
    private Drawable f297B;
    private Drawable f298C;
    private Object f299D;
    private boolean f300E;
    private Drawable f301F;
    private Drawable f302G;
    private Drawable f303H;
    private Drawable f304I;
    private final ArrayList f305J;
    public final pj f306a;
    public final pj f307b;
    public int f308c;
    public boolean f309d;
    public nu f310e;
    public CharSequence f311f;
    public CharSequence f312g;
    private final nq f313l;
    private float f314m;
    private int f315n;
    private int f316o;
    private float f317p;
    private Paint f318q;
    private final nx f319r;
    private final nx f320s;
    private boolean f321t;
    private boolean f322u;
    private int f323v;
    private int f324w;
    private boolean f325x;
    private float f326y;
    private float f327z;

    public class SavedState extends BaseSavedState {
        public static final Creator CREATOR;
        int f289a;
        int f290b;
        int f291c;

        public SavedState(Parcel parcel) {
            super(parcel);
            this.f289a = 0;
            this.f290b = 0;
            this.f291c = 0;
            this.f289a = parcel.readInt();
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
            this.f289a = 0;
            this.f290b = 0;
            this.f291c = 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f289a);
        }

        static {
            CREATOR = new nw();
        }
    }

    static {
        boolean z = true;
        f293i = new int[]{16842931};
        f294j = VERSION.SDK_INT >= 19;
        if (VERSION.SDK_INT < 21) {
            z = false;
        }
        f295k = z;
        if (VERSION.SDK_INT >= 21) {
            f292h = new ns();
        } else {
            f292h = new nt();
        }
    }

    public DrawerLayout(Context context) {
        this(context, null);
    }

    public DrawerLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public DrawerLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f313l = new nq(this);
        this.f316o = -1728053248;
        this.f318q = new Paint();
        this.f322u = true;
        this.f301F = null;
        this.f302G = null;
        this.f303H = null;
        this.f304I = null;
        setDescendantFocusability(262144);
        float f = getResources().getDisplayMetrics().density;
        this.f315n = (int) ((64.0f * f) + 0.5f);
        float f2 = 400.0f * f;
        this.f319r = new nx(this, 3);
        this.f320s = new nx(this, 5);
        this.f306a = pj.m6740a((ViewGroup) this, 1.0f, this.f319r);
        this.f306a.f5900j = 1;
        this.f306a.f5898h = f2;
        this.f319r.f5868b = this.f306a;
        this.f307b = pj.m6740a((ViewGroup) this, 1.0f, this.f320s);
        this.f307b.f5900j = 2;
        this.f307b.f5898h = f2;
        this.f320s.f5868b = this.f307b;
        setFocusableInTouchMode(true);
        iv.m5920c((View) this, 1);
        iv.m5908a((View) this, new np(this));
        js.m6171a(this);
        if (iv.m5948y(this)) {
            f292h.m6583a((View) this);
            this.f296A = f292h.m6582a(context);
        }
        this.f314m = f * 10.0f;
        this.f305J = new ArrayList();
    }

    public void setDrawerElevation(float f) {
        this.f314m = f;
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (m285d(childAt)) {
                iv.m5926e(childAt, this.f314m);
            }
        }
    }

    public float getDrawerElevation() {
        if (f295k) {
            return this.f314m;
        }
        return 0.0f;
    }

    public final void m298a(Object obj, boolean z) {
        this.f299D = obj;
        this.f300E = z;
        boolean z2 = !z && getBackground() == null;
        setWillNotDraw(z2);
        requestLayout();
    }

    public void setScrimColor(int i) {
        this.f316o = i;
        invalidate();
    }

    public void setDrawerListener(nu nuVar) {
        this.f310e = nuVar;
    }

    public void setDrawerLockMode(int i) {
        m279a(i, 3);
        m279a(i, 5);
    }

    private void m279a(int i, int i2) {
        int a = gr.m5763a(i2, iv.m5931h(this));
        if (a == 3) {
            this.f323v = i;
        } else if (a == 5) {
            this.f324w = i;
        }
        if (i != 0) {
            (a == 3 ? this.f306a : this.f307b).m6753a();
        }
        View a2;
        switch (i) {
            case ug.RecyclerView_layoutManager /*1*/:
                a2 = m294a(a);
                if (a2 != null) {
                    m305e(a2);
                }
            case ug.RecyclerView_spanCount /*2*/:
                a2 = m294a(a);
                if (a2 != null) {
                    m290h(a2);
                }
            default:
        }
    }

    public final int m293a(View view) {
        int c = m303c(view);
        if (c == 3) {
            return this.f323v;
        }
        if (c == 5) {
            return this.f324w;
        }
        return 0;
    }

    public final void m297a(View view, boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if ((z || m285d(childAt)) && !(z && childAt == view)) {
                iv.m5920c(childAt, 4);
            } else {
                iv.m5920c(childAt, 1);
            }
        }
    }

    public final void m296a(View view, float f) {
        nv nvVar = (nv) view.getLayoutParams();
        if (f != nvVar.f5864b) {
            nvVar.f5864b = f;
            if (this.f310e != null) {
                this.f310e.onDrawerSlide(view, f);
            }
        }
    }

    public static float m281b(View view) {
        return ((nv) view.getLayoutParams()).f5864b;
    }

    public final int m303c(View view) {
        return gr.m5763a(((nv) view.getLayoutParams()).f5863a, iv.m5931h(this));
    }

    public final boolean m300a(View view, int i) {
        return (m303c(view) & i) == i;
    }

    private View m286e() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (((nv) childAt.getLayoutParams()).f5866d) {
                return childAt;
            }
        }
        return null;
    }

    public final View m294a(int i) {
        int a = gr.m5763a(i, iv.m5931h(this)) & 7;
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if ((m303c(childAt) & 7) == a) {
                return childAt;
            }
        }
        return null;
    }

    private static String m283d(int i) {
        if ((i & 3) == 3) {
            return "LEFT";
        }
        if ((i & 5) == 5) {
            return "RIGHT";
        }
        return Integer.toHexString(i);
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f322u = true;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f322u = true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected void onMeasure(int r13, int r14) {
        /*
        r12 = this;
        r1 = 300; // 0x12c float:4.2E-43 double:1.48E-321;
        r4 = 0;
        r7 = -2147483648; // 0xffffffff80000000 float:-0.0 double:NaN;
        r11 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r3 = android.view.View.MeasureSpec.getMode(r13);
        r5 = android.view.View.MeasureSpec.getMode(r14);
        r2 = android.view.View.MeasureSpec.getSize(r13);
        r0 = android.view.View.MeasureSpec.getSize(r14);
        if (r3 != r11) goto L_0x001b;
    L_0x0019:
        if (r5 == r11) goto L_0x0124;
    L_0x001b:
        r6 = r12.isInEditMode();
        if (r6 == 0) goto L_0x008d;
    L_0x0021:
        if (r3 == r7) goto L_0x0026;
    L_0x0023:
        if (r3 != 0) goto L_0x0026;
    L_0x0025:
        r2 = r1;
    L_0x0026:
        if (r5 == r7) goto L_0x0124;
    L_0x0028:
        if (r5 != 0) goto L_0x0124;
    L_0x002a:
        r12.setMeasuredDimension(r2, r1);
        r0 = r12.f299D;
        if (r0 == 0) goto L_0x0095;
    L_0x0031:
        r0 = happy.hacking.iv.m5948y(r12);
        if (r0 == 0) goto L_0x0095;
    L_0x0037:
        r0 = 1;
        r3 = r0;
    L_0x0039:
        r5 = happy.hacking.iv.m5931h(r12);
        r6 = r12.getChildCount();
    L_0x0041:
        if (r4 >= r6) goto L_0x0123;
    L_0x0043:
        r7 = r12.getChildAt(r4);
        r0 = r7.getVisibility();
        r8 = 8;
        if (r0 == r8) goto L_0x008a;
    L_0x004f:
        r0 = r7.getLayoutParams();
        r0 = (happy.hacking.nv) r0;
        if (r3 == 0) goto L_0x006a;
    L_0x0057:
        r8 = r0.f5863a;
        r8 = happy.hacking.gr.m5763a(r8, r5);
        r9 = happy.hacking.iv.m5948y(r7);
        if (r9 == 0) goto L_0x0097;
    L_0x0063:
        r9 = f292h;
        r10 = r12.f299D;
        r9.m6584a(r7, r10, r8);
    L_0x006a:
        r8 = m289g(r7);
        if (r8 == 0) goto L_0x009f;
    L_0x0070:
        r8 = r0.leftMargin;
        r8 = r2 - r8;
        r9 = r0.rightMargin;
        r8 = r8 - r9;
        r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r11);
        r9 = r0.topMargin;
        r9 = r1 - r9;
        r0 = r0.bottomMargin;
        r0 = r9 - r0;
        r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r11);
        r7.measure(r8, r0);
    L_0x008a:
        r4 = r4 + 1;
        goto L_0x0041;
    L_0x008d:
        r0 = new java.lang.IllegalArgumentException;
        r1 = "DrawerLayout must be measured with MeasureSpec.EXACTLY.";
        r0.<init>(r1);
        throw r0;
    L_0x0095:
        r3 = r4;
        goto L_0x0039;
    L_0x0097:
        r9 = f292h;
        r10 = r12.f299D;
        r9.m6585a(r0, r10, r8);
        goto L_0x006a;
    L_0x009f:
        r8 = m285d(r7);
        if (r8 == 0) goto L_0x00fe;
    L_0x00a5:
        r8 = f295k;
        if (r8 == 0) goto L_0x00b8;
    L_0x00a9:
        r8 = happy.hacking.iv.m5945v(r7);
        r9 = r12.f314m;
        r8 = (r8 > r9 ? 1 : (r8 == r9 ? 0 : -1));
        if (r8 == 0) goto L_0x00b8;
    L_0x00b3:
        r8 = r12.f314m;
        happy.hacking.iv.m5926e(r7, r8);
    L_0x00b8:
        r8 = r12.m303c(r7);
        r8 = r8 & 7;
        r9 = r8 & 0;
        if (r9 == 0) goto L_0x00e1;
    L_0x00c2:
        r0 = new java.lang.IllegalStateException;
        r1 = new java.lang.StringBuilder;
        r2 = "Child drawer has absolute gravity ";
        r1.<init>(r2);
        r2 = m283d(r8);
        r1 = r1.append(r2);
        r2 = " but this DrawerLayout already has a drawer view along that edge";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x00e1:
        r8 = r12.f315n;
        r9 = r0.leftMargin;
        r8 = r8 + r9;
        r9 = r0.rightMargin;
        r8 = r8 + r9;
        r9 = r0.width;
        r8 = getChildMeasureSpec(r13, r8, r9);
        r9 = r0.topMargin;
        r10 = r0.bottomMargin;
        r9 = r9 + r10;
        r0 = r0.height;
        r0 = getChildMeasureSpec(r14, r9, r0);
        r7.measure(r8, r0);
        goto L_0x008a;
    L_0x00fe:
        r0 = new java.lang.IllegalStateException;
        r1 = new java.lang.StringBuilder;
        r2 = "Child ";
        r1.<init>(r2);
        r1 = r1.append(r7);
        r2 = " at index ";
        r1 = r1.append(r2);
        r1 = r1.append(r4);
        r2 = " does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY";
        r1 = r1.append(r2);
        r1 = r1.toString();
        r0.<init>(r1);
        throw r0;
    L_0x0123:
        return;
    L_0x0124:
        r1 = r0;
        goto L_0x002a;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.widget.DrawerLayout.onMeasure(int, int):void");
    }

    private static boolean m280a(Drawable drawable, int i) {
        if (drawable == null || !dx.m5542b(drawable)) {
            return false;
        }
        dx.m5541b(drawable, i);
        return true;
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.f321t = true;
        int i5 = i3 - i;
        int childCount = getChildCount();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                nv nvVar = (nv) childAt.getLayoutParams();
                if (m289g(childAt)) {
                    childAt.layout(nvVar.leftMargin, nvVar.topMargin, nvVar.leftMargin + childAt.getMeasuredWidth(), nvVar.topMargin + childAt.getMeasuredHeight());
                } else {
                    int i7;
                    float f;
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (m300a(childAt, 3)) {
                        i7 = ((int) (((float) measuredWidth) * nvVar.f5864b)) + (-measuredWidth);
                        f = ((float) (measuredWidth + i7)) / ((float) measuredWidth);
                    } else {
                        i7 = i5 - ((int) (((float) measuredWidth) * nvVar.f5864b));
                        f = ((float) (i5 - i7)) / ((float) measuredWidth);
                    }
                    Object obj = f != nvVar.f5864b ? 1 : null;
                    int i8;
                    switch (nvVar.f5863a & 112) {
                        case py.Toolbar_titleMarginBottom /*16*/:
                            int i9 = i4 - i2;
                            i8 = (i9 - measuredHeight) / 2;
                            if (i8 < nvVar.topMargin) {
                                i8 = nvVar.topMargin;
                            } else if (i8 + measuredHeight > i9 - nvVar.bottomMargin) {
                                i8 = (i9 - nvVar.bottomMargin) - measuredHeight;
                            }
                            childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
                            break;
                        case py.Theme_panelMenuListTheme /*80*/:
                            i8 = i4 - i2;
                            childAt.layout(i7, (i8 - nvVar.bottomMargin) - childAt.getMeasuredHeight(), measuredWidth + i7, i8 - nvVar.bottomMargin);
                            break;
                        default:
                            childAt.layout(i7, nvVar.topMargin, measuredWidth + i7, measuredHeight + nvVar.topMargin);
                            break;
                    }
                    if (obj != null) {
                        m296a(childAt, f);
                    }
                    int i10 = nvVar.f5864b > 0.0f ? 0 : 4;
                    if (childAt.getVisibility() != i10) {
                        childAt.setVisibility(i10);
                    }
                }
            }
        }
        this.f321t = false;
        this.f322u = false;
    }

    public void requestLayout() {
        if (!this.f321t) {
            super.requestLayout();
        }
    }

    public void computeScroll() {
        int childCount = getChildCount();
        float f = 0.0f;
        for (int i = 0; i < childCount; i++) {
            f = Math.max(f, ((nv) getChildAt(i).getLayoutParams()).f5864b);
        }
        this.f317p = f;
        if ((this.f306a.m6761b() | this.f307b.m6761b()) != 0) {
            iv.m5922d(this);
        }
    }

    public void setStatusBarBackground(Drawable drawable) {
        this.f296A = drawable;
        invalidate();
    }

    public Drawable getStatusBarBackgroundDrawable() {
        return this.f296A;
    }

    public void setStatusBarBackground(int i) {
        this.f296A = i != 0 ? dm.getDrawable(getContext(), i) : null;
        invalidate();
    }

    public void setStatusBarBackgroundColor(int i) {
        this.f296A = new ColorDrawable(i);
        invalidate();
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f300E && this.f296A != null) {
            int a = f292h.m6581a(this.f299D);
            if (a > 0) {
                this.f296A.setBounds(0, 0, getWidth(), a);
                this.f296A.draw(canvas);
            }
        }
    }

    protected boolean drawChild(Canvas canvas, View view, long j) {
        int right;
        int height = getHeight();
        boolean g = m289g(view);
        int i = 0;
        int width = getWidth();
        int save = canvas.save();
        if (g) {
            int childCount = getChildCount();
            int i2 = 0;
            while (i2 < childCount) {
                View childAt = getChildAt(i2);
                if (childAt != view && childAt.getVisibility() == 0) {
                    Object obj;
                    Drawable background = childAt.getBackground();
                    if (background == null) {
                        obj = null;
                    } else if (background.getOpacity() == -1) {
                        obj = 1;
                    } else {
                        obj = null;
                    }
                    if (obj != null && m285d(childAt) && childAt.getHeight() >= height) {
                        if (m300a(childAt, 3)) {
                            right = childAt.getRight();
                            if (right <= i) {
                                right = i;
                            }
                            i = right;
                            right = width;
                        } else {
                            right = childAt.getLeft();
                            if (right < width) {
                            }
                        }
                        i2++;
                        width = right;
                    }
                }
                right = width;
                i2++;
                width = right;
            }
            canvas.clipRect(i, 0, width, getHeight());
        }
        right = width;
        boolean drawChild = super.drawChild(canvas, view, j);
        canvas.restoreToCount(save);
        if (this.f317p > 0.0f && g) {
            this.f318q.setColor((((int) (((float) ((this.f316o & -16777216) >>> 24)) * this.f317p)) << 24) | (this.f316o & 16777215));
            canvas.drawRect((float) i, 0.0f, (float) right, (float) getHeight(), this.f318q);
        } else if (this.f297B != null && m300a(view, 3)) {
            right = this.f297B.getIntrinsicWidth();
            i = view.getRight();
            r2 = Math.max(0.0f, Math.min(((float) i) / ((float) this.f306a.f5899i), 1.0f));
            this.f297B.setBounds(i, view.getTop(), right + i, view.getBottom());
            this.f297B.setAlpha((int) (255.0f * r2));
            this.f297B.draw(canvas);
        } else if (this.f298C != null && m300a(view, 5)) {
            right = this.f298C.getIntrinsicWidth();
            i = view.getLeft();
            r2 = Math.max(0.0f, Math.min(((float) (getWidth() - i)) / ((float) this.f307b.f5899i), 1.0f));
            this.f298C.setBounds(i - right, view.getTop(), i, view.getBottom());
            this.f298C.setAlpha((int) (255.0f * r2));
            this.f298C.draw(canvas);
        }
        return drawChild;
    }

    private static boolean m289g(View view) {
        return ((nv) view.getLayoutParams()).f5863a == 0;
    }

    public static boolean m285d(View view) {
        return (gr.m5763a(((nv) view.getLayoutParams()).f5863a, iv.m5931h(view)) & 7) != 0;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onInterceptTouchEvent(android.view.MotionEvent r10) {
        /*
        r9 = this;
        r1 = 1;
        r2 = 0;
        r0 = happy.hacking.hu.m5837a(r10);
        r3 = r9.f306a;
        r3 = r3.m6757a(r10);
        r4 = r9.f307b;
        r4 = r4.m6757a(r10);
        r4 = r4 | r3;
        switch(r0) {
            case 0: goto L_0x0039;
            case 1: goto L_0x00b1;
            case 2: goto L_0x0062;
            case 3: goto L_0x00b1;
            default: goto L_0x0016;
        };
    L_0x0016:
        r0 = r2;
    L_0x0017:
        if (r4 != 0) goto L_0x0037;
    L_0x0019:
        if (r0 != 0) goto L_0x0037;
    L_0x001b:
        r4 = r9.getChildCount();
        r3 = r2;
    L_0x0020:
        if (r3 >= r4) goto L_0x00bf;
    L_0x0022:
        r0 = r9.getChildAt(r3);
        r0 = r0.getLayoutParams();
        r0 = (happy.hacking.nv) r0;
        r0 = r0.f5865c;
        if (r0 == 0) goto L_0x00ba;
    L_0x0030:
        r0 = r1;
    L_0x0031:
        if (r0 != 0) goto L_0x0037;
    L_0x0033:
        r0 = r9.f309d;
        if (r0 == 0) goto L_0x0038;
    L_0x0037:
        r2 = r1;
    L_0x0038:
        return r2;
    L_0x0039:
        r0 = r10.getX();
        r3 = r10.getY();
        r9.f326y = r0;
        r9.f327z = r3;
        r5 = r9.f317p;
        r6 = 0;
        r5 = (r5 > r6 ? 1 : (r5 == r6 ? 0 : -1));
        if (r5 <= 0) goto L_0x00c2;
    L_0x004c:
        r5 = r9.f306a;
        r0 = (int) r0;
        r3 = (int) r3;
        r0 = r5.m6759b(r0, r3);
        if (r0 == 0) goto L_0x00c2;
    L_0x0056:
        r0 = m289g(r0);
        if (r0 == 0) goto L_0x00c2;
    L_0x005c:
        r0 = r1;
    L_0x005d:
        r9.f325x = r2;
        r9.f309d = r2;
        goto L_0x0017;
    L_0x0062:
        r5 = r9.f306a;
        r0 = r5.f5893c;
        r6 = r0.length;
        r0 = r2;
    L_0x0068:
        if (r0 >= r6) goto L_0x00af;
    L_0x006a:
        r3 = r5.f5897g;
        r7 = r1 << r0;
        r3 = r3 & r7;
        if (r3 == 0) goto L_0x00a6;
    L_0x0071:
        r3 = r1;
    L_0x0072:
        if (r3 == 0) goto L_0x00aa;
    L_0x0074:
        r3 = r5.f5895e;
        r3 = r3[r0];
        r7 = r5.f5893c;
        r7 = r7[r0];
        r3 = r3 - r7;
        r7 = r5.f5896f;
        r7 = r7[r0];
        r8 = r5.f5894d;
        r8 = r8[r0];
        r7 = r7 - r8;
        r3 = r3 * r3;
        r7 = r7 * r7;
        r3 = r3 + r7;
        r7 = r5.f5892b;
        r8 = r5.f5892b;
        r7 = r7 * r8;
        r7 = (float) r7;
        r3 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1));
        if (r3 <= 0) goto L_0x00a8;
    L_0x0093:
        r3 = r1;
    L_0x0094:
        if (r3 == 0) goto L_0x00ac;
    L_0x0096:
        r0 = r1;
    L_0x0097:
        if (r0 == 0) goto L_0x0016;
    L_0x0099:
        r0 = r9.f319r;
        r0.m6597a();
        r0 = r9.f320s;
        r0.m6597a();
        r0 = r2;
        goto L_0x0017;
    L_0x00a6:
        r3 = r2;
        goto L_0x0072;
    L_0x00a8:
        r3 = r2;
        goto L_0x0094;
    L_0x00aa:
        r3 = r2;
        goto L_0x0094;
    L_0x00ac:
        r0 = r0 + 1;
        goto L_0x0068;
    L_0x00af:
        r0 = r2;
        goto L_0x0097;
    L_0x00b1:
        r9.m299a(r1);
        r9.f325x = r2;
        r9.f309d = r2;
        goto L_0x0016;
    L_0x00ba:
        r0 = r3 + 1;
        r3 = r0;
        goto L_0x0020;
    L_0x00bf:
        r0 = r2;
        goto L_0x0031;
    L_0x00c2:
        r0 = r2;
        goto L_0x005d;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.widget.DrawerLayout.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        this.f306a.m6760b(motionEvent);
        this.f307b.m6760b(motionEvent);
        float x;
        float y;
        switch (motionEvent.getAction() & 255) {
            case ug.RecyclerView_android_orientation /*0*/:
                x = motionEvent.getX();
                y = motionEvent.getY();
                this.f326y = x;
                this.f327z = y;
                this.f325x = false;
                this.f309d = false;
                break;
            case ug.RecyclerView_layoutManager /*1*/:
                boolean z;
                x = motionEvent.getX();
                y = motionEvent.getY();
                View b = this.f306a.m6759b((int) x, (int) y);
                if (b != null && m289g(b)) {
                    x -= this.f326y;
                    y -= this.f327z;
                    int i = this.f306a.f5892b;
                    if ((x * x) + (y * y) < ((float) (i * i))) {
                        View e = m286e();
                        if (e != null) {
                            z = m293a(e) == 2;
                            m299a(z);
                            this.f325x = false;
                            break;
                        }
                    }
                }
                z = true;
                m299a(z);
                this.f325x = false;
            case ug.RecyclerView_reverseLayout /*3*/:
                m299a(true);
                this.f325x = false;
                this.f309d = false;
                break;
        }
        return true;
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        this.f325x = z;
        if (z) {
            m299a(true);
        }
    }

    public final void m299a(boolean z) {
        int childCount = getChildCount();
        int i = 0;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            nv nvVar = (nv) childAt.getLayoutParams();
            if (m285d(childAt) && (!z || nvVar.f5865c)) {
                int width = childAt.getWidth();
                if (m300a(childAt, 3)) {
                    i |= this.f306a.m6758a(childAt, -width, childAt.getTop());
                } else {
                    i |= this.f307b.m6758a(childAt, getWidth(), childAt.getTop());
                }
                nvVar.f5865c = false;
            }
        }
        this.f319r.m6597a();
        this.f320s.m6597a();
        if (i != 0) {
            invalidate();
        }
    }

    private void m290h(View view) {
        if (m285d(view)) {
            if (this.f322u) {
                nv nvVar = (nv) view.getLayoutParams();
                nvVar.f5864b = 1.0f;
                nvVar.f5866d = true;
                m297a(view, true);
            } else if (m300a(view, 3)) {
                this.f306a.m6758a(view, 0, view.getTop());
            } else {
                this.f307b.m6758a(view, getWidth() - view.getWidth(), view.getTop());
            }
            invalidate();
            return;
        }
        throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
    }

    public final void m301b(int i) {
        View a = m294a(i);
        if (a == null) {
            throw new IllegalArgumentException("No drawer view found with gravity " + m283d(i));
        }
        m290h(a);
    }

    public final void m305e(View view) {
        if (m285d(view)) {
            if (this.f322u) {
                nv nvVar = (nv) view.getLayoutParams();
                nvVar.f5864b = 0.0f;
                nvVar.f5866d = false;
            } else if (m300a(view, 3)) {
                this.f306a.m6758a(view, -view.getWidth(), view.getTop());
            } else {
                this.f307b.m6758a(view, getWidth(), view.getTop());
            }
            invalidate();
            return;
        }
        throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
    }

    public final void m295a() {
        View a = m294a(8388611);
        if (a == null) {
            throw new IllegalArgumentException("No drawer view found with gravity " + m283d(8388611));
        }
        m305e(a);
    }

    private static boolean m291i(View view) {
        if (m285d(view)) {
            return ((nv) view.getLayoutParams()).f5866d;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    public final boolean m304c(int i) {
        View a = m294a(i);
        if (a != null) {
            return m291i(a);
        }
        return false;
    }

    private static boolean m292j(View view) {
        if (m285d(view)) {
            return ((nv) view.getLayoutParams()).f5864b > 0.0f;
        } else {
            throw new IllegalArgumentException("View " + view + " is not a drawer");
        }
    }

    public final boolean m302b() {
        View a = m294a(8388611);
        if (a != null) {
            return m292j(a);
        }
        return false;
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new nv();
    }

    protected LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        if (layoutParams instanceof nv) {
            return new nv((nv) layoutParams);
        }
        return layoutParams instanceof MarginLayoutParams ? new nv((MarginLayoutParams) layoutParams) : new nv(layoutParams);
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return (layoutParams instanceof nv) && super.checkLayoutParams(layoutParams);
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new nv(getContext(), attributeSet);
    }

    public void addFocusables(ArrayList arrayList, int i, int i2) {
        int i3 = 0;
        if (getDescendantFocusability() != 393216) {
            int i4;
            int childCount = getChildCount();
            int i5 = 0;
            for (i4 = 0; i4 < childCount; i4++) {
                View childAt = getChildAt(i4);
                if (!m285d(childAt)) {
                    this.f305J.add(childAt);
                } else if (m291i(childAt)) {
                    i5 = 1;
                    childAt.addFocusables(arrayList, i, i2);
                }
            }
            if (i5 == 0) {
                i4 = this.f305J.size();
                while (i3 < i4) {
                    View view = (View) this.f305J.get(i3);
                    if (view.getVisibility() == 0) {
                        view.addFocusables(arrayList, i, i2);
                    }
                    i3++;
                }
            }
            this.f305J.clear();
        }
    }

    private View m287f() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (m285d(childAt) && m292j(childAt)) {
                return childAt;
            }
        }
        return null;
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 4) {
            boolean z;
            if (m287f() != null) {
                z = true;
            } else {
                z = false;
            }
            if (z) {
                gv.m5773c(keyEvent);
                return true;
            }
        }
        return super.onKeyDown(i, keyEvent);
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (i != 4) {
            return super.onKeyUp(i, keyEvent);
        }
        View f = m287f();
        if (f != null && m293a(f) == 0) {
            m299a(false);
        }
        if (f != null) {
            return true;
        }
        return false;
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        if (savedState.f289a != 0) {
            View a = m294a(savedState.f289a);
            if (a != null) {
                m290h(a);
            }
        }
        m279a(savedState.f290b, 3);
        m279a(savedState.f291c, 5);
    }

    protected Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        View e = m286e();
        if (e != null) {
            savedState.f289a = ((nv) e.getLayoutParams()).f5863a;
        }
        savedState.f290b = this.f323v;
        savedState.f291c = this.f324w;
        return savedState;
    }

    public void addView(View view, int i, LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        if (m286e() != null || m285d(view)) {
            iv.m5920c(view, 4);
        } else {
            iv.m5920c(view, 1);
        }
        if (!f294j) {
            iv.m5908a(view, this.f313l);
        }
    }

    public void onRtlPropertiesChanged(int i) {
        if (!f295k) {
            Drawable drawable;
            int h = iv.m5931h(this);
            if (h == 0) {
                if (this.f301F != null) {
                    m280a(this.f301F, h);
                    drawable = this.f301F;
                }
                drawable = this.f303H;
            } else {
                if (this.f302G != null) {
                    m280a(this.f302G, h);
                    drawable = this.f302G;
                }
                drawable = this.f303H;
            }
            this.f297B = drawable;
            h = iv.m5931h(this);
            if (h == 0) {
                if (this.f302G != null) {
                    m280a(this.f302G, h);
                    drawable = this.f302G;
                }
                drawable = this.f304I;
            } else {
                if (this.f301F != null) {
                    m280a(this.f301F, h);
                    drawable = this.f301F;
                }
                drawable = this.f304I;
            }
            this.f298C = drawable;
        }
    }

    public static /* synthetic */ boolean m288f(View view) {
        return (iv.m5925e(view) == 4 || iv.m5925e(view) == 2) ? false : true;
    }
}
