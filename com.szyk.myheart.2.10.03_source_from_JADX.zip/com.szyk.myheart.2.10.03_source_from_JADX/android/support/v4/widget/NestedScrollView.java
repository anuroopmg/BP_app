package android.support.v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import happy.hacking.hu;
import happy.hacking.ia;
import happy.hacking.ib;
import happy.hacking.ic;
import happy.hacking.id;
import happy.hacking.ip;
import happy.hacking.ir;
import happy.hacking.iv;
import happy.hacking.oc;
import happy.hacking.oj;
import happy.hacking.ok;
import happy.hacking.ol;
import happy.hacking.ow;
import happy.hacking.py;
import happy.hacking.ug;
import java.util.List;

public class NestedScrollView extends FrameLayout implements ia, ic, ip {
    private static final oj f329v;
    private static final int[] f330w;
    private ok f331A;
    private long f332a;
    private final Rect f333b;
    private ow f334c;
    private oc f335d;
    private oc f336e;
    private int f337f;
    private boolean f338g;
    private boolean f339h;
    private View f340i;
    private boolean f341j;
    private VelocityTracker f342k;
    private boolean f343l;
    private boolean f344m;
    private int f345n;
    private int f346o;
    private int f347p;
    private int f348q;
    private final int[] f349r;
    private final int[] f350s;
    private int f351t;
    private SavedState f352u;
    private final id f353x;
    private final ib f354y;
    private float f355z;

    public class SavedState extends BaseSavedState {
        public static final Creator CREATOR;
        public int f328a;

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public SavedState(Parcel parcel) {
            super(parcel);
            this.f328a = parcel.readInt();
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f328a);
        }

        public String toString() {
            return "HorizontalScrollView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " scrollPosition=" + this.f328a + "}";
        }

        static {
            CREATOR = new ol();
        }
    }

    static {
        f329v = new oj();
        f330w = new int[]{16843130};
    }

    public NestedScrollView(Context context) {
        this(context, null);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f333b = new Rect();
        this.f338g = true;
        this.f339h = false;
        this.f340i = null;
        this.f341j = false;
        this.f344m = true;
        this.f348q = -1;
        this.f349r = new int[2];
        this.f350s = new int[2];
        this.f334c = new ow(getContext(), null);
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f345n = viewConfiguration.getScaledTouchSlop();
        this.f346o = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f347p = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f330w, i, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.f353x = new id(this);
        this.f354y = new ib(this);
        setNestedScrollingEnabled(true);
        iv.m5908a((View) this, f329v);
    }

    public void setNestedScrollingEnabled(boolean z) {
        this.f354y.m5867a(z);
    }

    public boolean isNestedScrollingEnabled() {
        return this.f354y.f5672a;
    }

    public boolean startNestedScroll(int i) {
        return this.f354y.m5871a(i);
    }

    public void stopNestedScroll() {
        this.f354y.m5874b();
    }

    public boolean hasNestedScrollingParent() {
        return this.f354y.m5868a();
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.f354y.m5872a(i, i2, i3, i4, iArr);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return this.f354y.m5873a(i, i2, iArr, iArr2);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.f354y.m5870a(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.f354y.m5869a(f, f2);
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return (i & 2) != 0;
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.f353x.f5676a = i;
        startNestedScroll(2);
    }

    public void onStopNestedScroll(View view) {
        stopNestedScroll();
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int scrollY = getScrollY();
        scrollBy(0, i4);
        int scrollY2 = getScrollY() - scrollY;
        dispatchNestedScroll(0, scrollY2, 0, i4 - scrollY2, null);
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (z) {
            return false;
        }
        m324e((int) f2);
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    public int getNestedScrollAxes() {
        return this.f353x.f5676a;
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    protected float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    protected float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = (getChildAt(0).getBottom() - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (0.5f * ((float) getHeight()));
    }

    public void addView(View view) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view);
    }

    public void addView(View view, int i) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, i);
    }

    public void addView(View view, LayoutParams layoutParams) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, layoutParams);
    }

    public void addView(View view, int i, LayoutParams layoutParams) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, i, layoutParams);
    }

    public void setOnScrollChangeListener(ok okVar) {
        this.f331A = okVar;
    }

    public void setFillViewport(boolean z) {
        if (z != this.f343l) {
            this.f343l = z;
            requestLayout();
        }
    }

    public void setSmoothScrollingEnabled(boolean z) {
        this.f344m = z;
    }

    protected void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        if (this.f331A != null) {
            this.f331A.onScrollChange(this, i, i2, i3, i4);
        }
    }

    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f343l && MeasureSpec.getMode(i2) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            int measuredHeight = getMeasuredHeight();
            if (childAt.getMeasuredHeight() < measuredHeight) {
                childAt.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight(), ((FrameLayout.LayoutParams) childAt.getLayoutParams()).width), MeasureSpec.makeMeasureSpec((measuredHeight - getPaddingTop()) - getPaddingBottom(), 1073741824));
            }
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || m326a(keyEvent);
    }

    public final boolean m326a(KeyEvent keyEvent) {
        boolean z;
        this.f333b.setEmpty();
        View childAt = getChildAt(0);
        if (childAt != null) {
            z = getHeight() < (childAt.getHeight() + getPaddingTop()) + getPaddingBottom();
        } else {
            z = false;
        }
        View childAt2;
        if (z) {
            if (keyEvent.getAction() != 0) {
                return false;
            }
            switch (keyEvent.getKeyCode()) {
                case py.Toolbar_collapseContentDescription /*19*/:
                    if (keyEvent.isAltPressed()) {
                        return m319b(33);
                    }
                    return m321c(33);
                case py.Toolbar_navigationIcon /*20*/:
                    if (keyEvent.isAltPressed()) {
                        return m319b(130);
                    }
                    return m321c(130);
                case py.Theme_editTextColor /*62*/:
                    int i;
                    if (keyEvent.isShiftPressed()) {
                        i = 33;
                    } else {
                        i = 130;
                    }
                    boolean z2 = i == 130;
                    int height = getHeight();
                    if (z2) {
                        this.f333b.top = getScrollY() + height;
                        int childCount = getChildCount();
                        if (childCount > 0) {
                            childAt2 = getChildAt(childCount - 1);
                            if (this.f333b.top + height > childAt2.getBottom()) {
                                this.f333b.top = childAt2.getBottom() - height;
                            }
                        }
                    } else {
                        this.f333b.top = getScrollY() - height;
                        if (this.f333b.top < 0) {
                            this.f333b.top = 0;
                        }
                    }
                    this.f333b.bottom = height + this.f333b.top;
                    m311a(i, this.f333b.top, this.f333b.bottom);
                    return false;
                default:
                    return false;
            }
        } else if (!isFocused() || keyEvent.getKeyCode() == 4) {
            return false;
        } else {
            childAt2 = findFocus();
            if (childAt2 == this) {
                childAt2 = null;
            }
            childAt2 = FocusFinder.getInstance().findNextFocus(this, childAt2, 130);
            if (childAt2 == null || childAt2 == this || !childAt2.requestFocus(130)) {
                return false;
            }
            return true;
        }
    }

    private void m308a() {
        if (this.f342k == null) {
            this.f342k = VelocityTracker.obtain();
        }
    }

    private void m317b() {
        if (this.f342k != null) {
            this.f342k.recycle();
            this.f342k = null;
        }
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        if (z) {
            m317b();
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z = true;
        int action = motionEvent.getAction();
        if (action == 2 && this.f341j) {
            return true;
        }
        int y;
        switch (action & 255) {
            case ug.RecyclerView_android_orientation /*0*/:
                boolean z2;
                y = (int) motionEvent.getY();
                action = (int) motionEvent.getX();
                if (getChildCount() > 0) {
                    int scrollY = getScrollY();
                    View childAt = getChildAt(0);
                    z2 = y >= childAt.getTop() - scrollY && y < childAt.getBottom() - scrollY && action >= childAt.getLeft() && action < childAt.getRight();
                } else {
                    z2 = false;
                }
                if (!z2) {
                    this.f341j = false;
                    m317b();
                    break;
                }
                this.f337f = y;
                this.f348q = hu.m5840b(motionEvent, 0);
                if (this.f342k == null) {
                    this.f342k = VelocityTracker.obtain();
                } else {
                    this.f342k.clear();
                }
                this.f342k.addMovement(motionEvent);
                if (this.f334c.m6675a()) {
                    z = false;
                }
                this.f341j = z;
                startNestedScroll(2);
                break;
                break;
            case ug.RecyclerView_layoutManager /*1*/:
            case ug.RecyclerView_reverseLayout /*3*/:
                this.f341j = false;
                this.f348q = -1;
                m317b();
                if (this.f334c.m6676a(getScrollX(), getScrollY(), getScrollRange())) {
                    iv.m5922d(this);
                }
                stopNestedScroll();
                break;
            case ug.RecyclerView_spanCount /*2*/:
                action = this.f348q;
                if (action != -1) {
                    y = hu.m5838a(motionEvent, action);
                    if (y != -1) {
                        action = (int) hu.m5843d(motionEvent, y);
                        if (Math.abs(action - this.f337f) > this.f345n && (getNestedScrollAxes() & 2) == 0) {
                            this.f341j = true;
                            this.f337f = action;
                            m308a();
                            this.f342k.addMovement(motionEvent);
                            this.f351t = 0;
                            ViewParent parent = getParent();
                            if (parent != null) {
                                parent.requestDisallowInterceptTouchEvent(true);
                                break;
                            }
                        }
                    }
                    Log.e("NestedScrollView", "Invalid pointerId=" + action + " in onInterceptTouchEvent");
                    break;
                }
                break;
            case py.Toolbar_contentInsetEnd /*6*/:
                m310a(motionEvent);
                break;
        }
        return this.f341j;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        m308a();
        MotionEvent obtain = MotionEvent.obtain(motionEvent);
        int a = hu.m5837a(motionEvent);
        if (a == 0) {
            this.f351t = 0;
        }
        obtain.offsetLocation(0.0f, (float) this.f351t);
        switch (a) {
            case ug.RecyclerView_android_orientation /*0*/:
                if (getChildCount() != 0) {
                    boolean z = !this.f334c.m6675a();
                    this.f341j = z;
                    if (z) {
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                    if (!this.f334c.m6675a()) {
                        this.f334c.m6683h();
                    }
                    this.f337f = (int) motionEvent.getY();
                    this.f348q = hu.m5840b(motionEvent, 0);
                    startNestedScroll(2);
                    break;
                }
                return false;
            case ug.RecyclerView_layoutManager /*1*/:
                if (this.f341j) {
                    VelocityTracker velocityTracker = this.f342k;
                    velocityTracker.computeCurrentVelocity(1000, (float) this.f347p);
                    a = (int) ir.m5884b(velocityTracker, this.f348q);
                    if (Math.abs(a) > this.f346o) {
                        m324e(-a);
                    } else if (this.f334c.m6676a(getScrollX(), getScrollY(), getScrollRange())) {
                        iv.m5922d(this);
                    }
                }
                this.f348q = -1;
                m320c();
                break;
            case ug.RecyclerView_spanCount /*2*/:
                int a2 = hu.m5838a(motionEvent, this.f348q);
                if (a2 != -1) {
                    int i;
                    int d = (int) hu.m5843d(motionEvent, a2);
                    a = this.f337f - d;
                    if (dispatchNestedPreScroll(0, a, this.f350s, this.f349r)) {
                        a -= this.f350s[1];
                        obtain.offsetLocation(0.0f, (float) this.f349r[1]);
                        this.f351t += this.f349r[1];
                    }
                    if (this.f341j || Math.abs(a) <= this.f345n) {
                        i = a;
                    } else {
                        ViewParent parent2 = getParent();
                        if (parent2 != null) {
                            parent2.requestDisallowInterceptTouchEvent(true);
                        }
                        this.f341j = true;
                        if (a > 0) {
                            i = a - this.f345n;
                        } else {
                            i = a + this.f345n;
                        }
                    }
                    if (this.f341j) {
                        Object obj;
                        this.f337f = d - this.f349r[1];
                        int scrollY = getScrollY();
                        int scrollRange = getScrollRange();
                        a = iv.m5901a(this);
                        if (a == 0 || (a == 1 && scrollRange > 0)) {
                            obj = 1;
                        } else {
                            obj = null;
                        }
                        if (m312a(0, i, 0, getScrollY(), scrollRange) && !hasNestedScrollingParent()) {
                            this.f342k.clear();
                        }
                        int scrollY2 = getScrollY() - scrollY;
                        if (!dispatchNestedScroll(0, scrollY2, 0, i - scrollY2, this.f349r)) {
                            if (obj != null) {
                                m322d();
                                a = scrollY + i;
                                if (a < 0) {
                                    this.f335d.m6616a(((float) i) / ((float) getHeight()), hu.m5841c(motionEvent, a2) / ((float) getWidth()));
                                    if (!this.f336e.m6614a()) {
                                        this.f336e.m6620c();
                                    }
                                } else if (a > scrollRange) {
                                    this.f336e.m6616a(((float) i) / ((float) getHeight()), 1.0f - (hu.m5841c(motionEvent, a2) / ((float) getWidth())));
                                    if (!this.f335d.m6614a()) {
                                        this.f335d.m6620c();
                                    }
                                }
                                if (!(this.f335d == null || (this.f335d.m6614a() && this.f336e.m6614a()))) {
                                    iv.m5922d(this);
                                    break;
                                }
                            }
                        }
                        this.f337f -= this.f349r[1];
                        obtain.offsetLocation(0.0f, (float) this.f349r[1]);
                        this.f351t += this.f349r[1];
                        break;
                    }
                }
                Log.e("NestedScrollView", "Invalid pointerId=" + this.f348q + " in onTouchEvent");
                break;
                break;
            case ug.RecyclerView_reverseLayout /*3*/:
                if (this.f341j && getChildCount() > 0 && this.f334c.m6676a(getScrollX(), getScrollY(), getScrollRange())) {
                    iv.m5922d(this);
                }
                this.f348q = -1;
                m320c();
                break;
            case py.Toolbar_contentInsetStart /*5*/:
                a = hu.m5839b(motionEvent);
                this.f337f = (int) hu.m5843d(motionEvent, a);
                this.f348q = hu.m5840b(motionEvent, a);
                break;
            case py.Toolbar_contentInsetEnd /*6*/:
                m310a(motionEvent);
                this.f337f = (int) hu.m5843d(motionEvent, hu.m5838a(motionEvent, this.f348q));
                break;
        }
        if (this.f342k != null) {
            this.f342k.addMovement(obtain);
        }
        obtain.recycle();
        return true;
    }

    private void m310a(MotionEvent motionEvent) {
        int action = (motionEvent.getAction() & 65280) >> 8;
        if (hu.m5840b(motionEvent, action) == this.f348q) {
            action = action == 0 ? 1 : 0;
            this.f337f = (int) hu.m5843d(motionEvent, action);
            this.f348q = hu.m5840b(motionEvent, action);
            if (this.f342k != null) {
                this.f342k.clear();
            }
        }
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if ((hu.m5844d(motionEvent) & 2) == 0) {
            return false;
        }
        switch (motionEvent.getAction()) {
            case py.Toolbar_contentInsetRight /*8*/:
                if (this.f341j) {
                    return false;
                }
                float e = hu.m5845e(motionEvent, 9);
                if (e == 0.0f) {
                    return false;
                }
                int verticalScrollFactorCompat = (int) (e * getVerticalScrollFactorCompat());
                int scrollRange = getScrollRange();
                int scrollY = getScrollY();
                verticalScrollFactorCompat = scrollY - verticalScrollFactorCompat;
                if (verticalScrollFactorCompat < 0) {
                    scrollRange = 0;
                } else if (verticalScrollFactorCompat <= scrollRange) {
                    scrollRange = verticalScrollFactorCompat;
                }
                if (scrollRange == scrollY) {
                    return false;
                }
                super.scrollTo(getScrollX(), scrollRange);
                return true;
            default:
                return false;
        }
    }

    private float getVerticalScrollFactorCompat() {
        if (this.f355z == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                this.f355z = typedValue.getDimension(context.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.f355z;
    }

    protected void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        super.scrollTo(i, i2);
    }

    private boolean m312a(int i, int i2, int i3, int i4, int i5) {
        boolean z;
        int i6;
        boolean z2;
        iv.m5901a(this);
        computeHorizontalScrollRange();
        computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        computeVerticalScrollExtent();
        int i7 = i3 + i;
        int i8 = i4 + i2;
        int i9 = i5 + 0;
        if (i7 > 0) {
            z = true;
            i6 = 0;
        } else if (i7 < 0) {
            z = true;
            i6 = 0;
        } else {
            i6 = i7;
            z = false;
        }
        if (i8 > i9) {
            i8 = i9;
            z2 = true;
        } else if (i8 < 0) {
            z2 = true;
            i8 = 0;
        } else {
            z2 = false;
        }
        if (z2) {
            this.f334c.m6676a(i6, i8, getScrollRange());
        }
        onOverScrolled(i6, i8, z, z2);
        if (z || z2) {
            return true;
        }
        return false;
    }

    private int getScrollRange() {
        if (getChildCount() > 0) {
            return Math.max(0, getChildAt(0).getHeight() - ((getHeight() - getPaddingBottom()) - getPaddingTop()));
        }
        return 0;
    }

    private boolean m319b(int i) {
        int i2 = i == 130 ? 1 : 0;
        int height = getHeight();
        this.f333b.top = 0;
        this.f333b.bottom = height;
        if (i2 != 0) {
            i2 = getChildCount();
            if (i2 > 0) {
                this.f333b.bottom = getChildAt(i2 - 1).getBottom() + getPaddingBottom();
                this.f333b.top = this.f333b.bottom - height;
            }
        }
        return m311a(i, this.f333b.top, this.f333b.bottom);
    }

    private boolean m311a(int i, int i2, int i3) {
        Object obj;
        boolean z;
        int height = getHeight();
        int scrollY = getScrollY();
        int i4 = scrollY + height;
        if (i == 33) {
            obj = 1;
        } else {
            obj = null;
        }
        List focusables = getFocusables(2);
        View view = null;
        Object obj2 = null;
        int size = focusables.size();
        int i5 = 0;
        while (i5 < size) {
            View view2;
            Object obj3;
            View view3 = (View) focusables.get(i5);
            int top = view3.getTop();
            int bottom = view3.getBottom();
            if (i2 < bottom && top < i3) {
                Object obj4 = (i2 >= top || bottom >= i3) ? null : 1;
                if (view == null) {
                    Object obj5 = obj4;
                    view2 = view3;
                    obj3 = obj5;
                } else {
                    Object obj6 = ((obj == null || top >= view.getTop()) && (obj != null || bottom <= view.getBottom())) ? null : 1;
                    if (obj2 != null) {
                        if (!(obj4 == null || obj6 == null)) {
                            view2 = view3;
                            obj3 = obj2;
                        }
                    } else if (obj4 != null) {
                        view2 = view3;
                        height = 1;
                    } else if (obj6 != null) {
                        view2 = view3;
                        obj3 = obj2;
                    }
                }
                i5++;
                view = view2;
                obj2 = obj3;
            }
            obj3 = obj2;
            view2 = view;
            i5++;
            view = view2;
            obj2 = obj3;
        }
        if (view == null) {
            view = this;
        }
        if (i2 < scrollY || i3 > i4) {
            m323d(obj != null ? i2 - scrollY : i3 - i4);
            z = true;
        } else {
            z = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i);
        }
        return z;
    }

    private boolean m321c(int i) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !m314a(findNextFocus, maxScrollAmount, getHeight())) {
            if (i == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                int bottom = getChildAt(0).getBottom();
                int scrollY = (getScrollY() + getHeight()) - getPaddingBottom();
                if (bottom - scrollY < maxScrollAmount) {
                    maxScrollAmount = bottom - scrollY;
                }
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            m323d(maxScrollAmount);
        } else {
            findNextFocus.getDrawingRect(this.f333b);
            offsetDescendantRectToMyCoords(findNextFocus, this.f333b);
            m323d(m306a(this.f333b));
            findNextFocus.requestFocus(i);
        }
        if (findFocus != null && findFocus.isFocused() && m313a(findFocus)) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    private boolean m313a(View view) {
        return !m314a(view, 0, getHeight());
    }

    private boolean m314a(View view, int i, int i2) {
        view.getDrawingRect(this.f333b);
        offsetDescendantRectToMyCoords(view, this.f333b);
        return this.f333b.bottom + i >= getScrollY() && this.f333b.top - i <= getScrollY() + i2;
    }

    private void m323d(int i) {
        if (i == 0) {
            return;
        }
        if (this.f344m) {
            m309a(0, i);
        } else {
            scrollBy(0, i);
        }
    }

    private void m309a(int i, int i2) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.f332a > 250) {
                int max = Math.max(0, getChildAt(0).getHeight() - ((getHeight() - getPaddingBottom()) - getPaddingTop()));
                int scrollY = getScrollY();
                max = Math.max(0, Math.min(scrollY + i2, max)) - scrollY;
                ow owVar = this.f334c;
                owVar.f5884b.m6685a(owVar.f5883a, getScrollX(), scrollY, max);
                iv.m5922d(this);
            } else {
                if (!this.f334c.m6675a()) {
                    this.f334c.m6683h();
                }
                scrollBy(i, i2);
            }
            this.f332a = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    public final void m325a(int i) {
        m309a(0 - getScrollX(), i - getScrollY());
    }

    public int computeVerticalScrollRange() {
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (getChildCount() == 0) {
            return height;
        }
        int bottom = getChildAt(0).getBottom();
        int scrollY = getScrollY();
        height = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        if (scrollY > height) {
            return bottom + (scrollY - height);
        }
        return bottom;
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    protected void measureChild(View view, int i, int i2) {
        view.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight(), view.getLayoutParams().width), MeasureSpec.makeMeasureSpec(0, 0));
    }

    protected void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        view.measure(getChildMeasureSpec(i, (((getPaddingLeft() + getPaddingRight()) + marginLayoutParams.leftMargin) + marginLayoutParams.rightMargin) + i2, marginLayoutParams.width), MeasureSpec.makeMeasureSpec(marginLayoutParams.bottomMargin + marginLayoutParams.topMargin, 0));
    }

    public void computeScroll() {
        if (this.f334c.m6682g()) {
            int scrollX = getScrollX();
            int scrollY = getScrollY();
            int b = this.f334c.m6677b();
            int c = this.f334c.m6678c();
            if (scrollX != b || scrollY != c) {
                int scrollRange = getScrollRange();
                int a = iv.m5901a(this);
                Object obj = (a == 0 || (a == 1 && scrollRange > 0)) ? 1 : null;
                m312a(b - scrollX, c - scrollY, scrollX, scrollY, scrollRange);
                if (obj != null) {
                    m322d();
                    if (c <= 0 && scrollY > 0) {
                        this.f335d.m6617a((int) this.f334c.m6681f());
                    } else if (c >= scrollRange && scrollY < scrollRange) {
                        this.f336e.m6617a((int) this.f334c.m6681f());
                    }
                }
            }
        }
    }

    private void m318b(View view) {
        view.getDrawingRect(this.f333b);
        offsetDescendantRectToMyCoords(view, this.f333b);
        int a = m306a(this.f333b);
        if (a != 0) {
            scrollBy(0, a);
        }
    }

    private int m306a(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        if (rect.bottom < getChildAt(0).getHeight()) {
            i -= verticalFadingEdgeLength;
        }
        if (rect.bottom > i && rect.top > scrollY) {
            if (rect.height() > height) {
                scrollY = (rect.top - scrollY) + 0;
            } else {
                scrollY = (rect.bottom - i) + 0;
            }
            scrollY = Math.min(scrollY, getChildAt(0).getBottom() - i);
        } else if (rect.top >= scrollY || rect.bottom >= i) {
            scrollY = 0;
        } else {
            if (rect.height() > height) {
                scrollY = 0 - (i - rect.bottom);
            } else {
                scrollY = 0 - (scrollY - rect.top);
            }
            scrollY = Math.max(scrollY, -getScrollY());
        }
        return scrollY;
    }

    public void requestChildFocus(View view, View view2) {
        if (this.f338g) {
            this.f340i = view2;
        } else {
            m318b(view2);
        }
        super.requestChildFocus(view, view2);
    }

    protected boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        View findNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, null, i) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i);
        if (findNextFocus == null || m313a(findNextFocus)) {
            return false;
        }
        return findNextFocus.requestFocus(i, rect);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int a = m306a(rect);
        boolean z2 = a != 0;
        if (z2) {
            if (z) {
                scrollBy(0, a);
            } else {
                m309a(0, a);
            }
        }
        return z2;
    }

    public void requestLayout() {
        this.f338g = true;
        super.requestLayout();
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.f338g = false;
        if (this.f340i != null && m315a(this.f340i, (View) this)) {
            m318b(this.f340i);
        }
        this.f340i = null;
        if (!this.f339h) {
            if (this.f352u != null) {
                scrollTo(getScrollX(), this.f352u.f328a);
                this.f352u = null;
            }
            int max = Math.max(0, (getChildCount() > 0 ? getChildAt(0).getMeasuredHeight() : 0) - (((i4 - i2) - getPaddingBottom()) - getPaddingTop()));
            if (getScrollY() > max) {
                scrollTo(getScrollX(), max);
            } else if (getScrollY() < 0) {
                scrollTo(getScrollX(), 0);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f339h = true;
    }

    public void onAttachedToWindow() {
        this.f339h = false;
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && m314a(findFocus, 0, i4)) {
            findFocus.getDrawingRect(this.f333b);
            offsetDescendantRectToMyCoords(findFocus, this.f333b);
            m323d(m306a(this.f333b));
        }
    }

    private static boolean m315a(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        return (parent instanceof ViewGroup) && m315a((View) parent, view2);
    }

    private void m324e(int i) {
        int scrollY = getScrollY();
        boolean z = (scrollY > 0 || i > 0) && (scrollY < getScrollRange() || i < 0);
        if (!dispatchNestedPreFling(0.0f, (float) i)) {
            dispatchNestedFling(0.0f, (float) i, z);
            if (z && getChildCount() > 0) {
                scrollY = (getHeight() - getPaddingBottom()) - getPaddingTop();
                int height = getChildAt(0).getHeight();
                ow owVar = this.f334c;
                owVar.f5884b.m6690b(owVar.f5883a, getScrollX(), getScrollY(), i, Math.max(0, height - scrollY), scrollY / 2);
                iv.m5922d(this);
            }
        }
    }

    private void m320c() {
        this.f341j = false;
        m317b();
        stopNestedScroll();
        if (this.f335d != null) {
            this.f335d.m6620c();
            this.f336e.m6620c();
        }
    }

    public void scrollTo(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            int b = m316b(i, (getWidth() - getPaddingRight()) - getPaddingLeft(), childAt.getWidth());
            int b2 = m316b(i2, (getHeight() - getPaddingBottom()) - getPaddingTop(), childAt.getHeight());
            if (b != getScrollX() || b2 != getScrollY()) {
                super.scrollTo(b, b2);
            }
        }
    }

    private void m322d() {
        if (iv.m5901a(this) == 2) {
            this.f335d = null;
            this.f336e = null;
        } else if (this.f335d == null) {
            Context context = getContext();
            this.f335d = new oc(context);
            this.f336e = new oc(context);
        }
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f335d != null) {
            int save;
            int width;
            int scrollY = getScrollY();
            if (!this.f335d.m6614a()) {
                save = canvas.save();
                width = (getWidth() - getPaddingLeft()) - getPaddingRight();
                canvas.translate((float) getPaddingLeft(), (float) Math.min(0, scrollY));
                this.f335d.m6613a(width, getHeight());
                if (this.f335d.m6618a(canvas)) {
                    iv.m5922d(this);
                }
                canvas.restoreToCount(save);
            }
            if (!this.f336e.m6614a()) {
                save = canvas.save();
                width = (getWidth() - getPaddingLeft()) - getPaddingRight();
                int height = getHeight();
                canvas.translate((float) ((-width) + getPaddingLeft()), (float) (Math.max(getScrollRange(), scrollY) + height));
                canvas.rotate(180.0f, (float) width, 0.0f);
                this.f336e.m6613a(width, height);
                if (this.f336e.m6618a(canvas)) {
                    iv.m5922d(this);
                }
                canvas.restoreToCount(save);
            }
        }
    }

    private static int m316b(int i, int i2, int i3) {
        if (i2 >= i3 || i < 0) {
            return 0;
        }
        if (i2 + i > i3) {
            return i3 - i2;
        }
        return i;
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.f352u = savedState;
        requestLayout();
    }

    protected Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        savedState.f328a = getScrollY();
        return savedState;
    }
}
