package android.support.v4.app;

import android.support.v4.app.NotificationCompatBase.Action;

interface NotificationBuilderWithActions {
    void addAction(Action action);
}
