package android.support.v4.app;

import android.os.Bundle;
import happy.hacking.ds;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class LoaderManager {

    public interface LoaderCallbacks {
        ds onCreateLoader(int i, Bundle bundle);

        void onLoadFinished(ds dsVar, Object obj);

        void onLoaderReset(ds dsVar);
    }

    public abstract void destroyLoader(int i);

    public abstract void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract ds getLoader(int i);

    public abstract ds initLoader(int i, Bundle bundle, LoaderCallbacks loaderCallbacks);

    public abstract ds restartLoader(int i, Bundle bundle, LoaderCallbacks loaderCallbacks);

    public static void enableDebugLogging(boolean z) {
        LoaderManagerImpl.DEBUG = z;
    }

    public boolean hasRunningLoaders() {
        return false;
    }
}
