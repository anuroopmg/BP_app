package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import happy.hacking.ds;
import happy.hacking.dt;
import happy.hacking.du;
import happy.hacking.fk;
import happy.hacking.fl;
import happy.hacking.ga;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;

class LoaderManagerImpl extends LoaderManager {
    static boolean DEBUG = false;
    static final String TAG = "LoaderManager";
    boolean mCreatingLoader;
    private FragmentHostCallback mHost;
    final ga mInactiveLoaders;
    final ga mLoaders;
    boolean mRetaining;
    boolean mRetainingStarted;
    boolean mStarted;
    final String mWho;

    final class LoaderInfo implements dt, du {
        final Bundle mArgs;
        LoaderCallbacks mCallbacks;
        Object mData;
        boolean mDeliveredData;
        boolean mDestroyed;
        boolean mHaveData;
        final int mId;
        boolean mListenerRegistered;
        ds mLoader;
        LoaderInfo mPendingLoader;
        boolean mReportNextStart;
        boolean mRetaining;
        boolean mRetainingStarted;
        boolean mStarted;

        public LoaderInfo(int i, Bundle bundle, LoaderCallbacks loaderCallbacks) {
            this.mId = i;
            this.mArgs = bundle;
            this.mCallbacks = loaderCallbacks;
        }

        final void start() {
            if (this.mRetaining && this.mRetainingStarted) {
                this.mStarted = true;
            } else if (!this.mStarted) {
                this.mStarted = true;
                if (LoaderManagerImpl.DEBUG) {
                    new StringBuilder("  Starting: ").append(this);
                }
                if (this.mLoader == null && this.mCallbacks != null) {
                    this.mLoader = this.mCallbacks.onCreateLoader(this.mId, this.mArgs);
                }
                if (this.mLoader == null) {
                    return;
                }
                if (!this.mLoader.getClass().isMemberClass() || Modifier.isStatic(this.mLoader.getClass().getModifiers())) {
                    ds dsVar;
                    if (!this.mListenerRegistered) {
                        dsVar = this.mLoader;
                        int i = this.mId;
                        if (dsVar.f5570b != null) {
                            throw new IllegalStateException("There is already a listener registered");
                        }
                        dsVar.f5570b = this;
                        dsVar.f5569a = i;
                        dsVar = this.mLoader;
                        if (dsVar.f5571c != null) {
                            throw new IllegalStateException("There is already a listener registered");
                        }
                        dsVar.f5571c = this;
                        this.mListenerRegistered = true;
                    }
                    dsVar = this.mLoader;
                    dsVar.f5572d = true;
                    dsVar.f5574f = false;
                    dsVar.f5573e = false;
                    return;
                }
                throw new IllegalArgumentException("Object returned from onCreateLoader must not be a non-static inner member class: " + this.mLoader);
            }
        }

        final void retain() {
            if (LoaderManagerImpl.DEBUG) {
                new StringBuilder("  Retaining: ").append(this);
            }
            this.mRetaining = true;
            this.mRetainingStarted = this.mStarted;
            this.mStarted = false;
            this.mCallbacks = null;
        }

        final void finishRetain() {
            if (this.mRetaining) {
                if (LoaderManagerImpl.DEBUG) {
                    new StringBuilder("  Finished Retaining: ").append(this);
                }
                this.mRetaining = false;
                if (!(this.mStarted == this.mRetainingStarted || this.mStarted)) {
                    stop();
                }
            }
            if (this.mStarted && this.mHaveData && !this.mReportNextStart) {
                callOnLoadFinished(this.mLoader, this.mData);
            }
        }

        final void reportStart() {
            if (this.mStarted && this.mReportNextStart) {
                this.mReportNextStart = false;
                if (this.mHaveData) {
                    callOnLoadFinished(this.mLoader, this.mData);
                }
            }
        }

        final void stop() {
            if (LoaderManagerImpl.DEBUG) {
                new StringBuilder("  Stopping: ").append(this);
            }
            this.mStarted = false;
            if (!this.mRetaining && this.mLoader != null && this.mListenerRegistered) {
                this.mListenerRegistered = false;
                this.mLoader.m5530a((du) this);
                this.mLoader.m5529a((dt) this);
                this.mLoader.f5572d = false;
            }
        }

        final void cancel() {
            if (LoaderManagerImpl.DEBUG) {
                new StringBuilder("  Canceling: ").append(this);
            }
            if (this.mStarted && this.mLoader != null && this.mListenerRegistered) {
                onLoadCanceled(this.mLoader);
            }
        }

        final void destroy() {
            dt dtVar;
            String str;
            Object obj = 1;
            LoaderCallbacks loaderCallbacks = null;
            Object obj2 = null;
            while (true) {
                if (LoaderManagerImpl.DEBUG) {
                    new StringBuilder("  Destroying: ").append(dtVar);
                }
                dtVar.mDestroyed = obj;
                boolean z = dtVar.mDeliveredData;
                dtVar.mDeliveredData = obj2;
                if (dtVar.mCallbacks != null && dtVar.mLoader != null && dtVar.mHaveData && z) {
                    if (LoaderManagerImpl.DEBUG) {
                        new StringBuilder("  Reseting: ").append(dtVar);
                    }
                    if (LoaderManagerImpl.this.mHost != null) {
                        String str2 = LoaderManagerImpl.this.mHost.mFragmentManager.mNoTransactionsBecause;
                        LoaderManagerImpl.this.mHost.mFragmentManager.mNoTransactionsBecause = "onLoaderReset";
                        str = str2;
                    } else {
                        Object obj3 = loaderCallbacks;
                    }
                    try {
                        dtVar.mCallbacks.onLoaderReset(dtVar.mLoader);
                    } finally {
                        loaderCallbacks = LoaderManagerImpl.this.mHost;
                        if (loaderCallbacks != null) {
                            loaderCallbacks = LoaderManagerImpl.this.mHost.mFragmentManager;
                            loaderCallbacks.mNoTransactionsBecause = str;
                        }
                        break;
                    }
                }
                dtVar.mCallbacks = loaderCallbacks;
                dtVar.mData = loaderCallbacks;
                dtVar.mHaveData = obj2;
                if (dtVar.mLoader != null) {
                    if (dtVar.mListenerRegistered) {
                        dtVar.mListenerRegistered = obj2;
                        dtVar.mLoader.m5530a((du) dtVar);
                        dtVar.mLoader.m5529a(dtVar);
                    }
                    ds dsVar = dtVar.mLoader;
                    dsVar.f5574f = obj;
                    dsVar.f5572d = obj2;
                    dsVar.f5573e = obj2;
                    dsVar.f5575g = obj2;
                    dsVar.f5576h = obj2;
                }
                if (dtVar.mPendingLoader != null) {
                    dtVar = dtVar.mPendingLoader;
                } else {
                    return;
                }
            }
        }

        public final void onLoadCanceled(ds dsVar) {
            if (LoaderManagerImpl.DEBUG) {
                new StringBuilder("onLoadCanceled: ").append(this);
            }
            boolean z;
            if (this.mDestroyed) {
                z = LoaderManagerImpl.DEBUG;
            } else if (LoaderManagerImpl.this.mLoaders.m5671a(this.mId) != this) {
                z = LoaderManagerImpl.DEBUG;
            } else {
                LoaderInfo loaderInfo = this.mPendingLoader;
                if (loaderInfo != null) {
                    if (LoaderManagerImpl.DEBUG) {
                        new StringBuilder("  Switching to pending loader: ").append(loaderInfo);
                    }
                    this.mPendingLoader = null;
                    LoaderManagerImpl.this.mLoaders.m5672a(this.mId, null);
                    destroy();
                    LoaderManagerImpl.this.installLoader(loaderInfo);
                }
            }
        }

        public final void onLoadComplete(ds dsVar, Object obj) {
            if (LoaderManagerImpl.DEBUG) {
                new StringBuilder("onLoadComplete: ").append(this);
            }
            boolean z;
            if (this.mDestroyed) {
                z = LoaderManagerImpl.DEBUG;
            } else if (LoaderManagerImpl.this.mLoaders.m5671a(this.mId) != this) {
                z = LoaderManagerImpl.DEBUG;
            } else {
                LoaderInfo loaderInfo = this.mPendingLoader;
                if (loaderInfo != null) {
                    if (LoaderManagerImpl.DEBUG) {
                        new StringBuilder("  Switching to pending loader: ").append(loaderInfo);
                    }
                    this.mPendingLoader = null;
                    LoaderManagerImpl.this.mLoaders.m5672a(this.mId, null);
                    destroy();
                    LoaderManagerImpl.this.installLoader(loaderInfo);
                    return;
                }
                if (!(this.mData == obj && this.mHaveData)) {
                    this.mData = obj;
                    this.mHaveData = true;
                    if (this.mStarted) {
                        callOnLoadFinished(dsVar, obj);
                    }
                }
                loaderInfo = (LoaderInfo) LoaderManagerImpl.this.mInactiveLoaders.m5671a(this.mId);
                if (!(loaderInfo == null || loaderInfo == this)) {
                    loaderInfo.mDeliveredData = false;
                    loaderInfo.destroy();
                    ga gaVar = LoaderManagerImpl.this.mInactiveLoaders;
                    int a = fk.m5648a(gaVar.f5647c, gaVar.f5649e, this.mId);
                    if (a >= 0 && gaVar.f5648d[a] != ga.f5645a) {
                        gaVar.f5648d[a] = ga.f5645a;
                        gaVar.f5646b = true;
                    }
                }
                if (LoaderManagerImpl.this.mHost != null && !LoaderManagerImpl.this.hasRunningLoaders()) {
                    LoaderManagerImpl.this.mHost.mFragmentManager.startPendingDeferredFragments();
                }
            }
        }

        final void callOnLoadFinished(ds dsVar, Object obj) {
            String str;
            if (this.mCallbacks != null) {
                if (LoaderManagerImpl.this.mHost != null) {
                    String str2 = LoaderManagerImpl.this.mHost.mFragmentManager.mNoTransactionsBecause;
                    LoaderManagerImpl.this.mHost.mFragmentManager.mNoTransactionsBecause = "onLoadFinished";
                    str = str2;
                } else {
                    str = null;
                }
                try {
                    if (LoaderManagerImpl.DEBUG) {
                        StringBuilder append = new StringBuilder("  onLoadFinished in ").append(dsVar).append(": ");
                        StringBuilder stringBuilder = new StringBuilder(64);
                        fl.m5653a(obj, stringBuilder);
                        stringBuilder.append("}");
                        append.append(stringBuilder.toString());
                    }
                    this.mCallbacks.onLoadFinished(dsVar, obj);
                    this.mDeliveredData = true;
                } finally {
                    if (LoaderManagerImpl.this.mHost != null) {
                        LoaderManagerImpl.this.mHost.mFragmentManager.mNoTransactionsBecause = str;
                    }
                }
            }
        }

        public final String toString() {
            StringBuilder stringBuilder = new StringBuilder(64);
            stringBuilder.append("LoaderInfo{");
            stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
            stringBuilder.append(" #");
            stringBuilder.append(this.mId);
            stringBuilder.append(" : ");
            fl.m5653a(this.mLoader, stringBuilder);
            stringBuilder.append("}}");
            return stringBuilder.toString();
        }

        public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            while (true) {
                printWriter.print(str);
                printWriter.print("mId=");
                printWriter.print(this.mId);
                printWriter.print(" mArgs=");
                printWriter.println(this.mArgs);
                printWriter.print(str);
                printWriter.print("mCallbacks=");
                printWriter.println(this.mCallbacks);
                printWriter.print(str);
                printWriter.print("mLoader=");
                printWriter.println(this.mLoader);
                if (this.mLoader != null) {
                    ds dsVar = this.mLoader;
                    String str2 = str + "  ";
                    printWriter.print(str2);
                    printWriter.print("mId=");
                    printWriter.print(dsVar.f5569a);
                    printWriter.print(" mListener=");
                    printWriter.println(dsVar.f5570b);
                    if (dsVar.f5572d || dsVar.f5575g || dsVar.f5576h) {
                        printWriter.print(str2);
                        printWriter.print("mStarted=");
                        printWriter.print(dsVar.f5572d);
                        printWriter.print(" mContentChanged=");
                        printWriter.print(dsVar.f5575g);
                        printWriter.print(" mProcessingChange=");
                        printWriter.println(dsVar.f5576h);
                    }
                    if (dsVar.f5573e || dsVar.f5574f) {
                        printWriter.print(str2);
                        printWriter.print("mAbandoned=");
                        printWriter.print(dsVar.f5573e);
                        printWriter.print(" mReset=");
                        printWriter.println(dsVar.f5574f);
                    }
                }
                if (this.mHaveData || this.mDeliveredData) {
                    printWriter.print(str);
                    printWriter.print("mHaveData=");
                    printWriter.print(this.mHaveData);
                    printWriter.print("  mDeliveredData=");
                    printWriter.println(this.mDeliveredData);
                    printWriter.print(str);
                    printWriter.print("mData=");
                    printWriter.println(this.mData);
                }
                printWriter.print(str);
                printWriter.print("mStarted=");
                printWriter.print(this.mStarted);
                printWriter.print(" mReportNextStart=");
                printWriter.print(this.mReportNextStart);
                printWriter.print(" mDestroyed=");
                printWriter.println(this.mDestroyed);
                printWriter.print(str);
                printWriter.print("mRetaining=");
                printWriter.print(this.mRetaining);
                printWriter.print(" mRetainingStarted=");
                printWriter.print(this.mRetainingStarted);
                printWriter.print(" mListenerRegistered=");
                printWriter.println(this.mListenerRegistered);
                if (this.mPendingLoader != null) {
                    printWriter.print(str);
                    printWriter.println("Pending Loader ");
                    printWriter.print(this.mPendingLoader);
                    printWriter.println(":");
                    this = this.mPendingLoader;
                    str = str + "  ";
                } else {
                    return;
                }
            }
        }
    }

    static {
        DEBUG = false;
    }

    LoaderManagerImpl(String str, FragmentHostCallback fragmentHostCallback, boolean z) {
        this.mLoaders = new ga();
        this.mInactiveLoaders = new ga();
        this.mWho = str;
        this.mHost = fragmentHostCallback;
        this.mStarted = z;
    }

    void updateHostController(FragmentHostCallback fragmentHostCallback) {
        this.mHost = fragmentHostCallback;
    }

    private LoaderInfo createLoader(int i, Bundle bundle, LoaderCallbacks loaderCallbacks) {
        LoaderInfo loaderInfo = new LoaderInfo(i, bundle, loaderCallbacks);
        loaderInfo.mLoader = loaderCallbacks.onCreateLoader(i, bundle);
        return loaderInfo;
    }

    private LoaderInfo createAndInstallLoader(int i, Bundle bundle, LoaderCallbacks loaderCallbacks) {
        try {
            this.mCreatingLoader = true;
            LoaderInfo createLoader = createLoader(i, bundle, loaderCallbacks);
            installLoader(createLoader);
            return createLoader;
        } finally {
            this.mCreatingLoader = false;
        }
    }

    void installLoader(LoaderInfo loaderInfo) {
        this.mLoaders.m5672a(loaderInfo.mId, loaderInfo);
        if (this.mStarted) {
            loaderInfo.start();
        }
    }

    public ds initLoader(int i, Bundle bundle, LoaderCallbacks loaderCallbacks) {
        if (this.mCreatingLoader) {
            throw new IllegalStateException("Called while creating a loader");
        }
        LoaderInfo loaderInfo = (LoaderInfo) this.mLoaders.m5671a(i);
        if (DEBUG) {
            new StringBuilder("initLoader in ").append(this).append(": args=").append(bundle);
        }
        if (loaderInfo == null) {
            loaderInfo = createAndInstallLoader(i, bundle, loaderCallbacks);
            if (DEBUG) {
                new StringBuilder("  Created new loader ").append(loaderInfo);
            }
        } else {
            if (DEBUG) {
                new StringBuilder("  Re-using existing loader ").append(loaderInfo);
            }
            loaderInfo.mCallbacks = loaderCallbacks;
        }
        if (loaderInfo.mHaveData && this.mStarted) {
            loaderInfo.callOnLoadFinished(loaderInfo.mLoader, loaderInfo.mData);
        }
        return loaderInfo.mLoader;
    }

    public ds restartLoader(int i, Bundle bundle, LoaderCallbacks loaderCallbacks) {
        if (this.mCreatingLoader) {
            throw new IllegalStateException("Called while creating a loader");
        }
        LoaderInfo loaderInfo = (LoaderInfo) this.mLoaders.m5671a(i);
        if (DEBUG) {
            new StringBuilder("restartLoader in ").append(this).append(": args=").append(bundle);
        }
        if (loaderInfo != null) {
            LoaderInfo loaderInfo2 = (LoaderInfo) this.mInactiveLoaders.m5671a(i);
            if (loaderInfo2 != null) {
                if (loaderInfo.mHaveData) {
                    if (DEBUG) {
                        new StringBuilder("  Removing last inactive loader: ").append(loaderInfo);
                    }
                    loaderInfo2.mDeliveredData = false;
                    loaderInfo2.destroy();
                } else if (loaderInfo.mStarted) {
                    loaderInfo.cancel();
                    if (loaderInfo.mPendingLoader != null) {
                        if (DEBUG) {
                            new StringBuilder("  Removing pending loader: ").append(loaderInfo.mPendingLoader);
                        }
                        loaderInfo.mPendingLoader.destroy();
                        loaderInfo.mPendingLoader = null;
                    }
                    loaderInfo.mPendingLoader = createLoader(i, bundle, loaderCallbacks);
                    return loaderInfo.mPendingLoader.mLoader;
                } else {
                    this.mLoaders.m5672a(i, null);
                    loaderInfo.destroy();
                }
            } else if (DEBUG) {
                new StringBuilder("  Making last loader inactive: ").append(loaderInfo);
            }
            loaderInfo.mLoader.f5573e = true;
            this.mInactiveLoaders.m5672a(i, loaderInfo);
        }
        return createAndInstallLoader(i, bundle, loaderCallbacks).mLoader;
    }

    public void destroyLoader(int i) {
        if (this.mCreatingLoader) {
            throw new IllegalStateException("Called while creating a loader");
        }
        if (DEBUG) {
            new StringBuilder("destroyLoader in ").append(this).append(" of ").append(i);
        }
        int e = this.mLoaders.m5677e(i);
        if (e >= 0) {
            LoaderInfo loaderInfo = (LoaderInfo) this.mLoaders.m5676d(e);
            this.mLoaders.m5674b(e);
            loaderInfo.destroy();
        }
        e = this.mInactiveLoaders.m5677e(i);
        if (e >= 0) {
            loaderInfo = (LoaderInfo) this.mInactiveLoaders.m5676d(e);
            this.mInactiveLoaders.m5674b(e);
            loaderInfo.destroy();
        }
        if (this.mHost != null && !hasRunningLoaders()) {
            this.mHost.mFragmentManager.startPendingDeferredFragments();
        }
    }

    public ds getLoader(int i) {
        if (this.mCreatingLoader) {
            throw new IllegalStateException("Called while creating a loader");
        }
        LoaderInfo loaderInfo = (LoaderInfo) this.mLoaders.m5671a(i);
        if (loaderInfo == null) {
            return null;
        }
        if (loaderInfo.mPendingLoader != null) {
            return loaderInfo.mPendingLoader.mLoader;
        }
        return loaderInfo.mLoader;
    }

    void doStart() {
        if (DEBUG) {
            new StringBuilder("Starting in ").append(this);
        }
        if (this.mStarted) {
            new RuntimeException("here").fillInStackTrace();
            new StringBuilder("Called doStart when already started: ").append(this);
            return;
        }
        this.mStarted = true;
        for (int a = this.mLoaders.m5670a() - 1; a >= 0; a--) {
            ((LoaderInfo) this.mLoaders.m5676d(a)).start();
        }
    }

    void doStop() {
        if (DEBUG) {
            new StringBuilder("Stopping in ").append(this);
        }
        if (this.mStarted) {
            for (int a = this.mLoaders.m5670a() - 1; a >= 0; a--) {
                ((LoaderInfo) this.mLoaders.m5676d(a)).stop();
            }
            this.mStarted = false;
            return;
        }
        new RuntimeException("here").fillInStackTrace();
        new StringBuilder("Called doStop when not started: ").append(this);
    }

    void doRetain() {
        if (DEBUG) {
            new StringBuilder("Retaining in ").append(this);
        }
        if (this.mStarted) {
            this.mRetaining = true;
            this.mStarted = false;
            for (int a = this.mLoaders.m5670a() - 1; a >= 0; a--) {
                ((LoaderInfo) this.mLoaders.m5676d(a)).retain();
            }
            return;
        }
        new RuntimeException("here").fillInStackTrace();
        new StringBuilder("Called doRetain when not started: ").append(this);
    }

    void finishRetain() {
        if (this.mRetaining) {
            if (DEBUG) {
                new StringBuilder("Finished Retaining in ").append(this);
            }
            this.mRetaining = false;
            for (int a = this.mLoaders.m5670a() - 1; a >= 0; a--) {
                ((LoaderInfo) this.mLoaders.m5676d(a)).finishRetain();
            }
        }
    }

    void doReportNextStart() {
        for (int a = this.mLoaders.m5670a() - 1; a >= 0; a--) {
            ((LoaderInfo) this.mLoaders.m5676d(a)).mReportNextStart = true;
        }
    }

    void doReportStart() {
        for (int a = this.mLoaders.m5670a() - 1; a >= 0; a--) {
            ((LoaderInfo) this.mLoaders.m5676d(a)).reportStart();
        }
    }

    void doDestroy() {
        int a;
        if (!this.mRetaining) {
            if (DEBUG) {
                new StringBuilder("Destroying Active in ").append(this);
            }
            for (a = this.mLoaders.m5670a() - 1; a >= 0; a--) {
                ((LoaderInfo) this.mLoaders.m5676d(a)).destroy();
            }
            this.mLoaders.m5673b();
        }
        if (DEBUG) {
            new StringBuilder("Destroying Inactive in ").append(this);
        }
        for (a = this.mInactiveLoaders.m5670a() - 1; a >= 0; a--) {
            ((LoaderInfo) this.mInactiveLoaders.m5676d(a)).destroy();
        }
        this.mInactiveLoaders.m5673b();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder(NotificationCompat.FLAG_HIGH_PRIORITY);
        stringBuilder.append("LoaderManager{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
        stringBuilder.append(" in ");
        fl.m5653a(this.mHost, stringBuilder);
        stringBuilder.append("}}");
        return stringBuilder.toString();
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int i = 0;
        if (this.mLoaders.m5670a() > 0) {
            printWriter.print(str);
            printWriter.println("Active Loaders:");
            String str2 = str + "    ";
            for (int i2 = 0; i2 < this.mLoaders.m5670a(); i2++) {
                LoaderInfo loaderInfo = (LoaderInfo) this.mLoaders.m5676d(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(this.mLoaders.m5675c(i2));
                printWriter.print(": ");
                printWriter.println(loaderInfo.toString());
                loaderInfo.dump(str2, fileDescriptor, printWriter, strArr);
            }
        }
        if (this.mInactiveLoaders.m5670a() > 0) {
            printWriter.print(str);
            printWriter.println("Inactive Loaders:");
            String str3 = str + "    ";
            while (i < this.mInactiveLoaders.m5670a()) {
                loaderInfo = (LoaderInfo) this.mInactiveLoaders.m5676d(i);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(this.mInactiveLoaders.m5675c(i));
                printWriter.print(": ");
                printWriter.println(loaderInfo.toString());
                loaderInfo.dump(str3, fileDescriptor, printWriter, strArr);
                i++;
            }
        }
    }

    public boolean hasRunningLoaders() {
        int a = this.mLoaders.m5670a();
        boolean z = false;
        for (int i = 0; i < a; i++) {
            int i2;
            LoaderInfo loaderInfo = (LoaderInfo) this.mLoaders.m5676d(i);
            if (!loaderInfo.mStarted || loaderInfo.mDeliveredData) {
                i2 = 0;
            } else {
                i2 = 1;
            }
            z |= i2;
        }
        return z;
    }
}
