package android.support.v4.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.app.FragmentTransaction;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import happy.hacking.C0020if;
import happy.hacking.et;
import happy.hacking.hu;
import happy.hacking.ir;
import happy.hacking.iv;
import happy.hacking.jm;
import happy.hacking.jz;
import happy.hacking.ka;
import happy.hacking.kb;
import happy.hacking.kc;
import happy.hacking.kd;
import happy.hacking.ke;
import happy.hacking.kf;
import happy.hacking.kg;
import happy.hacking.kh;
import happy.hacking.ki;
import happy.hacking.kj;
import happy.hacking.kk;
import happy.hacking.kl;
import happy.hacking.oc;
import happy.hacking.py;
import happy.hacking.ug;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ViewPager extends ViewGroup {
    private static final kl ah;
    private static final int[] f240c;
    private static final Comparator f241e;
    private static final Interpolator f242f;
    private boolean f243A;
    private int f244B;
    private boolean f245C;
    private boolean f246D;
    private int f247E;
    private int f248F;
    private int f249G;
    private float f250H;
    private float f251I;
    private float f252J;
    private float f253K;
    private int f254L;
    private VelocityTracker f255M;
    private int f256N;
    private int f257O;
    private int f258P;
    private int f259Q;
    private boolean f260R;
    private oc f261S;
    private oc f262T;
    private boolean f263U;
    private boolean f264V;
    private boolean f265W;
    public ki f266a;
    private int aa;
    private List ab;
    private kh ac;
    private kh ad;
    private kg ae;
    private Method af;
    private ArrayList ag;
    private final Runnable ai;
    private int aj;
    public int f267b;
    private int f268d;
    private final ArrayList f269g;
    private final kd f270h;
    private final Rect f271i;
    private C0020if f272j;
    private int f273k;
    private int f274l;
    private Parcelable f275m;
    private ClassLoader f276n;
    private Scroller f277o;
    private kj f278p;
    private int f279q;
    private Drawable f280r;
    private int f281s;
    private int f282t;
    private float f283u;
    private float f284v;
    private int f285w;
    private int f286x;
    private boolean f287y;
    private boolean f288z;

    public class SavedState extends BaseSavedState {
        public static final Creator CREATOR;
        int f237a;
        Parcelable f238b;
        ClassLoader f239c;

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f237a);
            parcel.writeParcelable(this.f238b, i);
        }

        public String toString() {
            return "FragmentPager.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " position=" + this.f237a + "}";
        }

        static {
            CREATOR = et.m5596a(new kk());
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel);
            if (classLoader == null) {
                classLoader = getClass().getClassLoader();
            }
            this.f237a = parcel.readInt();
            this.f238b = parcel.readParcelable(classLoader);
            this.f239c = classLoader;
        }
    }

    static {
        f240c = new int[]{16842931};
        f241e = new jz();
        f242f = new ka();
        ah = new kl();
    }

    public ViewPager(Context context) {
        super(context);
        this.f269g = new ArrayList();
        this.f270h = new kd();
        this.f271i = new Rect();
        this.f274l = -1;
        this.f275m = null;
        this.f276n = null;
        this.f283u = -3.4028235E38f;
        this.f284v = Float.MAX_VALUE;
        this.f244B = 1;
        this.f254L = -1;
        this.f263U = true;
        this.f264V = false;
        this.ai = new kb(this);
        this.aj = 0;
        m264d();
    }

    public ViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f269g = new ArrayList();
        this.f270h = new kd();
        this.f271i = new Rect();
        this.f274l = -1;
        this.f275m = null;
        this.f276n = null;
        this.f283u = -3.4028235E38f;
        this.f284v = Float.MAX_VALUE;
        this.f244B = 1;
        this.f254L = -1;
        this.f263U = true;
        this.f264V = false;
        this.ai = new kb(this);
        this.aj = 0;
        m264d();
    }

    private void m264d() {
        setWillNotDraw(false);
        setDescendantFocusability(262144);
        setFocusable(true);
        Context context = getContext();
        this.f277o = new Scroller(context, f242f);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        float f = context.getResources().getDisplayMetrics().density;
        this.f249G = jm.m6162a(viewConfiguration);
        this.f256N = (int) (400.0f * f);
        this.f257O = viewConfiguration.getScaledMaximumFlingVelocity();
        this.f261S = new oc(context);
        this.f262T = new oc(context);
        this.f258P = (int) (25.0f * f);
        this.f259Q = (int) (2.0f * f);
        this.f247E = (int) (16.0f * f);
        iv.m5908a((View) this, new kf(this));
        if (iv.m5925e(this) == 0) {
            iv.m5920c((View) this, 1);
        }
    }

    protected void onDetachedFromWindow() {
        removeCallbacks(this.ai);
        super.onDetachedFromWindow();
    }

    private void setScrollState(int i) {
        int i2 = 0;
        if (this.aj != i) {
            this.aj = i;
            if (this.f266a != null) {
                int i3;
                if (i != 0) {
                    i3 = 1;
                } else {
                    i3 = 0;
                }
                int childCount = getChildCount();
                for (int i4 = 0; i4 < childCount; i4++) {
                    iv.m5924d(getChildAt(i4), i3 != 0 ? 2 : 0);
                }
            }
            if (this.ac != null) {
                this.ac.m3626a(i);
            }
            if (this.ab != null) {
                int size = this.ab.size();
                while (i2 < size) {
                    kh khVar = (kh) this.ab.get(i2);
                    if (khVar != null) {
                        khVar.m3626a(i);
                    }
                    i2++;
                }
            }
            if (this.ad != null) {
                this.ad.m3626a(i);
            }
        }
    }

    public void setAdapter(C0020if c0020if) {
        if (this.f272j != null) {
            int i;
            this.f272j.unregisterDataSetObserver(this.f278p);
            this.f272j.startUpdate((ViewGroup) this);
            for (i = 0; i < this.f269g.size(); i++) {
                kd kdVar = (kd) this.f269g.get(i);
                this.f272j.destroyItem((ViewGroup) this, kdVar.f5737b, kdVar.f5736a);
            }
            this.f272j.finishUpdate((ViewGroup) this);
            this.f269g.clear();
            i = 0;
            while (i < getChildCount()) {
                if (!((ke) getChildAt(i).getLayoutParams()).f5741a) {
                    removeViewAt(i);
                    i--;
                }
                i++;
            }
            this.f273k = 0;
            scrollTo(0, 0);
        }
        C0020if c0020if2 = this.f272j;
        this.f272j = c0020if;
        this.f268d = 0;
        if (this.f272j != null) {
            if (this.f278p == null) {
                this.f278p = new kj();
            }
            this.f272j.registerDataSetObserver(this.f278p);
            this.f243A = false;
            boolean z = this.f263U;
            this.f263U = true;
            this.f268d = this.f272j.getCount();
            if (this.f274l >= 0) {
                this.f272j.restoreState(this.f275m, this.f276n);
                m250a(this.f274l, false, true);
                this.f274l = -1;
                this.f275m = null;
                this.f276n = null;
            } else if (z) {
                requestLayout();
            } else {
                m276b();
            }
        }
        if (this.ae != null && c0020if2 != c0020if) {
            this.ae.m5875a(c0020if2, c0020if);
        }
    }

    public C0020if getAdapter() {
        return this.f272j;
    }

    public void setOnAdapterChangeListener(kg kgVar) {
        this.ae = kgVar;
    }

    private int getClientWidth() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    public void setCurrentItem(int i) {
        boolean z;
        this.f243A = false;
        if (this.f263U) {
            z = false;
        } else {
            z = true;
        }
        m250a(i, z, false);
    }

    public final void m273a(int i, boolean z) {
        this.f243A = false;
        m250a(i, z, false);
    }

    public int getCurrentItem() {
        return this.f273k;
    }

    private void m250a(int i, boolean z, boolean z2) {
        m251a(i, z, z2, 0);
    }

    private void m251a(int i, boolean z, boolean z2, int i2) {
        boolean z3 = false;
        if (this.f272j == null || this.f272j.getCount() <= 0) {
            setScrollingCacheEnabled(false);
        } else if (z2 || this.f273k != i || this.f269g.size() == 0) {
            if (i < 0) {
                i = 0;
            } else if (i >= this.f272j.getCount()) {
                i = this.f272j.getCount() - 1;
            }
            int i3 = this.f244B;
            if (i > this.f273k + i3 || i < this.f273k - i3) {
                for (int i4 = 0; i4 < this.f269g.size(); i4++) {
                    ((kd) this.f269g.get(i4)).f5738c = true;
                }
            }
            if (this.f273k != i) {
                z3 = true;
            }
            if (this.f263U) {
                this.f273k = i;
                if (z3) {
                    m265d(i);
                }
                requestLayout();
                return;
            }
            m246a(i);
            m249a(i, z, i2, z3);
        } else {
            setScrollingCacheEnabled(false);
        }
    }

    private void m249a(int i, boolean z, int i2, boolean z2) {
        kd b = m259b(i);
        int i3 = 0;
        if (b != null) {
            i3 = (int) (((float) getClientWidth()) * Math.max(this.f283u, Math.min(b.f5740e, this.f284v)));
        }
        if (z) {
            if (getChildCount() == 0) {
                setScrollingCacheEnabled(false);
            } else {
                int scrollX = getScrollX();
                int scrollY = getScrollY();
                int i4 = i3 - scrollX;
                int i5 = 0 - scrollY;
                if (i4 == 0 && i5 == 0) {
                    m255a(false);
                    m276b();
                    setScrollState(0);
                } else {
                    setScrollingCacheEnabled(true);
                    setScrollState(2);
                    i3 = getClientWidth();
                    int i6 = i3 / 2;
                    float f = (float) i6;
                    float sin = (((float) i6) * ((float) Math.sin((double) ((float) (((double) (Math.min(1.0f, (1.0f * ((float) Math.abs(i4))) / ((float) i3)) - 0.5f)) * 0.4712389167638204d))))) + f;
                    int abs = Math.abs(i2);
                    if (abs > 0) {
                        i3 = Math.round(1000.0f * Math.abs(sin / ((float) abs))) * 4;
                    } else {
                        i3 = (int) (((((float) Math.abs(i4)) / ((((float) i3) * this.f272j.getPageWidth(this.f273k)) + ((float) this.f279q))) + 1.0f) * 100.0f);
                    }
                    this.f277o.startScroll(scrollX, scrollY, i4, i5, Math.min(i3, 600));
                    iv.m5922d(this);
                }
            }
            if (z2) {
                m265d(i);
                return;
            }
            return;
        }
        if (z2) {
            m265d(i);
        }
        m255a(false);
        scrollTo(i3, 0);
        m262c(i3);
    }

    @Deprecated
    public void setOnPageChangeListener(kh khVar) {
        this.ac = khVar;
    }

    public final void m274a(kh khVar) {
        if (this.ab == null) {
            this.ab = new ArrayList();
        }
        this.ab.add(khVar);
    }

    public void setChildrenDrawingOrderEnabledCompat(boolean z) {
        if (VERSION.SDK_INT >= 7) {
            if (this.af == null) {
                try {
                    this.af = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", new Class[]{Boolean.TYPE});
                } catch (Throwable e) {
                    Log.e("ViewPager", "Can't find setChildrenDrawingOrderEnabled", e);
                }
            }
            try {
                this.af.invoke(this, new Object[]{Boolean.valueOf(z)});
            } catch (Throwable e2) {
                Log.e("ViewPager", "Error changing children drawing order", e2);
            }
        }
    }

    protected int getChildDrawingOrder(int i, int i2) {
        if (this.f267b == 2) {
            i2 = (i - 1) - i2;
        }
        return ((ke) ((View) this.ag.get(i2)).getLayoutParams()).f5746f;
    }

    public final kh m275b(kh khVar) {
        kh khVar2 = this.ad;
        this.ad = khVar;
        return khVar2;
    }

    public int getOffscreenPageLimit() {
        return this.f244B;
    }

    public void setOffscreenPageLimit(int i) {
        if (i <= 0) {
            new StringBuilder("Requested offscreen page limit ").append(i).append(" too small; defaulting to 1");
            i = 1;
        }
        if (i != this.f244B) {
            this.f244B = i;
            m276b();
        }
    }

    public void setPageMargin(int i) {
        int i2 = this.f279q;
        this.f279q = i;
        int width = getWidth();
        m248a(width, width, i, i2);
        requestLayout();
    }

    public int getPageMargin() {
        return this.f279q;
    }

    public void setPageMarginDrawable(Drawable drawable) {
        this.f280r = drawable;
        if (drawable != null) {
            refreshDrawableState();
        }
        setWillNotDraw(drawable == null);
        invalidate();
    }

    public void setPageMarginDrawable(int i) {
        setPageMarginDrawable(getContext().getResources().getDrawable(i));
    }

    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f280r;
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f280r;
        if (drawable != null && drawable.isStateful()) {
            drawable.setState(getDrawableState());
        }
    }

    private kd m244a(int i, int i2) {
        kd kdVar = new kd();
        kdVar.f5737b = i;
        kdVar.f5736a = this.f272j.instantiateItem((ViewGroup) this, i);
        kdVar.f5739d = this.f272j.getPageWidth(i);
        if (i2 < 0 || i2 >= this.f269g.size()) {
            this.f269g.add(kdVar);
        } else {
            this.f269g.add(i2, kdVar);
        }
        return kdVar;
    }

    public final void m272a() {
        int count = this.f272j.getCount();
        this.f268d = count;
        boolean z = this.f269g.size() < (this.f244B * 2) + 1 && this.f269g.size() < count;
        boolean z2 = false;
        int i = this.f273k;
        boolean z3 = z;
        int i2 = 0;
        while (i2 < this.f269g.size()) {
            int i3;
            boolean z4;
            int max;
            boolean z5;
            kd kdVar = (kd) this.f269g.get(i2);
            int itemPosition = this.f272j.getItemPosition(kdVar.f5736a);
            if (itemPosition != -1) {
                if (itemPosition == -2) {
                    this.f269g.remove(i2);
                    i2--;
                    if (!z2) {
                        this.f272j.startUpdate((ViewGroup) this);
                        z2 = true;
                    }
                    this.f272j.destroyItem((ViewGroup) this, kdVar.f5737b, kdVar.f5736a);
                    if (this.f273k == kdVar.f5737b) {
                        i3 = i2;
                        z4 = z2;
                        max = Math.max(0, Math.min(this.f273k, count - 1));
                        z5 = true;
                    } else {
                        i3 = i2;
                        z4 = z2;
                        max = i;
                        z5 = true;
                    }
                } else if (kdVar.f5737b != itemPosition) {
                    if (kdVar.f5737b == this.f273k) {
                        i = itemPosition;
                    }
                    kdVar.f5737b = itemPosition;
                    i3 = i2;
                    z4 = z2;
                    max = i;
                    z5 = true;
                }
                z3 = z5;
                i = max;
                z2 = z4;
                i2 = i3 + 1;
            }
            i3 = i2;
            z4 = z2;
            max = i;
            z5 = z3;
            z3 = z5;
            i = max;
            z2 = z4;
            i2 = i3 + 1;
        }
        if (z2) {
            this.f272j.finishUpdate((ViewGroup) this);
        }
        Collections.sort(this.f269g, f241e);
        if (z3) {
            max = getChildCount();
            for (i2 = 0; i2 < max; i2++) {
                ke keVar = (ke) getChildAt(i2).getLayoutParams();
                if (!keVar.f5741a) {
                    keVar.f5743c = 0.0f;
                }
            }
            m250a(i, false, true);
            requestLayout();
        }
    }

    public final void m276b() {
        m246a(this.f273k);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m246a(int r19) {
        /*
        r18 = this;
        r3 = 0;
        r2 = 2;
        r0 = r18;
        r4 = r0.f273k;
        r0 = r19;
        if (r4 == r0) goto L_0x0334;
    L_0x000a:
        r0 = r18;
        r2 = r0.f273k;
        r0 = r19;
        if (r2 >= r0) goto L_0x0030;
    L_0x0012:
        r2 = 66;
    L_0x0014:
        r0 = r18;
        r3 = r0.f273k;
        r0 = r18;
        r3 = r0.m259b(r3);
        r0 = r19;
        r1 = r18;
        r1.f273k = r0;
        r4 = r3;
        r3 = r2;
    L_0x0026:
        r0 = r18;
        r2 = r0.f272j;
        if (r2 != 0) goto L_0x0033;
    L_0x002c:
        r18.m266e();
    L_0x002f:
        return;
    L_0x0030:
        r2 = 17;
        goto L_0x0014;
    L_0x0033:
        r0 = r18;
        r2 = r0.f243A;
        if (r2 == 0) goto L_0x003d;
    L_0x0039:
        r18.m266e();
        goto L_0x002f;
    L_0x003d:
        r2 = r18.getWindowToken();
        if (r2 == 0) goto L_0x002f;
    L_0x0043:
        r0 = r18;
        r2 = r0.f272j;
        r0 = r18;
        r2.startUpdate(r0);
        r0 = r18;
        r2 = r0.f244B;
        r5 = 0;
        r0 = r18;
        r6 = r0.f273k;
        r6 = r6 - r2;
        r11 = java.lang.Math.max(r5, r6);
        r0 = r18;
        r5 = r0.f272j;
        r12 = r5.getCount();
        r5 = r12 + -1;
        r0 = r18;
        r6 = r0.f273k;
        r2 = r2 + r6;
        r13 = java.lang.Math.min(r5, r2);
        r0 = r18;
        r2 = r0.f268d;
        if (r12 == r2) goto L_0x00d6;
    L_0x0073:
        r2 = r18.getResources();	 Catch:{ NotFoundException -> 0x00cc }
        r3 = r18.getId();	 Catch:{ NotFoundException -> 0x00cc }
        r2 = r2.getResourceName(r3);	 Catch:{ NotFoundException -> 0x00cc }
    L_0x007f:
        r3 = new java.lang.IllegalStateException;
        r4 = new java.lang.StringBuilder;
        r5 = "The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: ";
        r4.<init>(r5);
        r0 = r18;
        r5 = r0.f268d;
        r4 = r4.append(r5);
        r5 = ", found: ";
        r4 = r4.append(r5);
        r4 = r4.append(r12);
        r5 = " Pager id: ";
        r4 = r4.append(r5);
        r2 = r4.append(r2);
        r4 = " Pager class: ";
        r2 = r2.append(r4);
        r4 = r18.getClass();
        r2 = r2.append(r4);
        r4 = " Problematic adapter: ";
        r2 = r2.append(r4);
        r0 = r18;
        r4 = r0.f272j;
        r4 = r4.getClass();
        r2 = r2.append(r4);
        r2 = r2.toString();
        r3.<init>(r2);
        throw r3;
    L_0x00cc:
        r2 = move-exception;
        r2 = r18.getId();
        r2 = java.lang.Integer.toHexString(r2);
        goto L_0x007f;
    L_0x00d6:
        r6 = 0;
        r2 = 0;
        r5 = r2;
    L_0x00d9:
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.size();
        if (r5 >= r2) goto L_0x0331;
    L_0x00e3:
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.get(r5);
        r2 = (happy.hacking.kd) r2;
        r7 = r2.f5737b;
        r0 = r18;
        r8 = r0.f273k;
        if (r7 < r8) goto L_0x016b;
    L_0x00f5:
        r7 = r2.f5737b;
        r0 = r18;
        r8 = r0.f273k;
        if (r7 != r8) goto L_0x0331;
    L_0x00fd:
        if (r2 != 0) goto L_0x032e;
    L_0x00ff:
        if (r12 <= 0) goto L_0x032e;
    L_0x0101:
        r0 = r18;
        r2 = r0.f273k;
        r0 = r18;
        r2 = r0.m244a(r2, r5);
        r10 = r2;
    L_0x010c:
        if (r10 == 0) goto L_0x028f;
    L_0x010e:
        r9 = 0;
        r8 = r5 + -1;
        if (r8 < 0) goto L_0x0170;
    L_0x0113:
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.get(r8);
        r2 = (happy.hacking.kd) r2;
    L_0x011d:
        r14 = r18.getClientWidth();
        if (r14 > 0) goto L_0x0172;
    L_0x0123:
        r6 = 0;
    L_0x0124:
        r0 = r18;
        r7 = r0.f273k;
        r7 = r7 + -1;
        r16 = r7;
        r7 = r9;
        r9 = r16;
        r17 = r8;
        r8 = r5;
        r5 = r17;
    L_0x0134:
        if (r9 < 0) goto L_0x01b8;
    L_0x0136:
        r15 = (r7 > r6 ? 1 : (r7 == r6 ? 0 : -1));
        if (r15 < 0) goto L_0x0182;
    L_0x013a:
        if (r9 >= r11) goto L_0x0182;
    L_0x013c:
        if (r2 == 0) goto L_0x01b8;
    L_0x013e:
        r15 = r2.f5737b;
        if (r9 != r15) goto L_0x0168;
    L_0x0142:
        r15 = r2.f5738c;
        if (r15 != 0) goto L_0x0168;
    L_0x0146:
        r0 = r18;
        r15 = r0.f269g;
        r15.remove(r5);
        r0 = r18;
        r15 = r0.f272j;
        r2 = r2.f5736a;
        r0 = r18;
        r15.destroyItem(r0, r9, r2);
        r5 = r5 + -1;
        r8 = r8 + -1;
        if (r5 < 0) goto L_0x0180;
    L_0x015e:
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.get(r5);
        r2 = (happy.hacking.kd) r2;
    L_0x0168:
        r9 = r9 + -1;
        goto L_0x0134;
    L_0x016b:
        r2 = r5 + 1;
        r5 = r2;
        goto L_0x00d9;
    L_0x0170:
        r2 = 0;
        goto L_0x011d;
    L_0x0172:
        r6 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r7 = r10.f5739d;
        r6 = r6 - r7;
        r7 = r18.getPaddingLeft();
        r7 = (float) r7;
        r15 = (float) r14;
        r7 = r7 / r15;
        r6 = r6 + r7;
        goto L_0x0124;
    L_0x0180:
        r2 = 0;
        goto L_0x0168;
    L_0x0182:
        if (r2 == 0) goto L_0x019c;
    L_0x0184:
        r15 = r2.f5737b;
        if (r9 != r15) goto L_0x019c;
    L_0x0188:
        r2 = r2.f5739d;
        r7 = r7 + r2;
        r5 = r5 + -1;
        if (r5 < 0) goto L_0x019a;
    L_0x018f:
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.get(r5);
        r2 = (happy.hacking.kd) r2;
        goto L_0x0168;
    L_0x019a:
        r2 = 0;
        goto L_0x0168;
    L_0x019c:
        r2 = r5 + 1;
        r0 = r18;
        r2 = r0.m244a(r9, r2);
        r2 = r2.f5739d;
        r7 = r7 + r2;
        r8 = r8 + 1;
        if (r5 < 0) goto L_0x01b6;
    L_0x01ab:
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.get(r5);
        r2 = (happy.hacking.kd) r2;
        goto L_0x0168;
    L_0x01b6:
        r2 = 0;
        goto L_0x0168;
    L_0x01b8:
        r6 = r10.f5739d;
        r9 = r8 + 1;
        r2 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r2 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1));
        if (r2 >= 0) goto L_0x028a;
    L_0x01c2:
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.size();
        if (r9 >= r2) goto L_0x022c;
    L_0x01cc:
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.get(r9);
        r2 = (happy.hacking.kd) r2;
        r7 = r2;
    L_0x01d7:
        if (r14 > 0) goto L_0x022e;
    L_0x01d9:
        r2 = 0;
        r5 = r2;
    L_0x01db:
        r0 = r18;
        r2 = r0.f273k;
        r2 = r2 + 1;
        r16 = r7;
        r7 = r9;
        r9 = r2;
        r2 = r16;
    L_0x01e7:
        if (r9 >= r12) goto L_0x028a;
    L_0x01e9:
        r11 = (r6 > r5 ? 1 : (r6 == r5 ? 0 : -1));
        if (r11 < 0) goto L_0x023c;
    L_0x01ed:
        if (r9 <= r13) goto L_0x023c;
    L_0x01ef:
        if (r2 == 0) goto L_0x028a;
    L_0x01f1:
        r11 = r2.f5737b;
        if (r9 != r11) goto L_0x0327;
    L_0x01f5:
        r11 = r2.f5738c;
        if (r11 != 0) goto L_0x0327;
    L_0x01f9:
        r0 = r18;
        r11 = r0.f269g;
        r11.remove(r7);
        r0 = r18;
        r11 = r0.f272j;
        r2 = r2.f5736a;
        r0 = r18;
        r11.destroyItem(r0, r9, r2);
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.size();
        if (r7 >= r2) goto L_0x023a;
    L_0x0215:
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.get(r7);
        r2 = (happy.hacking.kd) r2;
    L_0x021f:
        r16 = r6;
        r6 = r2;
        r2 = r16;
    L_0x0224:
        r9 = r9 + 1;
        r16 = r2;
        r2 = r6;
        r6 = r16;
        goto L_0x01e7;
    L_0x022c:
        r7 = 0;
        goto L_0x01d7;
    L_0x022e:
        r2 = r18.getPaddingRight();
        r2 = (float) r2;
        r5 = (float) r14;
        r2 = r2 / r5;
        r5 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r2 = r2 + r5;
        r5 = r2;
        goto L_0x01db;
    L_0x023a:
        r2 = 0;
        goto L_0x021f;
    L_0x023c:
        if (r2 == 0) goto L_0x0263;
    L_0x023e:
        r11 = r2.f5737b;
        if (r9 != r11) goto L_0x0263;
    L_0x0242:
        r2 = r2.f5739d;
        r6 = r6 + r2;
        r7 = r7 + 1;
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.size();
        if (r7 >= r2) goto L_0x0261;
    L_0x0251:
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.get(r7);
        r2 = (happy.hacking.kd) r2;
    L_0x025b:
        r16 = r6;
        r6 = r2;
        r2 = r16;
        goto L_0x0224;
    L_0x0261:
        r2 = 0;
        goto L_0x025b;
    L_0x0263:
        r0 = r18;
        r2 = r0.m244a(r9, r7);
        r7 = r7 + 1;
        r2 = r2.f5739d;
        r6 = r6 + r2;
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.size();
        if (r7 >= r2) goto L_0x0288;
    L_0x0278:
        r0 = r18;
        r2 = r0.f269g;
        r2 = r2.get(r7);
        r2 = (happy.hacking.kd) r2;
    L_0x0282:
        r16 = r6;
        r6 = r2;
        r2 = r16;
        goto L_0x0224;
    L_0x0288:
        r2 = 0;
        goto L_0x0282;
    L_0x028a:
        r0 = r18;
        r0.m254a(r10, r8, r4);
    L_0x028f:
        r0 = r18;
        r4 = r0.f272j;
        r0 = r18;
        r5 = r0.f273k;
        if (r10 == 0) goto L_0x02de;
    L_0x0299:
        r2 = r10.f5736a;
    L_0x029b:
        r0 = r18;
        r4.setPrimaryItem(r0, r5, r2);
        r0 = r18;
        r2 = r0.f272j;
        r0 = r18;
        r2.finishUpdate(r0);
        r5 = r18.getChildCount();
        r2 = 0;
        r4 = r2;
    L_0x02af:
        if (r4 >= r5) goto L_0x02e0;
    L_0x02b1:
        r0 = r18;
        r6 = r0.getChildAt(r4);
        r2 = r6.getLayoutParams();
        r2 = (happy.hacking.ke) r2;
        r2.f5746f = r4;
        r7 = r2.f5741a;
        if (r7 != 0) goto L_0x02da;
    L_0x02c3:
        r7 = r2.f5743c;
        r8 = 0;
        r7 = (r7 > r8 ? 1 : (r7 == r8 ? 0 : -1));
        if (r7 != 0) goto L_0x02da;
    L_0x02ca:
        r0 = r18;
        r6 = r0.m245a(r6);
        if (r6 == 0) goto L_0x02da;
    L_0x02d2:
        r7 = r6.f5739d;
        r2.f5743c = r7;
        r6 = r6.f5737b;
        r2.f5745e = r6;
    L_0x02da:
        r2 = r4 + 1;
        r4 = r2;
        goto L_0x02af;
    L_0x02de:
        r2 = 0;
        goto L_0x029b;
    L_0x02e0:
        r18.m266e();
        r2 = r18.hasFocus();
        if (r2 == 0) goto L_0x002f;
    L_0x02e9:
        r2 = r18.findFocus();
        if (r2 == 0) goto L_0x0325;
    L_0x02ef:
        r0 = r18;
        r2 = r0.m260b(r2);
    L_0x02f5:
        if (r2 == 0) goto L_0x02ff;
    L_0x02f7:
        r2 = r2.f5737b;
        r0 = r18;
        r4 = r0.f273k;
        if (r2 == r4) goto L_0x002f;
    L_0x02ff:
        r2 = 0;
    L_0x0300:
        r4 = r18.getChildCount();
        if (r2 >= r4) goto L_0x002f;
    L_0x0306:
        r0 = r18;
        r4 = r0.getChildAt(r2);
        r0 = r18;
        r5 = r0.m245a(r4);
        if (r5 == 0) goto L_0x0322;
    L_0x0314:
        r5 = r5.f5737b;
        r0 = r18;
        r6 = r0.f273k;
        if (r5 != r6) goto L_0x0322;
    L_0x031c:
        r4 = r4.requestFocus(r3);
        if (r4 != 0) goto L_0x002f;
    L_0x0322:
        r2 = r2 + 1;
        goto L_0x0300;
    L_0x0325:
        r2 = 0;
        goto L_0x02f5;
    L_0x0327:
        r16 = r6;
        r6 = r2;
        r2 = r16;
        goto L_0x0224;
    L_0x032e:
        r10 = r2;
        goto L_0x010c;
    L_0x0331:
        r2 = r6;
        goto L_0x00fd;
    L_0x0334:
        r4 = r3;
        r3 = r2;
        goto L_0x0026;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.a(int):void");
    }

    private void m266e() {
        if (this.f267b != 0) {
            if (this.ag == null) {
                this.ag = new ArrayList();
            } else {
                this.ag.clear();
            }
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                this.ag.add(getChildAt(i));
            }
            Collections.sort(this.ag, ah);
        }
    }

    private void m254a(kd kdVar, int i, kd kdVar2) {
        float f;
        kd kdVar3;
        float f2;
        int i2;
        int i3;
        int count = this.f272j.getCount();
        int clientWidth = getClientWidth();
        if (clientWidth > 0) {
            f = ((float) this.f279q) / ((float) clientWidth);
        } else {
            f = 0.0f;
        }
        if (kdVar2 != null) {
            clientWidth = kdVar2.f5737b;
            float f3;
            int i4;
            int i5;
            int i6;
            float pageWidth;
            if (clientWidth < kdVar.f5737b) {
                f3 = (kdVar2.f5740e + kdVar2.f5739d) + f;
                i4 = 0;
                i5 = clientWidth + 1;
                while (i5 <= kdVar.f5737b && i4 < this.f269g.size()) {
                    kdVar3 = (kd) this.f269g.get(i4);
                    while (i5 > kdVar3.f5737b && i4 < this.f269g.size() - 1) {
                        i4++;
                        kdVar3 = (kd) this.f269g.get(i4);
                    }
                    i6 = i5;
                    f2 = f3;
                    i2 = i6;
                    while (i2 < kdVar3.f5737b) {
                        pageWidth = (this.f272j.getPageWidth(i2) + f) + f2;
                        i2++;
                        f2 = pageWidth;
                    }
                    kdVar3.f5740e = f2;
                    f2 += kdVar3.f5739d + f;
                    clientWidth = i2 + 1;
                    f3 = f2;
                    i5 = clientWidth;
                }
            } else if (clientWidth > kdVar.f5737b) {
                i4 = this.f269g.size() - 1;
                f3 = kdVar2.f5740e;
                i5 = clientWidth - 1;
                while (i5 >= kdVar.f5737b && i4 >= 0) {
                    kdVar3 = (kd) this.f269g.get(i4);
                    while (i5 < kdVar3.f5737b && i4 > 0) {
                        i4--;
                        kdVar3 = (kd) this.f269g.get(i4);
                    }
                    i6 = i5;
                    f2 = f3;
                    i2 = i6;
                    while (i2 > kdVar3.f5737b) {
                        pageWidth = f2 - (this.f272j.getPageWidth(i2) + f);
                        i2--;
                        f2 = pageWidth;
                    }
                    f2 -= kdVar3.f5739d + f;
                    kdVar3.f5740e = f2;
                    clientWidth = i2 - 1;
                    f3 = f2;
                    i5 = clientWidth;
                }
            }
        }
        int size = this.f269g.size();
        f2 = kdVar.f5740e;
        i2 = kdVar.f5737b - 1;
        this.f283u = kdVar.f5737b == 0 ? kdVar.f5740e : -3.4028235E38f;
        this.f284v = kdVar.f5737b == count + -1 ? (kdVar.f5740e + kdVar.f5739d) - 1.0f : Float.MAX_VALUE;
        for (i3 = i - 1; i3 >= 0; i3--) {
            kdVar3 = (kd) this.f269g.get(i3);
            while (i2 > kdVar3.f5737b) {
                f2 -= this.f272j.getPageWidth(i2) + f;
                i2--;
            }
            f2 -= kdVar3.f5739d + f;
            kdVar3.f5740e = f2;
            if (kdVar3.f5737b == 0) {
                this.f283u = f2;
            }
            i2--;
        }
        f2 = (kdVar.f5740e + kdVar.f5739d) + f;
        i2 = kdVar.f5737b + 1;
        for (i3 = i + 1; i3 < size; i3++) {
            kdVar3 = (kd) this.f269g.get(i3);
            while (i2 < kdVar3.f5737b) {
                f2 += this.f272j.getPageWidth(i2) + f;
                i2++;
            }
            if (kdVar3.f5737b == count - 1) {
                this.f284v = (kdVar3.f5739d + f2) - 1.0f;
            }
            kdVar3.f5740e = f2;
            f2 += kdVar3.f5739d + f;
            i2++;
        }
        this.f264V = false;
    }

    public Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        savedState.f237a = this.f273k;
        if (this.f272j != null) {
            savedState.f238b = this.f272j.saveState();
        }
        return savedState;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            super.onRestoreInstanceState(savedState.getSuperState());
            if (this.f272j != null) {
                this.f272j.restoreState(savedState.f238b, savedState.f239c);
                m250a(savedState.f237a, false, true);
                return;
            }
            this.f274l = savedState.f237a;
            this.f275m = savedState.f238b;
            this.f276n = savedState.f239c;
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    public void addView(View view, int i, LayoutParams layoutParams) {
        LayoutParams layoutParams2;
        if (checkLayoutParams(layoutParams)) {
            layoutParams2 = layoutParams;
        } else {
            layoutParams2 = generateLayoutParams(layoutParams);
        }
        ke keVar = (ke) layoutParams2;
        keVar.f5741a |= view instanceof kc;
        if (!this.f287y) {
            super.addView(view, i, layoutParams2);
        } else if (keVar == null || !keVar.f5741a) {
            keVar.f5744d = true;
            addViewInLayout(view, i, layoutParams2);
        } else {
            throw new IllegalStateException("Cannot add pager decor view during layout");
        }
    }

    public void removeView(View view) {
        if (this.f287y) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    private kd m245a(View view) {
        for (int i = 0; i < this.f269g.size(); i++) {
            kd kdVar = (kd) this.f269g.get(i);
            if (this.f272j.isViewFromObject(view, kdVar.f5736a)) {
                return kdVar;
            }
        }
        return null;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private happy.hacking.kd m260b(android.view.View r3) {
        /*
        r2 = this;
    L_0x0000:
        r0 = r3.getParent();
        if (r0 == r2) goto L_0x0012;
    L_0x0006:
        if (r0 == 0) goto L_0x000c;
    L_0x0008:
        r1 = r0 instanceof android.view.View;
        if (r1 != 0) goto L_0x000e;
    L_0x000c:
        r0 = 0;
    L_0x000d:
        return r0;
    L_0x000e:
        r0 = (android.view.View) r0;
        r3 = r0;
        goto L_0x0000;
    L_0x0012:
        r0 = r2.m245a(r3);
        goto L_0x000d;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.b(android.view.View):happy.hacking.kd");
    }

    private kd m259b(int i) {
        for (int i2 = 0; i2 < this.f269g.size(); i2++) {
            kd kdVar = (kd) this.f269g.get(i2);
            if (kdVar.f5737b == i) {
                return kdVar;
            }
        }
        return null;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f263U = true;
    }

    protected void onMeasure(int i, int i2) {
        ke keVar;
        int i3;
        setMeasuredDimension(getDefaultSize(0, i), getDefaultSize(0, i2));
        int measuredWidth = getMeasuredWidth();
        this.f248F = Math.min(measuredWidth / 10, this.f247E);
        int paddingLeft = (measuredWidth - getPaddingLeft()) - getPaddingRight();
        int measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        int childCount = getChildCount();
        for (int i4 = 0; i4 < childCount; i4++) {
            int i5;
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() != 8) {
                keVar = (ke) childAt.getLayoutParams();
                if (keVar != null && keVar.f5741a) {
                    int i6 = keVar.f5742b & 7;
                    int i7 = keVar.f5742b & 112;
                    i3 = Integer.MIN_VALUE;
                    i5 = Integer.MIN_VALUE;
                    Object obj = (i7 == 48 || i7 == 80) ? 1 : null;
                    Object obj2 = (i6 == 3 || i6 == 5) ? 1 : null;
                    if (obj != null) {
                        i3 = 1073741824;
                    } else if (obj2 != null) {
                        i5 = 1073741824;
                    }
                    if (keVar.width != -2) {
                        i7 = 1073741824;
                        i3 = keVar.width != -1 ? keVar.width : paddingLeft;
                    } else {
                        i7 = i3;
                        i3 = paddingLeft;
                    }
                    if (keVar.height != -2) {
                        i5 = 1073741824;
                        if (keVar.height != -1) {
                            measuredWidth = keVar.height;
                            childAt.measure(MeasureSpec.makeMeasureSpec(i3, i7), MeasureSpec.makeMeasureSpec(measuredWidth, i5));
                            if (obj != null) {
                                measuredHeight -= childAt.getMeasuredHeight();
                            } else if (obj2 != null) {
                                paddingLeft -= childAt.getMeasuredWidth();
                            }
                        }
                    }
                    measuredWidth = measuredHeight;
                    childAt.measure(MeasureSpec.makeMeasureSpec(i3, i7), MeasureSpec.makeMeasureSpec(measuredWidth, i5));
                    if (obj != null) {
                        measuredHeight -= childAt.getMeasuredHeight();
                    } else if (obj2 != null) {
                        paddingLeft -= childAt.getMeasuredWidth();
                    }
                }
            }
        }
        this.f285w = MeasureSpec.makeMeasureSpec(paddingLeft, 1073741824);
        this.f286x = MeasureSpec.makeMeasureSpec(measuredHeight, 1073741824);
        this.f287y = true;
        m276b();
        this.f287y = false;
        i3 = getChildCount();
        for (i5 = 0; i5 < i3; i5++) {
            View childAt2 = getChildAt(i5);
            if (childAt2.getVisibility() != 8) {
                keVar = (ke) childAt2.getLayoutParams();
                if (keVar == null || !keVar.f5741a) {
                    childAt2.measure(MeasureSpec.makeMeasureSpec((int) (keVar.f5743c * ((float) paddingLeft)), 1073741824), this.f286x);
                }
            }
        }
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3) {
            m248a(i, i3, this.f279q, this.f279q);
        }
    }

    private void m248a(int i, int i2, int i3, int i4) {
        if (i2 <= 0 || this.f269g.isEmpty()) {
            kd b = m259b(this.f273k);
            int min = (int) ((b != null ? Math.min(b.f5740e, this.f284v) : 0.0f) * ((float) ((i - getPaddingLeft()) - getPaddingRight())));
            if (min != getScrollX()) {
                m255a(false);
                scrollTo(min, getScrollY());
                return;
            }
            return;
        }
        int paddingLeft = (int) (((float) (((i - getPaddingLeft()) - getPaddingRight()) + i3)) * (((float) getScrollX()) / ((float) (((i2 - getPaddingLeft()) - getPaddingRight()) + i4))));
        scrollTo(paddingLeft, getScrollY());
        if (!this.f277o.isFinished()) {
            this.f277o.startScroll(paddingLeft, 0, (int) (m259b(this.f273k).f5740e * ((float) i)), 0, this.f277o.getDuration() - this.f277o.timePassed());
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        ke keVar;
        int max;
        int childCount = getChildCount();
        int i5 = i3 - i;
        int i6 = i4 - i2;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int i7 = 0;
        int i8 = 0;
        while (i8 < childCount) {
            int measuredWidth;
            View childAt = getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                keVar = (ke) childAt.getLayoutParams();
                if (keVar.f5741a) {
                    int i9 = keVar.f5742b & 112;
                    switch (keVar.f5742b & 7) {
                        case ug.RecyclerView_layoutManager /*1*/:
                            max = Math.max((i5 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                            break;
                        case ug.RecyclerView_reverseLayout /*3*/:
                            max = paddingLeft;
                            paddingLeft = childAt.getMeasuredWidth() + paddingLeft;
                            break;
                        case py.Toolbar_contentInsetStart /*5*/:
                            measuredWidth = (i5 - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                            max = measuredWidth;
                            break;
                        default:
                            max = paddingLeft;
                            break;
                    }
                    int i10;
                    switch (i9) {
                        case py.Toolbar_titleMarginBottom /*16*/:
                            measuredWidth = Math.max((i6 - childAt.getMeasuredHeight()) / 2, paddingTop);
                            i10 = paddingBottom;
                            paddingBottom = paddingTop;
                            paddingTop = i10;
                            break;
                        case py.Theme_homeAsUpIndicator /*48*/:
                            measuredWidth = childAt.getMeasuredHeight() + paddingTop;
                            i10 = paddingTop;
                            paddingTop = paddingBottom;
                            paddingBottom = measuredWidth;
                            measuredWidth = i10;
                            break;
                        case py.Theme_panelMenuListTheme /*80*/:
                            measuredWidth = (i6 - paddingBottom) - childAt.getMeasuredHeight();
                            i10 = paddingBottom + childAt.getMeasuredHeight();
                            paddingBottom = paddingTop;
                            paddingTop = i10;
                            break;
                        default:
                            measuredWidth = paddingTop;
                            i10 = paddingBottom;
                            paddingBottom = paddingTop;
                            paddingTop = i10;
                            break;
                    }
                    max += scrollX;
                    childAt.layout(max, measuredWidth, childAt.getMeasuredWidth() + max, childAt.getMeasuredHeight() + measuredWidth);
                    measuredWidth = i7 + 1;
                    i7 = paddingBottom;
                    paddingBottom = paddingTop;
                    paddingTop = paddingRight;
                    paddingRight = paddingLeft;
                    i8++;
                    paddingLeft = paddingRight;
                    paddingRight = paddingTop;
                    paddingTop = i7;
                    i7 = measuredWidth;
                }
            }
            measuredWidth = i7;
            i7 = paddingTop;
            paddingTop = paddingRight;
            paddingRight = paddingLeft;
            i8++;
            paddingLeft = paddingRight;
            paddingRight = paddingTop;
            paddingTop = i7;
            i7 = measuredWidth;
        }
        max = (i5 - paddingLeft) - paddingRight;
        for (paddingRight = 0; paddingRight < childCount; paddingRight++) {
            View childAt2 = getChildAt(paddingRight);
            if (childAt2.getVisibility() != 8) {
                keVar = (ke) childAt2.getLayoutParams();
                if (!keVar.f5741a) {
                    kd a = m245a(childAt2);
                    if (a != null) {
                        i5 = ((int) (a.f5740e * ((float) max))) + paddingLeft;
                        if (keVar.f5744d) {
                            keVar.f5744d = false;
                            childAt2.measure(MeasureSpec.makeMeasureSpec((int) (keVar.f5743c * ((float) max)), 1073741824), MeasureSpec.makeMeasureSpec((i6 - paddingTop) - paddingBottom, 1073741824));
                        }
                        childAt2.layout(i5, paddingTop, childAt2.getMeasuredWidth() + i5, childAt2.getMeasuredHeight() + paddingTop);
                    }
                }
            }
        }
        this.f281s = paddingTop;
        this.f282t = i6 - paddingBottom;
        this.aa = i7;
        if (this.f263U) {
            m249a(this.f273k, false, 0, false);
        }
        this.f263U = false;
    }

    public void computeScroll() {
        if (this.f277o.isFinished() || !this.f277o.computeScrollOffset()) {
            m255a(true);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int currX = this.f277o.getCurrX();
        int currY = this.f277o.getCurrY();
        if (!(scrollX == currX && scrollY == currY)) {
            scrollTo(currX, currY);
            if (!m262c(currX)) {
                this.f277o.abortAnimation();
                scrollTo(0, currY);
            }
        }
        iv.m5922d(this);
    }

    private boolean m262c(int i) {
        if (this.f269g.size() == 0) {
            this.f265W = false;
            m247a(0, 0.0f);
            if (this.f265W) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
        kd h = m270h();
        int clientWidth = getClientWidth();
        float f = ((float) this.f279q) / ((float) clientWidth);
        int i2 = h.f5737b;
        float f2 = ((((float) i) / ((float) clientWidth)) - h.f5740e) / (h.f5739d + f);
        this.f265W = false;
        m247a(i2, f2);
        if (this.f265W) {
            return true;
        }
        throw new IllegalStateException("onPageScrolled did not call superclass implementation");
    }

    private void m247a(int i, float f) {
        int paddingLeft;
        int paddingRight;
        int i2;
        if (this.aa > 0) {
            int scrollX = getScrollX();
            paddingLeft = getPaddingLeft();
            paddingRight = getPaddingRight();
            int width = getWidth();
            int childCount = getChildCount();
            i2 = 0;
            while (i2 < childCount) {
                int i3;
                View childAt = getChildAt(i2);
                ke keVar = (ke) childAt.getLayoutParams();
                if (keVar.f5741a) {
                    int max;
                    switch (keVar.f5742b & 7) {
                        case ug.RecyclerView_layoutManager /*1*/:
                            max = Math.max((width - childAt.getMeasuredWidth()) / 2, paddingLeft);
                            i3 = paddingRight;
                            paddingRight = paddingLeft;
                            paddingLeft = i3;
                            break;
                        case ug.RecyclerView_reverseLayout /*3*/:
                            max = childAt.getWidth() + paddingLeft;
                            i3 = paddingLeft;
                            paddingLeft = paddingRight;
                            paddingRight = max;
                            max = i3;
                            break;
                        case py.Toolbar_contentInsetStart /*5*/:
                            max = (width - paddingRight) - childAt.getMeasuredWidth();
                            i3 = paddingRight + childAt.getMeasuredWidth();
                            paddingRight = paddingLeft;
                            paddingLeft = i3;
                            break;
                        default:
                            max = paddingLeft;
                            i3 = paddingRight;
                            paddingRight = paddingLeft;
                            paddingLeft = i3;
                            break;
                    }
                    max = (max + scrollX) - childAt.getLeft();
                    if (max != 0) {
                        childAt.offsetLeftAndRight(max);
                    }
                } else {
                    i3 = paddingRight;
                    paddingRight = paddingLeft;
                    paddingLeft = i3;
                }
                i2++;
                i3 = paddingLeft;
                paddingLeft = paddingRight;
                paddingRight = i3;
            }
        }
        if (this.ac != null) {
            this.ac.m3627a(i, f);
        }
        if (this.ab != null) {
            paddingRight = this.ab.size();
            for (paddingLeft = 0; paddingLeft < paddingRight; paddingLeft++) {
                kh khVar = (kh) this.ab.get(paddingLeft);
                if (khVar != null) {
                    khVar.m3627a(i, f);
                }
            }
        }
        if (this.ad != null) {
            this.ad.m3627a(i, f);
        }
        if (this.f266a != null) {
            paddingRight = getScrollX();
            i2 = getChildCount();
            for (paddingLeft = 0; paddingLeft < i2; paddingLeft++) {
                View childAt2 = getChildAt(paddingLeft);
                if (!((ke) childAt2.getLayoutParams()).f5741a) {
                    this.f266a.m5193a(childAt2, ((float) (childAt2.getLeft() - paddingRight)) / ((float) getClientWidth()));
                }
            }
        }
        this.f265W = true;
    }

    private void m265d(int i) {
        if (this.ac != null) {
            this.ac.m3628b(i);
        }
        if (this.ab != null) {
            int size = this.ab.size();
            for (int i2 = 0; i2 < size; i2++) {
                kh khVar = (kh) this.ab.get(i2);
                if (khVar != null) {
                    khVar.m3628b(i);
                }
            }
        }
        if (this.ad != null) {
            this.ad.m3628b(i);
        }
    }

    private void m255a(boolean z) {
        int scrollX;
        boolean z2 = this.aj == 2;
        if (z2) {
            setScrollingCacheEnabled(false);
            this.f277o.abortAnimation();
            scrollX = getScrollX();
            int scrollY = getScrollY();
            int currX = this.f277o.getCurrX();
            int currY = this.f277o.getCurrY();
            if (!(scrollX == currX && scrollY == currY)) {
                scrollTo(currX, currY);
                if (currX != scrollX) {
                    m262c(currX);
                }
            }
        }
        this.f243A = false;
        boolean z3 = z2;
        for (scrollX = 0; scrollX < this.f269g.size(); scrollX++) {
            kd kdVar = (kd) this.f269g.get(scrollX);
            if (kdVar.f5738c) {
                kdVar.f5738c = false;
                z3 = true;
            }
        }
        if (!z3) {
            return;
        }
        if (z) {
            iv.m5910a((View) this, this.ai);
        } else {
            this.ai.run();
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & 255;
        if (action == 3 || action == 1) {
            m268f();
            return false;
        }
        if (action != 0) {
            if (this.f245C) {
                return true;
            }
            if (this.f246D) {
                return false;
            }
        }
        float x;
        switch (action) {
            case ug.RecyclerView_android_orientation /*0*/:
                x = motionEvent.getX();
                this.f252J = x;
                this.f250H = x;
                x = motionEvent.getY();
                this.f253K = x;
                this.f251I = x;
                this.f254L = hu.m5840b(motionEvent, 0);
                this.f246D = false;
                this.f277o.computeScrollOffset();
                if (this.aj == 2 && Math.abs(this.f277o.getFinalX() - this.f277o.getCurrX()) > this.f259Q) {
                    this.f277o.abortAnimation();
                    this.f243A = false;
                    m276b();
                    this.f245C = true;
                    m269g();
                    setScrollState(1);
                    break;
                }
                m255a(false);
                this.f245C = false;
                break;
                break;
            case ug.RecyclerView_spanCount /*2*/:
                action = this.f254L;
                if (action != -1) {
                    action = hu.m5838a(motionEvent, action);
                    float c = hu.m5841c(motionEvent, action);
                    float f = c - this.f250H;
                    float abs = Math.abs(f);
                    float d = hu.m5843d(motionEvent, action);
                    float abs2 = Math.abs(d - this.f253K);
                    if (f != 0.0f) {
                        boolean z;
                        x = this.f250H;
                        if ((x >= ((float) this.f248F) || f <= 0.0f) && (x <= ((float) (getWidth() - this.f248F)) || f >= 0.0f)) {
                            z = false;
                        } else {
                            z = true;
                        }
                        if (!z && m257a(this, false, (int) f, (int) c, (int) d)) {
                            this.f250H = c;
                            this.f251I = d;
                            this.f246D = true;
                            return false;
                        }
                    }
                    if (abs > ((float) this.f249G) && 0.5f * abs > abs2) {
                        this.f245C = true;
                        m269g();
                        setScrollState(1);
                        this.f250H = f > 0.0f ? this.f252J + ((float) this.f249G) : this.f252J - ((float) this.f249G);
                        this.f251I = d;
                        setScrollingCacheEnabled(true);
                    } else if (abs2 > ((float) this.f249G)) {
                        this.f246D = true;
                    }
                    if (this.f245C && m256a(c)) {
                        iv.m5922d(this);
                        break;
                    }
                }
                break;
            case py.Toolbar_contentInsetEnd /*6*/:
                m253a(motionEvent);
                break;
        }
        if (this.f255M == null) {
            this.f255M = VelocityTracker.obtain();
        }
        this.f255M.addMovement(motionEvent);
        return this.f245C;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z = false;
        if (this.f260R) {
            return true;
        }
        if (motionEvent.getAction() == 0 && motionEvent.getEdgeFlags() != 0) {
            return false;
        }
        if (this.f272j == null || this.f272j.getCount() == 0) {
            return false;
        }
        if (this.f255M == null) {
            this.f255M = VelocityTracker.obtain();
        }
        this.f255M.addMovement(motionEvent);
        float x;
        int i;
        float f;
        switch (motionEvent.getAction() & 255) {
            case ug.RecyclerView_android_orientation /*0*/:
                this.f277o.abortAnimation();
                this.f243A = false;
                m276b();
                x = motionEvent.getX();
                this.f252J = x;
                this.f250H = x;
                x = motionEvent.getY();
                this.f253K = x;
                this.f251I = x;
                this.f254L = hu.m5840b(motionEvent, 0);
                break;
            case ug.RecyclerView_layoutManager /*1*/:
                if (this.f245C) {
                    VelocityTracker velocityTracker = this.f255M;
                    velocityTracker.computeCurrentVelocity(1000, (float) this.f257O);
                    int a = (int) ir.m5883a(velocityTracker, this.f254L);
                    this.f243A = true;
                    int clientWidth = getClientWidth();
                    int scrollX = getScrollX();
                    kd h = m270h();
                    i = h.f5737b;
                    f = ((((float) scrollX) / ((float) clientWidth)) - h.f5740e) / h.f5739d;
                    if (Math.abs((int) (hu.m5841c(motionEvent, hu.m5838a(motionEvent, this.f254L)) - this.f252J)) <= this.f258P || Math.abs(a) <= this.f256N) {
                        scrollX = (int) ((((float) i) + f) + (i >= this.f273k ? 0.4f : 0.6f));
                    } else {
                        if (a <= 0) {
                            i++;
                        }
                        scrollX = i;
                    }
                    if (this.f269g.size() > 0) {
                        scrollX = Math.max(((kd) this.f269g.get(0)).f5737b, Math.min(scrollX, ((kd) this.f269g.get(this.f269g.size() - 1)).f5737b));
                    }
                    m251a(scrollX, true, true, a);
                    z = m268f();
                    break;
                }
                break;
            case ug.RecyclerView_spanCount /*2*/:
                if (!this.f245C) {
                    i = hu.m5838a(motionEvent, this.f254L);
                    if (i == -1) {
                        z = m268f();
                        break;
                    }
                    float c = hu.m5841c(motionEvent, i);
                    f = Math.abs(c - this.f250H);
                    float d = hu.m5843d(motionEvent, i);
                    x = Math.abs(d - this.f251I);
                    if (f > ((float) this.f249G) && f > x) {
                        this.f245C = true;
                        m269g();
                        if (c - this.f252J > 0.0f) {
                            x = this.f252J + ((float) this.f249G);
                        } else {
                            x = this.f252J - ((float) this.f249G);
                        }
                        this.f250H = x;
                        this.f251I = d;
                        setScrollState(1);
                        setScrollingCacheEnabled(true);
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
                if (this.f245C) {
                    z = m256a(hu.m5841c(motionEvent, hu.m5838a(motionEvent, this.f254L))) | 0;
                    break;
                }
                break;
            case ug.RecyclerView_reverseLayout /*3*/:
                if (this.f245C) {
                    m249a(this.f273k, true, 0, false);
                    z = m268f();
                    break;
                }
                break;
            case py.Toolbar_contentInsetStart /*5*/:
                i = hu.m5839b(motionEvent);
                this.f250H = hu.m5841c(motionEvent, i);
                this.f254L = hu.m5840b(motionEvent, i);
                break;
            case py.Toolbar_contentInsetEnd /*6*/:
                m253a(motionEvent);
                this.f250H = hu.m5841c(motionEvent, hu.m5838a(motionEvent, this.f254L));
                break;
        }
        if (z) {
            iv.m5922d(this);
        }
        return true;
    }

    private boolean m268f() {
        this.f254L = -1;
        this.f245C = false;
        this.f246D = false;
        if (this.f255M != null) {
            this.f255M.recycle();
            this.f255M = null;
        }
        return this.f261S.m6620c() | this.f262T.m6620c();
    }

    private void m269g() {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
    }

    private boolean m256a(float f) {
        boolean z;
        float f2;
        boolean z2 = true;
        boolean z3 = false;
        float f3 = this.f250H - f;
        this.f250H = f;
        float scrollX = ((float) getScrollX()) + f3;
        int clientWidth = getClientWidth();
        float f4 = ((float) clientWidth) * this.f283u;
        float f5 = ((float) clientWidth) * this.f284v;
        kd kdVar = (kd) this.f269g.get(0);
        kd kdVar2 = (kd) this.f269g.get(this.f269g.size() - 1);
        if (kdVar.f5737b != 0) {
            f4 = kdVar.f5740e * ((float) clientWidth);
            z = false;
        } else {
            z = true;
        }
        if (kdVar2.f5737b != this.f272j.getCount() - 1) {
            f2 = kdVar2.f5740e * ((float) clientWidth);
            z2 = false;
        } else {
            f2 = f5;
        }
        if (scrollX < f4) {
            if (z) {
                z3 = this.f261S.m6615a(Math.abs(f4 - scrollX) / ((float) clientWidth));
            }
        } else if (scrollX > f2) {
            if (z2) {
                z3 = this.f262T.m6615a(Math.abs(scrollX - f2) / ((float) clientWidth));
            }
            f4 = f2;
        } else {
            f4 = scrollX;
        }
        this.f250H += f4 - ((float) ((int) f4));
        scrollTo((int) f4, getScrollY());
        m262c((int) f4);
        return z3;
    }

    private kd m270h() {
        float f;
        int clientWidth = getClientWidth();
        float scrollX = clientWidth > 0 ? ((float) getScrollX()) / ((float) clientWidth) : 0.0f;
        if (clientWidth > 0) {
            f = ((float) this.f279q) / ((float) clientWidth);
        } else {
            f = 0.0f;
        }
        float f2 = 0.0f;
        float f3 = 0.0f;
        int i = -1;
        int i2 = 0;
        Object obj = 1;
        kd kdVar = null;
        while (i2 < this.f269g.size()) {
            int i3;
            kd kdVar2;
            kd kdVar3 = (kd) this.f269g.get(i2);
            kd kdVar4;
            if (obj != null || kdVar3.f5737b == i + 1) {
                kdVar4 = kdVar3;
                i3 = i2;
                kdVar2 = kdVar4;
            } else {
                kdVar3 = this.f270h;
                kdVar3.f5740e = (f2 + f3) + f;
                kdVar3.f5737b = i + 1;
                kdVar3.f5739d = this.f272j.getPageWidth(kdVar3.f5737b);
                kdVar4 = kdVar3;
                i3 = i2 - 1;
                kdVar2 = kdVar4;
            }
            f2 = kdVar2.f5740e;
            f3 = (kdVar2.f5739d + f2) + f;
            if (obj == null && scrollX < f2) {
                return kdVar;
            }
            if (scrollX < f3 || i3 == this.f269g.size() - 1) {
                return kdVar2;
            }
            f3 = f2;
            i = kdVar2.f5737b;
            obj = null;
            f2 = kdVar2.f5739d;
            kdVar = kdVar2;
            i2 = i3 + 1;
        }
        return kdVar;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        int i = 0;
        int a = iv.m5901a(this);
        if (a == 0 || (a == 1 && this.f272j != null && this.f272j.getCount() > 1)) {
            int width;
            if (!this.f261S.m6614a()) {
                a = canvas.save();
                i = (getHeight() - getPaddingTop()) - getPaddingBottom();
                width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((float) ((-i) + getPaddingTop()), this.f283u * ((float) width));
                this.f261S.m6613a(i, width);
                i = this.f261S.m6618a(canvas) | 0;
                canvas.restoreToCount(a);
            }
            if (!this.f262T.m6614a()) {
                a = canvas.save();
                width = getWidth();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float) (-getPaddingTop()), (-(this.f284v + 1.0f)) * ((float) width));
                this.f262T.m6613a(height, width);
                i |= this.f262T.m6618a(canvas);
                canvas.restoreToCount(a);
            }
        } else {
            this.f261S.m6619b();
            this.f262T.m6619b();
        }
        if (i != 0) {
            iv.m5922d(this);
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f279q > 0 && this.f280r != null && this.f269g.size() > 0 && this.f272j != null) {
            int scrollX = getScrollX();
            int width = getWidth();
            float f = ((float) this.f279q) / ((float) width);
            kd kdVar = (kd) this.f269g.get(0);
            float f2 = kdVar.f5740e;
            int size = this.f269g.size();
            int i = kdVar.f5737b;
            int i2 = ((kd) this.f269g.get(size - 1)).f5737b;
            int i3 = 0;
            int i4 = i;
            while (i4 < i2) {
                float f3;
                while (i4 > kdVar.f5737b && i3 < size) {
                    i3++;
                    kdVar = (kd) this.f269g.get(i3);
                }
                if (i4 == kdVar.f5737b) {
                    f3 = (kdVar.f5740e + kdVar.f5739d) * ((float) width);
                    f2 = (kdVar.f5740e + kdVar.f5739d) + f;
                } else {
                    float pageWidth = this.f272j.getPageWidth(i4);
                    f3 = (f2 + pageWidth) * ((float) width);
                    f2 += pageWidth + f;
                }
                if (((float) this.f279q) + f3 > ((float) scrollX)) {
                    this.f280r.setBounds((int) f3, this.f281s, (int) ((((float) this.f279q) + f3) + 0.5f), this.f282t);
                    this.f280r.draw(canvas);
                }
                if (f3 <= ((float) (scrollX + width))) {
                    i4++;
                } else {
                    return;
                }
            }
        }
    }

    private void m253a(MotionEvent motionEvent) {
        int b = hu.m5839b(motionEvent);
        if (hu.m5840b(motionEvent, b) == this.f254L) {
            b = b == 0 ? 1 : 0;
            this.f250H = hu.m5841c(motionEvent, b);
            this.f254L = hu.m5840b(motionEvent, b);
            if (this.f255M != null) {
                this.f255M.clear();
            }
        }
    }

    private void setScrollingCacheEnabled(boolean z) {
        if (this.f288z != z) {
            this.f288z = z;
        }
    }

    public boolean canScrollHorizontally(int i) {
        if (this.f272j == null) {
            return false;
        }
        int clientWidth = getClientWidth();
        int scrollX = getScrollX();
        if (i < 0) {
            if (scrollX > ((int) (((float) clientWidth) * this.f283u))) {
                return true;
            }
            return false;
        } else if (i <= 0 || scrollX >= ((int) (((float) clientWidth) * this.f284v))) {
            return false;
        } else {
            return true;
        }
    }

    private boolean m257a(View view, boolean z, int i, int i2, int i3) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (i2 + scrollX >= childAt.getLeft() && i2 + scrollX < childAt.getRight() && i3 + scrollY >= childAt.getTop() && i3 + scrollY < childAt.getBottom()) {
                    if (m257a(childAt, true, i, (i2 + scrollX) - childAt.getLeft(), (i3 + scrollY) - childAt.getTop())) {
                        return true;
                    }
                }
            }
        }
        if (z && iv.m5913a(view, -i)) {
            return true;
        }
        return false;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean dispatchKeyEvent(android.view.KeyEvent r5) {
        /*
        r4 = this;
        r1 = 1;
        r0 = 0;
        r2 = super.dispatchKeyEvent(r5);
        if (r2 != 0) goto L_0x0018;
    L_0x0008:
        r2 = r5.getAction();
        if (r2 != 0) goto L_0x0015;
    L_0x000e:
        r2 = r5.getKeyCode();
        switch(r2) {
            case 21: goto L_0x001a;
            case 22: goto L_0x0021;
            case 61: goto L_0x0028;
            default: goto L_0x0015;
        };
    L_0x0015:
        r2 = r0;
    L_0x0016:
        if (r2 == 0) goto L_0x0019;
    L_0x0018:
        r0 = r1;
    L_0x0019:
        return r0;
    L_0x001a:
        r2 = 17;
        r2 = r4.m267e(r2);
        goto L_0x0016;
    L_0x0021:
        r2 = 66;
        r2 = r4.m267e(r2);
        goto L_0x0016;
    L_0x0028:
        r2 = android.os.Build.VERSION.SDK_INT;
        r3 = 11;
        if (r2 < r3) goto L_0x0015;
    L_0x002e:
        r2 = happy.hacking.gv.m5772b(r5);
        if (r2 == 0) goto L_0x003a;
    L_0x0034:
        r2 = 2;
        r2 = r4.m267e(r2);
        goto L_0x0016;
    L_0x003a:
        r2 = happy.hacking.gv.m5771a(r5);
        if (r2 == 0) goto L_0x0015;
    L_0x0040:
        r2 = r4.m267e(r1);
        goto L_0x0016;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.dispatchKeyEvent(android.view.KeyEvent):boolean");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean m267e(int r10) {
        /*
        r9 = this;
        r1 = 0;
        r8 = 66;
        r7 = 17;
        r4 = 0;
        r3 = 1;
        r2 = r9.findFocus();
        if (r2 != r9) goto L_0x003f;
    L_0x000d:
        r0 = r1;
    L_0x000e:
        r1 = android.view.FocusFinder.getInstance();
        r1 = r1.findNextFocus(r9, r0, r10);
        if (r1 == 0) goto L_0x00bd;
    L_0x0018:
        if (r1 == r0) goto L_0x00bd;
    L_0x001a:
        if (r10 != r7) goto L_0x00a1;
    L_0x001c:
        r2 = r9.f271i;
        r2 = r9.m243a(r2, r1);
        r2 = r2.left;
        r3 = r9.f271i;
        r3 = r9.m243a(r3, r0);
        r3 = r3.left;
        if (r0 == 0) goto L_0x009c;
    L_0x002e:
        if (r2 < r3) goto L_0x009c;
    L_0x0030:
        r0 = r9.m271i();
    L_0x0034:
        r4 = r0;
    L_0x0035:
        if (r4 == 0) goto L_0x003e;
    L_0x0037:
        r0 = android.view.SoundEffectConstants.getContantForFocusDirection(r10);
        r9.playSoundEffect(r0);
    L_0x003e:
        return r4;
    L_0x003f:
        if (r2 == 0) goto L_0x00e9;
    L_0x0041:
        r0 = r2.getParent();
    L_0x0045:
        r5 = r0 instanceof android.view.ViewGroup;
        if (r5 == 0) goto L_0x00ec;
    L_0x0049:
        if (r0 != r9) goto L_0x007c;
    L_0x004b:
        r0 = r3;
    L_0x004c:
        if (r0 != 0) goto L_0x00e9;
    L_0x004e:
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r0 = r2.getClass();
        r0 = r0.getSimpleName();
        r5.append(r0);
        r0 = r2.getParent();
    L_0x0062:
        r2 = r0 instanceof android.view.ViewGroup;
        if (r2 == 0) goto L_0x0081;
    L_0x0066:
        r2 = " => ";
        r2 = r5.append(r2);
        r6 = r0.getClass();
        r6 = r6.getSimpleName();
        r2.append(r6);
        r0 = r0.getParent();
        goto L_0x0062;
    L_0x007c:
        r0 = r0.getParent();
        goto L_0x0045;
    L_0x0081:
        r0 = "ViewPager";
        r2 = new java.lang.StringBuilder;
        r6 = "arrowScroll tried to find focus based on non-child current focused view ";
        r2.<init>(r6);
        r5 = r5.toString();
        r2 = r2.append(r5);
        r2 = r2.toString();
        android.util.Log.e(r0, r2);
        r0 = r1;
        goto L_0x000e;
    L_0x009c:
        r0 = r1.requestFocus();
        goto L_0x0034;
    L_0x00a1:
        if (r10 != r8) goto L_0x0035;
    L_0x00a3:
        r2 = r9.f271i;
        r2 = r9.m243a(r2, r1);
        r2 = r2.left;
        r5 = r9.f271i;
        r5 = r9.m243a(r5, r0);
        r5 = r5.left;
        if (r0 == 0) goto L_0x00b7;
    L_0x00b5:
        if (r2 <= r5) goto L_0x00cc;
    L_0x00b7:
        r0 = r1.requestFocus();
        goto L_0x0034;
    L_0x00bd:
        if (r10 == r7) goto L_0x00c1;
    L_0x00bf:
        if (r10 != r3) goto L_0x00c7;
    L_0x00c1:
        r0 = r9.m271i();
        goto L_0x0034;
    L_0x00c7:
        if (r10 == r8) goto L_0x00cc;
    L_0x00c9:
        r0 = 2;
        if (r10 != r0) goto L_0x0035;
    L_0x00cc:
        r0 = r9.f272j;
        if (r0 == 0) goto L_0x00e6;
    L_0x00d0:
        r0 = r9.f273k;
        r1 = r9.f272j;
        r1 = r1.getCount();
        r1 = r1 + -1;
        if (r0 >= r1) goto L_0x00e6;
    L_0x00dc:
        r0 = r9.f273k;
        r0 = r0 + 1;
        r9.m273a(r0, r3);
        r0 = r3;
        goto L_0x0034;
    L_0x00e6:
        r0 = r4;
        goto L_0x0034;
    L_0x00e9:
        r0 = r2;
        goto L_0x000e;
    L_0x00ec:
        r0 = r4;
        goto L_0x004c;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.view.ViewPager.e(int):boolean");
    }

    private Rect m243a(Rect rect, View view) {
        Rect rect2;
        if (rect == null) {
            rect2 = new Rect();
        } else {
            rect2 = rect;
        }
        if (view == null) {
            rect2.set(0, 0, 0, 0);
            return rect2;
        }
        rect2.left = view.getLeft();
        rect2.right = view.getRight();
        rect2.top = view.getTop();
        rect2.bottom = view.getBottom();
        ViewPager parent = view.getParent();
        while ((parent instanceof ViewGroup) && parent != this) {
            ViewGroup viewGroup = parent;
            rect2.left += viewGroup.getLeft();
            rect2.right += viewGroup.getRight();
            rect2.top += viewGroup.getTop();
            rect2.bottom += viewGroup.getBottom();
            parent = viewGroup.getParent();
        }
        return rect2;
    }

    private boolean m271i() {
        if (this.f273k <= 0) {
            return false;
        }
        m273a(this.f273k - 1, true);
        return true;
    }

    public void addFocusables(ArrayList arrayList, int i, int i2) {
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i3 = 0; i3 < getChildCount(); i3++) {
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() == 0) {
                    kd a = m245a(childAt);
                    if (a != null && a.f5737b == this.f273k) {
                        childAt.addFocusables(arrayList, i, i2);
                    }
                }
            }
        }
        if ((descendantFocusability == 262144 && size != arrayList.size()) || !isFocusable()) {
            return;
        }
        if (((i2 & 1) != 1 || !isInTouchMode() || isFocusableInTouchMode()) && arrayList != null) {
            arrayList.add(this);
        }
    }

    public void addTouchables(ArrayList arrayList) {
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0) {
                kd a = m245a(childAt);
                if (a != null && a.f5737b == this.f273k) {
                    childAt.addTouchables(arrayList);
                }
            }
        }
    }

    protected boolean onRequestFocusInDescendants(int i, Rect rect) {
        int i2;
        int i3 = -1;
        int childCount = getChildCount();
        if ((i & 2) != 0) {
            i3 = 1;
            i2 = 0;
        } else {
            i2 = childCount - 1;
            childCount = -1;
        }
        while (i2 != childCount) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() == 0) {
                kd a = m245a(childAt);
                if (a != null && a.f5737b == this.f273k && childAt.requestFocus(i, rect)) {
                    return true;
                }
            }
            i2 += i3;
        }
        return false;
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == FragmentTransaction.TRANSIT_ENTER_MASK) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0) {
                kd a = m245a(childAt);
                if (a != null && a.f5737b == this.f273k && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                    return true;
                }
            }
        }
        return false;
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new ke();
    }

    protected LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return generateDefaultLayoutParams();
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return (layoutParams instanceof ke) && super.checkLayoutParams(layoutParams);
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ke(getContext(), attributeSet);
    }
}
