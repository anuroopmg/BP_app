package android.support.v4.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import happy.hacking.ig;
import happy.hacking.ih;
import happy.hacking.ii;
import happy.hacking.ug;

public class PagerTabStrip extends ii {
    private int f221f;
    private int f222g;
    private int f223h;
    private int f224i;
    private int f225j;
    private int f226k;
    private final Paint f227l;
    private final Rect f228m;
    private int f229n;
    private boolean f230o;
    private boolean f231p;
    private int f232q;
    private boolean f233r;
    private float f234s;
    private float f235t;
    private int f236u;

    public PagerTabStrip(Context context) {
        this(context, null);
    }

    public PagerTabStrip(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f227l = new Paint();
        this.f228m = new Rect();
        this.f229n = 255;
        this.f230o = false;
        this.f231p = false;
        this.f221f = this.e;
        this.f227l.setColor(this.f221f);
        float f = context.getResources().getDisplayMetrics().density;
        this.f222g = (int) ((3.0f * f) + 0.5f);
        this.f223h = (int) ((6.0f * f) + 0.5f);
        this.f224i = (int) (64.0f * f);
        this.f226k = (int) ((16.0f * f) + 0.5f);
        this.f232q = (int) ((1.0f * f) + 0.5f);
        this.f225j = (int) ((f * 32.0f) + 0.5f);
        this.f236u = ViewConfiguration.get(context).getScaledTouchSlop();
        setPadding(getPaddingLeft(), getPaddingTop(), getPaddingRight(), getPaddingBottom());
        setTextSpacing(getTextSpacing());
        setWillNotDraw(false);
        this.b.setFocusable(true);
        this.b.setOnClickListener(new ig(this));
        this.d.setFocusable(true);
        this.d.setOnClickListener(new ih(this));
        if (getBackground() == null) {
            this.f230o = true;
        }
    }

    public void setTabIndicatorColor(int i) {
        this.f221f = i;
        this.f227l.setColor(this.f221f);
        invalidate();
    }

    public void setTabIndicatorColorResource(int i) {
        setTabIndicatorColor(getContext().getResources().getColor(i));
    }

    public int getTabIndicatorColor() {
        return this.f221f;
    }

    public void setPadding(int i, int i2, int i3, int i4) {
        if (i4 < this.f223h) {
            i4 = this.f223h;
        }
        super.setPadding(i, i2, i3, i4);
    }

    public void setTextSpacing(int i) {
        if (i < this.f224i) {
            i = this.f224i;
        }
        super.setTextSpacing(i);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        if (!this.f231p) {
            this.f230o = drawable == null;
        }
    }

    public void setBackgroundColor(int i) {
        super.setBackgroundColor(i);
        if (!this.f231p) {
            this.f230o = (-16777216 & i) == 0;
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        if (!this.f231p) {
            this.f230o = i == 0;
        }
    }

    public void setDrawFullUnderline(boolean z) {
        this.f230o = z;
        this.f231p = true;
        invalidate();
    }

    public boolean getDrawFullUnderline() {
        return this.f230o;
    }

    int getMinHeight() {
        return Math.max(super.getMinHeight(), this.f225j);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (action != 0 && this.f233r) {
            return false;
        }
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        switch (action) {
            case ug.RecyclerView_android_orientation /*0*/:
                this.f234s = x;
                this.f235t = y;
                this.f233r = false;
                break;
            case ug.RecyclerView_layoutManager /*1*/:
                if (x >= ((float) (this.c.getLeft() - this.f226k))) {
                    if (x > ((float) (this.c.getRight() + this.f226k))) {
                        this.a.setCurrentItem(this.a.getCurrentItem() + 1);
                        break;
                    }
                }
                this.a.setCurrentItem(this.a.getCurrentItem() - 1);
                break;
                break;
            case ug.RecyclerView_spanCount /*2*/:
                if (Math.abs(x - this.f234s) > ((float) this.f236u) || Math.abs(y - this.f235t) > ((float) this.f236u)) {
                    this.f233r = true;
                    break;
                }
        }
        return true;
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int height = getHeight();
        int left = this.c.getLeft() - this.f226k;
        int right = this.c.getRight() + this.f226k;
        int i = height - this.f222g;
        this.f227l.setColor((this.f229n << 24) | (this.f221f & 16777215));
        canvas.drawRect((float) left, (float) i, (float) right, (float) height, this.f227l);
        if (this.f230o) {
            this.f227l.setColor(-16777216 | (this.f221f & 16777215));
            canvas.drawRect((float) getPaddingLeft(), (float) (height - this.f232q), (float) (getWidth() - getPaddingRight()), (float) height, this.f227l);
        }
    }

    final void m242a(int i, float f, boolean z) {
        Rect rect = this.f228m;
        int height = getHeight();
        int i2 = height - this.f222g;
        rect.set(this.c.getLeft() - this.f226k, i2, this.c.getRight() + this.f226k, height);
        super.m239a(i, f, z);
        this.f229n = (int) ((Math.abs(f - 0.5f) * 2.0f) * 255.0f);
        rect.union(this.c.getLeft() - this.f226k, i2, this.c.getRight() + this.f226k, height);
        invalidate(rect);
    }
}
