package android.support.v4.media.session;

import android.os.Build.VERSION;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import happy.hacking.es;

public final class MediaSessionCompat {

    public final class Token implements Parcelable {
        public static final Creator CREATOR;
        public final Object f203a;

        public Token(Object obj) {
            this.f203a = obj;
        }

        public final int describeContents() {
            return 0;
        }

        public final void writeToParcel(Parcel parcel, int i) {
            if (VERSION.SDK_INT >= 21) {
                parcel.writeParcelable((Parcelable) this.f203a, i);
            } else {
                parcel.writeStrongBinder((IBinder) this.f203a);
            }
        }

        static {
            CREATOR = new es();
        }
    }
}
