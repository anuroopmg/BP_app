package android.support.percent;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.RelativeLayout;
import happy.hacking.dc;
import happy.hacking.dd;
import happy.hacking.de;
import happy.hacking.df;
import happy.hacking.hk;

public class PercentRelativeLayout extends RelativeLayout {
    private final dc f197a;

    public /* synthetic */ LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return m237a(attributeSet);
    }

    public /* synthetic */ RelativeLayout.LayoutParams m7476generateLayoutParams(AttributeSet attributeSet) {
        return m237a(attributeSet);
    }

    public PercentRelativeLayout(Context context) {
        super(context);
        this.f197a = new dc(this);
    }

    public PercentRelativeLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f197a = new dc(this);
    }

    public PercentRelativeLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f197a = new dc(this);
    }

    private df m237a(AttributeSet attributeSet) {
        return new df(getContext(), attributeSet);
    }

    protected void onMeasure(int i, int i2) {
        dc dcVar = this.f197a;
        if (Log.isLoggable("PercentLayout", 3)) {
            new StringBuilder("adjustChildren: ").append(dcVar.f5484a).append(" widthMeasureSpec: ").append(MeasureSpec.toString(i)).append(" heightMeasureSpec: ").append(MeasureSpec.toString(i2));
        }
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        int childCount = dcVar.f5484a.getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = dcVar.f5484a.getChildAt(i3);
            LayoutParams layoutParams = childAt.getLayoutParams();
            if (Log.isLoggable("PercentLayout", 3)) {
                new StringBuilder("should adjust ").append(childAt).append(" ").append(layoutParams);
            }
            if (layoutParams instanceof de) {
                dd a = ((de) layoutParams).m5519a();
                if (Log.isLoggable("PercentLayout", 3)) {
                    new StringBuilder("using ").append(a);
                }
                if (a != null) {
                    if (layoutParams instanceof MarginLayoutParams) {
                        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) layoutParams;
                        a.m5495a(marginLayoutParams, size, size2);
                        a.f5547j.leftMargin = marginLayoutParams.leftMargin;
                        a.f5547j.topMargin = marginLayoutParams.topMargin;
                        a.f5547j.rightMargin = marginLayoutParams.rightMargin;
                        a.f5547j.bottomMargin = marginLayoutParams.bottomMargin;
                        hk.m5793a(a.f5547j, hk.m5792a(marginLayoutParams));
                        hk.m5795b(a.f5547j, hk.m5794b(marginLayoutParams));
                        if (a.f5540c >= 0.0f) {
                            marginLayoutParams.leftMargin = (int) (((float) size) * a.f5540c);
                        }
                        if (a.f5541d >= 0.0f) {
                            marginLayoutParams.topMargin = (int) (((float) size2) * a.f5541d);
                        }
                        if (a.f5542e >= 0.0f) {
                            marginLayoutParams.rightMargin = (int) (((float) size) * a.f5542e);
                        }
                        if (a.f5543f >= 0.0f) {
                            marginLayoutParams.bottomMargin = (int) (((float) size2) * a.f5543f);
                        }
                        if (a.f5544g >= 0.0f) {
                            hk.m5793a(marginLayoutParams, (int) (((float) size) * a.f5544g));
                        }
                        if (a.f5545h >= 0.0f) {
                            hk.m5795b(marginLayoutParams, (int) (a.f5545h * ((float) size)));
                        }
                        if (Log.isLoggable("PercentLayout", 3)) {
                            new StringBuilder("after fillMarginLayoutParams: (").append(marginLayoutParams.width).append(", ").append(marginLayoutParams.height).append(")");
                        }
                    } else {
                        a.m5495a(layoutParams, size, size2);
                    }
                }
            }
        }
        super.onMeasure(i, i2);
        if (this.f197a.m5445a()) {
            super.onMeasure(i, i2);
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        dc dcVar = this.f197a;
        int childCount = dcVar.f5484a.getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = dcVar.f5484a.getChildAt(i5);
            LayoutParams layoutParams = childAt.getLayoutParams();
            if (Log.isLoggable("PercentLayout", 3)) {
                new StringBuilder("should restore ").append(childAt).append(" ").append(layoutParams);
            }
            if (layoutParams instanceof de) {
                dd a = ((de) layoutParams).m5519a();
                if (Log.isLoggable("PercentLayout", 3)) {
                    new StringBuilder("using ").append(a);
                }
                if (a != null) {
                    if (layoutParams instanceof MarginLayoutParams) {
                        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) layoutParams;
                        a.m5494a(marginLayoutParams);
                        marginLayoutParams.leftMargin = a.f5547j.leftMargin;
                        marginLayoutParams.topMargin = a.f5547j.topMargin;
                        marginLayoutParams.rightMargin = a.f5547j.rightMargin;
                        marginLayoutParams.bottomMargin = a.f5547j.bottomMargin;
                        hk.m5793a(marginLayoutParams, hk.m5792a(a.f5547j));
                        hk.m5795b(marginLayoutParams, hk.m5794b(a.f5547j));
                    } else {
                        a.m5494a(layoutParams);
                    }
                }
            }
        }
    }

    protected /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        return new df();
    }
}
